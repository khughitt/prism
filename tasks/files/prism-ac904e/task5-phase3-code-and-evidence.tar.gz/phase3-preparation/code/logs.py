"""Incremental byte capture. Full integrity belongs to explicit checkpoints."""
import hashlib
import json
import os
import sys
import time
import phases
from pathlib import Path


def require(ok, message):
    if not ok: raise AssertionError(message)


def save(manifest, state, observer=None):
    temp = manifest.with_suffix('.tmp')
    with phases.measure(observer,'manifest.publish'):
        with temp.open('w') as f:
            f.write(json.dumps(state, indent=2)); f.write('\n')
            with phases.measure(observer,'manifest.flush'):f.flush()
            with phases.measure(observer,'manifest.fsync'):os.fsync(f.fileno())
        temp.replace(manifest)


def start(log, manifest):
    log, manifest = Path(log), Path(manifest)
    stat = log.stat()
    state = {'schema':2, 'log':str(log), 'current':{'dev':stat.st_dev, 'inode':stat.st_ino,
             'offset':stat.st_size, 'generation':1}, 'nextGeneration':2, 'segments':[], 'integrityComplete':False}
    # Exclusive creation preserves the activation's original offset.
    with manifest.open('x') as f:
        f.write(json.dumps(state, indent=2)); f.write('\n'); f.flush(); os.fsync(f.fileno())


def identity(stat): return stat.st_dev, stat.st_ino

def snapshot(stat): return identity(stat) + (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)


class GrowingSource(Exception):
    """A matched prefix must be rechecked after concurrent tail growth."""


class Capture:
    def __init__(self, manifest):
        self.observer = None
        self.manifest = Path(manifest)
        self.state = json.loads(self.manifest.read_text())
        self.log = Path(self.state['log'])
        self.integrity_complete = False
        self.failed = False
        self.source = self.archive = None
        self.metadata = {}
        try:
            self._structure()
            self._archives()
            self.source = self._source(self.state['current'])
            self._stable_prefix(self.source, self.state['current'])
            self._open_archive()
        except BaseException:
            self.close(); raise

    def _structure(self):
        s, held = self.state, self.state['current']
        require(s.get('schema')==2, 'capture requires schema2')
        require(all(type(held[k]) is int and held[k]>=0 for k in ('dev','inode','offset','generation')) and held['generation']>=1, 'invalid cursor generation/offset')
        segments = s['segments']
        generations = [r['generation'] for r in segments]
        require(generations == list(range(1,len(segments)+1)) and
                held['generation'] in (len(segments),len(segments)+1) and
                s['nextGeneration'] == held['generation']+1, 'invalid segment generations')
        for r in segments:
            require(r['path'] == f"segment-{r['generation']:06d}-{r['dev']}-{r['inode']}.raw", 'invalid segment path')
            require(all(type(r[k]) is int and r[k]>=0 for k in ('generation','dev','inode','bytes','startOffset','endOffset')) and
                    r['endOffset'] == r['startOffset']+r['bytes'], 'invalid segment offsets')
            require(type(r['sha256']) is str and len(r['sha256'])==64, 'invalid segment digest')
        if held['generation'] <= len(segments):
            r = segments[held['generation']-1]
            require((r['dev'],r['inode'],r['endOffset']) == (held['dev'],held['inode'],held['offset']), 'cursor does not match saved segment')

    def _path(self, r): return self.manifest.parent/r['path']
    def paths(self): return [self._path(r) for r in self.state['segments']]

    @phases.operation('archive.validate')
    def _archive(self, r):
        p = self._path(r)
        require(p.is_file(), 'archive missing; preserve capture')
        with p.open('rb') as f:
            before=os.fstat(f.fileno())
            require(snapshot(before)==self.metadata.get(p,snapshot(before)), 'archive metadata changed before validation')
            data=f.read(); after=os.fstat(f.fileno())
        require(snapshot(before)==snapshot(after)==snapshot(p.stat()), 'archive changed during validation')
        digest=hashlib.sha256(data)
        require(len(data)==r['bytes'] and digest.hexdigest()==r['sha256'], 'archive integrity failure; preserve capture')
        if r['generation']==self.state['current']['generation']:self.validated_current_hasher=digest
        self.metadata[p] = snapshot(after)

    def _archives(self, service=None):
        # Sealed occurrences are immutable. Service collection between their full hashes;
        # newly sealed generations join this same validation epoch before current is read.
        if not self.state['segments']:return
        index=0
        while True:
            while index < len(self.state['segments'])-1:
                self._archive(self.state['segments'][index]);index+=1
                if service:service(False)
            if service:service(True)
            if index == len(self.state['segments'])-1:break
        if self.state['segments']:self._archive(self.state['segments'][-1])

    def _live_stat(self):
        missing=None
        for attempt in range(8):
            try:
                
                with phases.measure(self.observer,'source.stat'):live=self.log.stat()
                if missing is not None:require(snapshot(self._source_stat(self.source))==missing, 'outgoing changed during absent live path')
                return live
            except FileNotFoundError:
                held=self.state['current'];p=self._locate(held)
                require(p==self.log.with_name(self.log.name+'.1'), 'absent live path without unique outgoing occurrence')
                now=snapshot(self._source_stat(self.source))
                require(now==snapshot(p.stat()) and (missing is None or now==missing), 'outgoing changed during absent live path')
                missing=now
                if attempt==7:raise
                time.sleep(.001)

    @phases.operation('source.locate')
    def _locate(self, held):
        missing=None
        for attempt in range(8):
            matches=[]
            for p in self.log.parent.glob(self.log.name+'*'):
                try:
                    if p.is_file() and identity(p.stat())==(held['dev'],held['inode']):matches.append(p)
                except FileNotFoundError:continue
            if matches:
                require(len(matches)==1, 'saved log inode missing or ambiguous; preserve capture')
                require(matches[0] in (self.log,self.log.with_name(self.log.name+'.1')), 'multiple rotations between polls; preserve capture')
                if missing is not None:require(snapshot(matches[0].stat())==missing, 'held source changed during pathname retry')
                return matches[0]
            # A directory enumeration can straddle rename. Retry only a still-linked,
            # stable held descriptor; a lost/overwritten occurrence never qualifies.
            require(self.source is not None, 'saved log inode missing or ambiguous; preserve capture')
            stat=self._source_stat(self.source);now=snapshot(stat)
            require(identity(stat)==(held['dev'],held['inode']) and stat.st_nlink==1 and (missing is None or now==missing),
                    'saved log inode missing or ambiguous; preserve capture')
            missing=now
            require(attempt<7, 'saved log inode missing or ambiguous; preserve capture')
            time.sleep(.001)

    @phases.operation('source.stat')
    def _source_stat(self, source):return os.fstat(source.fileno())

    def _source(self, held):
        p=self._locate(held); f=p.open('rb')
        try:
            require(identity(os.fstat(f.fileno()))==(held['dev'],held['inode']), 'log rotated during open')
            return f
        except BaseException: f.close(); raise

    @phases.operation('source.prefix')
    def _prefix(self, source, held):
        before=self._source_stat(source)
        require(identity(before)==(held['dev'],held['inode']) and before.st_size>=held['offset'], 'log truncated; preserve capture')
        if held['generation'] <= len(self.state['segments']):
            r=self.state['segments'][held['generation']-1]
            source.seek(r['startOffset']);data=source.read(r['bytes'])
            require(len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256'], 'log prefix changed; preserve capture')
        after=self._source_stat(source)
        if snapshot(before)!=snapshot(after):
            require(identity(after)==identity(before) and after.st_size>before.st_size,
                    'source changed during checkpoint')
            raise GrowingSource('source grew during checkpoint')
        return before

    def _stable_prefix(self, source, held):
        # Retrying a matched prefix is safe; corrupt bytes and non-growth never retry.
        for _ in range(8):
            try:return self._prefix(source,held)
            except GrowingSource:pass
        raise AssertionError('source growth exhausted checkpoint bound')

    def _open_archive(self):
        held=self.state['current'];g=held['generation'];segments=self.state['segments']
        self.hasher=hashlib.sha256()
        if g<=len(segments):
            r=segments[g-1]
            self.hasher=self.validated_current_hasher.copy()
            self.archive=self._path(r).open('ab')
        else:
            r={'path':f"segment-{g:06d}-{held['dev']}-{held['inode']}.raw",'generation':g,'dev':held['dev'],'inode':held['inode'],
               'startOffset':held['offset'],'endOffset':held['offset'],'bytes':0,'sha256':self.hasher.hexdigest()}
            self.archive=self._path(r).open('xb');segments.append(r)
            self.metadata[self._path(r)]=snapshot(os.fstat(self.archive.fileno()))
            save(self.manifest,self.state,self.observer)

    @phases.operation('archive.metadata')
    def _metadata(self):
        for p,expected in self.metadata.items():
            require(p.is_file(), 'archive missing; preserve capture')
            require(snapshot(p.stat())==expected, 'archive integrity metadata changed; preserve capture')
        require(snapshot(os.fstat(self.archive.fileno()))==self.metadata[self._path(self.state['segments'][-1])], 'archive descriptor changed')

    @phases.operation('source.resolve')
    def _append_growth(self, source, held, before, transition, data):
        # An append can publish advanced timestamps before its larger extent is visible.
        # Never accept stabilization alone: require the same append's later growth,
        # then re-read both the prior captured prefix and this pending read interval.
        stamps=(transition.st_mtime_ns,transition.st_ctime_ns)
        require(stamps[0]>before.st_mtime_ns and stamps[1]>before.st_ctime_ns,
                'non-advancing append timestamps')
        for _ in range(8):
            time.sleep(.001)
            observed=self._source_stat(source)
            require(identity(observed)==identity(before) and observed.st_size>=before.st_size
                    and (observed.st_mtime_ns,observed.st_ctime_ns)==stamps,
                    'append transition identity/extent/timestamps changed')
            require(self._locate(held)==self.log and identity(self._live_stat())==identity(before),
                    'rotation during append transition')
            if observed.st_size==before.st_size:continue
            r=self.state['segments'][-1]
            prefix=os.pread(source.fileno(),before.st_size-r['startOffset'],r['startOffset'])
            require(len(prefix)==r['bytes']+len(data) and hashlib.sha256(prefix[:r['bytes']]).hexdigest()==r['sha256']
                    and prefix[r['bytes']:]==data,'append transition prefix/read interval changed')
            final=self._source_stat(source)
            require(identity(final)==identity(before) and final.st_size>=observed.st_size
                    and (final.st_mtime_ns,final.st_ctime_ns)==stamps,
                    'append transition changed during prefix validation')
            require(self._locate(held)==self.log and identity(self._live_stat())==identity(before),
                    'rotation during append transition validation')
            self._metadata()
            return final
        raise AssertionError('append timestamps changed without observed growth')

    def _read_failure(self, reason, source, held, before, after, data):
        # Collector persists this structured exception in its private poll/receipt.
        def stat_fields(st):
            return dict(zip(('dev','inode','size','mtimeNs','ctimeNs'),snapshot(st)))
        try:live=stat_fields(self.log.stat())
        except OSError as error:live={'error':str(error)}
        detail={'reason':str(reason),'generation':held['generation'],'offset':held['offset'],
                'requestedBytes':before.st_size-held['offset'],'readBytes':len(data),
                'before':stat_fields(before),'after':stat_fields(after),
                'currentDescriptor':stat_fields(self._source_stat(source)),'livePath':live}
        raise AssertionError('log changed during read: '+json.dumps(detail,sort_keys=True)) from reason

    def _append(self, source, held):
        before=self._source_stat(source)
        require(identity(before)==(held['dev'],held['inode']) and before.st_size>=held['offset'], 'log truncated; preserve capture')
        self.provisional_tail=None
        archive_before=os.fstat(self.archive.fileno())
        require(snapshot(archive_before)==self.metadata[self._path(self.state['segments'][-1])], 'archive metadata changed before append')
        with phases.measure(self.observer,'source.read'):
            source.seek(held['offset']);data=source.read(before.st_size-held['offset'])
        require(snapshot(archive_before)==snapshot(os.fstat(self.archive.fileno())), 'archive changed during source read')
        after=self._source_stat(source)
        initial_after=after
        try:
            require(len(data)==before.st_size-held['offset'] and identity(before)==identity(after),
                    'read length or source identity mismatch')
            renamed=(before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns
                     and snapshot(before)!=snapshot(after)
                     and self._locate(held)==self.log.with_name(self.log.name+'.1')
                     and identity(self._live_stat())!=identity(after))
            if before.st_size==after.st_size and snapshot(before)!=snapshot(after) and not renamed:
                after=self._append_growth(source,held,before,after,data)
            require(snapshot(before)==snapshot(after) or after.st_size>before.st_size or renamed,
                    'source extent/metadata changed')
        except AssertionError as error:
            self._read_failure(error,source,held,before,initial_after,data)
        if after.st_size>before.st_size:self.provisional_tail=snapshot(after)
        # New bytes remain provisional until a stable full source-prefix checkpoint.
        # Growth never proves the already captured prefix unchanged.
        r=self.state['segments'][-1]
        require(archive_before.st_size==r['bytes'], 'interrupted archive append')
        if data:
            with phases.measure(self.observer,'archive.write'):require(self.archive.write(data)==len(data), 'short archive append')
            with phases.measure(self.observer,'archive.flush'):self.archive.flush()
            with phases.measure(self.observer,'archive.fsync'):os.fsync(self.archive.fileno())
        archive_after=os.fstat(self.archive.fileno())
        require(identity(archive_before)==identity(archive_after) and archive_after.st_size==r['bytes']+len(data), 'archive changed during append')
        self.hasher.update(data);held['offset']+=len(data)
        r.update(bytes=r['bytes']+len(data),endOffset=held['offset'],sha256=self.hasher.hexdigest())
        self.metadata[self._path(r)]=snapshot(archive_after)
        require(snapshot(self._path(r).stat())==snapshot(archive_after), 'archive path changed during append')
        save(self.manifest,self.state,self.observer)
        observed=self._source_stat(source)
        require(identity(observed)==identity(after) and observed.st_size>=after.st_size, 'source truncated during append publication')
        if observed.st_size==after.st_size and snapshot(observed)!=snapshot(after):
            require(observed.st_mtime_ns==after.st_mtime_ns and self._locate(held)==self.log.with_name(self.log.name+'.1')
                    and identity(self._live_stat())!=identity(observed), 'unexplained source metadata during append publication')
        if observed.st_size>before.st_size:self.provisional_tail=snapshot(observed)
        return after if renamed else before

    def poll(self):
        require(not self.failed, 'capture already refused; offline investigation only')
        self.integrity_complete=False
        try:
            self._structure();self._metadata();held=self.state['current'];old=self._locate(held)
            outgoing=snapshot(self._append(self.source,held))
            live=self._live_stat()
            if identity(live)!=(held['dev'],held['inode']):
                old=self._locate(held)
                require(old==self.log.with_name(self.log.name+'.1'), 'rotation ambiguous during poll')
                # A verified rename changes ctime; size/mtime and consumed range must not change.
                relocated=snapshot(self._source_stat(self.source))
                observed=self.provisional_tail
                if observed is not None:
                    require(relocated==snapshot(old.stat()) and observed[:4]==relocated[:4], 'unobserved outgoing growth before seal')
                    # Only the extent observed during the provisional read can be consumed.
                    # The stable, fully consumed snapshot below anchors every later check.
                    consumed=snapshot(self._append(self.source,held))
                    require(consumed==relocated and self.provisional_tail is None and held['offset']==relocated[2], 'outgoing changed while consuming observed tail')
                    outgoing=relocated
                require(relocated==snapshot(old.stat()) and outgoing[:4]==relocated[:4],
                        'outgoing source changed after capture; preserve evidence')
                outgoing=relocated
                # Keep the snapshot tied to consumed bytes, never absorb a later outgoing write.
                require(outgoing[2]==held['offset'] and snapshot(self._source_stat(self.source))==outgoing,
                        'outgoing source changed after capture; preserve evidence')
                require(snapshot(self._prefix(self.source,held))==outgoing,
                        'outgoing source changed during seal validation; preserve evidence')
                self._archive(self.state['segments'][-1])
                self._metadata()
                require(snapshot(self._source_stat(self.source))==snapshot(old.stat())==outgoing,
                        'outgoing source changed during seal validation; preserve evidence')
                outgoing_source=self.source;self.archive.close()
                try:
                    held={'dev':live.st_dev,'inode':live.st_ino,'offset':0,'generation':self.state['nextGeneration']}
                    self.state['current']=held;self.state['nextGeneration']+=1
                    self.source=self._source(held);self._open_archive();self._append(self.source,held)
                    require(snapshot(os.fstat(outgoing_source.fileno()))==snapshot(old.stat())==outgoing and
                            identity(self._live_stat())==identity(live), 'outgoing source changed or second rotation during transition; preserve evidence')
                finally:outgoing_source.close()
            else:
                require(old==self.log and identity(self._live_stat())==(held['dev'],held['inode']), 'rotation during poll')
            return self.paths()
        except BaseException:
            self.failed=True;self.integrity_complete=False;raise

    def checkpoint(self, reason, service=None):
        require(reason in ('ready','rotation','settled','finish'), 'unknown checkpoint reason')
        require(not self.failed, 'capture already refused; offline investigation only')
        self.integrity_complete=False
        try:
            self._structure();self._metadata()
            if reason=='rotation':self._archive(self.state['segments'][-1])
            elif service:self._archives(service)
            else:self._archives()
            held=self.state['current'];p=self._locate(held)
            require(p==self.log, 'rotation pending at checkpoint; poll first')
            before=self._stable_prefix(self.source,held)
            if reason=='finish':
                require(before.st_size==held['offset'], 'uncaptured source tail at finish; preserve evidence')
            require(identity(self._live_stat())==identity(before), 'rotation during checkpoint')
            self._metadata()
            if reason=='finish':
                require(snapshot(self._source_stat(self.source))==snapshot(self._live_stat())==snapshot(before),
                        'source changed at terminal cutoff; preserve evidence')
                self.state['terminalCutoff']={'generation':held['generation'],'dev':held['dev'],'inode':held['inode'],
                    'endOffset':held['offset'],'sourceSize':before.st_size,'sourceMtimeNs':before.st_mtime_ns,
                    'sourceCtimeNs':before.st_ctime_ns,'capturedBytes':sum(r['bytes'] for r in self.state['segments']),
                    'segmentSha256':[r['sha256'] for r in self.state['segments']]}
            self.integrity_complete=reason=='finish'
            self.state['integrityComplete']=False
            self.state['lastCheckpoint']=reason
            save(self.manifest,self.state,self.observer)
            return {'integrityComplete':self.integrity_complete,'generations':len(self.state['segments']),'reason':reason,'terminalCutoff':self.state.get('terminalCutoff')}
        except BaseException:
            self.failed=True;self.integrity_complete=False;raise

    def close(self):
        for f in (self.source,self.archive):
            if f is not None and not f.closed:f.close()


# A standalone collect is deliberately an offline full validation, never a live loop.
def collect(manifest):
    c=Capture(manifest)
    try:
        paths=c.poll();c.checkpoint('ready');return paths
    finally:c.close()

def portable(data,prefixes):
    marker=b'prism-budget ';before=[line.split(marker,1)[1] for line in data.splitlines() if marker in line]
    lines=[]
    for line in data.splitlines(keepends=True):
        header,sep,payload=line.partition(marker)
        for prefix in prefixes:header=header.replace(prefix.encode(),b'<private>')
        lines.append(header+sep+payload)
    result=b''.join(lines);assert [line.split(marker,1)[1] for line in result.splitlines() if marker in line]==before
    assert all(prefix.encode() not in result for prefix in prefixes),'private prefix inside measurement payload; preserve raw and stop before attaching'
    return result


if __name__=='__main__':
    if sys.argv[1]=='start':start(Path(sys.argv[2]),Path(sys.argv[3]))
    else:
        require(sys.argv[1]=='collect','use start LOG MANIFEST or collect MANIFEST')
        print('\n'.join(str(p) for p in collect(Path(sys.argv[2]))))
