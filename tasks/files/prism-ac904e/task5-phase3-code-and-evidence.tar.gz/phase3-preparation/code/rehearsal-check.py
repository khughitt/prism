"""Scaled rehearsal contracts; all host data are synthetic/private."""
import copy, datetime, hashlib, json, os, pathlib, runpy, sys, tempfile
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));import controller as c
os.umask(0o077)
assert (ROOT/'rehearse.py').exists(), 'Task5 prepare/start/verify interfaces are absent'
r=c.module('rehearse',ROOT/'rehearse.py')
checks=[]
def reject(label,fn):
 try:fn()
 except (ValueError,AssertionError):checks.append(label);return
 raise AssertionError('accepted '+label)
def proof_fixture(root):
 run={'runNonce':'fixture-nonce','runDir':str(root),'watchdogWall':1000,'threadId':'thread-fixture','codeSha256':r.inventory(ROOT)}
 rows=[]
 def add(kind,payload,sec):
  rows.append({'timestamp':datetime.datetime.fromtimestamp(sec,datetime.timezone.utc).isoformat(),'type':kind,'payload':payload})
 add('session_meta',{'id':run['threadId'],'cwd':str(root),'originator':'codex-tui','thread_source':'user'},1)
 add('event_msg',{'type':'task_started','turn_id':'first','turn_attribution':{'turn_trigger':'user'}},10)
 add('response_item',{'type':'custom_tool_call','call_id':'start-id','input':f'rehearse.py start {root} --nonce fixture-nonce'},11)
 add('response_item',{'type':'custom_tool_call_output','call_id':'start-id','output':json.dumps({'runDir':str(root),'runNonce':'fixture-nonce','started':True})},12)
 add('event_msg',{'type':'task_complete','turn_id':'first'},13)
 add('event_msg',{'type':'task_started','turn_id':'next','turn_attribution':{'turn_trigger':'user'}},1001)
 add('event_msg',{'type':'user_message','message':'The watchdog has passed.'},1002)
 add('response_item',{'type':'message','role':'user','content':[{'type':'input_text','text':'The watchdog has passed.'}]},1002)
 add('event_msg',{'type':'item_completed','turn_id':'next','item':{'type':'UserMessage'}},1002)
 add('response_item',{'type':'custom_tool_call','call_id':'read-id','input':f'python3 {ROOT}/rehearse.py read-evidence {root} --receipt {root}/receipt.json --rollout {root}/rollout.jsonl --nonce fixture-nonce'},1003)
 (root/'receipt.json').write_text(json.dumps({'syntheticFixture':True,'integrityComplete':True})+'\n')
 (root/'rollout.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
 ack=r.evidence_read(run,root/'receipt.json',root/'rollout.jsonl','fixture-nonce')
 # Representative actual root functions.exec envelope; acknowledgement is from real fixture reads.
 output=[{'type':'input_text','text':'Script completed\nWall time 0.2 seconds\nOutput:\n'},
  {'type':'input_text','text':json.dumps({'chunk_id':'fixture','wall_time_seconds':.2,'exit_code':0,'original_token_count':200,'output':json.dumps(ack)+'\n'})}]
 add('response_item',{'type':'custom_tool_call_output','call_id':'read-id','output':output},1004)
 return run,rows
with tempfile.TemporaryDirectory() as temp:
 root=pathlib.Path(temp);run,rows=proof_fixture(root);rollout=root/'rollout.jsonl'
 def prove(changes=None):
  data=copy.deepcopy(rows)
  if changes:changes(data)
  rollout.write_text(''.join(json.dumps(x)+'\n' for x in data))
  proof=r.turn_proof(run,rollout,'first','next',pathlib.Path.home()/'.agents/bin/session-episodes')
  return r.verify_turn(run,proof)
 assert prove()['distinctHumanTurn'];checks.append('task_started before serialized human associates correctly')
 def result_change(data,**changes):
  envelope=json.loads(data[10]['payload']['output'][1]['text']);envelope.update(changes)
  data[10]['payload']['output'][1]['text']=json.dumps(envelope)
 def ack_change(data,change):
  envelope=json.loads(data[10]['payload']['output'][1]['text']);ack=json.loads(envelope['output']);change(ack);result_change(data,output=json.dumps(ack))
 for label,change in [
  ('completed command permission denied',lambda x:result_change(x,exit_code=1,output='Permission denied')),
  ('error-only successful exit',lambda x:result_change(x,output='Permission denied')),
  ('success prose without acknowledgement',lambda x:result_change(x,output='read receipts and rollout')),
  ('still-running nested command',lambda x:result_change(x,exit_code=None,session_id=42)),
  ('session id with success ack',lambda x:result_change(x,session_id=42)),
  ('error property with success ack',lambda x:result_change(x,error='Permission denied')),
  ('yielded exec framing',lambda x:x[10]['payload']['output'][0].update(text='Script running with cell ID 1')),
  ('wrong acknowledgement nonce',lambda x:ack_change(x,lambda a:a.update(runNonce='wrong'))),
  ('wrong acknowledgement run',lambda x:ack_change(x,lambda a:a.update(runDir='/other'))),
  ('wrong acknowledgement thread',lambda x:ack_change(x,lambda a:a.update(threadId='other'))),
  ('wrong acknowledgement code',lambda x:ack_change(x,lambda a:a.update(codeDigest='0'*64))),
  ('wrong receipt path',lambda x:ack_change(x,lambda a:a['receipt'].update(path='/other'))),
  ('wrong receipt digest',lambda x:ack_change(x,lambda a:a['receipt'].update(sha256='0'*64))),
  ('wrong rollout path',lambda x:ack_change(x,lambda a:a['rollout'].update(path='/other'))),
  ('wrong rollout prefix digest',lambda x:ack_change(x,lambda a:a['rollout'].update(prefixSha256='0'*64))),
  ('prefix excludes evidence-read call',lambda x:ack_change(x,lambda a:a['rollout'].update(prefixBytes=1))),
  ('prefix includes its own result',lambda x:ack_change(x,lambda a:a['rollout'].update(prefixBytes=10**9))),
  ('wrong read call nonce',lambda x:x[9]['payload'].update(input=x[9]['payload']['input'].replace('fixture-nonce','other'))),
  ('wrong read result call id',lambda x:x[10]['payload'].update(call_id='other'))]:reject(label,lambda:prove(change))
 assert prove(lambda x:x.append({'timestamp':'1970-01-01T00:16:45+00:00','type':'event_msg','payload':{'type':'task_complete','turn_id':'next'}}))['distinctHumanTurn']
 checks.append('later rollout growth preserves actual read prefix')
 receipt_bytes=(root/'receipt.json').read_bytes();(root/'receipt.json').write_bytes(receipt_bytes+b' ')
 reject('receipt changed after actual read',lambda:prove());(root/'receipt.json').write_bytes(receipt_bytes)
 for missing in (root/'receipt.json',rollout):
  saved=missing.read_bytes();missing.unlink()
  try:r.evidence_read(run,root/'receipt.json',rollout,'fixture-nonce')
  except FileNotFoundError:checks.append('actual unreadable '+missing.name+' emits no ack')
  else:raise AssertionError('acknowledged absent evidence')
  missing.write_bytes(saved)
 reject('read API wrong nonce',lambda:r.evidence_read(run,root/'receipt.json',rollout,'other'))

 for label,change in [
  ('failed evidence read Permission denied',lambda x:x[10]['payload'].update(output=json.dumps({'exit_code':1,'output':'cat: receipt.json: Permission denied; cat: rollout: Permission denied'}))),
  ('same turn with parks',lambda x:x[5]['payload'].update(turn_id='first')),
  ('missing first task_complete',lambda x:x[4]['payload'].update(type='other')),
  ('injected user content',lambda x:x[7]['payload']['content'][0].update(text='# AGENTS.md injected')),
  ('child-agent trigger',lambda x:x[5]['payload']['turn_attribution'].update(turn_trigger='agent')),
  ('missing UserMessage completed',lambda x:x[8]['payload']['item'].update(type='Tool')),
  ('wrong-turn UserMessage completed',lambda x:x[8]['payload'].update(turn_id='first')),
  ('pre-watchdog reply',lambda x:x[7].update(timestamp='1970-01-01T00:16:39+00:00')),
  ('wrong run nonce',lambda x:x[2]['payload'].update(input=f'rehearse.py start {root} --nonce other')),
  ('failed start result',lambda x:x[3]['payload'].update(output=json.dumps({'runDir':str(root),'runNonce':'fixture-nonce','started':False}))),
  ('mismatched tool result',lambda x:x[3]['payload'].update(call_id='other')),
  ('aborted first turn',lambda x:x[4]['payload'].update(type='turn_aborted')),
  ('wrong session',lambda x:x[0]['payload'].update(id='other'))]:reject(label,lambda:prove(change))
 # verify_turn must independently reject a once-valid proof when the read result fails.
 prove();valid=r.turn_proof(run,rollout,'first','next',pathlib.Path.home()/'.agents/bin/session-episodes')
 failed=copy.deepcopy(rows);result_change(failed,exit_code=1,output='Permission denied')
 rollout.write_text(''.join(json.dumps(x)+'\n' for x in failed))
 reject('verify_turn rechecks failed completed read',lambda:r.verify_turn(run,valid))
 reject('session-only provenance',lambda:r.verify_turn(run,{'threadId':run['threadId']}))
 rollout.write_text(''.join(json.dumps(x)+'\n' for x in rows));p=r.turn_proof(run,rollout,'first','next',pathlib.Path.home()/'.agents/bin/session-episodes');p['events']['startCall']['sha256']='0'*64
 reject('altered event reference',lambda:r.verify_turn(run,p))
 # Controlled monotonic receipts: no real wait is used to claim lifetime.
 good={'complete':True,'started':100.,'ended':2500.,'deadline':2800.,'exitReason':'complete','bytes':2400*1117592,'blocks':24000,'starts':1}
 r.production_contract(good,2400,1117592)
 for label,change in [('premature SIGTERM',{'complete':False,'exitReason':'signal'}),('short lifetime',{'ended':2499}),('deadline',{'ended':2800}),('restarted producer',{'starts':2}),('silently reduced byte rate',{'bytes':2400*1117592-1})]:
  bad=good|change;reject(label,lambda:r.production_contract(bad,2400,1117592))
 polls=[{'start':1.,'end':1.01,'previousIntervalPersistence':None},{'start':1.1,'end':1.11,'previousIntervalPersistence':{'start':1.01,'end':1.02,'persistedObservationStart':1.}}]
 receipt={'lastIntervalPersistence':{'start':1.11,'end':1.12,'persistedObservationStart':1.1}}
 assert r.poll_contract(polls,receipt,.2)['persistenceCount']==2
 reject('missing persistence',lambda:r.poll_contract(polls,{},.2))
 reject('gap breach',lambda:r.poll_contract(polls,receipt,.05))
 reject('work plus persistence breach',lambda:r.poll_contract(polls,{'lastIntervalPersistence':{'start':1.11,'end':1.4,'persistedObservationStart':1.1}},.2))
 # Each payload is independently expected, including repeated exact A bytes.
 for n in range(4):assert r.block('n',n,2048).startswith(f'rehearsal n {n} 2048\n'.encode()) and len(r.block('n',n,2048))==2048
 data=b''.join(r.block('n',n,2048) for n in range(4));path=root/'blocks';path.write_bytes(data)
 assert r.check_blocks(path,'n',2048)==4
 path.write_bytes(data[:2048]+data[:2048]+data[4096:]);reject('duplicate id',lambda:r.check_blocks(path,'n',2048))
 path.write_bytes(data[:2048]+data[4096:]);reject('missing id',lambda:r.check_blocks(path,'n',2048))
with tempfile.TemporaryDirectory() as temp:
 root=pathlib.Path(temp)/'prepared';r.prepare(root,1)
 run=c.load(root/'run.json');original=(root/'run.json').read_bytes()
 c.atomic(root/'run.json',run|{'smoke':False})
 reject('scaled run promoted to lifetime',lambda:r.verify_inputs(root))
 (root/'run.json').write_bytes(original)
 artifact=root/'build/baseline/plugin/panel.lua'
 if not artifact.exists():artifact=next(p for p in (root/'build/baseline/plugin').rglob('*') if p.is_file())
 artifact.write_bytes(artifact.read_bytes()+b'\nchanged\n')
 reject('generated plugin changed before start',lambda:r.verify_inputs(root))
print('PASS scaled contracts',len(checks),json.dumps(checks))
