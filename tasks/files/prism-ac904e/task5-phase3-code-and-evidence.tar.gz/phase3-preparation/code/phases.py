"""Bounded operation summaries; nested operation durations are not additive."""
import contextlib,functools,math,time

NAMES=frozenset(('source.stat','source.locate','source.read','source.prefix','source.resolve',
 'archive.metadata','archive.validate','archive.write','archive.flush','archive.fsync',
 'manifest.publish','manifest.flush','manifest.fsync','heartbeat.publish','heartbeat.flush',
 'heartbeat.fsync','poll.write','poll.flush','poll.fsync'))
MAX_BYTES=16384

def require(ok,message):
 if not ok:raise ValueError('phase evidence: '+message)

class Recorder:
 def __init__(self):self.operations={}
 @contextlib.contextmanager
 def measure(self,name):
  require(name in NAMES,'unknown operation');start=time.monotonic();cpu=time.thread_time();failed=True
  try:
   yield
   failed=False
  finally:
   end=time.monotonic();used=time.thread_time()-cpu;elapsed=end-start
   op=self.operations.setdefault(name,{'name':name,'count':0,'totalSeconds':0.,'totalThreadCpuSeconds':0.,'failures':0,'max':None})
   op['count']+=1;op['totalSeconds']+=elapsed;op['totalThreadCpuSeconds']+=used;op['failures']+=int(failed)
   if op['max'] is None or elapsed>op['max']['end']-op['max']['start']:
    op['max']={'start':start,'end':end,'threadCpuSeconds':used,'failed':failed}
 def snapshot(self):return {'schema':1,'operations':[dict(op,max=dict(op['max'])) for _,op in sorted(self.operations.items())]}

def measure(observer,name):return observer.measure(name) if observer is not None else contextlib.nullcontext()

def operation(name):
 def decorate(fn):
  @functools.wraps(fn)
  def wrapped(self,*args,**kwargs):
   with measure(self.observer,name):return fn(self,*args,**kwargs)
  return wrapped
 return decorate

def number(value):
 require(type(value) in (int,float) and math.isfinite(value) and value>=0,'invalid finite number')
 return value

def validate(row):
 """Validate one summary against its containing actual observation interval."""
 import json
 require(type(row) is dict,'invalid observation')
 start=number(row['start']);end=number(row['end']);require(end>=start,'reversed observation')
 require(type(row['runId']) is str and bool(row['runId']) and type(row['clockOrigin']) is str and bool(row['clockOrigin']),'identity')
 require(row.get('error') is None or type(row['error']) is str,'error type')
 data=row['phases'];require(type(data) is dict and set(data)=={'schema','operations'} and type(data['schema']) is int and data['schema']==1,'schema')
 ops=data['operations'];require(type(ops) is list and len(ops)<=len(NAMES),'operation bound')
 require(len(json.dumps(data))<=MAX_BYTES,'serialized bound');seen=set()
 for op in ops:
  require(type(op) is dict and set(op)=={'name','count','totalSeconds','totalThreadCpuSeconds','failures','max'},'operation shape')
  name=op['name'];require(type(name) is str and name in NAMES and name not in seen,'unknown/duplicate operation');seen.add(name)
  require(type(op['count']) is int and 0<op['count']<=2**53 and type(op['failures']) is int and 0<=op['failures']<=op['count'],'counts')
  total=number(op['totalSeconds']);cpu=number(op['totalThreadCpuSeconds']);m=op['max']
  require(type(m) is dict and set(m)=={'start','end','threadCpuSeconds','failed'},'maximum shape')
  a=number(m['start']);b=number(m['end']);used=number(m['threadCpuSeconds'])
  require(start<=a<=b<=end and b-a<=total+1e-9 and total<=end-start+1e-6,'endpoints/total')
  # Adjacent clock samples can differ by sub-microsecond call overhead.
  require(used<=b-a+0.0001 and used<=cpu+1e-9 and cpu<=total+op['count']*0.0001,'CPU bounds')
  require(type(m['failed']) is bool and (not m['failed'] or op['failures']>0) and (op['failures']!=op['count'] or m['failed']),'failure status')
  require(total<=(b-a)*op['count']+1e-6,'maximum below mean')
 return True

def validate_capture(rows,receipt):
 """New-source evidence only; callers must use old frozen code for old captures."""
 require(receipt.get('phaseSchema')==1 and type(receipt.get('phaseSchema')) is int,'missing phase contract')
 require(bool(rows),'missing collection rows')
 seen=set();heartbeats=[];persists=[]
 for row in rows:
  validate(row);require(all(not op['name'].startswith(('poll.','heartbeat.')) for op in row['phases']['operations']),'collection operation scope');key=(row['runId'],row['clockOrigin'],row['start']);require(key not in seen,'duplicate collection');seen.add(key)
  require((row['runId'],row['clockOrigin'])==(receipt['runId'],receipt['clockOrigin']),'receipt identity')
  if row.get('previousIntervalPersistence') is not None:persists.append(row['previousIntervalPersistence'])
  if row.get('previousHeartbeat') is not None:
   h=row['previousHeartbeat'];require(number(h['end'])<=row['start'],'heartbeat outside carrier');heartbeats.append(h)
 if receipt.get('lastIntervalPersistence') is not None:persists.append(receipt['lastIntervalPersistence'])
 if receipt.get('lastHeartbeat') is not None:heartbeats.append(receipt['lastHeartbeat'])
 require(len(persists)==len(rows),'persistence coverage')
 for row,p in zip(rows,persists):
  validate(p);require(all(op['name'].startswith('poll.') for op in p['phases']['operations']),'persistence operation scope');require(p['observation']=='persistence' and (p['runId'],p['clockOrigin'],p['persistedObservationStart'],p['start'])==(row['runId'],row['clockOrigin'],row['start'],row['end']),'persistence linkage')
 count=receipt.get('heartbeatCount');require(type(count) is int and 0<count<=2**53 and len(heartbeats)==count,'heartbeat coverage')
 require([h.get('sequence') for h in heartbeats]==list(range(1,count+1)) and all(type(h.get('sequence')) is int for h in heartbeats),'heartbeat sequence')
 seen_h=set();anchors=set();by_start={row['start']:p for row,p in zip(rows,persists)}
 for h in heartbeats:
  validate(h);key=(h['runId'],h['clockOrigin'],h['start']);require(key not in seen_h,'duplicate heartbeat');seen_h.add(key)
  require((h['runId'],h['clockOrigin'])==(receipt['runId'],receipt['clockOrigin']) and h['observation']=='heartbeat' and h['bytes']==0 and h['checkpoint'] is False,'heartbeat identity')
  anchor=h['precedingPollStart'];require(anchor not in anchors,'duplicate heartbeat anchor');anchors.add(anchor)
  if anchor is None:require(h['startup'] is True and h['end']<=rows[0]['start'],'startup linkage')
  else:
   number(anchor);require(h['startup'] is False and anchor in by_start and by_start[anchor]['end']<=h['start'],'heartbeat linkage')
  require(all(op['name'].startswith('heartbeat.') for op in h['phases']['operations']),'heartbeat operation scope')
 return {'collection':len(rows),'persistence':len(persists),'heartbeat':len(heartbeats)}
