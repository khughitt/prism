"""Paced actual generated fake-host, independent writer, named collector. Never live."""
import os,sys,time,json,subprocess,selectors,signal,hashlib,math
from pathlib import Path
import controller as c, capture as cap, phases
ROOT=Path(__file__).parent
OUT=Path(sys.argv[1]);MODEL=Path(sys.argv[2]);CLI=sys.argv[3];mode=sys.argv[4];variant=sys.argv[5] if len(sys.argv)>5 else 'baseline'
os.umask(0o077);OUT.mkdir(mode=0o700)
# Import helper contracts; the module's main full lifecycle suite does not execute.
m=c.module('integration',ROOT/'controller-integration.py')
full=mode!='pilot';count=5 if full else 1
built=m.build('stage2','1',count,count);identity=c.load(built/variant/'identity.json')
root=OUT/'run';root.mkdir();log=root/'host.log';log.write_bytes(b'ignored startup history\n')
nonce=identity['activationNonce'];socket='prism-budget-capture-'+nonce
guard=float(os.environ.get('GUARD_BPS','1425679'));guard_T=1024*1024/guard
cfg={'schema':2,'environment':'synthetic','runId':identity['runId'],'clockOrigin':identity['clockOrigin'],'socket':socket,'deadlineSeconds':2700,'pollSeconds':min(.1,guard_T/4),'maxGapSeconds':min(10,guard_T/2),'log':str(log)}
for name in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[name]=str(root/(name+'.json'))
c.immutable(root/'RUN.json',cfg)
c.immutable(root/'source-inventory.json',{str(p.relative_to(ROOT)):c.digest(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
def default_snapshot():
 p=Path(os.getenv('TMUX_TMPDIR','/tmp'))/f'tmux-{os.getuid()}'/'default'
 if not p.exists():return None
 st=p.stat();return {'dev':st.st_dev,'inode':st.st_ino,'mtime':st.st_mtime_ns,'ctime':st.st_ctime_ns,'sessions':subprocess.check_output(['tmux','-L','default','list-sessions'],text=True)}
default=default_snapshot();c.immutable(root/'default-before.json',default)
host=m.Host(root,root/'RUN.json');now=[time.monotonic()];producer=None;producer_stderr=None;spans=[];ticks=[];produced=bytearray();rotations=[];rawfile=None
session={'sessionId':'paced-'+nonce,'runId':identity['runId'],'environment':'fake-host','clockOrigin':identity['clockOrigin'],'identity':identity,'steps':{'pre':1,'post':1,'recovery':1,'finish':1},'snapshotBundle':str(root/'bundle.json')}
obj=c.Controller(root,session,host,lambda:now[0])
def stop(sig,frame):raise SystemExit(128+sig)
old={s:signal.signal(s,stop) for s in (signal.SIGTERM,signal.SIGINT)}
try:
 obj.prepare(m.permit());hb=m.waitfile(root/'heartbeat.json',lambda r:r.get('collectorStarted') is not None);obj.collector_started(hb);obj.activate(m.permit())
 argv=['lua',str(ROOT/'controller-producer.lua'),str(built),str(MODEL),str(ROOT/'frozen-task2/test_encode.lua'),CLI,'handoff-'+('full' if full else 'pilot'),variant,str(root/'producer')]
 producer_stderr=(root/'producer-stderr.log').open('xb')
 producer=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=producer_stderr,env=os.environ|{'PACED':'1','FIXTURE_START':str(time.monotonic())},bufsize=0)
 producer_id=cap.process(producer.pid);c.immutable(root/'producer-identity.json',{'producer':producer_id,'writer':cap.process(os.getpid()),'argv':argv})
 sel=selectors.DefaultSelector();sel.register(producer.stdout,selectors.EVENT_READ)
 rawfile=(root/'writer-exact.raw').open('xb');spanfile=(root/'writer-spans.jsonl').open('x');tickfile=(root/'scheduler.jsonl').open('x')
 start=time.monotonic();next_tick=start;next_floor=start;buffer=b'';sequence=0;complete=False;limit=180;floor=max(4*1024*1024/60,float(os.environ.get('TARGET_BPS','0')))
 def write(raw,kind):
  if not raw:return
  # One .1 backup; rotate only before an atomic bounded host flush batch.
  if log.stat().st_size+len(raw)>1024*1024:
   began=time.monotonic();log.replace(log.with_name('host.log.1'));log.write_bytes(b'');rotations.append({'start':began,'end':time.monotonic(),'offset':len(produced)})
  began=time.monotonic()
  with log.open('ab',buffering=0) as f:
   assert f.write(raw)==len(raw);os.fsync(f.fileno())
  ended=time.monotonic();rawfile.write(raw);rawfile.flush();produced.extend(raw)
  row={'start':began,'end':ended,'bytes':len(raw),'kind':kind,'sha256':c.digest(raw),'endOffset':len(produced)}
  spans.append(row);spanfile.write(json.dumps(row)+'\n');spanfile.flush()
 while time.monotonic()-start<limit:
  at=time.monotonic()
  if at>=next_tick and producer.poll() is None:
   try:producer.stdin.write((str(at)+'\n').encode())
   except BrokenPipeError:pass
   ticks.append(at);tickfile.write(json.dumps({'timestamp':at})+'\n');tickfile.flush();next_tick=at+.016
  for key,mask in sel.select(max(0,min(.005,next_tick-time.monotonic()))):
   data=os.read(key.fd,65536)
   if data:
    buffer+=data
    # Preserve producer's actual batched flushes and each byte; never rescale payload time.
    if b'\n' in buffer:
     cut=buffer.rfind(b'\n')+1;write(buffer[:cut],'probe');buffer=buffer[cut:]
   else:sel.unregister(key.fileobj);complete=True
  # Fill only a trailing one-second source deficit after immediate native output.
  # Future native bursts are never delayed; any resulting higher total peak is reported.
  if at>=next_floor and producer.poll() is None:
   recent=sum(x['bytes'] for x in spans if x['start']>=at-1)
   deficit=max(0,int(floor)-recent);fill=min(int(floor*.1),deficit)
   if fill:write(b'.'*max(0,fill-1)+b'\n','floor')
   next_floor=at+.1
  if mode=='stop' and at-start>3:
   obj.control('stop');producer.terminate();break
  if complete and producer.poll() is not None:break
 else:raise AssertionError('paced producer deadline')
 producer.wait(timeout=5)
 if mode!='stop':assert producer.returncode==0,(producer.returncode,(root/'producer-stderr.log').read_text())
 if buffer:write(buffer,'partial')
 rawfile.close();rawfile=None;spanfile.close();tickfile.close();sel.close()
 runtime=time.monotonic()-start
 if mode=='stop':
  receipt=m.waitfile(root/'receipt.json',lambda r:r.get('exitReason')!='starting');assert receipt['integrityComplete'] is False
 else:
  meta=c.load(root/'producer-meta.json');b=m.bundle(meta['initialModel']);c.immutable(root/'bundle.json',b)
  rows=c.analyze.read_rotated([root/'producer-initial.log'])
  # Fake controller timestamps are explicitly bound to this producer's own card/reply times.
  now[0]=hb['collectorStarted']+.001
  manifest=c.action_manifest(identity,b['saved'],pilot=not full)
  obj.issue_initial(rows[0],b['saved'],manifest,10)
  obj.invoke('checkpoint-authorize',m.permit());obj.control('ready');m.waitfile(root/'heartbeat.json',lambda x:x['lastSequence']==obj.state['sequence'])
  now[0]=meta['initialReply'];obj.owner_complete('paced-actual-reply')
  normal,context=c.inspect_run(root);obj.checked(normal);assert normal['collectionComplete'],normal['certificates']
  obj.finish(m.permit(),normal);receipt=m.waitfile(root/'receipt.json',lambda x:x.get('wrapperEnded'))
  end=time.monotonic()+3
  while any(cap.same_process(x) for x in receipt['processes'].values()) and time.monotonic()<end:time.sleep(.01)
  now[0]=max(time.monotonic(),now[0]+.01);obj.exited(receipt,cap.same_process);obj.restore(m.permit())
  events,audit=c.read_capture(root/'manifest.json',receipt)
  raw=b''.join((root/r['path']).read_bytes() for r in c.load(root/'manifest.json')['segments'])
  assert raw==produced and audit['complete'] and audit['budgetErrors']==0
  marker=b'prism-budget '
  assert [line.split(marker,1)[1] for line in raw.splitlines() if marker in line]==[line.split(marker,1)[1] for line in (root/'producer-tail.log').read_bytes().splitlines() if marker in line]
  assert sorted(e['recordId'] for e in events)==list(range(1,len(events)+1))
  c.immutable(root/'context.json',context);c.immutable(root/'normalized.json',normal);c.immutable(root/'audit.json',audit)
 polls=[json.loads(line) for line in (root/'polls.json').read_text().splitlines()]
 if mode!='stop':
  phases.validate_capture(polls,receipt)
  c.immutable(root/'overlap.json',c.analyze.overlap_report(normal,polls+[receipt['lastIntervalPersistence']]+([receipt['lastHeartbeat']] if receipt['lastHeartbeat'] else [])))
 # Prospective 1-second peak and complete-workload mean, never offline Lua replay speed.
 peak=max(sum(x['bytes'] for x in spans if s['start']<=x['start']<s['start']+1) for s in spans)
 native=[x for x in spans if x['kind']=='probe'];native_peak=max(sum(x['bytes'] for x in native if s['start']<=x['start']<s['start']+1) for s in native)
 rate=max(4*1024*1024/60,peak);T=1024*1024/rate;gaps=[b['start']-a['start'] for a,b in zip(polls,polls[1:])]
 result={'mode':mode,'variant':variant,'runtimeSeconds':runtime,'bytes':len(produced),'sha256':c.digest(produced),'workloadCount':count,'framePeriodSeconds':.016,'ticks':len(ticks),'maxFrameGapSeconds':max((b-a for a,b in zip(ticks,ticks[1:])),default=0),'meanFrameGapSeconds':(ticks[-1]-ticks[0])/max(1,len(ticks)-1),'writerSynchronization':'none','rateWindowSeconds':1,'peakBytesPerSecond':peak,'nativeWorkloadPeakBytesPerSecond':native_peak,'ambientPaddingBytes':sum(x['bytes'] for x in spans if x['kind']=='floor'),'meanBytesPerSecond':len(produced)/runtime,'floorBytesPerSecond':floor,'paddingPolicy':'trailing1s source deficit after native dispatch; at most floor*0.1 per 100ms','guardBytesPerSecond':guard,'TSeconds':T,'requiredPollSeconds':min(2,T/4),'allowedGapSeconds':min(10,T/2),'configuredPollSeconds':cfg['pollSeconds'],'configuredGapSeconds':cfg['maxGapSeconds'],'maxPollGapSeconds':max(gaps,default=0),'maxCheckpointSeconds':max((p['end']-p['start'] for p in polls if p['checkpoint']),default=0),'rotations':rotations,'receipt':receipt,'limits':'actual generated fake host, synthetic target durations and fake controller host actions; no Noctalia/live throughput or performance acceptance'}
 c.immutable(root/'proof.json',result)
 assert cfg['pollSeconds']<=result['requiredPollSeconds'] and cfg['maxGapSeconds']<=result['allowedGapSeconds'] and max(gaps,default=0)<=result['allowedGapSeconds']
 assert default_snapshot()==default
 print('PASS independent',mode,variant,json.dumps({k:result[k] for k in ['runtimeSeconds','bytes','peakBytesPerSecond','TSeconds','maxPollGapSeconds','maxCheckpointSeconds']}))
finally:
 for s in old:signal.signal(s,signal.SIG_IGN)
 if rawfile:rawfile.close()
 if producer:
  if producer.poll() is None:producer.terminate()
  try:producer.wait(timeout=5)
  except subprocess.TimeoutExpired:producer.kill();producer.wait(timeout=5)
  for f in (producer.stdin,producer.stdout):f.close()
 if producer_stderr:producer_stderr.close()
 if host.child:
  subprocess.run(['tmux','-L',socket,'kill-server'],capture_output=True,timeout=3)
  host.child.communicate(timeout=8)
  for f in (host.child.stdout,host.child.stderr):f.close()
 ids=c.load(root/'identities.json') if (root/'identities.json').exists() else {}
 end=time.monotonic()+3
 while any(cap.same_process(x) for x in ids.values()) and time.monotonic()<end:time.sleep(.01)
 remaining={k:v for k,v in ids.items() if cap.same_process(v)}
 c.immutable(root/'cleanup.json',{'processes':ids,'remaining':remaining,'producerReaped':producer is None or producer.poll() is not None,'defaultServerUnchanged':default_snapshot()==default})
 for s,h in old.items():signal.signal(s,h)
 assert not remaining
