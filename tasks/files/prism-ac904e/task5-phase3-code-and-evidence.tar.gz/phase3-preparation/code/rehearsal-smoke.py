"""Seconds-long exact-wrapper lifecycle checks; no live desktop or application state."""
import json,os,signal,subprocess,sys,time
from pathlib import Path
import capture as cap,controller as c,rehearse as r
os.umask(0o077)
root=Path(sys.argv[1]).resolve();mode=sys.argv[2];duration=3 if mode=='fullburst' else 2
r.prepare(root,duration,mode in ('native','native-emergency'));cfg=c.load(root/'collector.json');ids={};result=None
p=Path(os.getenv('TMUX_TMPDIR','/tmp'))/f'tmux-{os.getuid()}'/'default'
def default():
 if not p.exists():return None
 st=p.stat();return [st.st_dev,st.st_ino,st.st_mtime_ns,st.st_ctime_ns,subprocess.check_output(['tmux','-L','default','list-sessions'],text=True)]
before=default();c.immutable(root/'default-before.json',before)
def wait(predicate,seconds=4):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  if predicate():return
  time.sleep(.02)
 raise AssertionError('bounded smoke condition failed')
try:
 r.start(root,c.load(root/'run.json')['runNonce'])
 wait(lambda:(root/'producer-start.json').exists(),2)
 ids=c.load(root/'processes.json');assert 'producer' in ids,'wrapper does not own producer'
 if mode=='deadline':
  binding=c.load(root/'start.json');binding['watchdogMonotonic']=time.monotonic()+.2;c.atomic(root/'start.json',binding)
 if mode in ('term','int','hup'):os.kill(ids['wrapper']['pid'],{'term':signal.SIGTERM,'int':signal.SIGINT,'hup':signal.SIGHUP}[mode])
 if mode=='native-emergency':wait(lambda:(root/'native-identity.json').exists(),4)
 if mode in ('emergency','native-emergency'):cap.tmux(cfg,'kill-server',check=False)
 if mode=='producer-term':os.kill(ids['producer']['pid'],signal.SIGTERM)
 wait(lambda:(root/'receipt.json').exists() and 'wrapperEnded' in c.load(root/'receipt.json'),120 if mode=='native' else 25)
 receipt=c.load(root/'receipt.json');wait(lambda:all(not cap.same_process(x) for x in receipt['processes'].values()))
 r.phases.validate_capture([json.loads(line) for line in (root/'polls.jsonl').read_text().splitlines()],receipt)
 if mode in ('normal','fullburst','native'):
  result=r.verify_capture(root);assert result['blocks']>=20 and len(c.load(root/'manifest.json')['segments'])>=3
 else:
  assert receipt['integrityComplete'] is False,receipt
  result={'incomplete':True,'exitReason':receipt['exitReason'],'processesGone':True}
 assert before==default(),'default tmux changed'
 c.immutable(root/'smoke-result.json',result);print('PASS',mode,json.dumps({k:v for k,v in result.items() if k!='overlap'}))
finally:
 cap.tmux(cfg,'kill-server',check=False)
 if (root/'processes.json').exists():ids=c.load(root/'processes.json')
 end=time.monotonic()+5
 while any(cap.same_process(x) for x in ids.values()) and time.monotonic()<end:time.sleep(.02)
 remaining={k:v for k,v in ids.items() if cap.same_process(v)}
 c.immutable(root/'smoke-cleanup.json',{'processes':ids,'remaining':remaining,'defaultServerUnchanged':default()==before})
 assert not remaining,remaining
