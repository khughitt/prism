"""Real-file race schedules; injections select an interleaving, never replace file data."""
import importlib.util,os,tempfile,sys,json,threading,types,time
from unittest.mock import patch
from pathlib import Path
code=Path(os.environ.get('BROAD_CODE',Path(__file__).parent))
s=importlib.util.spec_from_file_location('logs',code/'logs.py');logs=importlib.util.module_from_spec(s);s.loader.exec_module(logs)
class AfterRead:
 def __init__(self,file,action):self.file=file;self.action=action
 def __getattr__(self,name):return getattr(self.file,name)
 def read(self,*args):
  data=self.file.read(*args)
  if self.action:action,self.action=self.action,None;action()
  return data

def case(name):
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);log=root/'host.log';log.write_bytes(b'');manifest=root/'manifest.json';logs.start(log,manifest);c=logs.Capture(manifest)
  def append(data):
   with log.open('ab',buffering=0) as f:f.write(data)
  try:
   append(b'abc\n');c.poll()
   if name.startswith('finish'):
    original=c._archives
    def late():
     original()
     if name=='finish-mutation':log.write_bytes(b'xyz\n')
     else:append(b'exceeded its CPU budget\n' if name=='finish-error' else b'D\n')
    c._archives=late
    try:r=c.checkpoint('finish')
    except AssertionError:pass
    else:
     assert not r['integrityComplete'] or c.state['current']['offset']==log.stat().st_size,'finish certified uncaptured suffix'
     assert name!='finish-mutation','finish certified mutated prefix'
   elif name=='observed-growth-rotation':
    append(b'D')
    def grow_rotate():append(b'observed tail\n');log.rename(root/'host.log.1');log.write_bytes(b'new\n')
    c.source=AfterRead(c.source,grow_rotate);c.poll()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDobserved tail\nnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='rotation-create-gap':
    append(b'D');timer=None
    def rotate():
     nonlocal timer
     log.rename(root/'host.log.1');timer=threading.Timer(.002,lambda:log.write_bytes(b'new\n'));timer.start()
    c.source=AfterRead(c.source,rotate)
    try:c.poll()
    finally:
     if timer:timer.join()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='rotation-after-append':
    append(b'D');original=c._append;fired=[False]
    def append_then_rotate(*args):
     result=original(*args)
     if not fired[0]:fired[0]=True;log.rename(root/'host.log.1');log.write_bytes(b'new\n')
     return result
    c._append=append_then_rotate;c.poll()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='rotation-during-read':
    append(b'D')
    def rotate():log.rename(root/'host.log.1');log.write_bytes(b'new\n')
    c.source=AfterRead(c.source,rotate);c.poll()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name.startswith('metadata-'):
    # Replay the real ext4 observation: updated timestamps can precede size growth.
    # Only one fstat extent is delayed; every source/prefix byte uses actual file I/O.
    padding=b'P'*(1024*1024-9) if name=='metadata-growth-capacity' else b''
    if padding:append(padding);c.poll()
    append(b'D');initial=os.fstat(c.source.fileno());real=os.fstat;calls=[];fired=[False]
    evidence={p.name:p.read_bytes() for p in root.iterdir() if p.name.startswith(('manifest','segment'))}
    def action():
     fired[0]=True
     if name=='metadata-no-growth':os.utime(log,ns=(initial.st_atime_ns,initial.st_mtime_ns+1000000))
     elif name=='metadata-truncate':log.write_bytes(b'')
     else:
      if name=='metadata-rewrite-append':
       with log.open('r+b',buffering=0) as f:f.write(b'xyz')
      if name=='metadata-new-read-mutation':
       with log.open('r+b',buffering=0) as f:f.seek(4);f.write(b'E')
      if name=='metadata-regrowth':log.write_bytes(b'BAD')
      append(b'TAIL')
    c.source=AfterRead(c.source,action)
    if name=='metadata-short-read':
     read=c.source.read;c.source.read=lambda *args:read(*args)[:-1]
    def stat(fd):
     now=real(fd)
     if fd==c.source.fileno():
      if len(calls)==1 and name!='metadata-truncate':
       values={k:getattr(now,k) for k in dir(now) if k.startswith('st_')};values['st_size']=initial.st_size;now=types.SimpleNamespace(**values)
      elif len(calls)==2:
       if name=='metadata-identity':
        values={k:getattr(now,k) for k in dir(now) if k.startswith('st_')};values['st_ino']+=1;now=types.SimpleNamespace(**values)
       elif name=='metadata-second-change':os.utime(log,ns=(now.st_atime_ns,now.st_mtime_ns+1000000));now=real(fd)
       elif name=='metadata-second-rotation':log.rename(root/'host.log.2');log.write_bytes(b'new')
       elif name=='metadata-archive-mutation':c.paths()[0].write_bytes(b'bad!')
      calls.append(logs.snapshot(now))
     return now
    rejected=False;began=time.monotonic()
    with patch.object(os,'fstat',stat):
     try:c.poll()
     except AssertionError as e:
      rejected=True
      if name in ('metadata-growth','metadata-growth-capacity'):raise
      assert 'log changed during read' in str(e),str(e)
      diagnostic=json.loads(str(e).split(': ',1)[1]);assert diagnostic['before'] and diagnostic['after'] and diagnostic['readBytes']==(0 if name=='metadata-short-read' else 1) and diagnostic['currentDescriptor']
    assert fired[0]
    if name=='metadata-no-growth':assert len(calls)==11,'transition must stop after eight observations plus diagnostic'
    if name in ('metadata-growth','metadata-growth-capacity'):
     duration=time.monotonic()-began
     if padding:
      assert duration<.36774617568190315,'transition exceeds accepted work/gap bound'
      print('TRANSITION_METRIC',json.dumps({'sourceBytes':log.stat().st_size,'pollSeconds':duration}))
     assert not rejected;c.poll();assert b''.join(p.read_bytes() for p in c.paths())==b'abc\n'+padding+b'DTAIL'
     assert c.checkpoint('finish')['integrityComplete']
    else:
     assert rejected,'unsafe metadata transition accepted '+name
     assert c.failed and not c.integrity_complete
     if name!='metadata-archive-mutation':assert evidence=={p.name:p.read_bytes() for p in root.iterdir() if p.name.startswith(('manifest','segment'))},'refusal published evidence'
   elif name=='read-growth':
    append(b'1234567');c.source=AfterRead(c.source,lambda:append(b'D'))
    c.poll();assert c.state['current']['offset']==11
    c.poll();assert b''.join(p.read_bytes() for p in c.paths())==b'abc\n1234567D'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='checkpoint-growth':
    c.source=AfterRead(c.source,lambda:append(b'D'))
    c.checkpoint('ready');c.poll();assert c.checkpoint('finish')['integrityComplete']
   elif name in ('growth-mutation','regrowth','archive-corrupt'):
    append(b'D')
    if name=='archive-corrupt':c.paths()[0].write_bytes(b'xxxx')
    elif name=='regrowth':log.write_bytes(b'xyz\nLONG')
    else:
     with log.open('r+b') as f:f.write(b'xyz')
    try:c.poll();c.checkpoint('finish')
    except AssertionError:pass
    else:raise AssertionError('corruption certified '+name)
  finally:c.close()
 print('PASS',name)
if __name__=='__main__':
 for name in sys.argv[1:] or ['metadata-growth','metadata-growth-capacity','metadata-short-read','metadata-no-growth','metadata-rewrite-append','metadata-new-read-mutation','metadata-regrowth','metadata-truncate','metadata-identity','metadata-second-change','metadata-second-rotation','metadata-archive-mutation','observed-growth-rotation','rotation-create-gap','rotation-after-append','rotation-during-read','finish-append','finish-error','finish-mutation','read-growth','checkpoint-growth','growth-mutation','regrowth','archive-corrupt']:case(name)
