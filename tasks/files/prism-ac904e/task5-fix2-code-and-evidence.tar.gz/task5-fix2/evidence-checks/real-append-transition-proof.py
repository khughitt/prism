"""Actual kernel stat snapshots through bounded transition resolver; no stat mock."""
import os,time,json,multiprocessing,sys,hashlib
from pathlib import Path
os.umask(0o077)
root=Path(sys.argv[1]);root.mkdir(mode=0o700);code=Path(sys.argv[2]);sys.path.insert(0,str(code));import logs,capture
mp=multiprocessing.get_context('fork');log=root/'source';log.write_bytes(b'');manifest=root/'manifest.json';logs.start(log,manifest);c=logs.Capture(manifest)
def append(raw):
 with log.open('ab',buffering=0) as f:f.write(raw);os.fsync(f.fileno())
append(b'P'*4096);c.poll();append(b'pending-read\n')
def writer():time.sleep(.02);append(b'A'*68250)
p=mp.Process(target=writer);p.start();owned=capture.process(p.pid);found=None;start=time.monotonic();count=0
try:
 before=os.fstat(c.source.fileno())
 while time.monotonic()-start<3:
  after=os.fstat(c.source.fileno());count+=1
  if before.st_size==after.st_size and logs.snapshot(before)!=logs.snapshot(after):
   data=os.pread(c.source.fileno(),before.st_size-c.state['current']['offset'],c.state['current']['offset'])
   resolved=c._append_growth(c.source,c.state['current'],before,after,data)
   found={'before':logs.snapshot(before),'after':logs.snapshot(after),'resolved':logs.snapshot(resolved),'readBytes':len(data)};break
  before=after
 p.join(2);assert not p.is_alive();assert p.exitcode==0;assert found,'no actual transition observed within bounded probe'
 c.poll();assert c.checkpoint('finish')['integrityComplete'];expected=b'P'*4096+b'pending-read\n'+b'A'*68250;actual=b''.join(x.read_bytes() for x in c.paths());assert actual==expected
 result={'observed':found,'observations':count,'seconds':time.monotonic()-start,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'complete':True,'process':owned,'processGone':not capture.same_process(owned),'writerExit':p.exitcode}
 (root/'proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:
 if p.is_alive():p.terminate();p.join(2)
 c.close();assert not p.is_alive()
