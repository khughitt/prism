# Task 5: imported headless lifetime result

The root controller's strict verification passed for the reviewed synthetic headless rehearsal after the actual first turn ended and a distinct human turn began beyond the watchdog. This packet imports immutable saved evidence; the implementer did not rerun the verifier or launch another rehearsal. Independent Task 5 result review and closure remain pending.

Production ran for 2,424.8821696059895 seconds with one start and native exit 0. The complete capture contains 1,637,984,592 bytes, 23,953 synthetic blocks, 1,600 generations and 2,774 protocol records. The joined SHA256 is `4473a2683ec93be9cee7f22e68a75faf7dee56295c3da28d2fd0b4520800c43d`. Root verified every captured byte, segment hash, synthetic payload and identifier, complete protocol/error coverage, final operation-qualified drain, terminal cutoff, current phase schema and real turn binding. The import independently rehashed the 1,675 retained original files and all 1,600 segments; concatenating the segments reproduced that digest.

The saved full result is artifact A1673 (`verified.json`), 230,811,059 bytes, SHA256 `c8fbaae912ed269a9ae64b50586a0da686828f6e604b315be4de9dcb2c12aff0`. Its contents and the strict command's recorded exit 0 govern this result. Nested tool stdout was truncated; that is an output limitation, not a capture failure. The complete original stays private and is inventoried here.

## Actual collection and production

There are 17,482 collection observations, 17,482 persistence observations and 17,448 heartbeats. Maximum poll gap is 0.30096548597794026 seconds and maximum work plus persistence is 0.19096181099303067 seconds, below the unchanged configured 0.36774617568190315-second guard. Combined observed peak is 1,080,362 B/s; the unchanged conservative rate guard is 1,425,679 B/s and target/floor is 682,491 B/s. Root reported 244 overlap annotations; no samples were discarded. These are observations of a synthetic fake host, not live Noctalia performance acceptance.

The saved scheduler contains 4,411 actual ticks at a requested 16 ms period. Observed minimum/median/mean/maximum gaps are 16.00337598938495 / 16.902131988899782 / 16.997781114522346 / 25.168118008878082 ms. The first and last ticks occurred 2,310.0136649269843 and 2,384.973879642028 seconds after producer start, spanning 74.96021471504355 seconds. Native scheduling was requested 90 seconds before the nominal 2,400-second producer endpoint. The observations below describe what occurred; the tick span does not establish exact native process start/end timestamps.

| Write-start window | Duration (s) | Writes | Synthetic bytes | Protocol bytes |
| --- | ---: | ---: | ---: | ---: |
| Producer start to first tick | 2310.0136649269843 | 22,864 | 1,560,447,426 | 0 |
| First to last observed tick | 74.96021471504355 | 1,069 | 45,894,657 | 4,684,110 |
| Last observed tick to producer end | 39.90828996396158 | 396 | 26,958,321 | 78 |

These windows partition writes by their recorded start time; they are not exclusive CPU phases or exact native lifecycle intervals. Across the full run, 23,953 synthetic writes carried 1,633,300,404 bytes, and 376 protocol writes carried 4,684,188 bytes. Synthetic writes extended to offset 2,424.8819818220218 seconds; the last protocol write ended at offset 2,384.9870317829773 seconds. Producer end to wrapper end was 8.519220818008762 seconds. No cadence was extrapolated from short pilots.

## Phase observations and error distinctions

All collection, persistence and heartbeat error fields are empty; incomplete polls and source-observation failure diagnostics are zero. Operation telemetry separately records 3 `source.prefix` and 2 `source.stat` exception markers inside completed collection windows. These were handled operation exceptions, not collection failure or raw budget errors. Their exception types and causes were not recorded, so this report assigns no cause. `source.resolve` ran 6 times with 0 exception markers. The root strict verifier's complete raw budget-error check passed with zero matching errors.

The following rows summarize the saved operation observations. Nested operation durations overlap and must not be added. Startup and final receipt durability are not fully measured by these phase records.
| Observation | Operation | Calls | Exception markers | Max wall (ms) | Total wall (s) |
| --- | --- | ---: | ---: | ---: | ---: |
| collection | archive.flush | 17911 | 0 | 2.153985959 | 0.962376660 |
| collection | archive.fsync | 17911 | 0 | 29.665868031 | 69.863263172 |
| collection | archive.metadata | 22289 | 0 | 43.653013010 | 185.882313515 |
| collection | archive.validate | 6398 | 0 | 2.429751970 | 4.538235044 |
| collection | archive.write | 17911 | 0 | 2.734048991 | 0.775215174 |
| collection | manifest.flush | 22281 | 0 | 1.881700999 | 0.610694337 |
| collection | manifest.fsync | 22281 | 0 | 20.089985977 | 89.114257418 |
| collection | manifest.publish | 22281 | 0 | 28.010254959 | 143.125289333 |
| collection | source.locate | 22429 | 0 | 3.079310001 | 3.141503074 |
| collection | source.prefix | 3203 | 3 | 5.421860958 | 2.113187591 |
| collection | source.read | 19081 | 0 | 3.156279970 | 0.503675873 |
| collection | source.resolve | 6 | 0 | 19.064979977 | 0.071419086 |
| collection | source.stat | 105195 | 2 | 0.173526991 | 0.872207293 |
| heartbeat | heartbeat.flush | 17448 | 0 | 2.107848006 | 0.744179293 |
| heartbeat | heartbeat.fsync | 17448 | 0 | 30.827993993 | 64.216944973 |
| heartbeat | heartbeat.publish | 17448 | 0 | 31.470478978 | 72.909670142 |
| persistence | poll.flush | 17482 | 0 | 2.151829016 | 0.654473165 |
| persistence | poll.fsync | 17482 | 0 | 20.121418987 | 65.349162792 |
| persistence | poll.write | 17482 | 0 | 2.327850962 | 3.207271008 |

## Real turn and strict verifier provenance

The first turn is `01a13bd0-9e93-7722-b3ef-7c7c4ac7963c`; the distinct next turn is `01a13c62-d2ca-7b03-9d73-c6a1b2825e02`. Root start call/result references 14252/14255 are at 2026-10-14 20:17:56.443/20:17:57.080 UTC. First-turn `task_complete` reference 14330 is at 20:24:05.442 UTC. The recorded watchdog is 21:02:56.765392 UTC. Next-turn `task_started` 14332 is at 21:47:51.898 UTC; the actual human message and completed UserMessage references 14334/14335 are at 21:47:52.117/21:47:52.118 UTC. The corresponding actual read call/result 14344/14347 are at 21:48:13.477/21:48:13.878 UTC. The root proof binds these real events and the read acknowledgement to this run; park/resume notes alone are not the proof.

`turn-references.json` supplies every selected event's exact timestamp, event type, turn ID, rollout line and SHA256 without message text. The private turn-proof artifact A0001 has SHA256 `9c7ee1ce52254cf127637c98b2e952818e2c5858910fd34d8e78a06c93b2ddf2`; selected private evidence A1671 has SHA256 `3609cdbb5f064211540f06ed76286b2d473df1858960350911bda08aaa2b1ca1`. The classifier SHA256 is `bb67a2b492bb8c5292e4d1760a5a3161da614e54851b6766aa2478b647d8cd90`.

The actual root verification command, with only private path operands replaced, was:

```text
python3 <CAPTURE_ROOT>/code/rehearse.py verify <RUN> --turn-proof <RUN>/TURN_PROOF.json
```

Call 14370 at 21:49:40.396 UTC led to result 14374 and tracked session 3954. The subsequent read call/result 14380/14382 led to tracked cell 836. Wait call 14386 received completed result 14389 at 21:52:00.434 UTC with `exit_code: 0`. The result metadata records 118.120048877 seconds for that wait and 34,289,164 original output tokens; neither number is the whole command's elapsed duration. The full selected tool records and exact private command are retained privately for the independent reviewer. References 14401/14405 bind root's saved summary to the full result. No command was reconstructed and re-executed to generate this packet.

## Cleanup and source provenance

Root checked that all five recorded server, wrapper, collector, producer and native PID/start/boot identities were gone, the named server was unresponsive and no kernel socket endpoint remained. An owned stale filesystem socket pathname remained; root recorded its stat identity, rechecked actor absence and unchanged identity, then removed only that endpoint. Artifact A0066 binds the before record and A0063 the final cleanup verification; their exact hashes are in `original-inventory.json`. The endpoint was physically absent afterward. The default server was absent before and after. No plugin pointer, rotation state, profile or desktop state was changed. This import started no runtime process and made no cleanup change.

The unchanged 54-file active and frozen source has digest `4203ac5942263fcda74d5f741549674ecb0194345012b575229d5d0409ed5b32`, reviewed through `9243616`, with root disposition `737d47b` and import base `bfaa46b`. The accepted sibling attachment `task5-active5-code-and-evidence.tar.gz` is 205,868 bytes with SHA256 `46065d4f4fe976a79ff55677535842e206d7db39fd89b9d62532a671c69aa699`; its 5,406-byte source-inventory attachment has SHA256 `11c1a4b0295b52a2ae3a5d54250e609b5d92163196628399613f4300bf2f7b9f`. This packet references those exact sources and adds no replacement source archive.

`source-provenance.json` records the baseline source `9bf4e8e920c005f8a4d1666b32b4e1a516856ac2`, candidate source `e7384b0d7ab3e8e935cdf0776043839441132af5`, the prepared-run hash, the model fixture's 50,632-byte hash, and all 38 generated and 7 calibration input byte counts/hashes. The input files were rehashed without executing them. The unchanged native calibration peak is 682,491 B/s and observed source calibration peak is 1,117,592 B/s; the conservative rate guard is 1,425,679 B/s. Private input-name and original-artifact maps allow the reviewer to resolve each neutral public identifier without disclosing private paths or fixtures.

`original-inventory.json` covers every retained original file using neutral artifact IDs, kinds, lengths and hashes. `segment-inventory.json` binds all 1,600 generations, offsets, lengths and segment hashes to the joined capture. `result-summary.json`, `production-summary.json`, `phase-summary.json` and `turn-references.json` contain bounded derived observations. `packet-inventory.json` hashes the eight report/data members; it deliberately excludes itself. No raw logs, model data, conversation text, private paths, full verification result or overlap arrays are included.

## Pending disposition

The three earlier failed captures remain immutable and incomplete. Root owns the fresh read-only lifetime, actual-turn and calibration/provenance review before Task 5 closure. Task 6 has not started. Live clock rebinding, concrete host commands, fresh desktop permission and live performance acceptance remain pending. This evidence establishes the root-verified synthetic named-wrapper lifetime result only.
