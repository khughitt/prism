"""One incremental collector and its cleanup-owning isolated tmux supervisor."""
import json
import math
import os
import shlex
import signal
import subprocess
import sys
import time
from pathlib import Path
import logs
import phases


def atomic(path, data, observer=None):
    temp=path.with_suffix('.tmp')
    with phases.measure(observer,'heartbeat.publish'):
        with temp.open('w') as f:
            json.dump(data,f,indent=2);f.write('\n')
            with phases.measure(observer,'heartbeat.flush'):f.flush()
            with phases.measure(observer,'heartbeat.fsync'):os.fsync(f.fileno())
        temp.replace(path)


def process(pid):
    # /proc comm may contain spaces and parentheses; fields start after its final ')'.
    stat=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
    return {'pid':int(pid),'startTicks':int(stat[19]),'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}


def same_process(record):
    try:return process(record['pid'])==record and Path(f"/proc/{record['pid']}/stat").read_text().rsplit(')',1)[1].split()[0]!='Z'
    except (OSError,KeyError,ValueError):return False


def expired(deadline, started, clock=None):return (clock or time.monotonic)()-started>=deadline


def command(data, last):
    logs.require(set(data)=={'sequence','command'} and type(data['sequence']) is int and data['sequence']==last+1,'replayed or unknown command sequence')
    logs.require(data['command'] in ('ready','finish','stop'),'unknown command')
    return data['command']


def config(path):
    run=json.loads(path.read_text())
    logs.require(run['schema']==2 and run['environment'] in ('synthetic','live'),'invalid run schema/environment')
    logs.require(run['deadlineSeconds']==(2100 if run['environment']=='live' else 2700),'live deadline2100 / headless-rehearsal2700 required')
    for key,limit in [('pollSeconds',2),('maxGapSeconds',10)]:
        v=run[key];logs.require(type(v) in (int,float) and math.isfinite(v) and 0<v<=limit,'invalid '+key)
    logs.require(run['maxGapSeconds']>=run['pollSeconds'],'gap shorter than poll interval')
    logs.require(type(run['runId']) is str and bool(run['runId']) and type(run['clockOrigin']) is str and bool(run['clockOrigin']),'missing run/clock identity')
    socket=run['socket'];logs.require(socket.startswith('prism-budget-capture-') and all(c.isalnum() or c=='-' for c in socket),'unsafe socket name')
    for k in ('manifest','control','receipt','heartbeat','polls','identities'):
        p=Path(run[k]);logs.require(p.is_absolute() and p.parent.resolve()==path.parent.resolve(),'run output must be private within RUN directory: '+k)
    logs.require(len({run[k] for k in ('manifest','control','receipt','heartbeat','polls','identities')})==6,'run output paths collide')
    logs.require(Path(run['log']).is_absolute(),'log path must be explicit')
    if 'rehearsal' in run:
        logs.require(run['environment']=='synthetic' and Path(run['rehearsal'])==path.parent/'run.json','rehearsal is synthetic-only and run-local')
    return run


class Interrupted(Exception):pass
class Stopped(Exception):pass


def interrupt(signum, frame):raise Interrupted(signal.Signals(signum).name)


def install_traps():
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,interrupt)


def run_collector(path):
    cfg=config(path);root=path.parent;started=None;c=None;last_end=None;last_start=None;last_sequence=0;last_persistence=None;last_heartbeat=None;heartbeat_count=0;reason='unexpected';complete=False;error=None
    install_traps()
    me=process(os.getpid())
    def status():
        identities=json.loads(Path(cfg['identities']).read_text())
        return {'schema':2,'runId':cfg['runId'],'clockOrigin':cfg['clockOrigin'],'collectorStarted':started,
                'lastPollStart':last_start,'lastPollEnd':last_end,'lastIntervalPersistence':last_persistence,'phaseSchema':1,'lastHeartbeat':last_heartbeat,'heartbeatCount':heartbeat_count,'generations':len(c.state['segments']) if c else 0,
                'sourceObservationFailure':c.failure_detail if c else None,
                'terminalCutoff':c.state.get('terminalCutoff') if c and complete else None,'lastSequence':last_sequence,'exitReason':reason,'integrityComplete':complete,'processes':dict(identities,collector=me),'error':error}
    def heartbeat():
        nonlocal last_heartbeat,heartbeat_count
        observer=phases.Recorder();begin=time.monotonic();failure=None
        # A heartbeat file never claims its own still-in-flight persistence completed.
        try:atomic(Path(cfg['heartbeat']),status(),observer)
        except BaseException as exc:failure=str(exc);raise
        finally:
            heartbeat_count+=1
            last_heartbeat={'runId':cfg['runId'],'clockOrigin':cfg['clockOrigin'],'start':begin,'end':time.monotonic(),
                'bytes':0,'checkpoint':False,'error':failure,'observation':'heartbeat','precedingPollStart':last_start,
                'startup':last_start is None,'sequence':heartbeat_count,'phases':observer.snapshot()}
    try:
        # Options and wrapper identity must exist before the collector owns the log.
        gate=root/'wrapper-ready.json';wait_start=time.monotonic()
        while not gate.exists():
            logs.require(time.monotonic()-wait_start<10,'wrapper startup timeout');time.sleep(.01)
        logs.require(not Path(cfg['manifest']).exists(),'activation cannot resume a prior manifest')
        logs.start(Path(cfg['log']),Path(cfg['manifest']));c=logs.Capture(Path(cfg['manifest']))
        started=time.monotonic();reason='running';heartbeat()
        control_version=None
        with Path(cfg['polls']).open('x') as intervals:
            def interval(checkpoint=False):
                nonlocal last_start,last_end,last_sequence,control_version,last_persistence,last_heartbeat
                begin=None;count=0;poll_complete=False;effective_checkpoint=checkpoint
                def close_interval(failure=None):
                    nonlocal last_end,begin,last_persistence,last_heartbeat
                    if begin is None:return
                    last_end=time.monotonic()
                    row={'runId':cfg['runId'],'start':begin,'end':last_end,'clockOrigin':cfg['clockOrigin'],'bytes':count,'checkpoint':effective_checkpoint,'error':failure,
                         'pollComplete':poll_complete,'sourceObservationFailure':c.failure_detail,
                         'observation':'collection','previousIntervalPersistence':last_persistence,'previousHeartbeat':last_heartbeat,'phases':c.observer.snapshot()}
                    begin=None;last_heartbeat=None;c.observer=None
                    observer=phases.Recorder();persistence_error=failure
                    try:
                        with observer.measure('poll.write'):intervals.write(json.dumps(row)+'\n')
                        with observer.measure('poll.flush'):intervals.flush()
                        with observer.measure('poll.fsync'):os.fsync(intervals.fileno())
                    except BaseException as exc:persistence_error=str(exc);raise
                    finally:
                        last_persistence={'runId':cfg['runId'],'clockOrigin':cfg['clockOrigin'],'start':last_end,'end':time.monotonic(),
                            'bytes':0,'checkpoint':effective_checkpoint,'error':persistence_error,'observation':'persistence',
                            'persistedObservationStart':row['start'],'phases':observer.snapshot()}
                def guard(now=None):
                    logs.require(not expired(cfg['deadlineSeconds'],started),'collector deadline expired during work')
                    logs.require(last_start is None or (time.monotonic() if now is None else now)-last_start<=cfg['maxGapSeconds'],'poll gap breached during collection/checkpoint work')
                def collect():
                    nonlocal begin,count,poll_complete,last_start,effective_checkpoint
                    guard();close_interval();actual_start=time.monotonic();guard(actual_start);begin=actual_start;last_start=actual_start;c.observer=phases.Recorder()
                    count=0;poll_complete=False
                    before=sum(r['bytes'] for r in c.state['segments']);generations=len(c.state['segments']);c.poll();count=sum(r['bytes'] for r in c.state['segments'])-before;poll_complete=True
                    if not effective_checkpoint and len(c.state['segments'])!=generations:effective_checkpoint='rotation'
                    guard()
                def service(force):
                    nonlocal last_sequence,control_version
                    guard()
                    control=Path(cfg['control'])
                    if control.exists() and logs.snapshot(control.stat())!=control_version:
                        with control.open('rb') as stream:
                            before=os.fstat(stream.fileno());raw=stream.read();after=os.fstat(stream.fileno())
                        version=logs.snapshot(before)
                        logs.require(version==logs.snapshot(after)==logs.snapshot(control.stat()),'command changed during read')
                        data=json.loads(raw);action=command(data,last_sequence)
                        logs.require(action=='stop','checkpoint command arrived during checkpoint')
                        last_sequence=data['sequence'];control_version=version;raise Stopped()
                    if force or time.monotonic()-last_start>=cfg['pollSeconds']:collect()
                try:
                    collect()
                    if effective_checkpoint:c.checkpoint(effective_checkpoint,service)
                    guard();close_interval();guard()
                except BaseException as e:close_interval(str(e));raise
                finally:close_interval()
            while True:
                interval();heartbeat()
                control=Path(cfg['control'])
                if control.exists():
                    version=logs.snapshot(control.stat())
                    if version!=control_version:
                        with control.open('rb') as stream:
                            before=os.fstat(stream.fileno());raw=stream.read();after=os.fstat(stream.fileno())
                        logs.require(logs.snapshot(before)==logs.snapshot(after)==version==logs.snapshot(control.stat()),'command changed during read')
                        data=json.loads(raw);action=command(data,last_sequence);last_sequence=data['sequence'];control_version=version
                        if action=='stop':reason='stop';break
                        interval('ready' if action=='ready' else 'finish')
                        if action=='finish':complete=True;reason='finish';break
                        heartbeat()
                time.sleep(cfg['pollSeconds'])
    except Stopped:reason='stop'
    except Interrupted as e:reason='signal';error=str(e)
    except BaseException as e:reason='deadline' if 'deadline' in str(e) else 'failure';error=str(e)
    finally:
        complete=complete and reason=='finish'
        if c:c.close()
        atomic(root/'collector-receipt.json',status())
        atomic(Path(cfg['heartbeat']),status())
    return 0 if complete else 1


def tmux(cfg,*args,check=True):
    env=os.environ.copy();env.pop('TMUX',None)
    return subprocess.run(['tmux','-L',cfg['socket'],'-f','/dev/null',*args],env=env,check=check,capture_output=True,text=True)


def terminate(record):
    if same_process(record):os.kill(record['pid'],signal.SIGTERM)


def launch(path):
    cfg=config(path);root=path.parent
    socket_path=Path(os.environ.get('TMUX_TMPDIR','/tmp'))/f'tmux-{os.getuid()}'/cfg['socket']
    logs.require(not socket_path.exists(),'refuse existing tmux socket')
    for name in ('receipt','heartbeat','polls','identities','manifest'):
        logs.require(not Path(cfg[name]).exists(),'refuse reused run outputs')
    logs.require(not (root/'wrapper-ready.json').exists() and not (root/'collector-receipt.json').exists(),'refuse reused run directory')
    os.umask(0o077)
    # Publish incomplete before launching: an unexpected death never implies completion.
    atomic(Path(cfg['receipt']),{'schema':2,'runId':cfg['runId'],'exitReason':'starting','integrityComplete':False,
        'collectorStarted':None,'lastPollStart':None,'lastPollEnd':None,'generations':0,'clockOrigin':cfg['clockOrigin'],'processes':{}})
    invocation=shlex.join([sys.executable,str(Path(__file__).resolve()),'supervise',str(path)])
    server=None
    try:
        tmux(cfg,'new-session','-d','-s','capture',invocation,';','set-option','-s','exit-unattached','off',';','set-option','-s','exit-empty','on',';','set-option','-g','remain-on-exit','off')
        server=process(int(tmux(cfg,'display-message','-p','#{pid}').stdout.strip()))
        wrapper=process(int(tmux(cfg,'display-message','-p','-t','capture:0','#{pane_pid}').stdout.strip()))
        atomic(Path(cfg['identities']),{'server':server,'wrapper':wrapper})
        atomic(root/'wrapper-ready.json',{'socket':cfg['socket']})
    except BaseException as e:
        if server and same_process(server):tmux(cfg,'kill-server',check=False)
        atomic(Path(cfg['receipt']),{'schema':2,'runId':cfg['runId'],'exitReason':'launch-failure','integrityComplete':False,'error':str(e)})
        raise
    return 0


def collector_receipt(path,cfg,identities):
    value=json.loads(path.read_text())
    logs.require(type(value) is dict and type(value.get('schema')) is int and value['schema']==2
        and value.get('runId')==cfg['runId'] and value.get('clockOrigin')==cfg['clockOrigin']
        and type(value.get('integrityComplete')) is bool and type(value.get('processes')) is dict
        and type(value.get('phaseSchema')) is int and value['phaseSchema']==1
        and value['processes'].get('collector')==identities['collector'], 'collector receipt identity/schema mismatch')
    return value


def supervise(path):
    cfg=config(path);root=path.parent;identities={'wrapper':process(os.getpid())};reason='unexpected';error=None;started=None;receipt=None;child=None;producer=None;rehearsal=None;producer_checked=False;ready_sent=False;finish_sent=False
    os.umask(0o077);install_traps()
    try:
        gate=root/'wrapper-ready.json';startup=time.monotonic()
        while not gate.exists():
            logs.require(time.monotonic()-startup<10,'launcher startup timeout');time.sleep(.01)
        identities=json.loads(Path(cfg['identities']).read_text())
        logs.require(identities['wrapper']==process(os.getpid()),'wrapper identity mismatch')
        with (root/'collector-output.log').open('x') as output:
            child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'run',str(path)],stdout=output,stderr=subprocess.STDOUT)
        identities['collector']=process(child.pid);atomic(Path(cfg['identities']),identities)
        startup=time.monotonic()
        while True:
            hb=Path(cfg['heartbeat'])
            if hb.exists():
                heartbeat=json.loads(hb.read_text());started=heartbeat['collectorStarted']
            if started is None:logs.require(time.monotonic()-startup<10,'collector startup timeout')
            else:logs.require(not expired(cfg['deadlineSeconds'],started),'wrapper deadline expired')
            if 'rehearsal' in cfg and started is not None:
                if rehearsal is None:
                    import rehearse
                    rehearsal=rehearse
                    rehearsal.verify_inputs(root)
                deadline=rehearsal.c.load(root/'start.json')['watchdogMonotonic']
                logs.require(time.monotonic()<deadline,'rehearsal watchdog deadline expired')
                if producer is None:
                    # Publish ownership before a pending signal may transfer into finally.
                    blocked={signal.SIGTERM,signal.SIGINT,signal.SIGHUP}
                    prior=signal.pthread_sigmask(signal.SIG_BLOCK,blocked)
                    try:
                        with (root/'producer-output.log').open('x') as output:
                            producer=subprocess.Popen([sys.executable,str(Path(__file__).with_name('rehearse.py')),'produce',str(root)],stdout=output,stderr=subprocess.STDOUT,preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,prior))
                        identities['producer']=process(producer.pid);atomic(Path(cfg['identities']),identities)
                    finally:signal.pthread_sigmask(signal.SIG_SETMASK,prior)
                if (root/'native-identity.json').exists() and 'native' not in identities:
                    identities['native']=rehearsal.c.load(root/'native-identity.json');atomic(Path(cfg['identities']),identities)
                if producer.poll() is not None and not finish_sent:
                    logs.require(producer.returncode==0,'synthetic producer exited prematurely')
                    if not ready_sent:
                        atomic(Path(cfg['control']),{'sequence':1,'command':'ready'});ready_sent=True
                    elif heartbeat['lastSequence']==1:
                        rehearsal.before_finish(root);producer_checked=True
                        logs.require(time.monotonic()<deadline,'rehearsal deadline during final validation')
                        atomic(Path(cfg['control']),{'sequence':2,'command':'finish'});finish_sent=True
            cr=root/'collector-receipt.json'
            if cr.exists():receipt=json.loads(cr.read_text());reason=receipt['exitReason'];break
            logs.require(same_process(identities['server']) and child.poll() is None,'named server or collector exited unexpectedly')
            time.sleep(min(.05,cfg['pollSeconds']))
    except Interrupted as e:reason='signal';error=str(e)
    except BaseException as e:reason='deadline' if 'deadline' in str(e) else 'failure';error=str(e)
    finally:
        # EXIT/finally and signal traps reap only PID+start identities owned by this run.
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,signal.SIG_IGN)
        if producer:
            if producer.poll() is None:producer.terminate()
            try:producer.wait(timeout=2)
            except subprocess.TimeoutExpired:
                if 'producer' in identities and same_process(identities['producer']):producer.kill()
                producer.wait(timeout=2)
        if 'rehearsal' in cfg and (root/'native-identity.json').exists():
            identities['native']=json.loads((root/'native-identity.json').read_text())
            terminate(identities['native']);until=time.monotonic()+2
            while same_process(identities['native']) and time.monotonic()<until:time.sleep(.01)
            if same_process(identities['native']):os.kill(identities['native']['pid'],signal.SIGKILL)
            atomic(Path(cfg['identities']),identities)
        if child:
            if receipt and receipt.get('exitReason')=='finish' and receipt.get('integrityComplete') is True and reason=='finish':
                try:child.wait(timeout=2)
                except subprocess.TimeoutExpired:reason='failure';error='collector did not exit after finish receipt'
            if child.poll() is None:terminate(identities['collector'])
            try:child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                if same_process(identities['collector']):os.kill(child.pid,signal.SIGKILL)
                child.wait(timeout=2)
        # Reaping may complete a collector receipt after the supervisor's last poll.
        # Preserve that actual evidence; the wrapper's signal/failure still owns outcome.
        if receipt is None and (root/'collector-receipt.json').exists():
            try:receipt=collector_receipt(root/'collector-receipt.json',cfg,identities)
            except (OSError,ValueError,AssertionError,KeyError,TypeError) as exc:
                error=error or str(exc)
                if reason!='signal':reason='failure'
        complete=receipt is not None and receipt['integrityComplete'] is True and reason=='finish' and error is None and child.returncode==0
        if 'rehearsal' in cfg:complete=complete and producer_checked and producer is not None and producer.returncode==0
        final=dict(receipt or {'schema':2,'runId':cfg['runId'],'collectorStarted':started,'clockOrigin':cfg['clockOrigin'],'lastPollStart':None,'lastPollEnd':None,'generations':0})
        if Path(cfg['heartbeat']).exists():
            heartbeat=json.loads(Path(cfg['heartbeat']).read_text())
            for key in ('lastPollStart','lastPollEnd','generations','collectorStarted'):final[key]=heartbeat[key]
        final.update(exitReason=reason,integrityComplete=complete,processes=identities,wrapperEnded=time.monotonic(),error=error or final.get('error'))
        # Ignore HUP while removing our own server; final receipt follows the reap.
        if 'server' in identities and same_process(identities['server']):tmux(cfg,'kill-server',check=False)
        atomic(Path(cfg['receipt']),final)
    return 0 if complete else 1


if __name__=='__main__':
    mode,path=sys.argv[1],Path(sys.argv[2]).resolve()
    logs.require(mode in ('run','supervise','launch'),'use run, supervise or launch RUN.json')
    sys.exit({'run':run_collector,'supervise':supervise,'launch':launch}[mode](path))
