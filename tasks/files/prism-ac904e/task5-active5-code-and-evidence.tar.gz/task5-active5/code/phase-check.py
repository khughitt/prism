"""Saved evidence must identify real blocking work, not just report a generic gap."""
import copy,json,os,signal,tempfile,time,unittest,uuid
os.umask(0o077)
from pathlib import Path
from unittest.mock import patch
import capture,logs,phases,controller

class PhaseCheck(unittest.TestCase):
 def case(self,operation='archive',effect='slow',seed=False):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);log=root/'source.log';log.write_bytes(b'')
   cfg={'schema':2,'runId':'phase-case','clockOrigin':'linux-monotonic','socket':'prism-budget-capture-phase-case','environment':'synthetic','deadlineSeconds':2700,'pollSeconds':.01,'maxGapSeconds':.05 if effect=='slow' else 2,'log':str(log)}
   for k in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[k]=str(root/(k+'.json'))
   capture.atomic(root/'RUN.json',cfg);capture.atomic(root/'wrapper-ready.json',{});capture.atomic(root/'identities.json',{'wrapper':capture.process(os.getpid())});capture.atomic(root/'control.json',{'sequence':1,'command':'stop' if effect=='stop' else 'finish'})
   real_start=logs.start;real_sync=os.fsync;real_hash=logs.hashlib.sha256;real_checkpoint=logs.Capture.checkpoint;fired=[];active=[False];matches=[0]
   def start(*args):
    real_start(*args)
    if seed:
     owner=logs.Capture(root/'manifest.json')
     try:
      for i in range(4):
       log.write_bytes(b'captured\n');owner.poll()
       if i<3:log.replace(root/'source.log.1');log.write_bytes(b'')
     finally:owner.close()
    else:
     with log.open('ab') as f:f.write(b'captured\n')
   def sync(fd):
    name=Path(os.readlink(f'/proc/self/fd/{fd}')).name
    match=name.endswith('.raw') if operation=='archive' else name==operation+'.json' if operation=='polls' else name==operation+'.tmp'
    if match:matches[0]+=1
    if match and not fired and (operation!='heartbeat' or matches[0]==2):
     fired.append(True)
     if effect=='slow':time.sleep(.08)
     real_sync(fd)
     if effect=='error':raise OSError('controlled fsync failure')
     if effect=='signal':raise capture.Interrupted('SIGTERM')
    else:real_sync(fd)
   def checkpoint(owner,*args,**kwargs):
    active[0]=True
    try:return real_checkpoint(owner,*args,**kwargs)
    finally:active[0]=False
   def hashed(*args,**kwargs):
    if seed and active[0]:time.sleep(.015)
    return real_hash(*args,**kwargs)
   traps={s:signal.getsignal(s) for s in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
   try:
    with patch.object(logs,'start',start),patch.object(os,'fsync',sync),patch.object(logs.Capture,'checkpoint',checkpoint),patch.object(logs.hashlib,'sha256',hashed):result=capture.run_collector(root/'RUN.json')
   finally:
    for s,h in traps.items():signal.signal(s,h)
   receipt=json.loads((root/'collector-receipt.json').read_text());rows=[json.loads(x) for x in (root/'polls.json').read_text().splitlines()]
   self.assertTrue(fired or seed);self.assertEqual(result,0 if effect=='normal' else 1);self.assertEqual(receipt['integrityComplete'],effect=='normal')
   if os.environ.get('PHASE_CHECK_PROOFS'):
    dest=Path(os.environ['PHASE_CHECK_PROOFS'])/(operation+'-'+effect+'-'+str(seed)+'-'+uuid.uuid4().hex);dest.mkdir(parents=True,mode=0o700)
    (dest/'evidence.json').write_text(json.dumps({'rows':rows,'receipt':receipt},indent=2)+'\n')
   return rows,receipt
 def test_publication_failure_preserves_provisional_bytes_and_metadata(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);log=root/'source.log';log.write_bytes(b'')
   cfg={'schema':2,'runId':'publication-case','clockOrigin':'linux-monotonic','socket':'prism-budget-capture-publication-case','environment':'synthetic','deadlineSeconds':2700,'pollSeconds':.01,'maxGapSeconds':2,'log':str(log)}
   for k in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[k]=str(root/(k+'.json'))
   capture.atomic(root/'RUN.json',cfg);capture.atomic(root/'wrapper-ready.json',{});capture.atomic(root/'identities.json',{'wrapper':capture.process(os.getpid())})
   real_start=logs.start;real_save=logs.save;fired=[]
   def start(*args):
    real_start(*args);log.write_bytes(b'published provisional bytes\n')
   def save(manifest,state,observer=None):
    real_save(manifest,state,observer)
    if state['current']['offset'] and not fired:
     fired.append(True);st=log.stat();os.utime(log,ns=(st.st_atime_ns,st.st_mtime_ns+1000000))
   traps={s:signal.getsignal(s) for s in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
   try:
    with patch.object(logs,'start',start),patch.object(logs,'save',save):result=capture.run_collector(root/'RUN.json')
   finally:
    for s,h in traps.items():signal.signal(s,h)
   receipt=json.loads((root/'collector-receipt.json').read_text());rows=[json.loads(x) for x in (root/'polls.json').read_text().splitlines()]
   self.assertEqual(result,1);self.assertFalse(receipt['integrityComplete']);phases.validate_capture(rows,receipt)
   self.assertEqual(rows[0]['bytes'],0);self.assertIs(rows[0].get('pollComplete'),False,'incomplete poll lacks honest completion marker')
   detail=rows[0]['sourceObservationFailure'];self.assertEqual(detail,receipt['sourceObservationFailure'])
   self.assertEqual(detail['stage'],'post-publication');self.assertTrue(detail['archivePublished']);self.assertTrue(detail['manifestPublished'])
   state=json.loads((root/'manifest.json').read_text());raw=b''.join((root/r['path']).read_bytes() for r in state['segments'])
   self.assertEqual(raw,b'published provisional bytes\n');self.assertEqual(state['current']['offset'],len(raw))
   self.assertEqual(detail['capturedInterval'],{'start':0,'end':len(raw)});self.assertEqual(detail['pendingInterval'],{'start':len(raw),'end':len(raw)})
   self.assertEqual(detail['observedExtent'],len(raw));self.assertIsNone(receipt['terminalCutoff'])
   self.assertTrue(any(op['name']=='source.resolve' and op['failures']==1 for op in rows[0]['phases']['operations']))
   # Receipt validation must stand on its own even without a row diagnostic.
   rr=copy.deepcopy(rows)
   for row in rr:row.pop('sourceObservationFailure',None)
   phases.validate_capture(rr,receipt)
   for change in ('missing-error','error-type','empty-detail','detail-type','stage','publication-type'):
    rc=copy.deepcopy(receipt)
    if change=='missing-error':rc['error']=None
    if change=='error-type':rc['error']=True
    if change=='empty-detail':rc['sourceObservationFailure']={}
    if change=='detail-type':rc['sourceObservationFailure']='failed'
    if change=='stage':rc['sourceObservationFailure']['stage']='unknown'
    if change=='publication-type':rc['sourceObservationFailure']['manifestPublished']=1
    with self.subTest(change=change),self.assertRaises(ValueError):phases.validate_capture(rr,rc)


 def test_real_archive_fsync_cost_identified_after_gap(self):
  rows,receipt=self.case()
  self.assertIn('gap',receipt['error'])
  found=[op for row in rows for op in row.get('phases',{}).get('operations',[]) if op['name']=='archive.fsync' and op['max']['end']-op['max']['start']>=.08]
  self.assertTrue(found,'saved evidence cannot identify the actual slow archive fsync')

 def test_persistence_cost_failure_and_signal_are_carried(self):
  for effect in ('slow','error','signal'):
   with self.subTest(effect=effect):
    rows,receipt=self.case('polls',effect)
    p=receipt['lastIntervalPersistence'];self.assertEqual(p['persistedObservationStart'],rows[-1]['start'])
    phases.validate(p)
    op=next(x for x in p['phases']['operations'] if x['name']=='poll.fsync')
    self.assertEqual(op['failures'],int(effect!='slow'))
    if effect=='slow':self.assertGreaterEqual(op['max']['end']-op['max']['start'],.08)
    else:self.assertIn('SIGTERM' if effect=='signal' else 'controlled fsync failure',receipt['error'])
 def test_heartbeat_overlap_and_complete_duplicate_pair_refuse(self):
  rows,receipt=self.case(effect='normal');phases.validate_capture(rows,receipt)
  h=next(row['previousHeartbeat'] for row in rows if row.get('previousHeartbeat'))
  sample={'runId':'phase-case','clockOrigin':'linux-monotonic','block':'1','variant':'baseline','class':'coldRender','scope':'callback','startTimestamp':h['start'],'endTimestamp':h['end'],'elapsedMs':(h['end']-h['start'])*1000,'timestamp':h['end']}
  normal={'events':[sample],'samples':[sample],'certificates':[{'originVerified':True}],'exclusions':[]}
  observations=rows+[receipt['lastIntervalPersistence']]+([receipt['lastHeartbeat']] if receipt['lastHeartbeat'] else [])
  result=controller.analyze.overlap_report(normal,observations)
  self.assertEqual(result['overlapCount'],1);self.assertEqual(result['observations'][result['samples'][0]['overlapObservationIndices'][0]]['kind'],'heartbeat')
  with self.assertRaises(ValueError):controller.analyze.overlap_report(normal,observations+observations)
 def test_strict_phase_and_carrier_validation(self):
  rows,receipt=self.case(effect='normal');phases.validate_capture(rows,receipt)
  for kind in ('nan','bool','negative','outside','duplicate','unknown','cpu','count','correlation','duplicate-row','missing-schema','missing-heartbeat','duplicate-heartbeat','heartbeat-bool','heartbeat-clock'):
   rr=copy.deepcopy(rows);rc=copy.deepcopy(receipt);op=next(x for row in rr for x in row['phases']['operations'])
   if kind=='nan':op['max']['end']=float('nan')
   if kind=='bool':op['max']['start']=True
   if kind=='negative':op['totalSeconds']=-1
   if kind=='outside':op['max']['end']+=100
   if kind=='duplicate':rr[0]['phases']['operations'].append(copy.deepcopy(rr[0]['phases']['operations'][0]))
   if kind=='unknown':op['name']='owner-value'
   if kind=='cpu':op['max']['threadCpuSeconds']=100
   if kind=='count':op['count']=True
   if kind=='correlation':rc['lastIntervalPersistence']['persistedObservationStart']+=.01
   if kind=='duplicate-row':rr.append(copy.deepcopy(rr[-1]))
   if kind=='missing-schema':rc.pop('phaseSchema')
   if kind=='missing-heartbeat':rr[0]['previousHeartbeat']=None
   if kind=='duplicate-heartbeat':rc['lastHeartbeat']=copy.deepcopy(rr[0]['previousHeartbeat'])
   if kind=='heartbeat-bool':rr[0]['previousHeartbeat']['sequence']=True
   if kind=='heartbeat-clock':rr[0]['previousHeartbeat']['clockOrigin']='wrong'
   with self.subTest(kind=kind),self.assertRaises((ValueError,KeyError)):phases.validate_capture(rr,rc)

 def test_failed_or_missing_poll_completion_cannot_qualify(self):
  rows,receipt=self.case(effect='normal')
  for change in ('missing','integer','false','diagnostic'):
   rr=copy.deepcopy(rows);rc=copy.deepcopy(receipt)
   if change=='missing':rr[0].pop('pollComplete')
   if change=='integer':rr[0]['pollComplete']=1
   if change=='false':rr[0]['pollComplete']=False
   if change=='diagnostic':rr[0]['sourceObservationFailure']={'stage':'post-publication'}
   with self.subTest(change=change),self.assertRaises(ValueError):phases.validate_capture(rr,rc)

 def test_receipt_only_source_failure_cannot_qualify(self):
  saved=os.environ.get('PHASE_SAVED_SMOKE')
  if saved:
   root=Path(saved);rows=[json.loads(x) for x in (root/'polls.jsonl').read_text().splitlines()];receipt=json.loads((root/'receipt.json').read_text())
  else:rows,receipt=self.case(effect='normal')
  self.assertTrue(receipt['integrityComplete']);self.assertTrue(all(row.get('sourceObservationFailure') is None for row in rows))
  phases.validate_capture(rows,receipt)
  for detail in ({'stage':'post-publication','manifestPublished':True},{},True,[], 'failed'):
   rc=copy.deepcopy(receipt);rc['sourceObservationFailure']=detail
   with self.subTest(detail=detail),self.assertRaises(ValueError):phases.validate_capture(rows,rc)
  for absent in (False,True):
   rc=copy.deepcopy(receipt)
   if absent:rc.pop('sourceObservationFailure',None)
   else:rc['sourceObservationFailure']=None
   phases.validate_capture(rows,rc)

 def test_collection_error_and_early_stop(self):
  for effect in ('error','signal','stop'):
   rows,receipt=self.case(effect=effect)
   phases.validate_capture(rows,receipt)
   self.assertEqual(receipt['exitReason'],{'error':'failure','signal':'signal','stop':'stop'}[effect])
   op=next(x for x in rows[0]['phases']['operations'] if x['name']=='archive.fsync')
   self.assertEqual(op['failures'],int(effect!='stop'))
 def test_runtime_heartbeat_failure_keeps_actual_completed_span(self):
  rows,receipt=self.case('heartbeat','error')
  phases.validate_capture(rows,receipt)
  h=receipt['lastHeartbeat'];self.assertFalse(h['startup']);self.assertEqual(h['precedingPollStart'],rows[-1]['start'])
  op=next(x for x in h['phases']['operations'] if x['name']=='heartbeat.fsync');self.assertEqual(op['failures'],1)
 def test_cooperative_checkpoint_operations_belong_to_actual_windows(self):
  rows,receipt=self.case(effect='normal',seed=True)
  phases.validate_capture(rows,receipt)
  windows=[row for row in rows if row['checkpoint']=='finish']
  self.assertGreater(len(windows),2)
  operations=[op for row in windows for op in row['phases']['operations'] if op['name']=='archive.validate']
  self.assertEqual(sum(op['count'] for op in operations),4)
  self.assertTrue(all(op['max']['end']-op['max']['start']>=.015 for op in operations))
 def test_complete_pair_duplicate_refuses_without_heartbeat(self):
  row={'runId':'r','clockOrigin':'c','start':1.,'end':1.1,'bytes':1,'checkpoint':False,'error':None,'observation':'collection'}
  persist=row|{'start':1.1,'end':1.2,'bytes':0,'observation':'persistence','persistedObservationStart':1.}
  normal={'events':[{'runId':'r','clockOrigin':'c'}],'samples':[],'certificates':[{'originVerified':True}],'exclusions':[]}
  controller.analyze.overlap_report(normal,[row,persist])
  with self.assertRaises(ValueError):controller.analyze.overlap_report(normal,[row,persist,row,persist])

 def test_reaped_receipt_bound_to_owned_collector(self):
  rows,receipt=self.case(effect='normal');identity=receipt['processes']['collector']
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'receipt.json';cfg={'runId':'phase-case','clockOrigin':'linux-monotonic'};ids={'collector':identity}
   p.write_text(json.dumps(receipt));self.assertEqual(capture.collector_receipt(p,cfg,ids),receipt)
   for key,value in (('schema',True),('runId','other'),('clockOrigin','other'),('processes',{'collector':identity|{'startTicks':identity['startTicks']+1}}),('integrityComplete',1),('processes',None),('phaseSchema',True)):
    p.write_text(json.dumps(receipt|{key:value}))
    with self.subTest(key=key),self.assertRaises(AssertionError):capture.collector_receipt(p,cfg,ids)

if __name__=='__main__':unittest.main(verbosity=2)
