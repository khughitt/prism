# Panel-budget capture controller

Private scratch tooling; production Prism code is unchanged. The root controller
owns live permission, exact host command specifications and source/build clock proof.
Read `../runbook.md` before preparing a session. Calibration success is never live
acceptance, and these tools do not authorize a long rehearsal.

`controller.py` runs one explicit action on each root turn. Its inspection API is
`inspect_run(run_directory, receipt=None, prefix=None)`; each card uses its own immutable reply timestamp.
`session_verdict(normalized, identities, receipts, restoration, clock, observations,
stage1=None)` requires per-activation bound lifecycle and proof records. `clock`
contains an `activations` map; restoration entries come from the controller's
`restoration.json`. The runbook defines every field and recovery/cleanup command.

Focused checks (invoke using Python; Lua and tmux must be available):

- `controller-check.py`: budgets, source-clock refusal, intent oracle and permits.
- `corrective-check.py OLD_BUILD`: six reviewed defect regressions; OLD_BUILD is an
  immutable earlier build containing baseline/fix1-excluded-fake.log.
- `controller-integration.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI [recovery|cold|all]`:
  actual fresh Lua producer, controller inspection, temporary named collector,
  periodic callbacks during waits and after finish inspection, actual exit CLI/final
  raw reread, clean finish/reap, restoration and verdict. All host IPC/state is fake.
- `controller-cleanup-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: actual
  assertion/child TERM/INT, supervisor timeout/TERM/INT, startup and residual-server
  cases prove owned cleanup. Supervisors request graceful child termination first
  and always reap exact named socket/process identities in their outer finally.
- `controller-cleanup-boundary-check.py SUPERVISOR_SOURCE NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`:
  actual stop signals at cleanup entry and during child wait, owned reap, evidence
  and handler restoration, repeated bootstrap stops, and the forced-child-kill path.
  An outer test owner also cleans up when the reviewed old supervisor fails.
- `controller-abort-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: partial setup
  and crash reconciliation, no-collector cleanup, actual launched-collector abort,
  conflict refusal and cleanup resumption without repeating effects.
- `controller-proof-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: independent
  retained-stage binding and fake/synthetic prior-stage rejection. Its deliberately
  relabelled adversarial copies are test inputs only and never clock proof.
- `controller-recovery-negative-check.py SAVED_SUCCESSFUL_RECOVERY_RUN`: deliberate
  in-memory counterfeits of captured records, preserving all original files.

Use unique private output directories. Keep command/output/elapsed records and all
raw fixtures private. Portable review archives contain code, textual diffs, neutral
PASS summaries and hashes only. Earlier artifacts are never overwritten.

`controller-periodic-check.py SAVED_SUCCESSFUL_RECOVERY_RUN NEW_PRIVATE_OUT`
checks material dwell changes and the actual exit CLI against separately copied
counterfeit captures. The original raw archives remain unchanged. The controller's
`exited(receipt, is_alive)` reads and validates final raw itself; callers cannot pass
a stale normalization. `inspectionAudit`, `finishAudit` and `finalAudit` bind raw
prefixes and final integrity; ordinary periodic observations may extend a stable
settlement, but material changes fail. See the runbook for the exact boundary.

New broad-wave calibration uses an independent paced actual generated fake host and
prospective write/frame intervals. `broad-independent-check.py` runs the full five-unit
workload with complementary trailing-window padding, separate native/total peaks,
one-backup 1MiB rotation and exact final raw audit. `broad-capacity-check.py` exercises
the real collector loop with explicitly synthetic retained history and an independent
writer; this is not a live-resume interface. Each run records its actual configured
poll/gap bounds and measured source rate. Synthetic target durations and fake host
actions still require root clock/host review before any live use.

`Capture.checkpoint(reason, service=None)` allows synchronous cooperative collection
between full sealed-archive hashes; new generations join the same validation epoch.
The final forced collection precedes stable current/archive validation. `service`
never runs concurrently. Collector work rows and explicit persistence observations cover collection, hashing
and poll-row durability work under the same rate-derived gap/deadline. Finish receipt and manifest bind
one explicit fully consumed `terminalCutoff`; all non-finish exits remain incomplete.

Generated post-dwell close emits a strict durable handoff snapshot/close/flush/marker
chain without later ticks. Visible dwell ends at close, not the delayed reply. Original
and recovery replies remain independently bound. See the runbook and broad report for
exact fields, corruption/race negatives, preserved failed stress runs and proof limits.


Wave2: `operation_gates(events, manifest, reply_at, expected_reference)` requires the
card's independently materialized final reference. The parser separately validates
each card's final handoff; a valid recovery cannot replace the original card's cut.

New collector work rows have `observation: collection` and carry the known
`previousIntervalPersistence` span. The final known span is the receipt's
`lastIntervalPersistence`. Each persistence observation has the existing row identity,
start/end/bytes/checkpoint/error fields, `observation: persistence`, zero bytes, and
`persistedObservationStart` binding the work row. Endpoints are sampled after the
corresponding row fsync, not predicted. The final receipt publishes a completed
poll-row epoch; it makes no claim to observe its own subsequent control-file fsync.

`session_verdict` adds terminal receipt observations to the supplied work rows.
Standalone `analyze.py --observations` users append each receipt's
`lastIntervalPersistence` to the JSON observation list. Missing/duplicate/misbound
persistence evidence for modern work rows refuses overlap certification. Historical
rows remain historical and gain no invented persistence endpoints. Actual collection
starts are guarded after intervening persistence, before replacing the prior anchor;
terminal persistence is also guarded before successful completion.


### Phase evidence contract (new captures)

`phaseSchema: 1` on collector receipts requires bounded `phases` summaries on every collection/persistence observation. Each fixed operation has count, total wall/thread CPU, failure count and actual maximum start/end/thread CPU/failure. Nested names (for example manifest publication and its fsync) overlap; their totals must never be added. No per-file paths or values enter phase labels. `phases.validate_capture` checks current-version records; old captures retain their frozen readers and unknown internal phases.

Each collection window owns completed source/stat/read/prefix, archive validation/write/flush/fsync and manifest publication/flush/fsync operations. Cooperative checkpoint service closes a window only between leaf operations; there is no spanning checkpoint phase. Counts/maximums reflect only that window. The existing previousIntervalPersistence and lastIntervalPersistence carry poll serialization/write/flush/fsync after it completes, including failure. Its error propagates and guards still include actual persistence cost.

Runtime heartbeats occur outside collection. A completed heartbeat observation carries actual start/end, run/clock and precedingPollStart (null plus startup=true for the initial heartbeat). Contiguous heartbeat sequence/count binds complete carrier coverage. The next collection row consumes previousHeartbeat once; the receipt carries only a still-unconsumed lastHeartbeat. The heartbeat file never claims its own future fsync. Startup manifest/collector initialization and final receipt/final heartbeat durability are not phase measured; no endpoint is invented for those writes. After emergency child reaping, the wrapper can reread an actual collector receipt bound to schema/run/clock/owned identity; its own signal/failure outcome stays authoritative. If a failure prevents the existing evidence write, telemetry can be incomplete, never a successful certificate.

Overlap expands heartbeat and persistence carriers uniquely, rejecting repeated complete pairs and duplicate heartbeat identities. Only containing operation intervals enter overlap; nested phase summaries do not inflate it or alter target samples. Current rehearsal verification and independent native proof require strict phase validation before acceptance.

There are19 fixed names, at most19 summaries per observation, and a16KiB phase-summary validation bound. Runtime memory is one fixed-name recorder per active window plus completed carriers, independent of archive history. No new durable file or fsync is added. Phase bookkeeping, JSON serialization and extra bytes remain inside the existing actual time guards. Observer overhead is measured in preparation; this is observability, not a remedy for historical latency or evidence of long-run reliability.

Active append observations use one eight-observation budget (1 ms waits, including
post-validation observation) shared across a poll's read/publication seams and
across an active checkpoint's retries. The existing both-advanced fixed timestamp
pair remains valid. The additional split sequence permits one ctime-first epoch,
then exactly one mtime catch-up to that epoch; larger size under the converged
pair remains mandatory. Descriptor and unique live-path observations share the
same progression: once either observes convergence, neither may regress. Growth
still requires the descriptor itself to have converged; a later path observation
cannot substitute for it. Stable timestamps alone never establish an append.

The resolver validates the entire captured interval by hash and pending read bytes
by exact comparison. Observed source extent is distinct from captured cursor:
unread tail is provisional and never included in a prefix hash or terminal cutoff.
Source identity, unique live pathname, and archive metadata remain mandatory.
Active checkpoints repeat the full prefix read after resolution; held source
reads are unbuffered so a repeat cannot reuse stale Python reader bytes. Outgoing
seal checks have no active-transition exception. Finish still requires an exact,
fully consumed terminal source snapshot.

Private sourceObservationFailure records carry the failing stage, compared stat
tuples, captured/pending intervals, cursor and pre-transition observed extent.
archivePublished/manifestPublished indicate publication by the failing append
stage; prior captured bytes are always identified by capturedInterval, including
at a checkpoint that performs no append publication itself. A collection row's
pollComplete reports whether its poll returned. bytes counts completed polls;
an incomplete poll can have already published provisional bytes, exposed by the
failure record. Existing poll/receipt writes carry the bounded details; no new
per-poll durable write is introduced. The validator checks both row and receipt
diagnostics: any non-null detail requires a recognized stage, boolean publication
flags, a nonempty error string and incomplete integrity. Null or absent details
remain valid on success. All work remains inside the actual guards.
