"""Real byte/cursor evidence under bounded active-source stat interleavings."""
import hashlib,json,os,sys,tempfile,time,types,unittest
from pathlib import Path
from unittest.mock import patch
os.umask(0o077);sys.dont_write_bytecode=True
sys.path.insert(0,os.environ.get('ACTIVE_CODE',str(Path(__file__).parent)))
import logs

def stat(st,**changes):
    return types.SimpleNamespace(**({k:getattr(st,k) for k in dir(st) if k.startswith('st_')}|changes))

def append(path,data):
    with path.open('ab',buffering=0) as f:
        assert f.write(data)==len(data);os.fsync(f.fileno())

def sha(data):return hashlib.sha256(data).hexdigest()

class ActiveAppend(unittest.TestCase):
    def exercise(self,stage='read',sequence='split',pending=True,bad=None,extent=4096):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);p=d/'source.log';p.write_bytes(b'ignored\n');manifest=d/'manifest.json'
            logs.start(p,manifest);c=logs.Capture(manifest)
            try:
                prefix=b'P'*extent;new=b'pending-read\n' if pending and stage in ('read','publication','prior-growth') else b''
                append(p,prefix);c.poll();append(p,new)
                old=os.fstat(c.source.fileno());old_saved=manifest.read_bytes()
                tail=b'A'*68250;append(p,tail);grown=os.fstat(c.source.fileno())
                self.assertGreater(grown.st_mtime_ns,old.st_mtime_ns)
                self.assertEqual(grown.st_mtime_ns,grown.st_ctime_ns)
                epoch=grown.st_ctime_ns
                split=stat(grown,st_size=old.st_size,st_mtime_ns=old.st_mtime_ns)
                caught=stat(grown,st_size=old.st_size)
                before=split if sequence=='intermediate' else old
                transition=split if sequence=='split' else caught
                if stage=='prior-growth':
                    before_pub=grown;append(p,b'B'*7919);grown=os.fstat(c.source.fileno())
                    transition=stat(grown,st_size=before_pub.st_size,st_mtime_ns=before_pub.st_mtime_ns)
                    seq=[old,before_pub,transition,grown]
                else:seq=([before,before] if stage=='publication' else [before])+[transition]
                trigger=len(seq)-1 if stage!='prior-growth' else 2
                if stage!='prior-growth':
                    if sequence=='split':seq.append(caught)
                    seq.append(grown)
                if bad in ('no-growth','exhausted'):
                    seq=seq[:trigger+1]+[caught]*9
                elif bad=='second-epoch':seq[trigger+1]=stat(grown,st_mtime_ns=epoch+1,st_ctime_ns=epoch+1)
                elif bad=='mtime-value':seq[trigger+1]=stat(grown,st_mtime_ns=epoch+1)
                elif bad=='mtime-regression':seq=seq[:trigger+1]+[caught,split,grown]
                elif bad in ('live-path-regression','path-catchup-descriptor-regression'):
                    seq=seq[:trigger+1]+[split,grown,grown]
                elif bad=='descriptor-catchup-path-regression':seq=seq[:trigger+1]+[caught,grown,grown]
                elif bad=='identity':seq[trigger+1]=stat(grown,st_ino=grown.st_ino+1)
                elif bad=='truncation':seq[trigger+1]=stat(grown,st_size=old.st_size-1)
                elif bad in ('growth-before-catchup','growth-before-path-catchup'):seq=seq[:trigger+1]+[stat(grown,st_mtime_ns=old.st_mtime_ns)]
                elif bad=='second-after-growth':seq=seq[:trigger+1]+[grown,stat(grown,st_mtime_ns=epoch+1,st_ctime_ns=epoch+1)]
                if bad=='checkpoint-reread-mutation':
                    resolve=c._append_growth
                    def mutate_after_resolution(*args):
                        value=resolve(*args)
                        with p.open('r+b',buffering=0) as f:f.seek(8);f.write(b'X')
                        return value
                    c._append_growth=mutate_after_resolution
                real=c._source_stat;real_path_stat=Path.stat;calls=[];fired=False
                live_sequence={
                    'live-path-regression':[caught,split,grown,grown],
                    'path-catchup-descriptor-regression':[caught,caught,grown,grown],
                    'descriptor-catchup-path-regression':[split,split,grown,grown],
                    'growth-before-path-catchup':[split,grown,grown],
                }.get(bad)
                def path_stat(path,*args,**kwargs):
                    index=len(calls)-trigger-1
                    if path==p and live_sequence is not None and index>=0:
                        return live_sequence[min(index,len(live_sequence)-1)]
                    return real_path_stat(path,*args,**kwargs)
                def observe(source):
                    nonlocal fired
                    index=len(calls)
                    if index==trigger+1 and not fired:
                        fired=True
                        if bad=='prefix-mutation':
                            with p.open('r+b',buffering=0) as f:f.seek(8);f.write(b'X')
                        if bad=='pending-mutation':
                            with p.open('r+b',buffering=0) as f:f.seek(8+len(prefix));f.write(b'X')
                        if bad=='regrowth':p.write_bytes(b'X'*grown.st_size)
                        if bad=='archive-mutation':c.paths()[0].write_bytes(b'X'*len(prefix))
                        if bad=='missing':p.unlink()
                        if bad=='ambiguous':os.link(p,d/'source.log.alias')
                        if bad=='rotation':p.rename(d/'source.log.1');p.write_bytes(b'new occurrence\n')
                    value=seq[index] if index<len(seq) else real(source)
                    calls.append(logs.snapshot(value));return value
                c._source_stat=observe
                began=time.monotonic();error=None
                try:
                    with patch.object(Path,'stat',path_stat):
                        if stage in ('read','publication','prior-growth'):c.poll()
                        else:c.checkpoint(stage)
                except AssertionError as exc:error=exc
                elapsed=time.monotonic()-began
                expected=prefix+new
                archived=b''.join(x.read_bytes() for x in c.paths());saved=json.loads(manifest.read_text())
                if stage=='finish' and not bad:
                    self.assertIsNotNone(error);self.assertIn('uncaptured source tail at finish',str(error))
                    self.assertTrue(c.failed);self.assertFalse(c.integrity_complete);self.assertFalse(saved['integrityComplete'])
                    self.assertNotIn('terminalCutoff',saved);self.assertEqual(archived,prefix)
                    self.assertEqual(manifest.read_bytes(),old_saved)
                    return error,elapsed
                if bad:
                    self.assertIsNotNone(error,(stage,sequence,bad))
                    self.assertTrue(c.failed);self.assertFalse(c.integrity_complete);self.assertFalse(saved['integrityComplete'])
                    self.assertNotIn('terminalCutoff',saved)
                    if bad!='archive-mutation':
                        self.assertEqual(archived,expected if stage=='publication' else prefix)
                    if stage!='publication':self.assertEqual(manifest.read_bytes(),old_saved)
                    else:self.assertEqual(saved['current']['offset'],8+len(expected))
                    detail=c.failure_detail
                    self.assertEqual(detail['stage'],'during-read' if stage=='read' else 'post-publication' if stage=='publication' else 'active-checkpoint')
                    self.assertEqual(detail['manifestPublished'],stage=='publication')
                    self.assertEqual(detail['capturedInterval']['end'],8+len(expected if stage=='publication' else prefix))
                    self.assertEqual(detail['observedExtent'],grown.st_size if bad=='checkpoint-reread-mutation' else old.st_size)
                    self.assertTrue(all(k in detail for k in ('before','initialObserved','finalDescriptor','livePath','generation','cursor','pendingInterval','archivePublished')))
                    self.assertLess(len(json.dumps(detail)),4096)
                    if bad in ('no-growth','exhausted'):self.assertLessEqual(len(calls),trigger+1+8+1)
                    for op in (c.poll,lambda:c.checkpoint('finish')):
                        with self.assertRaises(AssertionError):op()
                else:
                    self.assertIsNone(error,(stage,sequence,str(error)))
                    self.assertEqual(archived,expected)
                    self.assertEqual(saved['current']['offset'],8+len(expected))
                    self.assertEqual(saved['segments'][0]['sha256'],sha(expected))
                    self.assertFalse(c.integrity_complete)
                    c._source_stat=real
                    if stage=='prior-growth':self.assertGreater(old.st_size+len(tail),saved['current']['offset'])
                    if stage=='finish':raise AssertionError('finish certified an unread tail')
                    c.poll();self.assertTrue(c.checkpoint('finish')['integrityComplete'])
                    final=p.read_bytes()[8:];self.assertEqual(b''.join(x.read_bytes() for x in c.paths()),final)
                    self.assertEqual(c.state['terminalCutoff']['sourceSize'],p.stat().st_size)
                    self.assertEqual(c.state['terminalCutoff']['segmentSha256'],[sha(final)])
                    if extent>=1024*1024:
                        self.assertLess(elapsed,.36774617568190315)
                        print('PREFIX_COST',json.dumps({'stage':stage,'bytes':extent,'seconds':elapsed}))
                return error,elapsed
            finally:c.close()

    def test_active_seams_exact_followup(self):
        for stage in ('read','publication','ready','settled'):
            for sequence in ('both','split','intermediate'):
                for pending in ((False,True) if stage in ('read','publication') else (False,)):
                    with self.subTest(stage=stage,sequence=sequence,pending=pending):self.exercise(stage,sequence,pending)
    def test_publication_after_prior_visible_read_growth(self):self.exercise('prior-growth')
    def test_refusals_preserve_evidence(self):
        for stage in ('read','publication','ready'):
            for bad in ('no-growth','exhausted','second-epoch','mtime-value','mtime-regression','second-after-growth','growth-before-catchup','identity','truncation','regrowth','prefix-mutation','archive-mutation','missing','ambiguous','rotation'):
                with self.subTest(stage=stage,bad=bad):self.exercise(stage,bad=bad)
            if stage=='ready':self.exercise(stage,bad='checkpoint-reread-mutation')
            if stage in ('read','publication'):
                with self.subTest(stage=stage,bad='pending-mutation'):self.exercise(stage,bad='pending-mutation')
    def test_path_and_descriptor_convergence_never_regresses(self):
        for stage in ('read','publication','ready'):
            for bad in ('live-path-regression','path-catchup-descriptor-regression','descriptor-catchup-path-regression','growth-before-path-catchup'):
                with self.subTest(stage=stage,bad=bad):self.exercise(stage,bad=bad)

    def test_finish_transition_never_certifies_unread_growth(self):
        for sequence in ('both','split','intermediate'):
            with self.subTest(sequence=sequence):
                self.exercise('finish',sequence,pending=False)
    def test_representative_full_prefix_cost(self):
        for stage in ('read','publication','ready'):
            with self.subTest(stage=stage):self.exercise(stage,extent=1024*1024)

if __name__=='__main__':unittest.main(verbosity=2)
