"""Receipt-only contradictions against actual saved smoke evidence, with receipt mutations kept in memory."""
import copy,json,os,sys
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
sys.path.insert(0,os.environ['ACTIVE_CODE'])
import phases
root=Path(sys.argv[1]);receipt=json.loads((root/'receipt.json').read_text());rows=[json.loads(x) for x in (root/'polls.jsonl').read_text().splitlines()]
assert receipt['integrityComplete'] is True
assert all(row.get('sourceObservationFailure') is None for row in rows)
assert phases.validate_capture(rows,receipt)['collection']==len(rows)
detail={'stage':'post-publication','archivePublished':True,'manifestPublished':True}
refusals=[]
for error in (None,'controlled source observation failure'):
 modified=copy.deepcopy(receipt);modified['sourceObservationFailure']=detail;modified['error']=error
 try:phases.validate_capture(rows,modified)
 except ValueError as exc:refusals.append(str(exc))
assert len(refusals)==2, 'structured receipt source failure accepted as successful evidence'
assert all('source failure reported as success' in error for error in refusals),refusals
if len(sys.argv)>2 and sys.argv[2]=='callsite':
 import rehearse
 actual_load=rehearse.c.load
 for invalid in (detail,{'stage':'post-publication','manifestPublished':True}):
  def load(path):
   value=actual_load(path)
   return value|{'sourceObservationFailure':invalid} if path==root/'receipt.json' else value
  with patch.object(rehearse.c,'load',load):
   try:rehearse.verify_capture(root)
   except ValueError as exc:assert str(exc).startswith('phase evidence: source failure'),str(exc)
   else:raise AssertionError('completion caller accepted receipt-only source failure')
 print('PASS completion caller rejects both receipt-only diagnostics')
print('PASS structured receipt failure refuses success independently of receipt error and collection rows')
