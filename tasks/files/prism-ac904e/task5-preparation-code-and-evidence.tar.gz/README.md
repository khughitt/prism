# Task5 preparation evidence

Preparation only; no long rehearsal or live-performance claim.

The code directory has51 files and preserves the accepted48-file predecessor except the opt-in synthetic capture.py change. Full textual diff and SHA256 inventory accompany it. preparation-results.json gives exact final code digest, rates, counts, hashes and cleanup evidence; stream-contract-results.json gives semantic corruption checks. No raw log, model fixture, actual conversation or rollout is included.

Root interfaces: `python3 code/rehearse.py prepare RUN_DIR`, `start RUN_DIR --nonce NONCE`, and `verify RUN_DIR --turn-proof PRIVATE_PROOF.json`. Default preparation is native2400 seconds with2700-second watchdog. Never promote a seconds-long smoke to lifetime proof. Runtime calibration and private inputs reside under the established CAPTURE_ROOT; code is invoked there after review.
