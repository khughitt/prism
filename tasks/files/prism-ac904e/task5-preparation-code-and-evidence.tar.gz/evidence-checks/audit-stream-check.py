"""Corrupt captured bytes while updating hashes: exercise stream semantics, not hash errors."""
from pathlib import Path
import json,shutil,sys,hashlib,os
os.umask(0o077)
code,source,out=map(Path,sys.argv[1:]);sys.path.insert(0,str(code))
import rehearse as mod,controller as c
out.mkdir(mode=0o700)
m=c.load(source/'manifest.json');data=b''.join((source/x['path']).read_bytes() for x in m['segments']);size=int(data.split(b'\n',1)[0].split()[-1]);results=[]
for label,raw in [('normal',data),('duplicate-id',data[:size]+data[:size]+data[2*size:]),('missing-id',data[:size]+data[2*size:]),('payload-mutation',data.replace(b'AAAAAA',b'CAAAAA',1)),('missing-final-protocol-line',data[:data.rstrip(b'\n').rfind(b'\n')+1]),('budget-error',data+b'exceeded its CPU budget\n')]:
 root=out/label;root.mkdir(mode=0o700);(root/'raw').mkdir(mode=0o700)
 for name in ('run.json','protocol.json','producer-tail.log'):shutil.copyfile(source/name,root/name)
 (root/'segment.raw').write_bytes(raw);sha=hashlib.sha256(raw).hexdigest();c.immutable(root/'manifest.json',{'segments':[{'generation':1,'path':'segment.raw','bytes':len(raw),'sha256':sha}]})
 pr=c.load(source/'producer-receipt.json');pr.update(bytes=len(raw),sha256=sha);c.immutable(root/'producer-receipt.json',pr)
 try:mod.audit_stream(root,allow_expired=True);outcome='accept'
 except ValueError as e:outcome=str(e)
 assert (outcome=='accept')==(label=='normal'),(label,outcome)
 results.append({'case':label,'verdict':outcome})
c.immutable(out/'results.json',{'exit':0,'results':results});print(json.dumps(results))
