# Diagnostic only — no qualified source change

These probes did not reproduce the historical gap breach and do not qualify a retry. The original51-file collector/producer freeze remains unchanged. This archive has a private-copy instrumentation diff, its52-file source, exact executed harness scripts and aggregate timings only. Raw spans, host process output and synthetic logs remain private.

The first probe used the actual wrapper with a3-second floor then controlled protocol tail, target682491B/s and unchanged guard. The second replayed a private21-segment seed for8seconds through isolated collector phases; its writer emitted68250B per100ms (ceiling block, nominal682500B/s). It is phase isolation, not a full controller run; heartbeat/poll records use reduced diagnostic payloads. Neither synchronizes source progress with collector heartbeat. Probe instrumentation measures monotonic spans/thread CPU around real operations, including os.fsync; it is not a kernel trace, and syscall wall time includes scheduling delay. Telemetry stays in memory during observation and is durably written on exit. No raw target callbacks were instrumented.

The history harness includes an unused multiprocessing prototype; the executed writer is explicitly started with subprocess.Popen and its recorded identity is reaped. Code is retained exactly as executed for audit.

Reproduction needs an exclusive private diagnostic directory with this code, a runs link to the existing private calibration store, and a private-fixtures link. The failed-run seed and private model are deliberately absent. Never place the instrumented code in the active qualification directory. Root must decide instrumentation/design scope before any further long experiment.
