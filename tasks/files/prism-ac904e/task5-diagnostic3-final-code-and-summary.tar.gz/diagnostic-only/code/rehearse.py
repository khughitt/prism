"""Synthetic lifetime preparation and strict private evidence verification; never live IPC."""
import argparse, datetime, hashlib, json, math, os, runpy, selectors, signal, subprocess, sys, time, uuid
from pathlib import Path
import controller as c
import capture as cap
ROOT=Path(__file__).resolve().parent
BASELINE='9bf4e8e920c005f8a4d1666b32b4e1a516856ac2'
CANDIDATE='e7384b0d7ab3e8e935cdf0776043839441132af5'
FLOOR=682491
OBSERVED=1117592
GUARD=1425679
MIB=1024*1024

def inventory(root):
    return {str(p.relative_to(root)):c.digest(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}

def production_contract(receipt,duration,rate):
    c.require(receipt['complete'] is True and receipt['exitReason']=='complete','producer incomplete or interrupted')
    c.require(receipt['starts']==1,'producer restart')
    c.require(receipt['ended']-receipt['started']>=duration,'short producer lifetime')
    c.require(receipt['ended']<receipt['deadline'],'producer deadline')
    c.require(receipt['bytes']>=math.ceil(duration*rate),'silently reduced producer rate')
    return True

def poll_contract(rows,receipt,gap):
    c.require(bool(rows),'missing polls')
    persists=[x['previousIntervalPersistence'] for x in rows if x.get('previousIntervalPersistence') is not None]
    if receipt.get('lastIntervalPersistence') is not None:persists.append(receipt['lastIntervalPersistence'])
    c.require(len(persists)==len(rows),'missing persistence coverage')
    c.require(len({x['persistedObservationStart'] for x in persists})==len(rows),'duplicate persistence coverage')
    for row,p in zip(rows,persists):
        c.require(row['start']==p['persistedObservationStart'] and row['end']==p['start'] and p['end']>=p['start']>=row['start'],'persistence identity/order')
        c.require(not row.get('error') and not p.get('error'),'poll error')
    work=max(p['end']-row['start'] for row,p in zip(rows,persists))
    maxgap=max((b['start']-a['start'] for a,b in zip(rows,rows[1:])),default=0)
    c.require(work<=gap and maxgap<=gap,'poll gap/work plus persistence breach')
    return {'collectionCount':len(rows),'persistenceCount':len(persists),'maxGapSeconds':maxgap,'maxWorkPersistenceSeconds':work}

def block(nonce,n,size):
    head=f'rehearsal {nonce} {n} {size}\n'.encode()
    # Exact A -> B -> A payload occurrences recur; numbered headers prove multiplicity/order.
    return head+bytes([65 if n%3!=1 else 66])*(size-len(head)-1)+b'\n'

def check_blocks(path,nonce,size):
    n=0
    with path.open('rb') as f:
        while raw:=f.read(size):
            c.require(raw==block(nonce,n,size),'synthetic payload/id/sequence mismatch');n+=1
    return n

def epoch(text):return datetime.datetime.fromisoformat(text.replace('Z','+00:00')).timestamp()

def start_ack(value,run):
    if isinstance(value,dict):
        if value.get('started') is True and value.get('runDir')==run['runDir'] and value.get('runNonce')==run['runNonce']:return True
        return any(start_ack(v,run) for v in value.values())
    if isinstance(value,list):return any(start_ack(v,run) for v in value)
    if isinstance(value,str):
        try:decoded=json.loads(value)
        except (ValueError,TypeError):
            # Harness output may wrap an exact JSON acknowledgement in tool status text.
            for i,char in enumerate(value):
                if char!='{':continue
                try:decoded,_=json.JSONDecoder().raw_decode(value[i:])
                except ValueError:continue
                if start_ack(decoded,run):return True
            return False
        return decoded!=value and start_ack(decoded,run)
    return False

def evidence_read(run,receipt,rollout,nonce):
    """Emit an acknowledgement only after both actual reads; rollout may keep growing."""
    c.require(nonce==run['runNonce'],'evidence-read nonce mismatch')
    c.require(receipt==Path(run['runDir'])/'receipt.json' and receipt.is_absolute() and rollout.is_absolute(),'evidence-read path mismatch')
    c.require(inventory(ROOT)==run['codeSha256'],'evidence-read code changed')
    receipt_bytes=receipt.read_bytes();json.loads(receipt_bytes)
    rollout_bytes=rollout.read_bytes()
    # A concurrently serialized last line is outside this stable, complete-line prefix.
    prefix=rollout_bytes[:rollout_bytes.rfind(b'\n')+1]
    c.require(bool(prefix),'empty evidence-read rollout prefix')
    first=json.loads(prefix.splitlines()[0])
    c.require(first['type']=='session_meta' and first['payload']['id']==run['threadId'],'evidence-read thread mismatch')
    return {'schema':1,'kind':'rehearsal-evidence-read','runDir':run['runDir'],'runNonce':nonce,
        'threadId':run['threadId'],'codeDigest':c.digest(c.encoded(run['codeSha256'])),
        'receipt':{'path':str(receipt),'bytes':len(receipt_bytes),'sha256':c.digest(receipt_bytes)},
        'rollout':{'path':str(rollout),'prefixBytes':len(prefix),'prefixSha256':c.digest(prefix)}}

def read_ack(value,run,rollout,raw,call_index,result_index):
    # Exact functions.exec text(await tools.exec_command(...)) completed envelope.
    # No recursive/string search: yielded sessions and arbitrary output cannot qualify.
    c.require(isinstance(value,list) and len(value)==2 and all(isinstance(x,dict) and set(x)=={'type','text'} and x['type']=='input_text' and isinstance(x['text'],str) for x in value),'invalid evidence-read harness envelope')
    framing=value[0]['text'].splitlines()
    c.require(len(framing)==3 and framing[0]=='Script completed' and framing[1].startswith('Wall time ') and framing[1].endswith(' seconds') and framing[2]=='Output:','evidence-read exec not completed')
    result=json.loads(value[1]['text'])
    c.require(isinstance(result,dict) and set(result)=={'chunk_id','wall_time_seconds','exit_code','original_token_count','output'} and type(result['exit_code']) is int and result['exit_code']==0 and isinstance(result['output'],str),'evidence-read command failed or still running')
    ack=json.loads(result['output'])
    c.require(isinstance(ack,dict) and set(ack)=={'schema','kind','runDir','runNonce','threadId','codeDigest','receipt','rollout'},'invalid evidence-read acknowledgement')
    prefix_info=ack['rollout']
    c.require(isinstance(prefix_info,dict) and set(prefix_info)=={'path','prefixBytes','prefixSha256'},'invalid evidence-read prefix')
    count=prefix_info['prefixBytes'];data=b''.join(raw)
    c.require(type(count) is int and sum(map(len,raw[:call_index+1]))<=count<=sum(map(len,raw[:result_index])) and data[:count].endswith(b'\n'),'evidence-read prefix does not cover call before result')
    receipt=Path(run['runDir'])/'receipt.json';receipt_bytes=receipt.read_bytes()
    expected={'schema':1,'kind':'rehearsal-evidence-read','runDir':run['runDir'],'runNonce':run['runNonce'],
        'threadId':run['threadId'],'codeDigest':c.digest(c.encoded(run['codeSha256'])),
        'receipt':{'path':str(receipt),'bytes':len(receipt_bytes),'sha256':c.digest(receipt_bytes)},
        'rollout':{'path':str(rollout),'prefixBytes':count,'prefixSha256':c.digest(data[:count])}}
    c.require(ack==expected,'evidence-read artifact/run/code binding mismatch')

def turn_proof(run,rollout,first,next_turn,classifier):
    """Root calls only after its evidence-read call and completed first turn exist."""
    c.require(first!=next_turn,'same turn is not a handoff')
    c.require(classifier.resolve()==(Path.home()/'.agents/bin/session-episodes').resolve(),'unrecognized human classifier')
    raw=rollout.read_bytes().splitlines(keepends=True);rows=[json.loads(x) for x in raw]
    classified=runpy.run_path(str(classifier))['read_codex'](rollout)
    c.require(classified.malformed==0 and classified.session_id==run['threadId'] and not classified.subagent,'wrong session or malformed rollout')
    human_lines={e.line for e in classified.events if e.kind=='human'}
    refs={};active=None
    def ref(i):
        x=rows[i];p=x['payload'];return {'line':i+1,'timestamp':x['timestamp'],'type':p.get('type',x['type']),'turnId':p.get('turn_id',active),'sha256':c.digest(raw[i])}
    def put(key,i):c.require(key not in refs,'ambiguous '+key);refs[key]=ref(i)
    for i,x in enumerate(rows):
        p=x['payload'];typ=p.get('type');kind=x['type']
        if kind=='session_meta' and 'session' not in refs:put('session',i)
        if kind=='event_msg' and typ=='task_started':
            active=p['turn_id']
            if active==first:put('firstStarted',i)
            if active==next_turn:
                c.require(p.get('turn_attribution',{}).get('turn_trigger')=='user','next turn is not human-triggered');put('nextStarted',i)
        if kind=='event_msg' and typ=='turn_aborted' and active in (first,next_turn):raise ValueError('aborted turn')
        if kind=='event_msg' and typ=='task_complete' and p.get('turn_id')==first:
            c.require(active==first,'first completion outside its bracket');put('firstComplete',i);active=None
        if active==first and kind=='response_item' and typ in ('custom_tool_call','function_call'):
            text=str(p.get('input',p.get('arguments','')))
            if 'rehearse.py' in text and 'start' in text and run['runDir'] in text and run['runNonce'] in text:put('startCall',i)
        if active==first and kind=='response_item' and typ in ('custom_tool_call_output','function_call_output') and 'startCall' in refs:
            call=rows[refs['startCall']['line']-1]['payload']
            if p.get('call_id')==call['call_id']:
                c.require(start_ack(p.get('output'),run),'start result lacks successful run binding');put('startResult',i)
        if active==next_turn:
            if i+1 in human_lines:put('human',i)
            if kind=='event_msg' and typ=='item_completed' and p.get('item',{}).get('type')=='UserMessage':
                c.require(p.get('turn_id')==next_turn,'wrong-turn UserMessage item_completed');put('humanCompleted',i)
            if kind=='response_item' and typ in ('custom_tool_call','function_call'):
                text=str(p.get('input',p.get('arguments','')))
                if 'rehearse.py' in text and 'read-evidence' in text and run['runNonce'] in text and str(rollout) in text and str(Path(run['runDir'])/'receipt.json') in text:put('readCall',i)
            if kind=='response_item' and typ in ('custom_tool_call_output','function_call_output') and 'readCall' in refs:
                call=rows[refs['readCall']['line']-1]['payload']
                if p.get('call_id')==call['call_id']:
                    read_ack(p.get('output'),run,rollout,raw,refs['readCall']['line']-1,i)
                    put('readResult',i);break
    required={'session','firstStarted','startCall','startResult','firstComplete','nextStarted','human','humanCompleted','readCall','readResult'}
    c.require(set(refs)==required,'missing turn evidence: '+','.join(sorted(required-set(refs))))
    c.require(rows[refs['session']['line']-1]['payload']['id']==run['threadId'],'session identity mismatch')
    c.require(refs['firstStarted']['line']<refs['startCall']['line']<refs['startResult']['line']<refs['firstComplete']['line']<refs['nextStarted']['line']<=refs['human']['line']<refs['readCall']['line']<refs['readResult']['line'],'turn bracket/tool order mismatch')
    c.require(refs['nextStarted']['line']<refs['humanCompleted']['line']<refs['readCall']['line'],'human completed outside next turn')
    c.require(epoch(refs['human']['timestamp'])>run['watchdogWall'] and epoch(refs['nextStarted']['timestamp'])>run['watchdogWall'],'pre-watchdog message')
    return {'threadId':run['threadId'],'firstTurnId':first,'nextTurnId':next_turn,'rolloutPath':str(rollout),'classifierPath':str(classifier),'classifierSha256':c.digest(classifier.read_bytes()),'events':refs}

def verify_turn(run,proof):
    c.require(set(proof)=={'threadId','firstTurnId','nextTurnId','rolloutPath','classifierPath','classifierSha256','events'},'session-only/invalid proof')
    c.require(proof['threadId']==run['threadId'],'proof thread mismatch')
    classifier=Path(proof['classifierPath'])
    c.require(c.digest(classifier.read_bytes())==proof['classifierSha256'],'classifier changed')
    actual=turn_proof(run,Path(proof['rolloutPath']),proof['firstTurnId'],proof['nextTurnId'],classifier)
    c.require(actual==proof,'selected event reference/hash mismatch')
    return {'distinctHumanTurn':True,'threadId':proof['threadId'],'firstTurnId':proof['firstTurnId'],'nextTurnId':proof['nextTurnId'],'events':proof['events'],'classifierSha256':proof['classifierSha256']}

def private(root):
    for p in [root,*root.rglob('*')]:
        if not p.is_symlink():p.chmod(0o700 if p.is_dir() else 0o600)

def prepare(root,smoke_seconds=None,native_smoke=False):
    os.umask(0o077);root=root.resolve();root.mkdir(mode=0o700)
    state=ROOT.parent;accepted=state/'runs/broad-fix2-b52be99db6a54e219e3b038e65c6cb93'
    calibration=[accepted/'final-qualification-baseline/run/proof.json',accepted/'final-qualification-candidate/run/proof.json',accepted/'final-qualification-capacity/proof.json']
    observed=state/'runs/root-accepted-proof-0c1040d5a4a040d7b332ff9937ddcb14'
    calibration += [observed/v/'run/proof.json' for v in ('baseline','candidate')]
    calibration += [accepted/('qualification-'+v)/'run/proof.json' for v in ('baseline','candidate')]
    proofs=[c.load(p) for p in calibration]
    c.require(max(p['nativeWorkloadPeakBytesPerSecond'] for p in proofs if 'nativeWorkloadPeakBytesPerSecond' in p)==682491,'native calibration mismatch')
    c.require(max(p['peakBytesPerSecond'] for p in proofs if 'peakBytesPerSecond' in p)==OBSERVED,'observed full source calibration mismatch')
    c.require(proofs[2]['PASS'] and proofs[2]['retainedBytes']>=FLOOR*2400,'insufficient retained-history qualification')
    nonce='rehearsal-'+uuid.uuid4().hex;duration=2400 if smoke_seconds is None else smoke_seconds
    c.require(smoke_seconds is None or 1<=duration<=10,'smoke must be seconds-long')
    build=root/'build';cli=str(Path.cwd()/'bin/prism')
    subprocess.run([sys.executable,str(ROOT/'frozen-task2/build.py'),'--baseline',BASELINE,'--candidate',CANDIDATE,'--cli',cli,'--output',str(build),'--nonce',nonce,'--stage','stage2','--block','1','--cold-pairs','5','--launch-pairs','5'],check=True,capture_output=True)
    model=state/'private-fixtures/model-private.lua'
    subprocess.run(['lua',str(ROOT/'controller-producer.lua'),str(build),str(model),str(ROOT/'frozen-task2/test_encode.lua'),cli,'handoff-full','baseline',str(root/'producer')],env=os.environ|{'FIXTURE_START':'1000'},check=True,capture_output=True)
    identity=c.load(build/'baseline/identity.json');meta=c.load(root/'producer-meta.json');model=meta['initialModel'];values={p['key']:p['value'] for p in model['params']}
    saved={'pair':{'P':'P','Q':'Q'},'profiles':{'P':values,'Q':values},'runtime':{'active':model['active'],'scratch':{}},'uneditedNumeric':[{'key':'glass.inactive.roughness'}]}
    definitions={p['key']:{k:p[k] for k in ('type','range') if k in p} for p in model['params']}
    actions=c.action_manifest(identity,saved)
    c.immutable(root/'protocol.json',{'identity':identity,'saved':saved,'definitions':definitions,'manifest':actions,'replyAt':meta['finalReply'],'payloadSha256':c.digest((root/'producer-tail.log').read_bytes())})
    protocol(root,root/'producer-tail.log')
    (root/'raw').mkdir();(root/'raw/host.log').write_bytes(b'')
    limits=c.capture_limits(MIB,GUARD,1)
    cfg={'schema':2,'environment':'synthetic','runId':identity['runId'],'clockOrigin':identity['clockOrigin'] if smoke_seconds is None or native_smoke else 'host-monotonic-synthetic-rehearsal','socket':'prism-budget-capture-'+nonce,'deadlineSeconds':2700,'pollSeconds':min(.1,limits['pollSeconds']),'maxGapSeconds':limits['maxGapSeconds'],'log':str(root/'raw/host.log'),'rehearsal':str(root/'run.json')}
    for k in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[k]=str(root/(('processes' if k=='identities' else k)+('.jsonl' if k=='polls' else '.json')))
    c.immutable(root/'collector.json',cfg)
    code=inventory(ROOT);inputs={str(p.relative_to(state)):c.digest(p.read_bytes()) for p in calibration}
    run={'schema':2,'environment':'synthetic','runDir':str(root),'runNonce':nonce,'durationSeconds':duration,'watchdogSeconds':2700,'smoke':smoke_seconds is not None,'native':smoke_seconds is None or native_smoke,'nativeLeadSeconds':90,'targetBytesPerSecond':FLOOR,'guardBytesPerSecond':GUARD,'nativePeakBytesPerSecond':682491,'observedSourcePeakBytesPerSecond':OBSERVED,'cli':cli,'modelSha256':c.digest((state/'private-fixtures/model-private.lua').read_bytes()),'blockBytes':math.ceil(FLOOR*.1),'tickSeconds':.1,'codeSha256':code,'calibrationSha256':inputs,'baselineSource':BASELINE,'candidateSource':CANDIDATE,'clock':'host monotonic; protocol times controlled fixture only','inputs':{str(p.relative_to(root)):c.digest(p.read_bytes()) for p in [root/'collector.json',root/'protocol.json',root/'producer-tail.log',*(x for x in build.rglob('*') if x.is_file())]}}
    c.immutable(root/'run.json',run);private(root)
    return {'runDir':str(root),'runNonce':nonce,'prepared':True,'smoke':run['smoke'],'codeDigest':c.digest(c.encoded(code))}

def protocol(root,path):
    p=c.load(root/'protocol.json');run=c.load(root/'run.json') if (root/'run.json').exists() else None
    expected=root/'producer-tail.log'
    if run and run['native']:
        expected=root/'native-tail.log';p=p|{'replyAt':c.load(root/'native-meta.json')['finalReply']}
    # Compare every measurement line to the producer's independently retained full history.
    payload=b''.join(line for line in path.read_bytes().splitlines(keepends=True) if b'prism-budget ' in line)
    expected_payload=b''.join(line for line in expected.read_bytes().splitlines(keepends=True) if b'prism-budget ' in line)
    c.require(payload==expected_payload,'measurement payload equality')
    p=p|{'payloadSha256':c.digest(expected_payload)}
    events=c.analyze.read_rotated([path]);i=p['identity'];n=i['activationNonce']
    c.require(sorted(e['recordId'] for e in events)==list(range(1,len(events)+1)),'duplicate/missing protocol ids')
    normal,context=c.inspect_capture(events,[i],{n:p['manifest']},{n:p['saved']},{n:p['definitions']},{n:p['replyAt']},True,{})
    c.require(normal['collectionComplete'] and context['cardTiming'][i['cardId']],'strict synthetic operation contract incomplete')
    c.require(any(e['class']=='drain' and e.get('operationId')==p['manifest']['operations'][-1]['id'] for e in events),'final operation-qualified drain missing')
    return {'records':len(events),'payloadSha256':p['payloadSha256'],'collectionComplete':True,'normal':normal}

def verify_inputs(root):
    run=c.load(root/'run.json');c.require(run['environment']=='synthetic' and run['runDir']==str(root),'non-synthetic/path mismatch')
    c.require(run['schema']==2 and type(run['smoke']) is bool and run['watchdogSeconds']==2700 and run['targetBytesPerSecond']==FLOOR and run['guardBytesPerSecond']==GUARD,'invalid rehearsal contract')
    c.require((run['smoke'] and 1<=run['durationSeconds']<=10) or (not run['smoke'] and run['durationSeconds']==2400 and run['native'] is True),'invalid duration/native contract')
    c.require(inventory(ROOT)==run['codeSha256'],'code changed since prepare')
    for name,sha in run['inputs'].items():c.require(c.digest((root/name).read_bytes())==sha,'prepared input changed: '+name)
    for name,sha in run['calibrationSha256'].items():c.require(c.digest((ROOT.parent/name).read_bytes())==sha,'calibration changed')
    return run

def start(root,nonce):
    run=verify_inputs(root);c.require(nonce==run['runNonce'],'run nonce mismatch')
    c.require(not (root/'start.json').exists(),'run cannot restart')
    thread=os.environ.get('CODEX_THREAD_ID') or os.environ.get('CODEX_SESSION_ID')
    c.require(run['smoke'] or bool(thread),'native thread identity required')
    now=time.monotonic();wall=time.time();cfg=c.load(root/'collector.json')
    c.immutable(root/'start.json',{'threadId':thread,'runNonce':nonce,'startedMonotonic':now,'startedWall':wall,'watchdogMonotonic':now+2700,'watchdogWall':wall+2700,'stopCommand':f"tmux -L {cfg['socket']} kill-server"})
    # Same shell wrapper and capture launch path for smoke and the root's long run.
    subprocess.run(['bash',str(ROOT/'capture-wrapper.sh'),str(root/'collector.json')],check=True,capture_output=True)
    return {'runDir':str(root),'runNonce':nonce,'started':True,**c.load(root/'start.json')}

def produce(root):
    run=verify_inputs(root);cfg=c.load(root/'collector.json');started=time.monotonic();deadline=c.load(root/'start.json')['watchdogMonotonic'];seq=0;total=0;sha=hashlib.sha256();reason='unexpected';complete=False;spans=[];native=None;native_id=None;sel=None
    cap.install_traps();c.immutable(root/'producer-start.json',{'process':cap.process(os.getpid()),'started':started,'deadline':deadline})
    log=Path(cfg['log']);size=run['blockBytes'];tick=run['tickSeconds'];next_floor=started;native_started=False;buffer=b'';ticks=[]
    try:
        with (root/'writer-spans.jsonl').open('x') as out, (root/'native-stderr.log').open('x') as errors, (root/'scheduler.jsonl').open('x') as scheduler:
            def write(raw,kind):
                nonlocal total
                c.require(time.monotonic()<deadline,'producer deadline')
                c.require(len(raw)<=MIB,'source flush exceeds rotation capacity')
                if log.stat().st_size+len(raw)>MIB:log.replace(log.with_name(log.name+'.1'));log.write_bytes(b'')
                begin=time.monotonic()
                with log.open('ab',buffering=0) as f:c.require(f.write(raw)==len(raw),'partial producer write');os.fsync(f.fileno())
                end=time.monotonic();sha.update(raw);total+=len(raw)
                row={'start':begin,'end':end,'bytes':len(raw),'kind':kind};out.write(json.dumps(row)+'\n');out.flush();spans.append(row)
            def padding(amount):
                nonlocal seq
                if amount>=128:write(block(run['runNonce'],seq,amount),'synthetic');seq+=1
            next_tick=started
            while True:
                now=time.monotonic();c.require(now<deadline,'producer deadline')
                if run['native'] and not native_started and now-started>=max(0,run['durationSeconds']-run['nativeLeadSeconds']):
                    model=ROOT.parent/'private-fixtures/model-private.lua'
                    c.require(c.digest(model.read_bytes())==run['modelSha256'],'private fixture changed')
                    argv=['lua',str(ROOT/'controller-producer.lua'),str(root/'build'),str(model),str(ROOT/'frozen-task2/test_encode.lua'),run['cli'],'handoff-full','baseline',str(root/'native')]
                    prior=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGINT,signal.SIGHUP})
                    try:
                        native=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors,env=os.environ|{'PACED':'1','FIXTURE_START':str(now)},bufsize=0,preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,prior))
                        native_id=cap.process(native.pid);c.immutable(root/'native-identity.json',native_id)
                    finally:signal.pthread_sigmask(signal.SIG_SETMASK,prior)
                    sel=selectors.DefaultSelector();sel.register(native.stdout,selectors.EVENT_READ);native_started=True;next_tick=time.monotonic()
                if native and native.poll() is None and now>=next_tick:
                    try:native.stdin.write((str(now)+'\n').encode())
                    except BrokenPipeError:pass
                    scheduler.write(json.dumps({'timestamp':now})+'\n');scheduler.flush();ticks.append(now);next_tick=now+.016
                if sel:
                    for key,mask in sel.select(0):
                        data=os.read(key.fd,65536)
                        if data:
                            buffer+=data
                            if b'\n' in buffer:
                                cut=buffer.rfind(b'\n')+1;write(buffer[:cut],'protocol');buffer=buffer[cut:]
                        else:sel.unregister(key.fileobj)
                if now>=next_floor:
                    recent=0
                    for span in reversed(spans):
                        if span['start']<now-1:break
                        recent+=span['bytes']
                    padding(min(size,max(0,FLOOR-recent)));next_floor=now+.1
                native_done=native_started and native.poll() is not None and not sel.get_map() if run['native'] else True
                if native_done and now-started>=run['durationSeconds'] and total>=math.ceil(run['durationSeconds']*FLOOR):break
                time.sleep(.002)
            if native:
                native.wait(timeout=2);c.require(native.returncode==0,'native producer failed')
                c.require(not buffer,'partial native final line')
            else:
                with (root/'producer-tail.log').open('rb') as f:
                    for line in f:
                        write(line,'protocol');time.sleep(max(0,len(line)/FLOOR-(time.monotonic()-spans[-1]['start'])))
            complete=True;reason='complete'
    except cap.Interrupted:reason='signal'
    except BaseException as e:reason=str(e)
    finally:
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,signal.SIG_IGN)
        if native:
            if native.poll() is None:native.terminate()
            try:native.wait(timeout=2)
            except subprocess.TimeoutExpired:
                if native_id and cap.same_process(native_id):native.kill()
                native.wait(timeout=2)
            native.stdin.close();native.stdout.close()
        if sel:sel.close()
        ended=time.monotonic();peak=0;j=0;running=0
        for row in spans:
            while j<len(spans) and spans[j]['start']<row['start']+1:running+=spans[j]['bytes'];j+=1
            peak=max(peak,running);running-=row['bytes']
        c.immutable(root/'producer-receipt.json',{'complete':complete,'exitReason':reason,'started':started,'ended':ended,'deadline':deadline,'starts':1,'blocks':seq,'bytes':total,'sha256':sha.hexdigest(),'peakBytesPerSecond':peak,'nativeProcess':native_id,'nativeExit':native.returncode if native else None,'framePeriodSeconds':.016 if native else None,'nativeTicks':len(ticks),'maxFrameGapSeconds':max((b-a for a,b in zip(ticks,ticks[1:])),default=0)})
    return 0 if complete else 1

def before_finish(root):
    run=verify_inputs(root);receipt=c.load(root/'producer-receipt.json')
    production_contract(receipt,run['durationSeconds'],FLOOR)
    c.require(time.monotonic()<receipt['deadline'],'supervisor deadline before verification')
    cfg=c.load(root/'collector.json');limits=c.capture_limits(MIB,max(FLOOR,receipt['peakBytesPerSecond']),1)
    c.require(cfg['pollSeconds']<=limits['pollSeconds'] and cfg['maxGapSeconds']<=limits['maxGapSeconds'],'actual burst exceeds prospective guard')
    result=audit_stream(root)['protocol']
    c.require(time.monotonic()<receipt['deadline'],'supervisor deadline during verification')
    return {k:v for k,v in result.items() if k!='normal'}

def audit_stream(root,allow_expired=False):
    run=c.load(root/'run.json');pr=c.load(root/'producer-receipt.json');manifest=c.load(root/'manifest.json')
    sha=hashlib.sha256();total=0;blocks=0;pending=b'';payload=root/'raw/verified-protocol.log';expected_block=None
    with payload.open('wb') as out:
        for index,segment in enumerate(manifest['segments'],1):
            c.require(segment['generation']==index and Path(segment['path']).name==segment['path'],'segment order/path')
            path=root/segment['path'];h=hashlib.sha256();count=0
            with path.open('rb') as f:
                while chunk:=f.read(MIB):
                    c.require(time.monotonic()<pr['deadline'] or allow_expired,'stream verification deadline')
                    h.update(chunk);count+=len(chunk);sha.update(chunk);total+=len(chunk);pending+=chunk
                    while b'\n' in pending:
                        line,pending=pending.split(b'\n',1);line+=b'\n'
                        if expected_block:
                            c.require(line==expected_block,'captured synthetic payload mismatch');expected_block=None;blocks+=1
                        elif line.startswith(b'rehearsal '):
                            parts=line.decode().split();c.require(len(parts)==4 and parts[1]==run['runNonce'] and int(parts[2])==blocks,'captured duplicate/missing synthetic id')
                            amount=int(parts[3]);c.require(128<=amount<=run['blockBytes'],'synthetic block size')
                            expected=block(run['runNonce'],blocks,amount);c.require(expected.startswith(line),'synthetic header');expected_block=expected[len(line):]
                        else:out.write(line)
            c.require(count==segment['bytes'] and h.hexdigest()==segment['sha256'],'captured segment hash/bytes mismatch')
    c.require(not pending and expected_block is None,'truncated captured line/block')
    c.require(total==pr['bytes'] and sha.hexdigest()==pr['sha256'] and blocks==pr['blocks'],'all captured bytes/ids differ from producer')
    c.require(b'exceeded its CPU budget' not in payload.read_bytes(),'captured budget error')
    normal=protocol(root,payload)
    return {'bytes':total,'sha256':sha.hexdigest(),'blocks':blocks,'protocol':normal,'protocolSha256':normal['payloadSha256']}

def verify_capture(root):
    run=verify_inputs(root);receipt=c.load(root/'receipt.json');pr=c.load(root/'producer-receipt.json');cfg=c.load(root/'collector.json')
    production_contract(pr,run['durationSeconds'],FLOOR)
    c.require(receipt['integrityComplete'] is True and receipt['exitReason']=='finish' and receipt.get('error') is None,'incomplete collector receipt')
    start=c.load(root/'start.json');producer_start=c.load(root/'producer-start.json')
    c.require(pr['started']==producer_start['started']>=start['startedMonotonic'] and pr['deadline']==producer_start['deadline']==start['watchdogMonotonic'] and start['watchdogMonotonic']==start['startedMonotonic']+2700 and start['watchdogWall']==start['startedWall']+2700,'producer/watchdog lifetime binding')
    c.require(receipt['processes']['producer']==producer_start['process'],'producer process identity changed')
    if run['native']:c.require(receipt['processes']['native']==pr['nativeProcess'] and pr['nativeExit']==0,'native process identity/exit mismatch')
    ids=receipt['processes'];c.require('producer' in ids and all(not cap.same_process(x) for x in ids.values()),'owned process alive/missing producer identity')
    c.require(cap.tmux(cfg,'list-sessions',check=False).returncode!=0,'named socket still alive')
    manifest=c.load(root/'manifest.json');cutoff=manifest.get('terminalCutoff');c.require(manifest['lastCheckpoint']=='finish' and cutoff==receipt.get('terminalCutoff'),'terminal cutoff mismatch')
    held=manifest['current'];last=manifest['segments'][-1]
    c.require(cutoff['generation']==held['generation']==last['generation'] and cutoff['dev']==held['dev']==last['dev'] and cutoff['inode']==held['inode']==last['inode'] and cutoff['endOffset']==cutoff['sourceSize']==held['offset']==last['endOffset'],'terminal offset/source identity mismatch')
    stream=audit_stream(root,allow_expired=True);normal=stream['protocol']
    c.require(stream['bytes']==cutoff['capturedBytes'] and cutoff['segmentSha256']==[s['sha256'] for s in manifest['segments']],'terminal segment identities mismatch')
    rows=[json.loads(x) for x in Path(cfg['polls']).read_text().splitlines()]
    limits=c.capture_limits(MIB,max(FLOOR,pr['peakBytesPerSecond']),1)
    c.require(cfg['pollSeconds']<=limits['pollSeconds'] and cfg['maxGapSeconds']<=limits['maxGapSeconds'],'actual peak exceeds configured guard')
    poll=poll_contract(rows,receipt,min(cfg['maxGapSeconds'],limits['maxGapSeconds']))
    # Synthetic protocol timestamps are a distinct clock; never relabel them as host time.
    if run['native']:
        overlap=c.analyze.overlap_report(normal['normal'],rows+[receipt['lastIntervalPersistence']])
    else:
        persistence=[x['previousIntervalPersistence'] for x in rows if x.get('previousIntervalPersistence')]+[receipt['lastIntervalPersistence']]
        spans=[json.loads(x) for x in (root/'writer-spans.jsonl').read_text().splitlines()]
        intervals=rows+persistence
        overlap={'clockOrigin':cfg['clockOrigin'],'collectionCount':len(rows),'persistenceCount':len(persistence),'writerCount':len(spans),
            'writerOverlapCount':sum(any(p['start']<w['end'] and w['start']<p['end'] for p in intervals) for w in spans),
            'protocolWindowOverlap':'inapplicable: controlled synthetic protocol and actual host monotonic are distinct clocks'}
    return {'bytes':stream['bytes'],'sha256':stream['sha256'],'blocks':stream['blocks'],'protocolRecords':normal['records'],'protocolSha256':stream['protocolSha256'],'producerSeconds':pr['ended']-pr['started'],'peakBytesPerSecond':pr['peakBytesPerSecond'],'limits':limits,'polls':poll,'overlap':overlap,'processesGone':True,'socketGone':True}

def verify(root,proof_path):
    run=verify_inputs(root);c.require(not run['smoke'],'seconds-long smoke is not lifetime proof')
    result=verify_capture(root);binding=run|c.load(root/'start.json');proof=c.load(proof_path);result['turnProof']=verify_turn(binding,proof)
    c.immutable(root/'verified.json',result);return result

def main():
    os.umask(0o077);p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','start','verify','produce','read-evidence']);p.add_argument('run',type=Path);p.add_argument('--nonce');p.add_argument('--receipt',type=Path);p.add_argument('--rollout',type=Path);p.add_argument('--turn-proof',type=Path);p.add_argument('--smoke-seconds',type=float);p.add_argument('--native-smoke',action='store_true');a=p.parse_args();root=a.run.resolve()
    if a.mode=='prepare':result=prepare(root,a.smoke_seconds,a.native_smoke)
    elif a.mode=='start':result=start(root,a.nonce)
    elif a.mode=='verify':result=verify(root,a.turn_proof)
    elif a.mode=='read-evidence':result=evidence_read(verify_inputs(root)|c.load(root/'start.json'),a.receipt,a.rollout,a.nonce)
    else:return produce(root)
    print(json.dumps(result));return 0
if __name__=='__main__':
    if sys.argv[1]=='produce':
        import phase_probe
        phase_probe.install(None,Path(sys.argv[2]),'producer')
    sys.exit(main())
