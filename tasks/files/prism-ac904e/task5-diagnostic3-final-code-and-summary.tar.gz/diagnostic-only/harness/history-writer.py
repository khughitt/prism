import os,sys,time,signal
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'code'));import phase_probe
out=Path(sys.argv[1]);phase_probe.install(None,out,'writer');source=out/'host.log';start=time.monotonic();next_write=start
signal.signal(signal.SIGTERM,lambda *args:sys.exit(0))
while time.monotonic()-start<8:
 now=time.monotonic()
 if now<next_write:time.sleep(min(.002,next_write-now));continue
 raw=b'D'*68249+b'\n'
 if source.stat().st_size+len(raw)>1048576:source.replace(source.with_name('host.log.1'));source.write_bytes(b'')
 with source.open('ab',buffering=0) as f:f.write(raw);os.fsync(f.fileno())
 next_write=now+.1
