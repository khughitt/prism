"""Diagnostic replay of retained-history shape; never an original-run continuation."""
import os,sys,json,shutil,time,multiprocessing,signal
from pathlib import Path
os.umask(0o077);base=Path(__file__).parent;out=base/'history21-8s';out.mkdir(mode=0o700);sys.path.insert(0,str(base/'code'));import logs,capture as cap,phase_probe
old=base.parents[1]/'runs/task5-rehearsal-fix2-6b6f791b7f6b4c56ac30ca120e818b32';m=json.loads((old/'manifest.json').read_text());last=m['segments'][-1];source=out/'host.log';source.write_bytes((old/last['path']).read_bytes());st=source.stat();manifest=out/'manifest.json'
for row in m['segments'][:-1]:shutil.copyfile(old/row['path'],out/row['path'])
last.update(dev=st.st_dev,inode=st.st_ino,path=f"segment-{last['generation']:06d}-{st.st_dev}-{st.st_ino}.raw");shutil.copyfile(source,out/last['path']);m['log']=str(source);m['current'].update(dev=st.st_dev,inode=st.st_ino);logs.save(manifest,m)
stop=multiprocessing.get_context('fork').Event()
def writer():
 phase_probe.install(None,out,'writer');at=time.monotonic();next_write=at
 while not stop.is_set() and time.monotonic()-at<8:
  now=time.monotonic()
  if now<next_write:time.sleep(min(.002,next_write-now));continue
  raw=b'D'*68249+b'\n'
  if source.stat().st_size+len(raw)>1048576:source.replace(source.with_name('host.log.1'));source.write_bytes(b'')
  begin=time.monotonic()
  with source.open('ab',buffering=0) as f:f.write(raw);os.fsync(f.fileno())
  next_write=now+.1
p=multiprocessing.get_context('fork').Process(target=writer);owner=None;rows=[];samples=[];failure=None
phase_probe.install(cap,out,'collector');owner=logs.Capture(manifest)
# Spawn via exec so the writer has fresh telemetry, not inherited collector wrappers.
import subprocess
p=subprocess.Popen([sys.executable,str(base/'history-writer.py'),str(out)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);writer_id=cap.process(p.pid)
started=time.monotonic();gap=.36774617568190315
try:
 with (out/'polls.jsonl').open('x') as records:
  while p.poll() is None:
   begin=time.monotonic();before=len(owner.state['segments']);owner.poll()
   if len(owner.state['segments'])!=before:owner.checkpoint('rotation')
   work_end=time.monotonic();row={'start':begin,'end':work_end,'workSeconds':work_end-begin}
   records.write(json.dumps(row)+'\n');records.flush();os.fsync(records.fileno());persist_end=time.monotonic();row['persistenceEnd']=persist_end
   cap.atomic(out/'heartbeat.json',{'generation':len(owner.state['segments']),'at':persist_end});row['heartbeatEnd']=time.monotonic();rows.append(row)
   samples.append({'at':time.monotonic(),'deviceStat':Path('/sys/class/block/nvme0n1/stat').read_text(),'ioPressure':Path('/proc/pressure/io').read_text(),'collectorSchedstat':Path(f'/proc/{os.getpid()}/schedstat').read_text()})
   if work_end-begin>gap or persist_end-begin>gap:failure='diagnostic work/persistence exceeds unchanged bound';break
   time.sleep(.1)
finally:
 if p.poll() is None:p.terminate()
 stdout,stderr=p.communicate(timeout=5)
 if owner:owner.close()
 (out/'diagnostic-result.json').write_text(json.dumps({'diagnosticOnly':True,'seedSegments':21,'seconds':time.monotonic()-started,'failure':failure,'writerExit':p.returncode,'writer':writer_id,'writerGone':not cap.same_process(writer_id),'rows':rows,'samples':samples,'writerStdout':stdout.decode(),'writerStderr':stderr.decode()},indent=2)+'\n')
 print(json.dumps({'diagnosticOnly':True,'failure':failure,'cycles':len(rows),'maxWork':max(x['workSeconds'] for x in rows),'maxWorkPersistence':max(x['persistenceEnd']-x['start'] for x in rows),'writerGone':not cap.same_process(writer_id)}))
