"""One bounded independent same-filesystem diagnostic, never qualification."""
import sys,os,json,time,subprocess,signal
from pathlib import Path
os.umask(0o077);base=Path(__file__).parent;sys.path.insert(0,str(base/'code'));import rehearse as r,controller as c,capture as cap
out=base/sys.argv[1];seconds=float(sys.argv[2]);r.prepare(out,seconds);cfg=c.load(out/'collector.json');samples=[];ids={};started=time.monotonic()
(out/'host-load-before.txt').write_text(subprocess.check_output(['host-load','--section','load'],text=True))
(out/'filesystem.txt').write_text(subprocess.check_output(['findmnt','-T',str(out),'-o','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True))
def sample():
 row={'at':time.monotonic(),'deviceStat':Path('/sys/class/block/nvme0n1/stat').read_text().strip(),'ioPressure':Path('/proc/pressure/io').read_text(),'cpuPressure':Path('/proc/pressure/cpu').read_text(),'actors':{}}
 for name,identity in ids.items():
  try:row['actors'][name]={'schedstat':Path(f"/proc/{identity['pid']}/schedstat").read_text().strip(),'io':Path(f"/proc/{identity['pid']}/io").read_text()}
  except FileNotFoundError:pass
 samples.append(row)
try:
 r.start(out,c.load(out/'run.json')['runNonce']);end=time.monotonic()+30
 while time.monotonic()<end:
  if (out/'processes.json').exists():ids=c.load(out/'processes.json')
  sample()
  if (out/'receipt.json').exists():
   receipt=c.load(out/'receipt.json')
   if 'wrapperEnded' in receipt:break
  time.sleep(.02)
 else:raise AssertionError('bounded diagnostic timeout')
 receipt=c.load(out/'receipt.json');result={'diagnosticOnly':True,'receipt':receipt,'seconds':time.monotonic()-started}
 if receipt['integrityComplete']:
  try:result['boundedChecks']=r.verify_capture(out)
  except BaseException as e:result['boundedCheckError']=str(e)
 c.immutable(out/'diagnostic-result.json',result)
 print(json.dumps({'diagnosticOnly':True,'exitReason':receipt['exitReason'],'error':receipt['error'],'seconds':result['seconds'],'complete':receipt['integrityComplete']}))
finally:
 cap.tmux(cfg,'kill-server',check=False)
 for identity in ids.values():cap.terminate(identity)
 deadline=time.monotonic()+3
 while any(cap.same_process(x) for x in ids.values()) and time.monotonic()<deadline:time.sleep(.02)
 remaining={k:v for k,v in ids.items() if cap.same_process(v)}
 c.immutable(out/'diagnostic-samples.json',samples);c.immutable(out/'diagnostic-cleanup.json',{'processes':ids,'remaining':remaining});assert not remaining,remaining
