# Third headless rehearsal failure

Failed after 944.356 seconds. This packet preserves portable failure facts and hashes only. Private raw originals remain in the durable private run directory. No complete lifetime, native-workload, error-count or live-performance certification. Exact stat tuples at the failed publication assertion were not saved; historical cause is uncertain. All four owned actors and the named server exited.
