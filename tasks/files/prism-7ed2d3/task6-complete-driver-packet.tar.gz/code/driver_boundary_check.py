"""Bounded negative driver checks, with only temporary synthetic effects."""
import hashlib,importlib.util,json,pathlib,tempfile,types,unittest,sys,time
from unittest.mock import patch
N=pathlib.Path(__file__).resolve().parent
def mod(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
d=mod('driver',N/'packet_driver.py');S=pathlib.Path(json.loads((N/'inputs.json').read_text())['corrected']);c=mod('controller',S/'code/controller.py')

class Boundary(unittest.TestCase):
    def test_dispatch_reserves_attempt_before_exec_and_refuses_replay(self):
        with tempfile.TemporaryDirectory(prefix='synthetic-dispatch-') as folder:
            root=pathlib.Path(folder);master=root/'master.json';contract=root/'contract.json';action='panel-close'
            spec={'argv':['/usr/bin/python3.14',str(N/'packet_driver.py'),'dispatch',str(master),'B1',action]}
            session={'sessionId':'synthetic','runId':'synthetic-run','clockOrigin':'synthetic-clock','identity':{'activationNonce':'synthetic-nonce'},'hostActions':{action:spec}}
            session_sha=c.immutable(root/'session.json',session)
            attempt={'id':'synthetic-attempt','action':action,'phase':'preparing','started':time.monotonic(),'status':'pending'}
            c.immutable(root/'state.json',{'attempts':[attempt]});c.immutable(root/'attempt-synthetic-attempt.json',attempt)
            (root/'permits').mkdir();c.immutable(root/'permits'/'synthetic-permit',{'action':action,'permit':{'arguments':spec,'issuedAt':attempt['started']-1,'expiresAt':attempt['started']+30}})
            expected={'sessionId':'synthetic','runId':'synthetic-run','clockOrigin':'synthetic-clock','activationNonce':'synthetic-nonce','sessionFileSha256':session_sha}
            ctsha=c.immutable(contract,{'runRoot':str(root),'expected':expected})
            entry={'label':'B1','runRoot':str(root),'sessionSha256':session_sha,'contracts':{'panel-close@original':str(contract)},'contractSha256':{'panel-close@original':ctsha}}
            msha=c.immutable(master,{'activations':[entry],'helpers':str(S/'helpers'),'interpreters':{'python':'/usr/bin/python3.14'}})
            c.immutable(root/'actual-review.json',{'accepted':True,'synthetic':False,'masterSha256':msha})
            with patch.object(d.os,'execv',side_effect=RuntimeError('synthetic exec boundary')) as execute:
                with self.assertRaisesRegex(RuntimeError,'synthetic exec boundary'):d.dispatch(str(master),'B1',action)
                with self.assertRaises(FileExistsError):d.dispatch(str(master),'B1',action)
                self.assertEqual(execute.call_count,1)
    def test_complete_seed_and_late_remaining_reserve(self):
        self.assertEqual(c.reserve([36,21,20,67]),180)
        with self.assertRaisesRegex(ValueError,'approval'):c.reserve([36,21,20,68])
        w=c.Window(1000,{'pre':36,'post':21,'recovery':20,'finish':67})
        self.assertTrue(w.can_initial(1001,135));self.assertFalse(w.can_initial(1166,135))
        self.assertFalse(w.valid_reserve(134));self.assertTrue(w.valid_reserve(109,True));self.assertFalse(w.valid_reserve(108,True))
    def test_uncertain_effect_stops_abort_without_replay(self):
        with tempfile.TemporaryDirectory(prefix='synthetic-command-') as folder:
            root=pathlib.Path(folder);calls=[]
            def uncertain(action,auth,args):calls.append(action);raise TimeoutError('synthetic uncertainty')
            obj=c.Controller(root,{'environment':'synthetic','hostActions':{'plugins-enable':{}}},types.SimpleNamespace(invoke=uncertain))
            with self.assertRaises(ValueError):obj.invoke('plugins-enable','synthetic')
            driver=d.Driver.__new__(d.Driver);driver.controller=lambda label:(obj,{},{});driver.audit=lambda *a:None
            with self.assertRaisesRegex(ValueError,'unresolved'):driver.abort('B1','synthetic invalid cleanup')
            self.assertEqual(calls,['plugins-enable']);self.assertFalse((root/'administrative-stop.json').exists())
            self.assertEqual(obj.state['attempts'][0]['status'],'uncertain')
    def test_phase_uses_owned_pointer_history_before_exact_attempt(self):
        with tempfile.TemporaryDirectory(prefix='synthetic-phase-') as folder:
            root=pathlib.Path(folder)
            a={'id':'close-before','action':'panel-close','status':'completed'}
            b={'id':'swap','action':'pointer-swap','status':'completed','result':{'from':'original','to':'active'}}
            e={'id':'close-after','action':'panel-close','status':'completed'}
            f={'id':'inverse','action':'pointer-restore','status':'completed','result':{'from':'active','to':'original'}}
            g={'id':'restore','action':'plugins-restore','status':'pending'}
            c.immutable(root/'state.json',{'attempts':[a,b,e,f,g]})
            for action in (b,f):c.immutable(root/('result-'+action['id']+'.json'),{'action':action['action'],'result':action['result']})
            self.assertEqual(d.source_phase(root,a),'original');self.assertEqual(d.source_phase(root,e),'active');self.assertEqual(d.source_phase(root,g),'original')
            (root/'result-swap.json').write_text('{}')
            with self.assertRaises((KeyError,ValueError)):d.source_phase(root,e)

if __name__=='__main__':unittest.main()
