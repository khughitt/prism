"""Synthetic tests of driver trust boundaries; never actual owner authority."""
import copy, importlib.util, pathlib, unittest
HERE=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('packet_driver', HERE/'packet_driver.py')
d=importlib.util.module_from_spec(s);s.loader.exec_module(d)

class OwnerBoundary(unittest.TestCase):
    def setUp(self):
        self.binding={'sessionId':'synthetic-group','runId':'synthetic-run','cardId':'synthetic-card','masterSha256':'a'*64}
        self.good=dict(self.binding,kind='completion',author='root-controller',synthetic=False,receivedAt=12.0,
                       provenance={'harness':'codex','rootSessionId':'synthetic-root','messageId':'fixture-human-message','human':True})
    def test_reject_synthetic_at_live_front_door(self):
        bad=self.good|{'synthetic':True}
        with self.assertRaises(ValueError): d.validate_owner(bad,'completion',self.binding,10,13)
    def test_reject_wrong_card_master_and_reply_before_issue(self):
        for change in ({'cardId':'old-card'},{'masterSha256':'b'*64},{'receivedAt':9.0}):
            with self.subTest(change=change),self.assertRaises(ValueError):
                d.validate_owner(self.good|change,'completion',self.binding,10,13)
    def test_require_actual_human_provenance(self):
        bad=self.good|{'provenance':{'human':False}}
        with self.assertRaises(ValueError):d.validate_owner(bad,'completion',self.binding,10,13)
    def test_matching_receipt(self):
        self.assertEqual(d.validate_owner(self.good,'completion',self.binding,10,13),self.good)

if __name__=='__main__':unittest.main()
