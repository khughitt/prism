"""External-effect fixture for synthetic smoke only; refuses a non-synthetic contract."""
import json,os,shutil,sys
from pathlib import Path
action=sys.argv[1];ct=json.loads(Path(sys.argv[2]).read_text());assert ct['synthetic'] is True
root=Path(ct['runRoot']);statepath=root/'fixture-state.json'
def write(path,value):Path(path).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
state=json.loads(statepath.read_text()) if statepath.exists() else {'pointer':'original','scratch':{'synthetic':1},'enabled':True,'timer':False}
result={}
if action=='state-snapshot':
    b=json.loads(Path(ct['bundle']).read_text());write(root/'snapshot-bundle.json',b);write(root/'saved-state.json',b['saved'])
    write(root/'clock-verified.json',{'synthetic':True,'verified':False})
if action=='state-clear':state['scratch']={}
if action=='plugins-disable':state['enabled']=False
if action=='plugins-enable':
    state['enabled']=True
    with Path(ct['log']).open('ab',buffering=0) as f:f.write(Path(ct['initial']).read_bytes());os.fsync(f.fileno())
if action=='plugins-restore':state['enabled']=True
if action=='state-restore':state['scratch']={'synthetic':1}
if action=='pointer-swap':state['pointer']='active'
if action=='pointer-restore':state['pointer']='original'
if action=='restore-verify':
    assert state=={'pointer':'original','scratch':{'synthetic':1},'enabled':True,'timer':False}
    result={'documentsEqual':True,'scratchExact':True,'activeMatchesExpected':True,'canonicalMatchesExpected':True,'pluginStateExact':True,'pointerExact':True,'timerExact':True,'synthetic':True}
write(statepath,state);print(json.dumps(result))
