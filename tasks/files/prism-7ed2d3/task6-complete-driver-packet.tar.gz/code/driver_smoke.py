"""Small real collector/producer/controller/driver smoke, entirely synthetic host effects."""
import copy, importlib.util, json, os, signal, subprocess, sys, time, types, uuid
from pathlib import Path
N=Path(__file__).resolve().parent;os.umask(0o077)
def load(path):return json.loads(Path(path).read_bytes())
def mod(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
inputs=load(N/'inputs.json');S=Path(inputs['corrected']);C=S/'code';H=S/'helpers';sys.path[:0]=[str(C),str(H)]
d=mod('packet_driver',N/'packet_driver.py');c=mod('smoke_controller',C/'controller.py');cap=mod('smoke_capture',C/'capture.py');builder=mod('smoke_builder',C/'frozen-task2/build.py')
OUT=N/('smoke-'+uuid.uuid4().hex);OUT.mkdir(mode=0o700);(OUT/'actual').mkdir(mode=0o700)
source_inputs=load(Path(inputs['readonlyInputs'])/'packet-inputs-v3.json');model=load(source_inputs['currentDescribe'])
modelpath=OUT/'model.lua';modelpath.write_text('return '+builder.lua(model)+'\n')
manifest={'sessionId':'synthetic-group-'+uuid.uuid4().hex,'activations':[],'initialRemainingReserve':135,'steps':{'pre':36,'post':21,'recovery':20,'finish':67},'sourceProof':str(OUT/'synthetic-proof.json')}
c.immutable(OUT/'synthetic-proof.json',{'synthetic':True,'observed':{'running':{'pid':os.getpid()}}})
manifest['outer']={'journal':str(OUT/'outer-journal.json')}
driver=d.Driver.__new__(d.Driver);driver.root=OUT;driver.m=manifest;driver.master_sha='synthetic-master';driver.c=c;driver.cap=cap
driver.audit=lambda *args,**kwargs:None
driver.note=lambda text:None
def outer(action):
    c.atomic(Path(manifest['outer']['journal']),{'synthetic':True,'stage':'paused' if action=='begin' else 'restored'});return {'synthetic':True}
driver.outer=outer
def batch(entry,session,actions):
    now=time.monotonic();path=OUT/'actual'/('synthetic-auth-'+uuid.uuid4().hex+'.json')
    c.immutable(path,{'synthetic':True,'approved':True,'author':'root-controller','sessionId':session['sessionId'],'runId':session['runId'],
      'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
      'permits':[{'id':uuid.uuid4().hex,'action':a,'arguments':session['hostActions'][a],'issuedAt':now,'expiresAt':now+55} for a in actions]})
    return path
driver.batch=batch
def current(ct,mode):
    bundle=load(Path(ct['runRoot'])/'snapshot-bundle.json');saved=bundle['saved'];return {'runtime':{'active':saved['runtime']['active'],'scratch':{}},'canonical':saved['profiles'][saved['pair']['P']]}
driver.host=types.SimpleNamespace(state_verify=current,source_observation=lambda ct:{'synthetic':True})
owned=[];results=[]
def run(argv,**kw):
    result=subprocess.run(argv,cwd=source_inputs['repo'],capture_output=True,text=True,timeout=20,**kw)
    assert result.returncode==0,(argv,result.stdout,result.stderr);return result.stdout
def prepare(label,variant,block,launch,scenario='handoff'):
    file_label=label+'-'+uuid.uuid4().hex[:6];built=OUT/('build-'+file_label);root=OUT/('run-'+file_label);nonce='synthetic-'+uuid.uuid4().hex;cli=source_inputs['repo']+'/bin/prism'
    args=['/usr/bin/python3.14',str(C/'frozen-task2/build.py'),'--baseline','9bf4e8e920c005f8a4d1666b32b4e1a516856ac2','--candidate','e7384b0d7ab3e8e935cdf0776043839441132af5','--cli',cli,'--output',str(built),'--nonce',nonce,'--block',block,'--cold-pairs','1','--launch-pairs',str(launch),'--stage','stage1','--environment','synthetic','--run-id',nonce,'--clock-origin','synthetic-clock-'+nonce]
    run(args);prefix=OUT/('producer-'+file_label)
    started=time.monotonic()+2
    run(['/usr/bin/lua',str(C/'controller-producer.lua'),str(built),str(modelpath),str(C/'frozen-task2/test_encode.lua'),cli,scenario,variant,str(prefix)],env=os.environ|{'FIXTURE_START':str(started)})
    meta=load(str(prefix)+'-meta.json');identity=load(built/variant/'identity.json');values={p['key']:p['value'] for p in meta['initialModel']['params']}
    P=meta['initialModel']['active']['profile'];Q=next(p for p in model['profiles'] if p!=P)
    bundle={'saved':{'documents':{},'pair':{'P':P,'Q':Q},'profiles':{P:values,Q:copy.deepcopy(values)},'runtime':{'active':meta['initialModel']['active'],'scratch':{'synthetic':1}},'uneditedNumeric':[{'key':'glass.inactive.roughness'}]},
            'resolverSources':{},'definitions':{p['key']:{k:p[k] for k in ('type','range') if k in p} for p in model['params']}}
    bundlepath=OUT/(file_label+'-bundle.json');c.immutable(bundlepath,bundle)
    log=OUT/(file_label+'-host.log');log.write_text('synthetic outside start offset\n')
    socket='prism-budget-capture-synthetic-'+uuid.uuid4().hex
    cfg={'schema':2,'environment':'synthetic','runId':identity['runId'],'clockOrigin':identity['clockOrigin'],'socket':socket,'deadlineSeconds':2700,'pollSeconds':.1,'maxGapSeconds':2,'log':str(log)}
    for key in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[key]=str(root/(key+'.json'))
    cfgfile=OUT/(file_label+'-collector.json');c.immutable(cfgfile,cfg);owned.append((root,cfg))
    ct={'synthetic':True,'runRoot':str(root),'bundle':str(bundlepath),'log':str(log),'initial':str(prefix)+'-initial.log','pointerPath':str(OUT/(file_label+'-pointer'))}
    Path(ct['pointerPath']).symlink_to('synthetic-original');ctpath=OUT/(file_label+'-contract.json');c.immutable(ctpath,ct)
    actions={a:{'argv':['/usr/bin/python3.14',str(N/'smoke_host.py'),a,str(ctpath)],'timeoutSeconds':5,'json':True} for a in ('rotation-snapshot','rotation-pause','state-snapshot','state-clear','panel-close','plugins-disable','plugins-enable','export-ready','panel-open','plugins-restore','state-restore','rotation-resume','restore-verify')}
    # Native RootHost pointer mutation is exercised on a synthetic private symlink.
    actions['pointer-swap']={'path':ct['pointerPath'],'from':'synthetic-original','to':'synthetic-active'}
    actions['pointer-restore']={'path':ct['pointerPath'],'from':'synthetic-active','to':'synthetic-original'}
    actions['collector-launch']={'argv':['/usr/bin/python3.14',str(C/'capture.py'),'launch',str(root/'run.json')],'timeoutSeconds':10,'json':False}
    for a in ('checkpoint-authorize','finish-authorize','stop-authorize'):actions[a]={}
    session={'sessionId':manifest['sessionId'],'runId':identity['runId'],'clockOrigin':identity['clockOrigin'],'environment':'synthetic','identity':identity,'pilot':True,'buildRoot':str(built/variant),
             'steps':{'pre':36,'post':21,'recovery':20,'finish':67},'snapshotBundle':str(root/'snapshot-bundle.json'),'hostActions':actions}
    drainct=OUT/(file_label+'-drain.json');actions['final-drain']={'argv':['/usr/bin/python3.14',str(H/'drain.py'),str(drainct)],'timeoutSeconds':15,'json':True}
    sessionfile=OUT/(file_label+'-session.json');sessionhash=c.immutable(sessionfile,session)
    c.immutable(drainct,{'synthetic':True,'codeRoot':str(C),'runRoot':str(root),'expected':{'sessionFileSha256':sessionhash,'sessionId':session['sessionId'],'runId':identity['runId'],'clockOrigin':identity['clockOrigin'],'activationNonce':identity['activationNonce']}})
    entry={'label':label,'runRoot':str(root),'session':str(sessionfile),'collector':str(cfgfile),'sourceContracts':{'active':str(ctpath),'original':str(ctpath)}}
    manifest['activations'].append(entry);return entry,meta
def stopped(signum,frame):raise SystemExit(128+signum)
for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,stopped)
try:
    sequence=[] if '--negative-only' in sys.argv else [('B1','baseline','1',1),('C1','candidate','1',1),('C2','candidate','2',0),('B2','baseline','2',0)]
    for label,variant,block,launch in sequence:
        entry,meta=prepare(label,variant,block,launch);card=driver.start(label)
        root=Path(entry['runRoot']);obj,entry,session=driver.controller(label)
        # A synthetic reply is passed only to the continuation behind the live front door.
        # Real producer chronology is retained; wait for its short synthetic dwell to elapse.
        delay=meta['initialReply']-time.monotonic()+.02
        if delay>0:time.sleep(delay)
        reply={'synthetic':True,'receivedAt':meta['initialReply'],'provenance':{'messageId':'synthetic-'+label}}
        result=driver.completed_reply(obj,entry,session,reply);results.append(result)
        print('PASS driver lifecycle',label,'restored',load(root/'driver-result.json')['restored'],'collection',load(root/'driver-result.json')['collectionGate'],flush=True)
    if results:assert results[-1]['collectionGate'] is True and results[-1]['accepted'] is False and results[-1]['nextStageEligible'] is False
    if '--negative-only' in sys.argv:
        manifest['activations']=[];manifest['outer']={'journal':str(OUT/'short-outer-journal.json')}
        entry,meta=prepare('B1','baseline','1',1,'shortlaunch-gainpass-handoff');driver.start('B1')
        obj,entry,session=driver.controller('B1')
        delay=meta['initialReply']-time.monotonic()+.02
        if delay>0:time.sleep(delay)
        short=driver.completed_reply(obj,entry,session,{'synthetic':True,'receivedAt':meta['initialReply'],'provenance':{'messageId':'synthetic-short'}})
        assert short['restored'] is True and short['collectionGate'] is False and short['noRecoveryIssued'] is True
        assert not (Path(entry['runRoot'])/'recovery.json').exists()
        print('PASS short class stays inconclusive; restored without automatic recovery',flush=True)
    # Wrong current source/reference refuses before card, then known effects restore
    # through the explicitly invalid administrative path with no invented reply.
    manifest['activations']=[];manifest['outer']={'journal':str(OUT/'abort-outer-journal.json')}
    entry,meta=prepare('B1','baseline','1',1)
    driver.host.state_verify=lambda ct,mode:current(ct,mode)|{'canonical':{'wrong':1}}
    try:driver.start('B1');raise AssertionError('wrong initial reference accepted')
    except ValueError as error:assert 'canonical' in str(error)
    finally:driver.host.state_verify=current
    root=Path(entry['runRoot']);assert not (root/'owner-card.txt').exists()
    stopped=driver.abort('B1','synthetic pre-card wrong-reference refusal')
    assert stopped['restored'] is True and stopped['collectionGate'] is False
    assert not (root/'initialCompleteReceived.json').exists() and not (root/'restoration.json').exists()
    print('PASS driver invalid pre-card stop/restoration; no owner reply or normal certificate',flush=True)
    c.immutable(OUT/'smoke-result.json',{'synthetic':True,'normalFourActivations':bool(results),'collectionGate':True if results else False,'performance':'inconclusive n1','result':results[-1] if results else {'negativeCasesPassed':True}})
finally:
    cleanup=[]
    for root,cfg in owned:
        ids=load(root/'identities.json') if (root/'identities.json').exists() else {}
        if ids.get('server') and cap.same_process(ids['server']):cap.tmux(cfg,'kill-server',check=False)
        deadline=time.monotonic()+4
        while any(cap.same_process(p) for p in ids.values()) and time.monotonic()<deadline:time.sleep(.01)
        remaining={k:v for k,v in ids.items() if cap.same_process(v)}
        cleanup.append({'root':str(root),'socket':cfg['socket'],'processes':ids,'remaining':remaining});assert not remaining
    c.immutable(OUT/'cleanup.json',{'synthetic':True,'actors':cleanup})
    print('CLEANUP',len(cleanup),'owned actor groups, none remaining',flush=True)
print('PASS complete synthetic driver verdict',OUT,flush=True)
