# Complete inert Task6 packet

Exact new source is in code/ and full text changes.diff. Every source byte matches the private packet; source hashes are in private-binding-hashes.json. The unchanged accepted source/helper archives are identified by source-inventories.json.

Contracts, master, commands and build evidence use normalized role paths and clock identifiers. Their private SHA256 values refer to the private original bytes and intentionally do not equal normalized file hashes. These copies cannot authorize or run a host operation. Root retains the exact private files and must review them before fresh permission.

No owner model, log, store, raw clock/source proof, actual paths or permits is included. The private failed smoke artifacts remain retained; portable evidence contains only outcomes, counts, hashes and normalized test output. Synthetic lifecycle timings provide no live allowance.

The owner handoff asks for ten seconds visible after the controls settle and the action button disappears, then close and report completion. This guidance leaves the unchanged five-second stable-drain gate and UI intact.

SHA256SUMS covers every archive payload other than itself. Code, full diff and member bytes are read back and verified after packaging.
