# Task6 private helper handoff — root review required

This packet is inert preparation, not host authorization. It supplements the four n=1 proposals in task6-pilot-preparation-v2. No accepted runtime file changed. Root owns current observations, command/session materialization, exact permits, owner permission, live execution and cleanup. Helper paths below are placeholders in argv arrays, not executable shell snippets. Resolve every placeholder to a private absolute path before review; no live session/permit was created by this worker.

## Source-backed host commands

`host.py` uses fixed `/usr/bin/noctalia msg` argument arrays, timeout3s, captures both channels. Mutations require exit0 plus exact `ok\n`; enable additionally accepts exact `ok (exporting in background)\n` as an enable receipt. The pinned IPC client maps an `error:` response to exit1, so this validates both channels; it is not evidence of a Noctalia exit-zero error defect.

Read-only registration is exactly `["/usr/bin/noctalia","msg","panel-close",":"]`. The helper requires exit1 and exact `error: unknown panel ":" (available: ID, ID)\n`, or its no-available form. It rejects malformed/duplicate IDs and sentinel registration, and matches the exact ID `khughitt/prism:panel`. A prefix/suffix match is insufficient. Async enable is followed by this registration observation and a separately captured fresh activation identity; it is never readiness itself.

The eight files in sentinel-source.json match both pinned Git revision6ef43e2 and working bytes. Every registration is either a fixed builtin (clipboard, session, test, control-center, launcher, wallpaper, tray-drawer, polkit, setup-wizard) or a resolved plugin entry. Plugin manifests require author/plugin, with full ID manifest.id + colon + entry.id. Persistent registration forwards to the same manager. Bare colon cannot occur. Unknown membership is checked before any close. Root must maintain the running binary/package/source binding separately; helper source hashes alone do not prove a running binary.

## Concrete argv proposals

All command hostActions have `json:true`; root supplies a timeout ceiling and explicit environment. Fixed wrapper commands are:

| Action | Exact argv template | Successful evidence |
| --- | --- | --- |
| panel-close | ["python","HELPERS/host.py","panel-close","CONTRACT"] | exact IPC success receipt |
| panel-open | ["python","HELPERS/host.py","panel-open","CONTRACT"] | exact IPC success receipt |
| plugins-disable | ["python","HELPERS/host.py","plugins-disable","CONTRACT"] | exact IPC success receipt |
| plugins-enable | ["python","HELPERS/host.py","plugins-enable","CONTRACT"] | exact enable receipt, possibly exportPending |
| export-ready | ["python","HELPERS/host.py","export-ready","CONTRACT"] | fresh exact registration, then separate raw activation gate |
| plugins-restore | ["python","HELPERS/host.py","plugins-restore","CONTRACT"] | exact enable/disable plus bounded registration for saved priorEnabled |
| final-drain | ["python","HELPERS/drain.py","CONTRACT"] | independently reread physical/raw terminal evidence |
| restore-verify | ["python","HELPERS/host.py","restore-verify","CONTRACT"] | combined independent state/pointer/plugin/timer proof |
| reconcile-ACTION | ["python","HELPERS/reconcile.py","CONTRACT","ACTION"] | bound attemptId/action/outcome/receipt, or refusal |

Current state for issue is `["python","HELPERS/host.py","current","CONTRACT"]`; its JSON has runtime and canonical fields. It checks the fresh setup snapshot, exact documents and empty test scratch under the store lock.

Retain accepted mutation interfaces: rotation snapshot/pause/resume `["python","CODE/rotation-guard.py","snapshot|pause|resume","JOURNAL"]`; snapshot `["node","CODE/snapshot.mjs","BUNDLE","SAVED"]`; clear/restore `["node","CODE/state.mjs","clear|restore","SAVED"]`; collector launch `["bash","CODE/capture-wrapper.sh","COLLECTOR_CONFIG"]`. For state commands, explicitly bind PRISM_TASK3_REPO, PRISM_CONFIG_DIR and PRISM_STATE_DIR. Only authorized mutations receive PRISM_TASK3_APPROVED=yes or PRISM_ROTATION_RETRY_APPROVED=yes. Pointer swap/restore use RootHost's native exact `{path,from,to}` inverse literal endpoints and journal. Control authorizations remain RootHost builtins.

No wrapper retries a mutation or waits indefinitely. export-ready and plugins-restore now share the same bounded registration wait: a four-second monotonic action deadline, leaving one second within the existing five-second outer timeout. Restoration enable/disable consumes that same deadline before registration is checked; it cannot receive a fresh wait budget. Each IPC timeout is min(three seconds, remaining action time); a late successful reply still refuses. Only an exact successfully parsed sentinel observation with registration opposite the expected boolean is retried, with at most100ms sleep and a fresh matching enabled catalog observation each time. Source/response/exit/ID/catalog conflicts and command failures propagate immediately. Raw IPC receipts/timestamps and each complete registration poll are emitted on stderr for durable RootHost capture, including polls before failure; successful stdout also contains the poll list. Async plugins-enable alone remains a receipt, followed by export-ready. Independent restore verification still checks every original field after plugins-restore. Concrete outer timeout proposals: fixed IPC5s, current15s, final-drain15s, restore-verify60s, reconcile60s. Rotation snapshot can make four systemctl calls with10s each; restore verification adds up to6s IPC plus10s state. These ceilings are prospective limits, not measured duration claims. Root may tighten after actual read-only measurement and review; a timeout creates an uncertain attempt that must be reconciled before any next effect.

## Contract and immutable provenance

`contract-template.json` names required paths/fields. Root fills repo, codeRoot, sourceRoot, snapshotBundle, savedState, runRoot, pointerPath, originalPointer, priorEnabled, rotationJournal and explicit stateEnvironment. Expected binds sessionId/runId/clockOrigin/activationNonce and exact session.json byte hash. All paths refer to the correct activation; priorEnabled is an observed boolean, not a guessed default.

Materialize the immutable session first, then its private helper contract with sessionFileSha256. Do not put that contract's hash inside the session being hashed: that would create a hash cycle. Freeze helper source hashes in session.artifactSha256; retain the contract hash separately in root's reviewed materialization manifest and exact permit provenance. Root must verify the private contract is unchanged before each permit. Initial n=1 proposals are still inert and cannot be executed until this concrete binding is completed and reviewed.

## Independent restoration and abort drain

state-verify.mjs acquires the existing store lock, compares all raw profile/base documents, definitions and five resolver-source hashes, exact scratch, and active owner fields. Restored mode preserves the latest current wallpaper exactly as accepted state.mjs does, then independently derives canonical values from saved scratch and current wallpaper. Before mode also compares raw runtime bytes. It never calls clear/restore. Combined verification additionally observes the literal symlink, parsed enabled catalog state, exact registry membership, timer/service unit configuration and actual activation timestamps against the completed rotation journal. Originally inactive timers retain exact before state; originally active timers match the journal's resumedState. Missing, partial, conflicting or unknown data refuses.

Normal final-drain binds actual session bytes, run/clock/nonce, receipt and collector-start stamp; all three named process identities must be gone. It reruns accepted inspect_run with the saved raw prefix, requires exact final audit/inspection equality, complete raw capture, one physical-drain certificate, the exact handoff/observerSnapshot/close/observerFlush/handoffClosed terminal tail and final reference. Raw manifest, receipt, certificate and raw hashes are returned.

Root must close the actual panel AFTER the owner's settled reply and BEFORE the first inspect/checked checkpoint. `operation_gates` checks the visible dwell through reply; `verify_final_observations` freezes the checked evidence and refuses a later close. This precise ordering replaces the earlier overly broad 'close before finish' advice.

Controller.restore invokes final-drain for stopped runs too. The separate `physical-only-abort` path leaves protocolComplete and coldProtocolComplete false, including when a short collection has invalid reasons. It reruns inspect_run without promoting capture completeness; requires actual closed-tail/reference evidence, error-free stop receipt, reaped identities and an independently stable source extent. The uniquely identified current held source (log or its single backup) must match the last archive dev/inode/generation/end offset and exact bytes, with size/mtime/ctime stable across the read. Any unarchived tail, lost source, ambiguous identity, absent action card/actual reply, missing handoff or source error refuses. It never manufactures a completion certificate or edits controller state.

## Reconciliation and manual recovery boundary

The helper requires one unresolved actual attempt, the immutable attempt file's exact id/action/phase/start, exact session bytes and one consumed exact permit covering its start. Multiple plausible permits refuse. Classifications use actual inverse pointer/journal state, independently checked before/cleared/restored state, snapshot file pair, rotation stages/configuration/activation stamps, and successful durable plugin command receipt plus fresh enabled/registration observations. Read-only export/drain/restore checks can be rerun. Empty-before-and-after scratch without a durable result is ambiguous and refuses.

Panel open/close, collector launch and control authorizations are deliberately not guessed from current state or absence of a result. A missing successful plugin command receipt also refuses. For these unknown effects root must retain attempt, consumed permit, permit-result, result-attempt, raw/control/heartbeat/receipt and identity records; compare exact run/nonce/clock and PID/startTicks/boot identities. A current plugin catalog alone cannot prove which runtime was enabled. Do not repeat an uncertain effect or fabricate `not-applied`.

If normal/stopped physical evidence cannot be established, root's manual safety/recovery checklist is:

1. Preserve all raw/source extents and immutable journals; keep collection/protocol verdict incomplete. Do not silently clear invalid reasons.
2. Check exact owned collector server/wrapper/collector identities and actual control/receipt; stop only the named owned actor under fresh authorization and verify all identities reaped. Never target the default tmux server or use broad process matching.
3. If the panel can still run work, obtain/retain an actual close receipt and inspect queue/describe/render/log closure facts. A close or final raw tail missing after source loss cannot be reconstructed as earlier evidence.
4. Inspect the literal pointer and plugin enabled/registered state. Preserve any owner change or unrelated target. Only an independently supported inverse operation may restore the original runtime.
5. Under the existing lock compare saved documents, active profile and exact scratch; use accepted restore only when its guards pass, preserving current wallpaper. Any owner conflict needs root/person resolution; do not overwrite it.
6. Inspect rotation journal stage and actual unit configuration/activation timestamps. Resolve partial pause-issued/resume-issued safely; never blindly replay stop/start. Restore the exact originally active/inactive condition only after attribution.
7. Run independent restoration verification; record manual recovery separately. If evidence is irretrievably absent, do not claim Controller normal restoration/protocol completion and do not proceed to the next activation.

These are explicit conservative refusal boundaries, not implemented automatic recovery for every crash point. Root review must decide whether the remaining manual paths are adequate before any host request.

## Honest reserve binding and timing front door

`measure.py ACTION CONTRACT OUTPUT` performs one read-only observation and writes an exclusive0600 monotonic timing receipt including the actual observation and contract hash. Root invokes it with an outer timeout: state-before15s, registration5s, catalog5s, rotation45s, drain15s. No worker invoked it on the real host. Use a separate representative retained-run contract for drain; fake/retained data timing is labeled representative, never actual future live analysis. Actual current raw state, source hash checking, IPC registration/catalog and rotation observations can be measured before consent. Full restored-state verification and actual activation/setup/cleanup cannot be measured in the new live state before authorized setup; their historical/component/timeout provenance stays explicit.

The four Window.steps groups should account for these exact operations:

- pre: verified source/clock/session setup; rotation snapshot/pause, locked snapshot/clear, panel close, disable, pointer swap, collector launch/start heartbeat, enable/export registration, open, fresh raw checkpoint/identity, current locked state and card issue preparation. Include actual elapsed startup work; distinguish work before collectorStarted from its five-minute controller allowance.
- post: actual owner-reply receipt, authorized actual close BEFORE first checked checkpoint, captured closed tail/checkpoint, initial inspect/checked, missing-unit classification and request preparation.
- recovery: one approved recovery packet materialization/authorization, required reopen/export/identity checks, issue preparation, subsequent reply/actual close/checkpoint/inspection and combined result. The separately reserved600s owner interval is not a helper duration.
- finish: finish authorization/control, final checkpoint/collector exit/receipt/reaping, independent final-drain, disable/inverse pointer/plugin restoration, locked state restoration, rotation resume, combined independent restore verification and final frozen artifacts/analysis. Count repeated actions and any reconciliation separately; no invented free retry allowance.

Frozen session.steps is created before setup. Controller records actual stepSeconds later but does not feed them into Window automatically. Therefore no preparation can truthfully call future new-helper effects already measured. Root's explicit prospective ruling is to combine newly measured read-only components, precisely identified historical real broad-phase durations, and separately labeled conservative command timeout ceilings; freeze that bound before the session, then enforce actual pre-card elapsed plus an adequate remainingStepReserve at issue. `remainingStepReserve` can be raised but cannot retroactively change the immutable provenance. Root/independent pre-pilot review must accept this ruling; otherwise the host request stays blocked. No frozen change is proposed. Later activations may use measured B1 live steps.

Root's actual r2 extraction: real pre-reload/owner-handoff22.376–29.834s, Prism restore2.980s, timer resume1.505s, total restore4.485s. These are historical broad phases only. There is no paired analysis end: analysisSeconds=null. The earlier7.18s fake lifecycle cannot fund any live Window.steps. Reserve formula remains ceil(1.25*sum), at least120s approval allowance within300s; no guard change or silent broad-phase transfer.

## Current input and final gate

Root's fresh read-only preflight identifies the running log via its actual fd,1MiB/one backup/8KiB line source configuration, eligible current P/Q and scratchCount0. Authorized setup still takes a new exact snapshot. Owner wording must say preserve exact current scratch (presently observed empty), not twelve current edits.

Private Stage1-only wrapper reuses the accepted paced writer/rate logic and serialization with unchanged16ms ticks. It supplies the exact83parameter/12device/24profile model, performs one full diagnostics click per variant and never rewrites Q/P/scratch. Both complete five cold plus five launch/control pairs, exact raw byte capture, closed handoff and fake restoration. Portable proof records actual bytes/rates/counts; the old seven calibrations remain unchanged. This establishes prospective guard compatibility only. No live throughput, performance, collection permission, permit or source change is claimed.

Root next: review helper sources/tests and refusal boundaries; run actual permitted read-only timings; materialize concrete commands/env/contract/session hashes and reserve provenance; obtain independent pre-pilot review. Only then present the concrete fresh owner host request. Task6 remains open.


## Readiness follow-up package

This v2 helper package supersedes host.py in the original helper packet; the original archive and its inventory remain immutable evidence. readiness-check.py reproduces the original single-query export failure and restoration-without-query gap, then verifies delayed registration for both expected states, shared fixed deadlines including mutation time and slow queries, refusal of late success, persistent absence and malformed/source/catalog failures. All IPC is mocked; no new live observations or collector runs occurred. Root must regenerate its session/contract/master inventories from this new portable-helper-inventory.json before any permission review. Prior actual component timings remain observations of the earlier helper bytes and must not be relabeled as this helper's exact duration.

Changed host.py SHA256: fbe4a8f3ec0e16bdf964e11674a17791ade4d9846cdd43c0c4fa49023ce52961 → ffedc55a350f749cbff680ff66d180c867a02ef31b1fd34cba32b4edb186068f. New readiness-check.py SHA256: be51b2bd3756eaeb7ddaf81031de6439f8839e37ab4ef5f400a719cb9d0f48ea. All other executable helper sources are unchanged; inventory records supporting proof/handoff changes.
