import contextlib,io,json,subprocess,sys,unittest
from unittest.mock import patch
import host
class Tests(unittest.TestCase):
 def invoke(self,action,registrations,prior=True,cost=.01):
  now=[100.0];calls=[];answers=iter(registrations)
  def run(argv,**kwargs):
   calls.append((argv[2:],kwargs['timeout']));now[0]+=cost
   if argv[2:]==['plugins','list']:return subprocess.CompletedProcess(argv,0,'khughitt/prism [local] 1 '+('enabled' if prior else 'disabled')+'\n','')
   if argv[2:]==['panel-close',':']:
    registered=next(answers);return subprocess.CompletedProcess(argv,1,'error: unknown panel ":"'+(' (available: khughitt/prism:panel)' if registered else '')+'\n','')
   return subprocess.CompletedProcess(argv,0,'ok (exporting in background)\n' if prior else 'ok\n','')
  output=io.StringIO()
  with patch.object(sys,'argv',['host.py',action,'fixture']),patch.object(host,'load',return_value={'sourceRoot':'fixture','priorEnabled':prior}),patch.object(host,'source_check',return_value='pinned'),patch.object(host.subprocess,'run',side_effect=run),patch.object(host.time,'monotonic',side_effect=lambda:now[0]),patch.object(host.time,'sleep',side_effect=lambda n:now.__setitem__(0,now[0]+n)),contextlib.redirect_stdout(output):
   host.main()
  return json.loads(output.getvalue()),calls,now[0]
 def test_export_waits_false_then_true(self):
  result,calls,now=self.invoke('export-ready',[False,True]);self.assertTrue(result['registered']);self.assertEqual(len(result['polls']),2)
 def test_restore_waits_for_saved_registration_state(self):
  for prior in (True,False):
   result,calls,now=self.invoke('plugins-restore',[not prior,prior],prior);self.assertEqual(sum(argv==['panel-close',':'] for argv,timeout in calls),2,'restore returned before checking registration');self.assertEqual(result['registration']['registered'],prior);self.assertEqual(len(result['registration']['polls']),2)
 def test_fixed_deadline_includes_slow_query_and_no_late_success(self):
  now=[0.0];timeouts=[]
  def run(argv,**kwargs):
   timeouts.append(kwargs['timeout'])
   if argv[2:]==['plugins','list']:
    now[0]+=2.8;return subprocess.CompletedProcess(argv,0,'khughitt/prism [local] 1 enabled\n','')
   now[0]+=1.3 # A delayed successful reply past the deadline must still refuse.
   return subprocess.CompletedProcess(argv,1,'error: unknown panel ":" (available: khughitt/prism:panel)\n','')
  with patch.object(host,'source_check',return_value='pinned'),patch.object(host.subprocess,'run',side_effect=run),patch.object(host.time,'monotonic',side_effect=lambda:now[0]):
   with self.assertRaises(TimeoutError):host.wait_registration('fixture',True,4)
  self.assertEqual(len(timeouts),2);self.assertAlmostEqual(timeouts[1],1.2)
 def test_never_registered_exhausts_one_fixed_deadline(self):
  now=[0.0];timeouts=[];err=io.StringIO()
  def run(argv,**kwargs):
   timeouts.append(kwargs['timeout']);now[0]+=.4
   return subprocess.CompletedProcess(argv,0 if argv[2:]==['plugins','list'] else 1,'khughitt/prism [local] 1 enabled\n' if argv[2:]==['plugins','list'] else 'error: unknown panel ":"\n','')
  with patch.object(host,'source_check',return_value='pinned'),patch.object(host.subprocess,'run',side_effect=run),patch.object(host.time,'monotonic',side_effect=lambda:now[0]),patch.object(host.time,'sleep',side_effect=lambda n:now.__setitem__(0,now[0]+n)),contextlib.redirect_stderr(err):
   with self.assertRaises(TimeoutError):host.wait_registration('fixture',True,4)
  self.assertLessEqual(now[0],4.4);self.assertLess(timeouts[-1],.5);self.assertIn('registrationPoll',err.getvalue())
 def test_restore_mutation_consumes_same_deadline(self):
  now=[0.0];timeouts=[];output=io.StringIO()
  def run(argv,**kwargs):
   timeouts.append(kwargs['timeout'])
   if argv[2:]==['plugins','enable','khughitt/prism']:
    now[0]+=2.8;return subprocess.CompletedProcess(argv,0,'ok (exporting in background)\n','')
   raise subprocess.TimeoutExpired(argv,kwargs['timeout'])
  with patch.object(sys,'argv',['host.py','plugins-restore','fixture']),patch.object(host,'load',return_value={'sourceRoot':'fixture','priorEnabled':True}),patch.object(host.subprocess,'run',side_effect=run),patch.object(host.time,'monotonic',side_effect=lambda:now[0]),contextlib.redirect_stdout(output):
   with self.assertRaises(subprocess.TimeoutExpired):host.main()
  self.assertEqual(output.getvalue(),'');self.assertEqual(len(timeouts),2);self.assertAlmostEqual(timeouts[1],1.2)
 def test_malformed_response_source_and_catalog_conflicts_never_retry(self):
  good=subprocess.CompletedProcess([],0,'khughitt/prism [local] 1 enabled\n','')
  for replies in ([good,subprocess.CompletedProcess([],1,'malformed\n','')],[good,subprocess.CompletedProcess([],0,'error: unknown panel ":"\n','')],[subprocess.CompletedProcess([],0,'khughitt/prism [local] 1 disabled\n','')]):
   with patch.object(host,'source_check',return_value='pinned'),patch.object(host.subprocess,'run',side_effect=replies) as run,patch.object(host.time,'sleep') as sleep:
    with self.assertRaises(ValueError):host.wait_registration('fixture',True,host.time.monotonic()+4)
    self.assertEqual(run.call_count,len(replies));sleep.assert_not_called()
  with patch.object(host,'source_check',side_effect=ValueError('source changed')),patch.object(host.subprocess,'run',return_value=good) as run,patch.object(host.time,'sleep') as sleep:
   with self.assertRaises(ValueError):host.wait_registration('fixture',True,host.time.monotonic()+4)
   self.assertEqual(run.call_count,1);sleep.assert_not_called()
if __name__=='__main__':unittest.main()

