# Stage 1 n=1 preparation handoff

Status: preparation only. Four selected transformed builds exist; no live session,
permit, run directory, desktop action, host state write or collector was created.
Task 6 stays open. The controller must resolve the missing facts below, review its
concrete commands and fresh clock proof, and obtain fresh owner permission.

## Authority and limits

The accepted 54-file code digest is
`4203ac5942263fcda74d5f741549674ecb0194345012b575229d5d0409ed5b32`.
The existing Task5 active5 source archive remains authority; no new source package
is needed. Baseline is `9bf4e8e920c005f8a4d1666b32b4e1a516856ac2`;
candidate is `e7384b0d7ab3e8e935cdf0776043839441132af5`, with its full signature-token
scope. Every copied source blob, unchanged module and manifest was checked against
git. All four selected copies have identical normalized instrumentation. The
builder emits pairs, so four unused companion copies are retained for its equality
proof; they are never selected for an activation.

Order: B1, C1, C2, B2. One cold per activation; one launch and one control in B1 and
C1 only. All rack cards auto-expand administratively. No owner slider/profile work.
Keep five seconds of visible settled dwell, then close the panel physically before
replying. The exact open-handoff / snapshot / completed close / flush / closed
marker tail and that card's own reply remain mandatory.

Current root-provided describe has 83 parameters, 12 devices and 24 profiles.
It is preliminary read-only evidence, not a locked snapshot or authority to clear
scratch. The old 23-profile calibration remains unchanged. The new private Lua
input preserves the current describe structure; the existing synthetic lifecycle
producer explicitly replaces profile labels with Q/P and removes scratch-held
labels. Thus its correctness result does not establish live P/Q eligibility or
current live burst throughput. Current-model expansion checks retain all24 profiles.

The focused four-activation fake check completed in7.18s, with complete cold/full
collection, normal final raw rereads, four restorations and phaseSchema1. This
synthetic duration is not occupancy. Performance remains inconclusive at n=1.
The old r2 run took96minutes and was inconclusive. The independently reviewed
Task5 collector rehearsal produced40minutes of actual capture; it proves the
specified lifetime/result gate, not live Noctalia panel timing.

The old runbook's “review pending” and blanket metadata-only refusal paragraphs
are historical. Current README/active5 accepts only its bounded verified active
append transition, including the constrained ctime-first/mtime-catch-up case;
stable metadata alone never proves append. Full prefix checks, unique source
identity, archive invariants and exact terminal cutoff still bind. Task5 is now
independently accepted. Use modern phaseSchema1 carriers, pollComplete and
sourceObservationFailure fields; never map handled phase exceptions to terminal
capture failures or infer zero errors from missing evidence.

## Controller checklist before requesting the owner

1. Verify the private proposal/build hashes and accepted source/calibration
   inventories. Keep all raw models/state/results private. Reobserve installed and
   running Noctalia, build, source and boot. Materialize a new source proof bound to
   the actual pilot controller session and run clock-gate.py. The old preparation
   proof is not this session. Any changed boot/runtime/source rebuilds the relevant
   identities before proceeding; never relabel an existing sampled activation.
2. Resolve explicit worktree CLI and the actual literal plugin symlink. Preserve
   both literal and resolved original, prior enabled state, exact config/state
   environment, timer unit/config/state and journal paths. The CLI on PATH is a
   wrapper, so use `.worktrees/panel-budget/bin/prism` explicitly. No launcher swap.
3. Resolve actual Noctalia log path and1MiB capacity/rotation behavior. Proposed
   prior qualified conservative rate is1,425,679B/s (native682,491B/s;
   observed padded source1,117,592B/s). This gives T0.735492352s,
   poll0.1s (bound0.183873088s), gap0.367746176s. Current-model live/full-burst
   qualification is explicitly missing; root must justify or requalify this bound,
   never mark the proposal as measured on the current live model.
4. Complete exact argv/env/timeout/json command specifications and every uncertain
   action reconciliation below. Inert envelopes have null environment, sessionId,
   log, steps, sourceProof and hostActions, so they cannot be submitted as sessions.
   RootHost only checks exit status: wrappers must also reject textual IPC errors.
   capture.py launch returns empty stdout on success: json=false is required.
5. Prepare current P/Q eligibility and restoration checks from the reviewed helper,
   then obtain a fresh locked snapshot at authorized setup. Do not reuse preliminary
   describe as snapshotBundle. Bind later activations to B1 saved documents,
   profiles, pair and runtime; refuse drift. Measure actual live command durations
   for steps/remaining reserve. Fake IPC timings cannot fund the300s controller cap.
6. Complete readiness, drain and independent restore verification interfaces.
   Record exact source evidence and command output expectations before permission.
   No existing nested Noctalia panel host was found; GLES material fixtures are
   insufficient. Do not invent a new panel export or alter measured callbacks.
7. Review the owner request below. Only then ask for fresh host permission. Root
   materializes sessions and one-use permits after authorization. No worker-created
   approval or “yes” placeholder exists. Run directories remain absent until then.

## Root-owned command and reconciliation contracts

All commands below are proposals using existing APIs, not executable authorization.
Private envelopes expand CODE, RUN, BUNDLE, SAVED and JOURNAL to exact private paths.
Every controller action uses a fresh permit with exact arguments and expiry≤60s.
For any pending/uncertain attempt, reconcile its actual effect before retrying or
restoring: return `{attemptId,action,outcome,receipt}`; outcome is `completed` or
`not-applied`. Unknown/conflicting state must fail. Root must supply concrete
bounded read-only reconcile-ACTION commands for every mutating action.

| Action | Existing API / expected evidence | Independent reconciliation/restoration check |
|---|---|---|
| rotation-snapshot | `python3 CODE/rotation-guard.py snapshot JOURNAL`, JSON saved/prior states | Journal bytes, unit config and captured activation timestamps match; missing file alone does not prove later effects absent |
| rotation-pause | helper `pause JOURNAL`, approval env; timerPaused/serviceInactive/configurationPreserved | Journal stage, pausedState and systemd config/activation; no service kill or unit disable |
| state-snapshot | `node CODE/snapshot.mjs BUNDLE SAVED`, explicit repo env; exclusive files and SHA | Same locked runtime/raw documents/definitions/resolver identities, complete exact bundle pair |
| state-clear | `node CODE/state.mjs clear SAVED`, approval env; empty scratch and exact P/canonical | Locked current runtime/documents compared with saved and expected cleared state; unrelated edits refuse |
| panel-close | Noctalia panel-close target; exact successful response required | Completed handoff/drain plus host visibility where available; no missing reply inferred as closed |
| plugins-disable | Noctalia plugins disable target; successful response | Fresh plugin enabled state and actual export removal/runtime unload; absent response not not-applied |
| pointer-swap | RootHost literal `{path,from,to}` journal then atomic replacement | `readlink` exactly selected target; preserve literal original and task note immediately |
| collector-launch | `python3 CODE/capture.py launch RUN/run.json`, json=false | Exact fresh named socket and PID/startTicks/boot identities; matching collectorStarted heartbeat before enable |
| plugins-enable | Noctalia plugins enable target, validate response | Enabled catalog plus registration and fresh activation raw identity; background exporting response is not readiness |
| export-ready | Missing concrete bounded read-only root command | Registry presence plus matching transformed activation identity; list alone does not prove either |
| panel-open | Noctalia panel-open target, validate response | Matching fresh startup/P reference; no owner card before issue's actual checkpoint checks |
| checkpoint/recovery/finish/stop authorize | Controller permit consumption and exact atomic control sequence | Immutable consumed permit and matching sequence heartbeat/control/receipt; never reuse permit |
| final-drain | Missing root read-only command over final frozen capture | Exact physical queue/describe/render/log drain and valid closed handoff at final cut; preserve aborted/short groups separately |
| pointer-restore | RootHost inverse literal pointer operation | Literal original exactly restored; no host pointers resolve into transient build |
| plugins-restore | Enable only if captured originally enabled; otherwise retain disabled | Original activation state plus original export/runtime, using actual prior state |
| state-restore | helper restore SAVED; documentsEqual/scratchExact | Independent locked raw document + exact scratch comparison; active profile original, latest wallpaper preserved |
| rotation-resume | helper resume JOURNAL with approval env | Journal restored, original prior activation resumed, config preserved, service inactive/success |
| restore-verify | Missing root combined read-only command | Return documentsEqual=true/scratchExact=true only after checking pointer, plugin state, state and timer; no constant-success command |

Noctalia pinned primary-source evidence: `src/app/application_ipc.cpp:665–698`
implements plugins list from the local catalog and enable's optional “exporting in
background”; `src/shell/panel/panel_manager.cpp:2860–2936` checks registered panels
and returns unknown-panel errors listing available IDs before any open. There is
no panel-list verb there. Root selected an unknown-ID panel-close query using a provably unregistrable
sentinel (for example a reserved bare-colon ID after checking every panel registration
construction). Require the exact unknown response, bounded timeout, parsed available
IDs and exact Prism registration. Root still owns that construction proof and the
concrete wrapper; no helper is claimed to exist. Registration still must be joined to the
fresh matching raw activation, source/build hashes and reference. Never use a registered panel target as a read-only close query.

Physical drain can be checked using `inspect_run` on the actual immutable final
capture and its terminal handoff. It cannot prove arbitrary live host state after
the cutoff; freeze/disable and verify the relevant runtime boundary under root
commands. The independent restore check should reuse store.withLock/readRuntime
and raw-document semantics from state.mjs, rotation-guard snapshot/config comparison,
and literal pointer/plugin state. None of these missing wrappers was invented or
installed by the worker. A task pause before host permission is appropriate until
root resolves them.

## Authorized action sequence

For each B1→C1→C2→B2 activation, root creates the exclusive session/run, executes
prepare (snapshot/pause/snapshot/clear/close/disable/swap/collector launch), records
the actual pointer note, verifies collectorStarted, then activate (enable/readiness/
open). Checkpoint, match lastSequence, verify fresh raw identity and current clear
result, then issue the exact pilot card. Root records actual timestamps and park
metadata and yields for the owner's completion message. A process exit never wakes
Codex. On that explicit reply, resume, record its actual message ID, checkpoint and
inspect; decide at most one separately owner-approved combined recovery packet.
Check counts/reference/drain/deadlines before swapping. Missing data, identity,
reference/source errors or budget errors cannot be repaired by samples.

Finish only after the explicit completion and physical drain; re-read final raw,
require exact fully consumed terminalCutoff, clean process exit/reap and modern
phase/completion evidence. Restore pointer, original plugin state, exact saved
scratch/documents and timer's prior activation; then independent restore-verify.
Each next activation needs the preceding restored outgoingState and B1 exact
referenceSnapshot. Collectors are bounded at35min, card20min, recovery10min,
controller5min; estimates do not trigger cleanup or shorten a card. Expiry produces
incomplete evidence, then authorized reconciliation/restoration.

Every owner-card park is root-held, waiting-on user/reason dependency and names
actual PID/startTicks/boot/socket/deadline/stop command, literal pointer from/to and
inverse restore, paused timer journal/prior-state resume command, and pending reply.
No generic placeholders in an actual handoff. Other parks restore first. Observe
and timestamp default tmux socket/server facts before/after; do not hardcode a
root-reported claim. Root final cleanup includes owned process/kernel/filesystem
socket absence and host-load session output.

## Owner-facing request draft — do not send before root review

“May I run the four-card Stage1 collection pilot on the current Noctalia desktop?
Plan for about25minutes. The previous pilot took96minutes and was inconclusive;
the revised one-click controls now expand the rack automatically, and the reviewed
collector completed its40-minute rehearsal. The25-minute estimate uses the old
17.5-minute diagnostic work plus about2minutes controller work, with25% allowance;
it excludes the old24-minute manual expansion/chat bucket and is not a cutoff.

I will temporarily clear saved scratch edits after a locked snapshot, pause wallpaper
rotation without disabling its units, reload four fresh baseline/candidate panels,
and restore the exact saved edits, original plugin pointer/state and prior rotation
state afterward. Each card asks for one diagnostic click and five seconds of
visible settled dwell, then close the panel and reply. No sliders or profile changes.
Initial cards allow20minutes, each collector35minutes, and controller work5minutes.
Any replacement needs a separate request for at most one combined packet. This
one-sample pilot checks collection; it cannot establish performance acceptance.”

## Owner action-card drafts

Replace LABEL with the one currently issued by controller owner-card.txt; never
show all four as permission to operate ahead of the active session.

“LABEL: Wait until the panel controls are ready. Click **Sample diagnostics** once.
The rack expands automatically. Keep the panel visible for at least five seconds
after the button disappears and the controls settle. Close the panel, then reply
‘LABEL complete’. Do not reopen it or operate sliders/profiles.”

B1 and C1 each take one cold plus one launch/control pair. C2 and B2 take one cold
only. Recovery uses only its separately approved generated recovery-card.txt and
never a guessed click count. All estimates remain provisional until the actual
pilot's complete phase counts, raw evidence and normal analysis are available.
