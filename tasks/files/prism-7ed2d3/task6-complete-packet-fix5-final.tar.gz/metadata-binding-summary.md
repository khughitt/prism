# Round5 changed metadata and binding summary

Baseline: `26f9116043c7b77a20a170db8de8036618d2f569`; driver/test source comes from `$PRIOR_PACKET`, helper source from `$ACCEPTED_V2/helpers`. `code-changes.diff` contains the complete executable/test delta, including replaced test deletions. All old copies remain intact. Generated build identity changes are in `changes.diff`; `measurement-payload-equality.json` independently proves every measurement body and other module unchanged.

Final inert master SHA256: `1f4d858db1513accd9c05359eb67faf01377fd21fc1998267588597e993649c6`; 472 inventory entries. Paths are role labels in this attachment, so private hashes describe the private original bytes. This normalized copy cannot authorize execution.

| Changed executable | Base SHA256 | Final SHA256 |
| --- | --- | --- |
| `packet_driver.py` | `3ddbfef7e23f6a6825df6f830e538c5b7b669b62d97dd3e7e835fd2c533c1cd1` | `4a472b0b1769357652dff122e2a56e65bf9fc57604c5ef4e4677ae36aba76bba` |
| `helpers/host.py` | `0cfa9d168ee40f985f46f07c2bc078bf3dbc80974c329320c99e709264c7224c` | `0828772ba97b3e3ad1bbb85ad6abf89af5b0785d62649521a44d93b1ca4a7a27` |
| `materialize.py` | `4a9dd66bc5c0903e968e2dafc5fdb06d40a60464e78f2fb842f115075a13e1e2` | `1b597fa2e8a64b01a2eefb6ab847d795f19073bfe07e38e70df189da3a009980` |
| `packet_check.py` | `a401439cac2a107e7042151d336487f0d80f0064c2e1615554b9e5a046d2b849` | `cdbad6f4819d39310acf6153cf19f6a8ba72efe019e456595265f92fecd21b14` |
| `round5_check.py` | `new` | `5c7654f183e5a0aebacaaa915003118ed515fc8c9bc257aa0a0b6795a17b4f08` |
| `integrated_smoke.py` | `new` | `e52baf4c36f089956ae1afed7a03f8323f343e00558846938d71a1c876d6380b` |
| `helpers/pending-enable-check.py` | `1a043ff6f8d7bb877859f8a177429ea3626bb695ba753e5734cad0bd8a774c65` | `fd5dfd4faa1e4a4e83925c13f51d28fe64c15ec68f660ecc287ffb5e1aafcdb3` |
| `helpers/source-phase-check.py` | `3bba5630b8fced89865dd325b475121eb1de64fe5f63c2e7e6d5b65b18a7f87e` | `e9852ccf5d298e11cee69428bc1a168308b13f4f0d228f2640776a64f558b7f2` |

`code-delta-inventory.json` also binds all unchanged helper scripts and the removed `driver_smoke.py`, `smoke_host.py`, and `driver_boundary_check.py`. Replacement integration/boundary coverage exercises the real Guard/RootHost/dispatch/helper seam; the old smoke and all old evidence are preserved in the prior namespace.

| Activation | Canonical session SHA256 | Collector SHA256 | Phase contracts |
| --- | --- | --- | ---: |
| B1 | `369e1227607e2b0b14682e8ca675f602c15c8a077afbcecc8b532da2ff951af2` | `bf82ea884a8c7e2fabd534ecb4f0c9db141690718972d5203369704d607af946` | 52 |
| C1 | `cd0df3d4cd5ee9492dd539a6c149360c476db5452142e139c67e0f368252b839` | `d7880a749b87fcfd4913f88ba738f40d1465abef9881b2b2037f0cb93709a9f1` | 52 |
| C2 | `40aa242c721f9b389d21f5a6e13fb5486f9234c350d094c3c757d9eca6d82728` | `0e67505ef18a70ce2cb62c73de104d789b7bcae4f1d5119739527da0c671bee1` | 52 |
| B2 | `a785b20d70be1bf872c189330fbff2521422f50d89c4c73f350c3a499dbdc334` | `b90c6f08b14a640547315135fc0b7e0f02e2736b3d678a54adf675ad2b308b35` | 52 |

Bindings run in one direction: final code/build inventories and fresh run/card/nonces → canonical sessions → exact command/phase/reconciliation contracts → master inventory/hash → future separately supplied actual review and approval. No master hashes itself, no actual review/approval/permit is present, and no `live-*` namespace exists.

All four n1 builds have fresh diagnostic identity declarations and corresponding transform/identity/manifest hashes; no measurement body changed. The accepted 58-file code digest remains `4ea47695846dbcdf1d2dff5bf703486ccfe38da597a71d56e314d0abb89fdfce`; original54 digest remains `4203ac5942263fcda74d5f741549674ecb0194345012b575229d5d0409ed5b32`. Accepted helper dependencies other than the copied permit-binding seam remain unchanged.

The original discovered source entry and literal inverse, B1 saved-state reference, unchanged Root readonly source/clock group, exact worktree CLI, pinned Node PATH and explicit Python `-B` are retained. New session/contract/helper paths bind `$FIX5/helpers`; accepted Controller, RootHost, parser, collector, state and rotation guards stay pinned to `$ACCEPTED_V2/code`. Historical Root facts remain historical; there is no fresh endorsement.

New audit metadata specifies 8 recorded log reobservations, 0.25 seconds of nonpreemptive elapsed checks and 0.01-second polls. Each check retains exact running process/binary/environment, active log path/descriptor identity and approved logger settings. The old descriptor number is not an identity requirement.

Reserve groups remain pre36/post21/recovery20/finish67 seconds: sum144, ceil(1.25×144)=180, 300−180=120 seconds available for approval; initial1200/recovery600/collector2100 and initial/recovery remaining135/109 stay unchanged. `contracts/reserve.json` counts all new binding/phase/descriptor work: per activation24 immutable bindings,8 batches,36 audits,46 phase evaluations,42 direct pointer validations,11 dispatch claims and14 direct dispatch/helper consumed-binding validations; outer work adds4 actions,6 audits,2 batches. At most150×8=1200 normal-group log observations. Variable reads/polls, reconciliation, final analysis and cleanup consume actual elapsed; there is no fixed synchronous-I/O guarantee.

Current final472-file inventory hashing measured0.14891769498353824 seconds for184671290 bytes; this is a readonly component, not future host setup or live feasibility. The144-second seed has no spare margin. Root owns the final scoped review and cap decision before fresh host-use permission.
