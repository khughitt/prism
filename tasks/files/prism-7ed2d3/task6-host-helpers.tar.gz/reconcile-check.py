import json,tempfile,unittest,os,hashlib
from pathlib import Path
import reconcile
class Tests(unittest.TestCase):
 def test_unknown_attempt_cannot_be_declared_completed(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'session.json').write_text(json.dumps({'sessionId':'s','runId':'r','clockOrigin':'c','hostActions':{}}));(p/'state.json').write_text(json.dumps({'attempts':[]}))
   contract={'runRoot':d,'expected':{'sessionId':'s','runId':'r','clockOrigin':'c','sessionFileSha256':hashlib.sha256((p/'session.json').read_bytes()).hexdigest()}}
   with self.assertRaises(ValueError):reconcile.reconcile(contract,'pointer-swap')
 def test_pointer_completion_inverse_and_conflict(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);pointer=p/'pointer';pointer.symlink_to('new');(p/'permits').mkdir()
   spec={'path':str(pointer),'from':'old','to':'new'};session={'sessionId':'s','runId':'r','clockOrigin':'c','hostActions':{'pointer-swap':spec}};(p/'session.json').write_text(json.dumps(session))
   attempt={'id':'attempt-one','action':'pointer-swap','phase':'preparing','status':'pending','started':10};(p/'attempt-attempt-one.json').write_text(json.dumps(attempt));(p/'state.json').write_text(json.dumps({'attempts':[attempt|{'status':'uncertain'}]}))
   (p/'permits/token-one').write_text(json.dumps({'action':'pointer-swap','permit':{'arguments':spec,'issuedAt':9,'expiresAt':20}}));(p/'permits/token-one-pointer').write_text(json.dumps({'what':str(pointer),'from':'old','to':'new'}))
   contract={'runRoot':d,'expected':{'sessionId':'s','runId':'r','clockOrigin':'c','sessionFileSha256':hashlib.sha256((p/'session.json').read_bytes()).hexdigest()}}
   result=reconcile.reconcile(contract,'pointer-swap');self.assertEqual((result['attemptId'],result['outcome']),('attempt-one','completed'));self.assertEqual(os.readlink(pointer),'new')
   pointer.unlink();pointer.symlink_to('old');self.assertEqual(reconcile.reconcile(contract,'pointer-swap')['outcome'],'not-applied')
   pointer.unlink();pointer.symlink_to('owner-edit')
   with self.assertRaises(ValueError):reconcile.reconcile(contract,'pointer-swap')
   self.assertEqual(os.readlink(pointer),'owner-edit')
   (p/'state.json').write_text(json.dumps({'attempts':[attempt,attempt]}))
   with self.assertRaises(ValueError):reconcile.reconcile(contract,'pointer-swap')
if __name__=='__main__':unittest.main()
