// Independent observations under the existing lock; never clear or restore state.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const repo=process.env.PRISM_TASK3_REPO;assert(repo,'explicit worktree required');
const {withLock}=await import(`${repo}/src/lock.js`);
const {lockPath,activePath,defsDir}=await import(`${repo}/src/paths.js`);
const {readRuntime,listContexts,lookPath}=await import(`${repo}/src/contexts.js`);
const {loadDefs}=await import(`${repo}/src/defs.js`);
const {loadStore,loadLayers,withScratch}=await import(`${repo}/src/layers.js`);
const {resolveLayered}=await import(`${repo}/src/resolve.js`);
const raw=p=>fs.existsSync(p)?fs.readFileSync(p).toString('base64'):null;
export async function verify(mode,bundle) {
 assert(['before','cleared','restored'].includes(mode),'unknown verification mode');
 return withLock(lockPath(),async()=>{
  const saved=bundle.saved;const defs=loadDefs(defsDir());
  assert.deepEqual(Object.fromEntries(defs),bundle.definitions,'definition source changed');
  for(const [name,sha] of Object.entries(bundle.resolverSources)) {
   assert(['values.js','resolve.js','layers.js','contexts.js','cli.js'].includes(name),'unknown resolver source');
   assert.equal(crypto.createHash('sha256').update(fs.readFileSync(`${repo}/src/${name}`)).digest('hex'),sha,'resolver source changed');
  }
  assert.equal(Object.keys(bundle.resolverSources).length,5,'incomplete resolver freeze');
  const documents=Object.fromEntries([null,...listContexts().profile].map(n=>[n??'@base',raw(lookPath(n))]));
  assert.deepEqual(documents,saved.documents,'raw source document changed');
  const current=readRuntime(),active={...saved.runtime.active};
  if(mode==='restored') {
   if(current.active.wallpaper===undefined)delete active.wallpaper;
   else active.wallpaper=current.active.wallpaper;
  }
  assert.deepEqual(current.active,active,'active owner fields changed');
  const scratch=mode==='cleared'?{}:saved.runtime.scratch;
  assert.deepEqual(current.scratch,scratch,'scratch not exactly '+mode);
  if(mode==='before')assert.equal(raw(activePath()),saved.runtimeRaw,'raw runtime changed');
  const store=loadStore(defs);
  const expected=resolveLayered(defs,store.base,withScratch(loadLayers(active),scratch)).params;
  assert.deepEqual(store.params,expected,'canonical restoration mismatch');
  return {documentsEqual:true,scratchExact:true,canonicalMatchesExpected:true,activeMatchesExpected:true,runtime:current,canonical:store.params,mode};
 });
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) {
 const [mode,file]=process.argv.slice(2);assert(file,'bundle path required');
 console.log(JSON.stringify(await verify(mode,JSON.parse(fs.readFileSync(file)))));
}
