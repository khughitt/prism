"""Fixed pilot host commands. Invocation is root-owned; importing has no host effects."""
import hashlib,importlib.util,json,os,re,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PLUGIN='khughitt/prism';PANEL=PLUGIN+':panel';SENTINEL=':'
ARGV={'panel-close':['panel-close',PANEL],'panel-open':['panel-open',PANEL],
      'plugins-disable':['plugins','disable',PLUGIN],'plugins-enable':['plugins','enable',PLUGIN]}
def require(ok,message):
 if not ok:raise ValueError(message)
def load(p):return json.loads(Path(p).read_text())
def response(action,result):
 require(action in ARGV,'unsupported host action')
 allowed=['ok\n']+(['ok (exporting in background)\n'] if action=='plugins-enable' else [])
 require(result.returncode==0 and result.stdout in allowed,'Noctalia command failed or unexpected response')
 return {'stdout':result.stdout,'stderr':result.stderr,'exit':result.returncode,'exportPending':result.stdout=='ok (exporting in background)\n'}
def registration(text):
 match=re.fullmatch(r'error: unknown panel ":"(?: \(available: ([^\n]+)\))?\n',text)
 require(match is not None,'unexpected registration response')
 ids=match[1].split(', ') if match[1] else []
 require(len(ids)==len(set(ids)) and SENTINEL not in ids,'duplicate or registered sentinel')
 require(all(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*(?:/[A-Za-z0-9][A-Za-z0-9_.-]*:[A-Za-z0-9][A-Za-z0-9_.-]*)?',x) for x in ids),'malformed panel id')
 return ids
def enabled(text):
 rows=[line for line in text.splitlines() if line.split(' ',1)[0]==PLUGIN]
 require(len(rows)==1,'plugin catalog identity missing/duplicated')
 parts=rows[0].split()
 require(len(parts)>=4 and re.fullmatch(r'\[[^\s\[\]]+\]',parts[1]) and parts[3] in ('enabled','disabled'),'malformed plugin catalog entry')
 require('incompatible' not in parts,'plugin incompatible')
 return parts[3]=='enabled'
def source_check(source):
 proof=load(HERE/'sentinel-source.json');source=Path(source)
 for name,sha in proof['sha256'].items():require(hashlib.sha256((source/name).read_bytes()).hexdigest()==sha,'sentinel source proof changed: '+name)
 return proof['revision']
def ipc(args):
 return subprocess.run(['/usr/bin/noctalia','msg',*args],capture_output=True,text=True,timeout=3)
def registry(source):
 source_check(source);result=ipc(['panel-close',SENTINEL])
 require(result.returncode==1,'sentinel did not return expected IPC error exit')
 return {'registered':PANEL in registration(result.stdout),'stdout':result.stdout,'stderr':result.stderr,'exit':result.returncode,'observedAt':time.monotonic()}
def catalog():
 result=ipc(['plugins','list']);require(result.returncode==0,'plugin catalog query failed')
 return {'enabled':enabled(result.stdout),'stdout':result.stdout,'stderr':result.stderr,'observedAt':time.monotonic()}
def rotation(code):
 spec=importlib.util.spec_from_file_location('rotation_guard',Path(code)/'rotation-guard.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 return mod.snapshot()
def timer_restored(journal,observed):
 require(journal['stage']=='restored','rotation journal not restored')
 before=journal['before']
 for name in ('timer','service'):require(observed[name]['config']==before[name]['config'],'rotation configuration changed')
 expected=before['timer']['state'] if before['timer']['state']['active']=='inactive' else journal['resumedState']
 require(observed['timer']['state']==expected and expected['active']==before['timer']['state']['active'],'timer activation not restored')
 require(observed['service']['state']['active']=='inactive' and observed['service']['result']=='success','rotation service not settled successfully')
 require(observed['timer']['subState']==('waiting' if expected['active']=='active' else 'dead'),'timer not settled')
def verify_restoration(contract,state,observed,journal):
 require(state.get('documentsEqual') is True and state.get('scratchExact') is True and state.get('canonicalMatchesExpected') is True and state.get('activeMatchesExpected') is True,'partial state restoration')
 require(observed['pointer']==contract['originalPointer'],'literal pointer not restored')
 require(type(contract['priorEnabled']) is bool and observed['enabled'] is contract['priorEnabled'] and observed['registered'] is contract['priorEnabled'],'plugin activation/registration not restored')
 timer_restored(journal,observed['rotation'])
 return {'documentsEqual':True,'scratchExact':True,'canonicalMatchesExpected':True,'activeMatchesExpected':True,'pointerExact':True,'pluginStateExact':True,'timerExact':True,'observedAt':time.monotonic()}
def state_verify(contract,mode):
 require(set(contract['stateEnvironment'])=={'PRISM_CONFIG_DIR','PRISM_STATE_DIR'} and all(isinstance(x,str) and Path(x).is_absolute() for x in contract['stateEnvironment'].values()),'explicit absolute config/state directories required')
 result=subprocess.run(['node',str(HERE/'state-verify.mjs'),mode,contract['snapshotBundle']],env=os.environ|contract['stateEnvironment']|{'PRISM_TASK3_REPO':contract['repo']},capture_output=True,text=True,timeout=10)
 require(result.returncode==0,'independent state verification failed: '+result.stderr)
 return json.loads(result.stdout)
def observe(contract):
 reg=registry(contract['sourceRoot']);cat=catalog()
 return {'pointer':os.readlink(contract['pointerPath']),'enabled':cat['enabled'],'registered':reg['registered'],'rotation':rotation(contract['codeRoot']),'registrationReceipt':reg,'catalogReceipt':cat,'observedAt':time.monotonic()}
def main():
 action=sys.argv[1];contract=load(sys.argv[2])
 if action in ARGV:result=response(action,ipc(ARGV[action]))
 elif action=='export-ready':
  result=registry(contract['sourceRoot']);require(result['registered'],'Prism panel export absent')
 elif action=='plugins-restore':
  require(type(contract['priorEnabled']) is bool,'prior enabled state missing')
  verb='plugins-enable' if contract['priorEnabled'] else 'plugins-disable';result=response(verb,ipc(ARGV[verb]))
 elif action=='current':result=state_verify(contract,'cleared')
 elif action=='restore-verify':result=verify_restoration(contract,state_verify(contract,'restored'),observe(contract),load(contract['rotationJournal']))
 else:raise ValueError('unknown fixed host command')
 print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
