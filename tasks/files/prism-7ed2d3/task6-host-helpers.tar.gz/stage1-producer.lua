-- Private Stage1-only actual-model probe. No model/profile/scratch rewriting.
arg[5]='harness'
local root=assert(os.getenv('PRISM_CAPTURE_CODE'))
local H=dofile(root..'/frozen-task2/self-check.lua')
local base,variant,prefix=arg[1],arg[6],arg[7]
local now=assert(tonumber(os.getenv('FIXTURE_START')))
local nativeos=os;os=setmetatable({clock=function() now=now+.0000001;return now end},{__index=nativeos})
local h=H.host(base..'/'..variant..'/plugin',true,false)
local initial=H.copy(h.model)
local identity=H.up(h.env.onFrameTick,'diagnosticIdentity')
assert(identity.stage=='stage1' and identity.coldPairs==5 and identity.launchPairs==5)
assert(#initial.profiles==24 and #initial.params==83)
for _,line in ipairs(h.logs) do io.write(line..'\n') end;io.flush()
local log=h.env.noctalia.log
h.env.noctalia.log=function(line) log(line);io.write(line..'\n');io.flush() end
local function step() local tick=assert(tonumber(io.read('*l')),'scheduler ended');now=math.max(now,tick) end
local function drain()
 for _=1,1000 do
  if not h.frame then return end
  step();h.env.onFrameTick(16)
  local pair=H.up(h.env.onFrameTick,'diagnosticPair')
  if pair and pair.pending and pair.frameDone then h.launches[#h.launches].callback(H.success) end
 end
 error('unbounded fixture drain')
end
assert(H.button(h,'Sample diagnostics')).props.onClick() -- Exactly one click; production observer expands admin cards.
drain()
local untilAt=now+6;local nextSecond=now+1
while now<untilAt do
 step()
 if now>=nextSecond then
  nextSecond=nextSecond+1;local count=#h.launches;h.env.update()
  if #h.launches>count then h.launches[#h.launches].callback(H.success) end
 end
 if h.frame then h.env.onFrameTick(16) end
end
drain()
assert(H.canonical(h.model)==H.canonical(initial),'actual model changed')
local reply=now -- Owner settles first; close is captured before the first inspection/checkpoint.
h.env.onClose();assert(not h.frame,'close must disable frame ticks')
for _,suffix in ipairs({'-initial','-final','-tail'}) do
 local f=assert(io.open(prefix..suffix..'.log','w'));f:write(table.concat(h.logs,'\n')..'\n');f:close()
end
local metadata={schema=2,initialModel=initial,initialReply=reply,finalReply=reply,recovery=false,diagnosticsClicks=1,modelUnchanged=true}
local f=assert(io.open(prefix..'-meta.json','w'));f:write(h.env.noctalia.json.encode(metadata));f:close()
print('PASS Stage1 current-model one click five cold plus five launch/control pairs '..variant)
