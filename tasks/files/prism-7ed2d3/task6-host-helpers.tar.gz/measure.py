"""Root-only, one read-only observation with measured elapsed time; no reserve claim."""
import hashlib,json,sys,time
from pathlib import Path
import host,drain
contract=host.load(sys.argv[2]);action=sys.argv[1];output=Path(sys.argv[3])
host.require(not output.exists(),'timing receipt already exists')
began=time.monotonic()
if action=='state-before':result=host.state_verify(contract,'before')
elif action=='registration':result=host.registry(contract['sourceRoot'])
elif action=='catalog':result=host.catalog()
elif action=='rotation':result=host.rotation(contract['codeRoot'])
elif action=='drain':result=drain.verify(contract['codeRoot'],contract['runRoot'],contract['expected'])
else:raise ValueError('unknown read-only timing action')
ended=time.monotonic()
record={'action':action,'started':began,'ended':ended,'elapsedSeconds':ended-began,'contractSha256':hashlib.sha256(Path(sys.argv[2]).read_bytes()).hexdigest(),'observation':result,'limits':'Component observation only; retained capture drain is representative, never a future live drain duration.'}
with output.open('x') as f:
 import os
 os.chmod(output,0o600);json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'action':action,'elapsedSeconds':ended-began,'receipt':str(output)}))
