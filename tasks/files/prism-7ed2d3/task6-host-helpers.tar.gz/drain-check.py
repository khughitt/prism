import sys,json,hashlib,copy,unittest,tempfile,shutil
from pathlib import Path
import drain
CODE=Path(sys.argv[1]);RUN=Path(sys.argv[2]);sys.argv=sys.argv[:1]
session=json.loads((RUN/'session.json').read_text());expected={k:session[k] for k in ['sessionId','runId','clockOrigin']};expected['activationNonce']=session['identity']['activationNonce'];expected['sessionFileSha256']=hashlib.sha256((RUN/'session.json').read_bytes()).hexdigest()
class Tests(unittest.TestCase):
 def test_wrong_nonce_does_not_drain_other_runtime(self):
  wrong=expected|{'activationNonce':'wrong'}
  with self.assertRaises(ValueError):drain.verify(CODE,RUN,wrong)
 def test_normal_raw_terminal_capture_is_independently_reread(self):
  result=drain.verify(CODE,RUN,expected);self.assertTrue(result['physicalDrainComplete']);self.assertTrue(result['ownedProcessesReaped']);self.assertEqual(result['activationNonce'],expected['activationNonce'])
 def test_raw_tail_and_saved_certificate_tampering_refuse(self):
  for fault in ('raw','certificate'):
   with tempfile.TemporaryDirectory() as d:
    target=Path(d)/'copy';shutil.copytree(RUN,target,symlinks=True)
    if fault=='raw':
     manifest=json.loads((target/'manifest.json').read_text());f=target/manifest['segments'][-1]['path'];f.write_bytes(f.read_bytes()+b'corruption')
    else:
     f=target/'state.json';state=json.loads(f.read_text());state['inspection']['certificates'][0]['physicalDrainComplete']=False;f.write_text(json.dumps(state))
    with self.assertRaises(ValueError):drain.verify(CODE,target,expected)
 def test_stopped_capture_only_proves_physical_drain(self):
  with tempfile.TemporaryDirectory() as d:
   target=Path(d)/'copy';shutil.copytree(RUN,target,symlinks=True)
   state=json.loads((target/'state.json').read_text());receipt=json.loads((target/'receipt.json').read_text());manifest=json.loads((target/'manifest.json').read_text())
   source=target/'source.log';source.write_bytes(Path(manifest['log']).read_bytes());st=source.stat();manifest['log']=str(source);manifest.pop('terminalCutoff',None);manifest['integrityComplete']=False;manifest['lastCheckpoint']='ready';manifest['current'].update(dev=st.st_dev,inode=st.st_ino);manifest['segments'][-1].update(dev=st.st_dev,inode=st.st_ino)
   receipt.update(exitReason='stop',integrityComplete=False);receipt.pop('terminalCutoff',None);state.update(phase='stopped',protocolComplete=False,coldProtocolComplete=False,invalid=['short/aborted collection']);state['receipts']['collectorExited']=receipt
   for name,value in [('state',state),('receipt',receipt),('manifest',manifest)]:(target/(name+'.json')).write_text(json.dumps(value))
   
   try:result=drain.verify(CODE,target,expected)
   except ValueError as e:self.fail('physical-only stopped capture refused: '+str(e))
   self.assertEqual(result['scope'],'physical-only-abort');self.assertFalse(result['protocolComplete']);self.assertTrue(result['physicalDrainComplete'])
   self.assertFalse(json.loads((target/'state.json').read_text())['protocolComplete'])
   source.write_bytes(source.read_bytes()+b'unobserved tail')
   with self.assertRaises(ValueError):drain.verify(CODE,target,expected)
if __name__=='__main__':unittest.main()
