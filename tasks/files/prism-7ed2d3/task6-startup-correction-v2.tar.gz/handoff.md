# Task6 round4 offline correction: ready issuance and restored source

This v2 private correction supersedes v1 only after Root's independent review. The
original54, original helpers, v1 namespace/attachment, and earlier evidence remain
immutable. This is not a new live packet, authorization, actual host/source/clock
proof, performance verdict, or qualification of these changed bytes by the old long
rehearsal. Root owns the future complete driver, packet, observations and permission.

## Fresh readiness

The existing call order stays: candidate read_capture snapshot; new consumed
checkpoint-authorize via Controller.invoke; Controller.control('ready'); wait for
the matching successful collector heartbeat; Controller.ready(candidate, sequence);
verify_initial and issue_initial for the exact candidate activation.

Controller.control('ready') now requires the preceding completed checkpoint attempt
and its successful result, preserving exact live consumed-permit and frozen-attempt
validation. It refuses an already used authorization, stale controller state, an
ambiguous prior sequence, or an unacknowledged prior control. It exclusively creates
ready-control-N.json before publishing the unchanged {sequence, command} payload.
The immutable record binds N, N-1, the control, attempt id, issuance time, and SHA256
of the session, frozen attempt and completed result. State records its exact hash
only after publication. An interrupted publication or state-save seam cannot certify
readiness; retain the failed namespace and reconcile deliberately. Do not replay a
mutation or issue overlapping ready commands. No new collector field or wire command
exists. Finish and stop payloads and behavior remain unchanged.

verify_ready requires this exact issuance record and state binding, authorization
completion after the candidate and before issuance, and a matching successful
heartbeat after issuance from the same collector/run/clock. It then uses the unchanged
reader to check prefix and identity coverage. A new authorization plus retained old
sequence and later ordinary poll refuses. The existing exact activation binding on
live issue_initial remains in force.

The added checkpoint_authorization helper merely shares the existing authorization
checks between control and verification, adding validation of the recorded elapsed
duration. The raw permit-result checks for enable/export/restore remain untouched;
checkpoint-authorize is the existing internal RootHost action and creates no external
command-result file.

## Restoration

host.verify_restoration now requires observed sourceBinding to equal expectedSource,
with catalogReceipt.source and sourceBinding.catalogSource both local. This shared
certificate path covers host.main('restore-verify') and reconcile('restore-verify').
Literal pointer, enabled/registered state, independent documents/scratch/canonical/
active state, and timer restoration checks remain required. Existing source discovery
and phase contracts are unchanged.

## Scope and checks

Scoped code delta is controller.py and host.py; two focused checks are new. Existing
startup-reader-check and host-check fixtures now supply evidence through actual
control issuance or the existing source binding shape. No production, collector,
supervisor, producer, probe, threshold, source commit, protocol or timing-window change.

The exact same-sequence/later-poll regression failed on unchanged v1 with the real
Controller and RootHost consuming synthetic permits. The conflicting remote catalog
failed its expected rejection on v1 through pure verification, direct restore-verify,
and reconciliation while local pointer/files, state and timer were valid. Both are
GREEN in v2. Eleven readiness tests cover valid live permit checks, resume, reuse,
overlap, missing/tampered proof, ordering, failed/wrong identity acknowledgment,
interrupted issuance, and unchanged finish/stop wire payloads. Two restoration tests
cover all three real paths. External IPC/state/timer observation alone is replaced by
synthetic fixture values; actual source binding and verification remain real.

Affected inherited checks passed: reader18, host7, pending-enable11, readiness6,
source-binding1, source-phase2, reconcile2, controller assertions, internal active
checked/finish assertions, and drain4. Two incomplete inherited fixtures first failed
and their output is retained. The one smallest complete real schema2 lifecycle passed
with protocol=True and cold=True using real producer/materializer/normalizer/collector/
controller ready/check/finish/exited, followed by owned cleanup. Its fake host is
synthetic evidence, not a substitute for live RootHost permit proof.

All commands used PYTHONDONTWRITEBYTECODE=1 for private Python checks. See commands.md
and evidence/ for RED, GREEN, inherited failures/final outputs, lifecycle and gates.
No production suite was run because production files are unchanged and the scoped
brief expressly requires only the affected private checks. No long rehearsal or live
host action was run. Root must freshly assess the complete driver and remaining
allowance before any future authorization.
