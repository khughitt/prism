"""Offline races: real collector publication, immutable parsed bytes, strict failures."""
import copy, json, os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import controller as c, logs

class Reader(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.log=self.root/'host.log';self.log.write_bytes(b'')
  self.manifest=self.root/'manifest.json';logs.start(self.log,self.manifest);self.capture=logs.Capture(self.manifest)
  self.append(1);self.capture.poll();self.capture.checkpoint('ready')
  self.archive=self.capture.paths()[0]
 def tearDown(self):self.capture.close();self.tmp.cleanup()
 def event(self,n):return ('prism-budget '+json.dumps({'activationNonce':'fixture','recordId':n})+'\n').encode()
 def append(self,n):
  with self.log.open('ab') as f:f.write(self.event(n))
 def publish(self):logs.save(self.manifest,self.capture.state)
 def grow_unpublished(self):
  self.append(2)
  with patch.object(logs,'save'):self.capture.poll()
 def test_append_before_publication_survives(self):
  self.grow_unpublished()
  with patch.object(c.time,'sleep',side_effect=lambda _:self.publish()):events,audit=c.read_capture(self.manifest)
  self.assertEqual([e['recordId'] for e in events],[1,2]);self.assertEqual(set(audit['rawLineSha256']),{'fixture:1','fixture:2'})
 def test_parser_never_sees_unaudited_tail(self):
  original=c.digest;done=[]
  def digest(raw):
   value=original(raw)
   if raw==self.event(1) and not done:
    done.append(True)
    with self.archive.open('ab') as f:f.write(self.event(2))
   return value
  with patch.object(c,'digest',side_effect=digest):events,audit=c.read_capture(self.manifest)
  self.assertEqual([e['recordId'] for e in events],[1]);self.assertEqual(set(audit['rawLineSha256']),{'fixture:1'})
 def test_changed_prefix_refuses_without_wait(self):
  self.grow_unpublished();self.archive.write_bytes(b'X'+self.archive.read_bytes()[1:])
  with patch.object(c.time,'sleep') as delay:
   with self.assertRaises(ValueError):c.read_capture(self.manifest)
   delay.assert_not_called()

 def test_manifest_publication_between_reads_preserves_lineage(self):
  original=Path.read_bytes;calls=[]
  def read(path):
   if path==self.manifest:
    calls.append(True)
    if len(calls)==2:self.append(2);self.capture.poll();self.capture.checkpoint('ready')
   return original(path)
  with patch.object(Path,'read_bytes',read):events,audit=c.read_capture(self.manifest)
  self.assertEqual([e['recordId'] for e in events],[1,2]);self.assertEqual(len(audit['snapshotRetries']),1)
  self.assertEqual(audit['rawManifestSha256'],c.digest(self.manifest.read_bytes()))
 def test_wrong_source_or_generation_on_retry_refuses(self):
  for changed in ('log','dev','startOffset'):
   with self.subTest(changed=changed):
    self.grow_unpublished()
    def mutate(_):
     m=c.load(self.manifest)
     if changed=='log':m['log']='other'
     else:m['segments'][0][changed]+=1
     self.manifest.write_bytes(c.encoded(m))
    with patch.object(c.time,'sleep',side_effect=mutate):
     with self.assertRaises(ValueError):c.read_capture(self.manifest)
    self.publish()
 def test_replaced_archive_refuses_even_with_identical_bytes(self):
  self.grow_unpublished()
  def replace(_):
   raw=self.archive.read_bytes();self.archive.rename(self.root/'old');self.archive.write_bytes(raw);self.publish()
  with patch.object(c.time,'sleep',side_effect=replace):
   with self.assertRaisesRegex(ValueError,'prefix/identity'):c.read_capture(self.manifest)
 def test_truncation_refuses(self):
  self.archive.write_bytes(self.event(1)[:-2])
  with patch.object(c.time,'sleep') as delay:
   with self.assertRaises(ValueError):c.read_capture(self.manifest)
   delay.assert_not_called()
 def test_sealed_append_refuses(self):
  self.log.rename(self.root/'host.log.1');self.log.write_bytes(self.event(2));self.capture.poll();self.capture.checkpoint('ready')
  with self.archive.open('ab') as f:f.write(b'extra')
  with patch.object(c.time,'sleep') as delay:
   with self.assertRaisesRegex(ValueError,'sealed/terminal'):c.read_capture(self.manifest)
   delay.assert_not_called()
 def test_strict_parser_refuses_before_retry(self):
  for payload in (b'{"activationNonce":"n","recordId":1,"recordId":2}',b'{"activationNonce":"n","recordId":NaN}',b'{',b'\xff'):
   with self.subTest(payload=payload):
    raw=b'prism-budget '+payload+b'\n';self.archive.write_bytes(raw)
    m=c.load(self.manifest);m['segments'][0].update(bytes=len(raw),endOffset=len(raw),sha256=c.digest(raw));m['current']['offset']=len(raw);self.manifest.write_bytes(c.encoded(m))
    with patch.object(c.time,'sleep') as delay:
     with self.assertRaises((ValueError,UnicodeDecodeError)):c.read_capture(self.manifest)
     delay.assert_not_called()
 def test_malformed_manifest_refuses(self):
  self.manifest.write_bytes(b'{"schema":2,"schema":2}')
  with self.assertRaisesRegex(ValueError,'duplicate JSON'):c.read_capture(self.manifest)
 def test_retry_count_and_deadline_exhaustion(self):
  self.grow_unpublished()
  with patch.object(c.time,'sleep') as delay:
   with self.assertRaisesRegex(ValueError,'retry exhausted.*active-append'):c.read_capture(self.manifest)
   self.assertEqual(delay.call_count,7)
  with patch.object(c.time,'monotonic',side_effect=[0,1]),patch.object(c.time,'sleep') as delay:
   with self.assertRaisesRegex(ValueError,'retry exhausted'):c.read_capture(self.manifest)
   delay.assert_not_called()
 def test_terminal_cutoff_is_exact_and_never_retried(self):
  self.capture.checkpoint('finish');m=c.load(self.manifest);receipt={'integrityComplete':True,'exitReason':'finish','error':None,'terminalCutoff':m['terminalCutoff']}
  self.assertTrue(c.read_capture(self.manifest,receipt)[1]['complete'])
  self.assertFalse(c.read_capture(self.manifest)[1]['complete'])
  for fault in ('missing','wrong','incomplete','append'):
   bad=copy.deepcopy(receipt)
   if fault=='missing':bad.pop('terminalCutoff')
   elif fault=='wrong':bad['terminalCutoff']['capturedBytes']+=1
   elif fault=='incomplete':bad['integrityComplete']=False
   else:
    with self.archive.open('ab') as f:f.write(b'tail')
   with patch.object(c.time,'sleep') as delay:
    with self.assertRaises(ValueError):c.read_capture(self.manifest,bad)
    delay.assert_not_called()
 def test_saved_prefix_requires_same_archive_identity(self):
  _,audit=c.read_capture(self.manifest);raw=self.archive.read_bytes();self.archive.rename(self.root/'old');self.archive.write_bytes(raw)
  with self.assertRaisesRegex(ValueError,'archive identity'):c.read_capture(self.manifest,prefix=audit)
 def test_fresh_ready_requires_candidate_then_owned_authorize_then_new_ack(self):
  run={'schema':2,'runId':'r','clockOrigin':'clock','manifest':str(self.manifest),'log':str(self.log)};c.immutable(self.root/'RUN.json',run)
  _,audit=c.read_capture(self.manifest)
  session={'runId':'r','clockOrigin':'clock','environment':'synthetic'}
  class Authorization:
   def invoke(self,action,authorization,arguments):return {'authorized':True}
  obj=c.Controller(self.root,session,Authorization())
  collector={'collectorStarted':audit['snapshotStarted']-1,'processes':{'collector':{'pid':123,'start':4,'boot':'synthetic'}}}
  obj.state['receipts']['collectorStarted']=collector;obj.save()
  ack=session|collector|{'lastSequence':0,'lastPollStart':c.time.monotonic(),'exitReason':'running','error':None};c.atomic(self.root/'heartbeat.json',ack)
  obj.invoke('checkpoint-authorize','synthetic');obj.control('ready');ack.update(lastSequence=1,lastPollStart=c.time.monotonic());c.atomic(self.root/'heartbeat.json',ack)
  self.assertEqual(c.verify_ready(self.root,audit,1)['candidateRawSha256'],audit['rawSha256'])
  for field,value in [('lastSequence',0),('error','failed'),('runId','other'),('lastPollStart',audit['snapshotStarted']-1)]:
   c.atomic(self.root/'heartbeat.json',ack|{field:value})
   with self.assertRaises(ValueError):c.verify_ready(self.root,audit,1)
  c.atomic(self.root/'heartbeat.json',ack);obj.state['attempts'][0]['started']=audit['snapshotStarted']-1;obj.save()
  with self.assertRaisesRegex(ValueError,'after candidate'):c.verify_ready(self.root,audit,1)
  self.assertFalse(audit['complete'])
 def test_live_card_cannot_issue_without_fresh_ready(self):
  root=self.root/'controller';root.mkdir()
  session={'environment':'live','identity':{'stage':'stage1','coldPairs':1,'launchPairs':0,'cardId':'card','activationNonce':'fixture'},'steps':{'pre':1,'post':1,'recovery':1,'finish':1}}
  obj=c.Controller(root,session,None,lambda:10);obj.state['phase']='enabled';obj.window=c.Window(0,session['steps'])
  activation={k:True for k in ('initialModelEmpty','initialStructureEmpty','initialMemoEmpty','initialDragEmpty','initialQueueEmpty','initialPairEmpty')};activation.update(initialRenderPending=False,initialEnqueued=0)
  with self.assertRaisesRegex(ValueError,'fresh ready'):obj.issue_initial(activation,{}, {'operations':[]},10)
  self.assertFalse((root/'owner-card.txt').exists())

 def test_unread_observed_tail_cannot_shrink_on_retry(self):
  original=c.os.fstat;calls=[0];self.grow_unpublished()
  def stat(fd):
   result=original(fd);calls[0]+=1
   # Simulate a legitimate append after read() but before the final descriptor stat.
   if calls[0]==2:
    with self.archive.open('ab') as f:f.write(b'unread-tail')
    result=original(fd)
   return result
  def shrink(_):
   self.archive.write_bytes(self.event(1)+self.event(2));self.publish()
  with patch.object(c.os,'fstat',side_effect=stat),patch.object(c.time,'sleep',side_effect=shrink):
   with self.assertRaisesRegex(ValueError,'prefix/identity'):c.read_capture(self.manifest)
 def test_stopped_receipt_is_strict_incomplete(self):
  stopped={'exitReason':'stop','integrityComplete':False,'error':None}
  self.assertFalse(c.read_capture(self.manifest,stopped)[1]['complete'])
  self.grow_unpublished()
  with patch.object(c.time,'sleep') as delay:
   with self.assertRaises(ValueError):c.read_capture(self.manifest,stopped)
   delay.assert_not_called()

 def test_terminal_append_at_parse_boundary_refuses(self):
  self.capture.checkpoint('finish');m=c.load(self.manifest);receipt={'integrityComplete':True,'exitReason':'finish','error':None,'terminalCutoff':m['terminalCutoff']};parse=c.analyze.read_bytes
  def append_after_read(raw):
   events=parse(raw)
   with self.archive.open('ab') as f:f.write(b'unaudited terminal tail')
   return events
  with patch.object(c.analyze,'read_bytes',side_effect=append_after_read),patch.object(c.time,'sleep') as delay:
   with self.assertRaisesRegex(ValueError,'terminal archive changed'):c.read_capture(self.manifest,receipt)
   delay.assert_not_called()

if __name__=='__main__':unittest.main()
