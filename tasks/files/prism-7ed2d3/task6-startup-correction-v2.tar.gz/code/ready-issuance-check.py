"""Actual controller and consumed synthetic RootHost permits; no external action."""
import copy, json, os, tempfile, time, unittest, uuid
from pathlib import Path
from unittest.mock import patch
import controller as c, logs

class Ready(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.log=self.root/'host.log';self.log.write_bytes(b'')
  self.manifest=self.root/'manifest.json';logs.start(self.log,self.manifest);self.capture=logs.Capture(self.manifest)
  with self.log.open('ab') as f:f.write(b'prism-budget {"activationNonce":"fixture","recordId":1}\n')
  self.capture.poll();self.capture.checkpoint('ready')
  c.immutable(self.root/'RUN.json',{'schema':2,'runId':'fixture-run','clockOrigin':'fixture-clock','manifest':str(self.manifest),'log':str(self.log)})
  self.session={'environment':'live','sessionId':'fixture-session','runId':'fixture-run','clockOrigin':'fixture-clock','hostActions':{'checkpoint-authorize':{}},'steps':{'pre':1,'post':1,'recovery':1,'finish':1}}
  self.obj=c.Controller(self.root,self.session,c.RootHost(self.root,self.session));self.obj.state['phase']='enabled'
  self.collector={'collectorStarted':time.monotonic()-1,'processes':{'collector':{'pid':123,'start':4,'boot':'synthetic'}}}
  self.obj.state['receipts']['collectorStarted']=self.collector;self.obj.save();self.ack()
 def tearDown(self):self.capture.close();self.tmp.cleanup()
 def candidate(self):return c.read_capture(self.manifest)[1]
 def authorize(self):
  now=time.monotonic();token='fixture-'+uuid.uuid4().hex;path=self.root/(token+'.json')
  c.immutable(path,{'approved':True,'author':'root-controller','sessionId':self.session['sessionId'],'runId':self.session['runId'],'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'permits':[{'id':token,'action':'checkpoint-authorize','arguments':{},'issuedAt':now,'expiresAt':now+10}]})
  self.obj.invoke('checkpoint-authorize',str(path))
 def ack(self,**changes):
  value={k:self.session[k] for k in ('runId','clockOrigin')}|self.collector|{'lastSequence':self.obj.state['sequence'],'lastPollStart':time.monotonic(),'exitReason':'running','error':None}
  c.atomic(self.root/'heartbeat.json',value|changes)
 def ready(self):
  candidate=self.candidate();self.authorize();self.obj.control('ready');self.ack();return candidate
 def test_retained_matching_sequence_after_new_authorization_and_ordinary_poll_refuses(self):
  old=self.ready();self.obj.ready(old,self.obj.state['sequence'])
  candidate=self.candidate();self.authorize();self.ack() # Ordinary poll: the same already acknowledged sequence.
  with self.assertRaises(ValueError):c.verify_ready(self.root,candidate,self.obj.state['sequence'])
 def test_new_control_and_ack_cover_candidate_after_resume(self):
  candidate=self.ready();obj=c.Controller.resume(self.root,c.RootHost(self.root,self.session));obj.ready(candidate,obj.state['sequence'])
  self.assertEqual(obj.state['readyAcknowledgment']['candidateRawSha256'],candidate['rawSha256'])
  self.assertFalse(obj.state['readyAcknowledgment']['coveringAudit']['complete'])
  self.assertEqual(c.load(self.root/'control.json'),{'sequence':1,'command':'ready'})
 def test_one_authorization_cannot_issue_two_ready_controls(self):
  self.ready();before=(self.root/'control.json').read_bytes()
  with self.assertRaises(ValueError):self.obj.control('ready')
  self.assertEqual((self.root/'control.json').read_bytes(),before)
 def test_overlapping_ready_commands_refuse_without_publishing(self):
  self.authorize();self.obj.control('ready');self.authorize();before=(self.root/'control.json').read_bytes()
  with self.assertRaises(ValueError):self.obj.control('ready')
  self.assertEqual((self.root/'control.json').read_bytes(),before)
 def test_missing_or_tampered_issuance_proof_refuses(self):
  candidate=self.ready();proof=self.root/'ready-control-1.json';raw=proof.read_bytes();proof.unlink()
  with self.assertRaises((ValueError,FileNotFoundError)):c.verify_ready(self.root,candidate,1)
  proof.write_bytes(raw);value=json.loads(raw)
  for field,changed in [('sequence',2),('previousSequence',1),('attemptId','other'),('issuedAt',0),('resultSha256','wrong')]:
   with self.subTest(field=field):
    c.atomic(proof,value|{field:changed})
    with self.assertRaises(ValueError):c.verify_ready(self.root,candidate,1)
  proof.write_bytes(raw)
 def test_candidate_after_authorization_and_ack_before_issuance_refuse(self):
  self.authorize();candidate=self.candidate();self.obj.control('ready');self.ack()
  with self.assertRaises(ValueError):c.verify_ready(self.root,candidate,1)
  candidate=self.ready();proof=c.load(self.root/'ready-control-2.json');self.ack(lastPollStart=proof['issuedAt']-.1)
  with self.assertRaises(ValueError):c.verify_ready(self.root,candidate,2)
 def test_completed_result_must_precede_issuance(self):
  self.authorize();attempt=self.obj.state['attempts'][-1];path=self.root/('result-'+attempt['id']+'.json');value=c.load(path);c.atomic(path,value|{'elapsedSeconds':100})
  with self.assertRaises(ValueError):self.obj.control('ready')
  self.assertFalse((self.root/'control.json').exists())
 def test_consumed_live_permit_and_frozen_attempt_still_required(self):
  candidate=self.ready();a=self.obj.state['attempts'][-1];p=self.root/'permits'/a['result']['permitId'];raw=p.read_bytes();p.unlink()
  with self.assertRaises((ValueError,FileNotFoundError)):c.verify_ready(self.root,candidate,1)
  p.write_bytes(raw);frozen=self.root/('attempt-'+a['id']+'.json');v=c.load(frozen);c.atomic(frozen,v|{'started':v['started']-1})
  with self.assertRaises(ValueError):c.verify_ready(self.root,candidate,1)
 def test_wrong_sequence_identity_or_failed_ack_refuses(self):
  candidate=self.ready()
  for field,value in [('lastSequence',0),('error','failed'),('runId','other'),('clockOrigin','other'),('processes',{}),('collectorStarted',0)]:
   with self.subTest(field=field):
    self.ack(**{field:value})
    with self.assertRaises(ValueError):c.verify_ready(self.root,candidate,1)
 def test_crash_between_issuance_and_control_refuses_replay(self):
  self.authorize();original=c.atomic
  def write(path,value):
   if Path(path).name=='control.json':raise OSError('synthetic interrupted publication')
   return original(path,value)
  with patch.object(c,'atomic',side_effect=write):
   with self.assertRaises(OSError):self.obj.control('ready')
  self.obj=c.Controller.resume(self.root,c.RootHost(self.root,self.session))
  with self.assertRaises((ValueError,FileExistsError)):self.obj.control('ready')
  self.assertFalse((self.root/'control.json').exists())
 def test_other_control_payloads_are_unchanged(self):
  for seq,command in enumerate(('finish','stop'),1):
   self.obj.control(command);self.assertEqual(c.load(self.root/'control.json'),{'sequence':seq,'command':command})

if __name__=='__main__':unittest.main()
