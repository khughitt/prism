# Reproduction commands

Run from the locked task worktree. Set N to the private v2 namespace from the
round4 locator. Python commands below use PYTHONDONTWRITEBYTECODE=1. Original private
outputs are retained under N; attachment evidence substitutes symbolic path labels.

- RED on the unchanged copied v1: python3 "$N/code/ready-issuance-check.py" Ready.test_retained_matching_sequence_after_new_authorization_and_ordinary_poll_refuses -v
- RED on the unchanged copied v1: python3 "$N/helpers/restoration-source-check.py" Restoration.test_remote_catalog_with_exact_local_files_and_state_refuses -v
- GREEN: python3 "$N/code/ready-issuance-check.py" -v
- GREEN: python3 "$N/helpers/restoration-source-check.py" -v
- Inherited: python3 "$N/code/startup-reader-check.py"
- Inherited: python3 "$N/code/controller-check.py"
- Inherited: python3 "$N/helpers/host-check.py"
- Inherited: python3 "$N/helpers/source-phase-check.py"
- Inherited: python3 "$N/helpers/reconcile-check.py"
- Inherited: python3 "$N/helpers/readiness-check.py"
- Inherited: python3 "$N/helpers/pending-enable-check.py"
- Inherited: python3 "$N/helpers/source-binding-check.py"
- Complete lifecycle: python3 "$N/code/startup-lifecycle-check.py" "$N/lifecycle-final" "$CAPTURE_ROOT/private-fixtures/model-private.lua" "$WORKTREE/bin/prism" (CLI uses its explicit resolved physical path)
- Internal read paths: python3 "$N/code/startup-internal-check.py" "$RUN" (RUN is the new lifecycle's handoff run)
- Terminal drain: python3 "$N/helpers/drain-check.py" "$N/code" "$RUN"
- Repository: just check; tasks check; git diff --check (each executed separately)
- Process cleanup observation: host-load --section session

The lifecycle subprocess has a120-second timeout and its harness uses finally and
TERM/INT handlers to reap the named owned processes. Every other interpreter check
has a30-second timeout. The initial focused RED/GREEN checks exit in under a second.
