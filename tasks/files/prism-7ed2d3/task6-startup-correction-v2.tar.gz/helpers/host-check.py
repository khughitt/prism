import unittest,subprocess,copy
from unittest.mock import patch
import host
class Tests(unittest.TestCase):
 def test_exit_zero_error_is_not_success(self):
  for action in ['panel-close','panel-open','plugins-disable','plugins-enable']:
   with self.assertRaises(ValueError):host.response(action,subprocess.CompletedProcess([],0,'error: unavailable\n',''))
 def test_readiness_requires_exact_unique_registration(self):
  for text in ['ok\n','error: unknown panel ":" (available: :)\n','error: unknown panel ":" (available: other/khughitt/prism:panel)\n','error: unknown panel ":" (available: khughitt/prism:panel, khughitt/prism:panel)\n','error: unknown panel ":" (available: khughitt/prism:panel) trailing\n']:
   with self.assertRaises(ValueError):host.registration(text)
 def test_partial_restore_never_certifies(self):
  with self.assertRaises((ValueError,KeyError)):host.verify_restoration({'originalPointer':'original','priorEnabled':True},{'documentsEqual':True,'scratchExact':False},{}, {})
 def test_exact_success_and_registration(self):
  self.assertFalse(host.response('panel-close',subprocess.CompletedProcess([],0,'ok\n',''))['exportPending'])
  self.assertTrue(host.response('plugins-enable',subprocess.CompletedProcess([],0,'ok (exporting in background)\n',''))['exportPending'])
  self.assertIn('khughitt/prism:panel',host.registration('error: unknown panel ":" (available: clipboard, khughitt/prism:panel)\n'))
  with self.assertRaises(ValueError):host.response('panel-open',subprocess.CompletedProcess([],1,'ok\n',''))
  with self.assertRaises(ValueError):host.response('panel-close',subprocess.CompletedProcess([],0,'ok (exporting in background)\n',''))
 def test_timeout_and_wrong_exit_refuse_readiness(self):
  with patch.object(host,'source_check',return_value='pinned'),patch.object(host,'ipc',side_effect=subprocess.TimeoutExpired('fixture',3)):
   with self.assertRaises(subprocess.TimeoutExpired):host.registry('fixture')
  with patch.object(host,'source_check',return_value='pinned'),patch.object(host,'ipc',return_value=subprocess.CompletedProcess([],0,'error: unknown panel ":" (available: khughitt/prism:panel)\n','')):
   with self.assertRaises(ValueError):host.registry('fixture')
 def test_substring_registration_is_not_exact_panel(self):
  with patch.object(host,'source_check',return_value='pinned'),patch.object(host,'ipc',return_value=subprocess.CompletedProcess([],1,'error: unknown panel ":" (available: khughitt/prism:panel-extra)\n','')):
   self.assertFalse(host.registry('fixture')['registered'])
 def test_full_restoration_and_each_partial_conflict(self):
  timer={'config':{'unit':'fixture'},'state':{'active':'active','activeEnter':'10','inactiveEnter':'2'},'subState':'waiting','result':'success'}
  service={'config':{'unit':'fixture-service'},'state':{'active':'inactive','activeEnter':'8','inactiveEnter':'9'},'subState':'dead','result':'success'}
  journal={'stage':'restored','before':{'timer':copy.deepcopy(timer),'service':copy.deepcopy(service)},'resumedState':dict(timer['state'],activeEnter='20')}
  observed={'pointer':'original','enabled':True,'registered':True,'rotation':{'timer':copy.deepcopy(timer),'service':copy.deepcopy(service)}};observed['rotation']['timer']['state']=journal['resumedState'].copy()
  state={k:True for k in ('documentsEqual','scratchExact','canonicalMatchesExpected','activeMatchesExpected')};contract={'originalPointer':'original','priorEnabled':True}
  observed.update(sourceBinding={'catalogSource':'local'},catalogReceipt={'source':'local'});contract['expectedSource']={'catalogSource':'local'}
  self.assertTrue(host.verify_restoration(contract,state,observed,journal)['timerExact'])
  for field in state:
   with self.assertRaises(ValueError):host.verify_restoration(contract,state|{field:False},observed,journal)
  for field,value in [('pointer','other'),('enabled',False),('registered',False)]:
   with self.assertRaises(ValueError):host.verify_restoration(contract,state,observed|{field:value},journal)
  changed=copy.deepcopy(observed);changed['rotation']['timer']['state']['activeEnter']='21'
  with self.assertRaises(ValueError):host.verify_restoration(contract,state,changed,journal)
  inactive=copy.deepcopy(journal);inactive['before']['timer']['state']['active']='inactive';inactive['before']['timer']['subState']='dead';inactiveObserved=copy.deepcopy(observed);inactiveObserved['rotation']['timer']=copy.deepcopy(inactive['before']['timer']);self.assertTrue(host.verify_restoration(contract,state,inactiveObserved,inactive)['timerExact'])
if __name__=='__main__':unittest.main()
