"""Restoration through real observation/verification and reconciliation, synthetic IPC only."""
import contextlib,copy,importlib.util,io,json,os,subprocess,sys,unittest
from pathlib import Path
from unittest.mock import patch
import host,reconcile
spec=importlib.util.spec_from_file_location('fixture',Path(__file__).with_name('pending-enable-check.py'));fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
class Restoration(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Pending();self.f.setUp();self.f.prepare('restore-verify');f=self.f
  f.contract.update(pointerPath=f.contract['pluginSource']['pointer_path'],originalPointer=f.contract['expectedSource']['literalTarget'],codeRoot='synthetic-code',rotationJournal=str(f.root/'rotation.json'))
  self.timer={'config':{'unit':'synthetic'},'state':{'active':'inactive','activeEnter':'1','inactiveEnter':'2'},'subState':'dead','result':'success'}
  self.rotation={'timer':copy.deepcopy(self.timer),'service':copy.deepcopy(self.timer)}
  f.write('rotation.json',{'stage':'restored','before':self.rotation});f.write('contract.json',f.contract)
  self.state={k:True for k in ('documentsEqual','scratchExact','canonicalMatchesExpected','activeMatchesExpected')}
 def tearDown(self):self.f.tearDown()
 def run_path(self,path,source):
  def ipc(args,deadline=None):
   if args==['plugins','list']:return subprocess.CompletedProcess([],0,'khughitt/prism ['+source+'] 1 enabled\n','')
   self.assertEqual(args,['panel-close',':']);return subprocess.CompletedProcess([],1,'error: unknown panel ":" (available: khughitt/prism:panel)\n','')
  with patch.object(host,'ipc',side_effect=ipc),patch.object(host,'source_check',return_value='synthetic'),patch.object(host,'rotation',return_value=self.rotation),patch.object(host,'state_verify',return_value=self.state):
   if path=='reconcile':return reconcile.reconcile(self.f.contract,'restore-verify')['receipt']
   if path=='direct':
    out=io.StringIO()
    with patch.object(sys,'argv',['host.py','restore-verify',str(self.f.root/'contract.json')]),contextlib.redirect_stdout(out):host.main()
    return json.loads(out.getvalue())
   return host.verify_restoration(self.f.contract,self.state,host.observe(self.f.contract),host.load(self.f.contract['rotationJournal']))
 def test_remote_catalog_with_exact_local_files_and_state_refuses(self):
  for path in ('verify','direct','reconcile'):
   with self.subTest(path=path):
    with self.assertRaises(ValueError):self.run_path(path,'remote')
 def test_local_source_restores_through_each_path(self):
  for path in ('verify','direct','reconcile'):
   with self.subTest(path=path):self.assertTrue(self.run_path(path,'local')['pluginStateExact'])
if __name__=='__main__':unittest.main()
