# Task6 offline startup correction handoff

This is a new private execution version, not the accepted54 source. No live packet,
permit, actual source/clock proof, owner card, performance verdict or authorization
is generated here. The old40-minute result covers unchanged collector/supervisor/
producer/probe behavior only. The failed B1 remains invalid, with no owner card and
its recorded351.816s controller allowance overrun. No40-minute rerun is authorized.

## Root startup ordering

Use this namespace's controller and helper files when constructing a fresh immutable
session/artifact inventory; never repoint the original accepted code. All new build,
run and activation identities must be fresh. Root must create and separately review
a complete concrete driver for startup, card completion, check, finish, restore and
abort; argv templates alone do not satisfy that next gate.

1. Root materializes the correct discovered local source pointer action from the
   running shell's explicit environment/home and pinned discovery rules below.
2. After actual enable/export/open, obtain `(events, candidate) = read_capture(...)`.
   This audits/parses one immutable byte snapshot. It does not acknowledge source
   validation, complete missing-error counts, or terminal completion.
3. After that snapshot, consume a NEW `checkpoint-authorize` action with
   `obj.invoke('checkpoint-authorize', authorization)`, then `obj.control('ready')`.
   Wait for the matching successful heartbeat sequence without issuing overlapping
   ready commands. A retained `lastCheckpoint=ready` label does not satisfy this.
4. Call `obj.ready(candidate, obj.state['sequence'])`. This requires the completed
   attempt/result, the consumed exact live permit, current ready control, matching
   run/clock/process/start identity, successful fresh heartbeat, and current archive
   coverage of every candidate prefix/identity. It saves `readyAcknowledgment`.
5. Run the unchanged `verify_initial` against the candidate activation, actual
   current state, new build sources and snapshot. Call `issue_initial` using that
   exact parsed activation. Live `issue_initial` now refuses absent/stale readiness
   or a different parsed activation hash. Do not reuse a candidate with a later
   control sequence. Root still owns all actual source, activation and clock proof.

`checked`, `finish`, `exited` and `inspect_run` use the shared corrected reader.
The normalized argument equality and final-observation rules remain strict. A real
new event between an external inspection and internal check requires a new current
inspection; the snapshot correction does not silently merge event histories.
`inspect_run.rawManifestSha256` comes from the exact manifest bytes used by its audit.

The reader has8 total attempts, a0.25s elapsed deadline and at most7 sleeps of up to
0.01s. Only append/publication with unchanged captured prefix, path, filesystem
identity and source lineage may retry. Diagnostics preserve causes and advertised,
read and observed extents. The bound is checked between synchronous reads/parsing;
it is NOT a preemptive filesystem-I/O timeout. Budget actual elapsed time under the
existing controller reserve. Normal calls include startup snapshot, `ready` coverage,
external inspection + internal `checked`, external pre-finish inspection + internal
`finish`, terminal `exited`, and final-drain inspection. Additional Root inspections
also consume reserve. Terminal or stopped receipts get no append retry. Finish cutoff
and terminal manifest/archive metadata remain exact; stop stays incomplete.

## Source contracts and phase mapping

`source_binding.bind_source` takes only Root-supplied values:
`environment` with explicit NOCTALIA_DATA_HOME/XDG_DATA_HOME values (None for absent),
`home`, `plugin_id='khughitt/prism'`, `pointer_path`, `catalog_source='local'`.
The pinned precedence is NOCTALIA_DATA_HOME, XDG_DATA_HOME, then home/.local/share;
each base gets `/noctalia/plugins`. Local discovery is highest precedence. Relative
roots, other sources, duplicate/missing selected IDs, unsupported API/panel entries,
wrong pointer entries/targets or expected hashes refuse. This narrow helper supports
the pinned API22 local plugin only; it does not guess another source's behavior.

Bindings contain selected plugin ID, catalog source, local root, discovered symlink
entry, literal target, resolved directory, manifest hash, panel entry and source hash.
Equal resolved directories do NOT make a config link the discovered data link.
Catalog/registration/prepared build hashes never replace the raw activation gate.

Each helper contract carries `pluginSource` (the arguments above) and `expectedSource`
(the complete exact binding), plus the existing run/session/expected fields. Root
materializes distinct immutable contracts for these observed phases:

| Action/observation | Expected discovered source |
| --- | --- |
| Initial close and disable, before pointer-swap | Original binding |
| Enable, export-ready, open, active close/disable | This activation's new binding |
| plugins-restore and restore-verify, after pointer-restore | Exact original binding |
| Pointer-swap reconciliation from/to | Original/new binding respectively |
| Pointer-restore reconciliation from/to | New/original binding respectively |

Pointer reconciliation additionally requires `pointerSources={'from': binding,
 'to': binding}` matching its immutable action path and literal endpoints. It chooses
the expected binding from the actual observed endpoint, then preserves the existing
attempt-bound completed/not-applied classification. Neither endpoint nor an unknown
source may be guessed. Other reconciliation observations use their action-specific
expectedSource; export reconciliation requires enabled/local/registered state.

## Receipt-bound asynchronous observation

`export-ready` reads the immediately preceding completed plugins-enable attempt from
this run's state and its immutable attempt/result files. It verifies the immutable
session hash/identity, exact consumed permit and raw successful permit-result JSON,
and the state receipt; it requires that result to precede the pending export attempt.
No copied boolean or catalog state substitutes for the preceding receipt.
`plugins-restore` validates its own pending attempt and consumed permit before issuing
exactly one enable/disable; its observation consumes that same in-process response.

Only `ok (exporting in background)` from that owned enable permits initial disabled
catalog observations. Every poll binds the actual source, requires exact local catalog
identity, and records the raw observation. Once enabled was seen, disabled is a fault.
Missing/duplicate/malformed/remote catalog, wrong provenance, unknown IPC responses and
source conflicts refuse. Plain ok and disable remain strict. Polling never repeats a
mutation. Each action retains the4s common deadline, each call uses remaining time,
late success refuses, and the existing5s outer contract is unchanged. Uncertain actions
still need Root reconciliation; failure does not mean no effect occurred.

## Evidence and limits

Focused reader, source, source-phase, pending-enable and internal-read tests accompany
this delta. The complete synthetic lifecycle uses the real unchanged Lua producer,
normalizer, materializer, collector and controller, with named private tmux cleanup.
It exercises ready/check/finish/exited and returns a complete schema2 synthetic result.
The separate internal fault-injection check uses disposable active snapshots, with no
source-integrity or terminal claim. IPC tests replace only external IPC, using real
synthetic session/attempt/permit/source files. One inherited pointer-reconciliation
unit test stubs source observation to retain its endpoint assertions; the new source
phase check exercises actual binding without that stub.

Drain compares all stable audit fields exactly while excluding only per-read start,
end and retry diagnostics. Stopped captures remain physical-only/incomplete, with
strict source/archive reread checks. No collector, control protocol, producer, probe,
production panel/queue/integration, thresholds, source commit or lifetime changed.

Review is still required. Root owns new actual observations, complete driver/packet,
remaining-time enforcement, actual permission and any future host run. No long
rehearsal or actual source/clock fact is certified by this correction.
