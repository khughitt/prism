"""Read-path fault injection on disposable copies of a new synthetic lifecycle.

The complete lifecycle/terminal provenance is tested separately by the real collector.
These temporary active snapshots make no source-integrity/terminal claim.
"""
import copy, json, shutil, sys, tempfile
from pathlib import Path
from unittest.mock import patch
import controller as c
SOURCE=Path(sys.argv[1])
class Host:
 def invoke(self,action,authorization,arguments):
  assert action=='finish-authorize';return {'authorized':True}
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp)/'run';shutil.copytree(SOURCE,root,symlinks=True)
 config=c.load(root/'RUN.json');config['manifest']=str(root/'manifest.json');c.atomic(root/'RUN.json',config)
 manifest=c.load(root/'manifest.json');manifest.pop('terminalCutoff');manifest['lastCheckpoint']='ready';c.atomic(root/'manifest.json',manifest)
 normal,context=c.inspect_run(root)
 original=manifest.copy();raw_manifest=(root/'manifest.json').read_bytes();real_materialize=c.materialize
 def publish_during_materialize(*args,**kwargs):
  value=real_materialize(*args,**kwargs);(root/'manifest.json').write_bytes(raw_manifest+b' ');return value
 with patch.object(c,'materialize',side_effect=publish_during_materialize):
  _,held=c.inspect_run(root)
 assert held['rawManifestSha256']==c.digest(raw_manifest)
 assert held['rawManifestSha256']!=c.digest((root/'manifest.json').read_bytes())
 (root/'manifest.json').write_bytes(raw_manifest)
 obj=c.Controller.resume(root,Host());obj.state['phase']='owner-complete';obj.state['invalid']=[];obj.window.invalid=[]
 for name in ('finishSent','collectorExited','restored'):obj.window.stamps.pop(name,None)
 obj.clock=lambda:max(obj.window.stamps.values())+.001;obj.save()
 def unpublished_append():
  m=c.load(root/'manifest.json');row=m['segments'][-1];p=root/row['path'];data=p.read_bytes()+b'ordinary synthetic observation\n';p.write_bytes(data)
  row.update(bytes=len(data),endOffset=row['startOffset']+len(data),sha256=c.digest(data));m['current']['offset']=row['endOffset']
  return m
 for operation in ('checked','finish'):
  pending=unpublished_append()
  with patch.object(c.time,'sleep',side_effect=lambda _:c.atomic(root/'manifest.json',pending)):
   if operation=='checked':obj.checked(normal)
   else:obj.finish('synthetic-owned-action',normal)
  audit=obj.state['inspectionAudit' if operation=='checked' else 'finishAudit']
  assert audit['snapshotRetries'] and audit['bytes']==sum(row['bytes'] for row in pending['segments'])
  events,again=c.read_capture(root/'manifest.json');assert {e['activationNonce']+':'+str(e['recordId']) for e in events}==set(audit['rawLineSha256'])
 assert obj.state['phase']=='finishing'
 print('PASS internal checked/finish append-publication retries, exact parsed/audited event IDs, inspect manifest bytes bound before later publication')
