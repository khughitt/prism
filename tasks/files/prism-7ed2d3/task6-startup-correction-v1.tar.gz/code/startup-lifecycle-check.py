"""One short real producer/collector/controller lifecycle, no live IPC."""
import importlib.util, sys
from pathlib import Path
s=importlib.util.spec_from_file_location('integration',Path(__file__).with_name('controller-integration.py'));it=importlib.util.module_from_spec(s);s.loader.exec_module(it)
result=it.pipeline('handoff','stage1')
assert result['normalized']['collectionComplete'] and result['state']['phase']=='restored'
assert result['state']['readyAcknowledgment']['candidateAudit']['firstEventSha256']
assert result['state']['finalAudit']['complete']
print('PASS schema2 real producer/materializer/normalizer/controller/check/finish/exited; explicit fresh-ready gate; owned cleanup')
