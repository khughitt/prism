"""Read-only reconciliation. Unobservable or ambiguous outcomes deliberately refuse."""
import hashlib,json,os,sys
from pathlib import Path
import host,drain
from host import require,load

def reconcile(contract,action):
 root=Path(contract['runRoot']);session=load(root/'session.json');state=load(root/'state.json');expected=contract['expected']
 require(hashlib.sha256((root/'session.json').read_bytes()).hexdigest()==expected['sessionFileSha256'],'session changed')
 for k in ('sessionId','runId','clockOrigin'):require(session[k]==expected[k],'session ownership mismatch')
 pending=[a for a in state['attempts'] if a['action']==action and a['status'] in ('pending','uncertain')]
 require(len(pending)==1,'missing/ambiguous unresolved attempt')
 attempt=pending[0];frozen=load(root/('attempt-'+attempt['id']+'.json'))
 require(all(attempt[k]==frozen[k] for k in ('id','action','phase','started')) and frozen['status']=='pending','attempt identity/phase changed')
 require(action in session['hostActions'],'action missing from immutable session')
 spec=session['hostActions'][action];permits=[]
 for path in (root/'permits').iterdir():
  if path.name.endswith(('-result','-pointer')):continue
  value=load(path);permit=value['permit']
  if value['action']==action and permit['arguments']==spec and permit['issuedAt']<=attempt['started']<=permit['expiresAt']:permits.append((path,value))
 require(len(permits)==1,'missing/ambiguous consumed exact permit for attempt window')
 permitpath,permit=permits[0];resultpath=root/('result-'+attempt['id']+'.json');durable=None
 if resultpath.exists():
  result=load(resultpath);require(result['action']==action,'durable result action changed');durable=result['result']
 def done(receipt):return {'attemptId':attempt['id'],'action':action,'outcome':'completed','receipt':receipt,'attemptPhase':attempt['phase'],'permitSha256':hashlib.sha256(permitpath.read_bytes()).hexdigest()}
 def unapplied():return {'attemptId':attempt['id'],'action':action,'outcome':'not-applied','receipt':{},'attemptPhase':attempt['phase'],'permitSha256':hashlib.sha256(permitpath.read_bytes()).hexdigest()}
 if action in ('pointer-swap','pointer-restore'):
  pointer=Path(spec['path']);require(pointer.is_symlink(),'pointer missing or replaced with regular file');current=os.readlink(pointer)
  require(spec['from']!=spec['to'],'identical pointer endpoints ambiguous')
  require(current in (spec['from'],spec['to']),'pointer conflict; preserve all targets and journal for root')
  endpoint='to' if current==spec['to'] else 'from';binding=contract['pointerSources'][endpoint]
  require(binding['pointerEntry']==str(pointer) and binding['literalTarget']==spec[endpoint],'pointer source binding names another action endpoint')
  host.source_observation(contract|{'expectedSource':binding})
  if current==spec['to']:
   journal=load(str(permitpath)+'-pointer');require(journal['what']==str(pointer) and journal['from']==spec['from'] and journal['to']==spec['to'],'pointer intent journal mismatch')
   return done({'pointer':str(pointer),'from':spec['from'],'to':current})
  if current==spec['from'] and durable is None:return unapplied()
  raise ValueError('pointer conflict; preserve all targets and journal for root')
 if action in ('state-clear','state-restore'):
  modes=('cleared','before') if action=='state-clear' else ('restored','cleared');observed={}
  for mode in modes:
   try:observed[mode]=host.state_verify(contract,mode)
   except ValueError:pass
  if modes[0] in observed and (durable is not None or modes[1] not in observed):return done(observed[modes[0]])
  if modes[1] in observed and modes[0] not in observed and durable is None:return unapplied()
  raise ValueError('state effect ambiguous/conflicting; retain snapshot and inspect exact scratch/documents')
 if action=='state-snapshot':
  bundle=Path(contract['snapshotBundle']);saved=Path(contract['savedState'])
  if not bundle.exists() and not saved.exists() and durable is None:return unapplied()
  require(bundle.exists() and saved.exists() and load(bundle)['saved']==load(saved),'partial/mismatched snapshot files')
  host.state_verify(contract,'before');return done({'snapshot':str(bundle),'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'readOnly':True})
 if action.startswith('rotation-'):
  journalpath=Path(contract['rotationJournal'])
  if action=='rotation-snapshot' and not journalpath.exists() and durable is None:return unapplied()
  journal=load(journalpath);observed=host.rotation(contract['codeRoot'])
  for name in ('timer','service'):require(observed[name]['config']==journal['before'][name]['config'],'rotation configuration conflict')
  if action=='rotation-snapshot':
   require(journal['stage']=='saved' and observed==journal['before'],'snapshot no longer matches actual rotation state')
   return done({'saved':str(journalpath),'timerActive':observed['timer']['state']['active'],'serviceActive':observed['service']['state']['active']})
  if action=='rotation-pause':
   if journal['stage']=='paused' and observed['timer']['state']==journal['pausedState'] and observed['timer']['state']['active']=='inactive' and observed['service']['state']['active']=='inactive' and observed['service']['result']=='success':return done({'timerPaused':True,'serviceInactive':True,'configurationPreserved':True,'previouslyActive':journal['before']['timer']['state']['active']=='active'})
   if journal['stage']=='saved' and observed==journal['before'] and durable is None:return unapplied()
  if action=='rotation-resume':
   host.timer_restored(journal,observed);return done({'timerRestored':True,'serviceInactive':True,'configurationPreserved':True,'active':observed['timer']['state']['active']=='active'})
  raise ValueError('partial timer stage; root must inspect pause/resume-issued journal and activation timestamps')
 if action in ('plugins-disable','plugins-enable','plugins-restore'):
  require(durable is not None,'plugin mutation lacks bound successful command receipt; current catalog alone cannot identify attempted runtime effect')
  enabled=(action=='plugins-enable' or action=='plugins-restore' and contract['priorEnabled'])
  host.source_observation(contract)
  cat=host.catalog();reg=host.registry(contract['sourceRoot']);require(cat['source']=='local' and cat['enabled'] is enabled and reg['registered'] is enabled,'plugin catalog/source/registration not settled')
  require(durable.get('stdout') in (['ok\n','ok (exporting in background)\n'] if enabled else ['ok\n']) and durable.get('exit')==0,'plugin receipt not successful')
  return done(durable)
 if action=='export-ready':
  host.source_observation(contract);cat=host.catalog();reg=host.registry(contract['sourceRoot']);require(cat['source']=='local' and cat['enabled'] and reg['registered'],'export absent or source conflict');return done(reg)
 if action=='final-drain':return done(drain.verify(contract['codeRoot'],root,expected))
 if action=='restore-verify':return done(host.verify_restoration(contract,host.state_verify(contract,'restored'),host.observe(contract),load(contract['rotationJournal'])))
 # Closing/opening may have happened without a durable response, and a launch may
 # have partially created children. No public visibility API proves the former.
 raise ValueError('no independent safe classification for '+action+'; root must retain attempt/permit/results, inspect exact panel raw boundary or named collector identities/control/receipt, and resolve without replaying effects')
if __name__=='__main__':print(json.dumps(reconcile(load(sys.argv[1]),sys.argv[2]),sort_keys=True))
