import contextlib, copy, hashlib, io, json, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import host, source_binding

def encode(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
class Pending(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);(self.root/'permits').mkdir();self.now=[100.]
  self.contract={'runRoot':str(self.root),'sourceRoot':'pinned-fixture','priorEnabled':True,'expected':{'sessionId':'s','runId':'r','clockOrigin':'clock','activationNonce':'n'}}
  self.state={'attempts':[],'receipts':{}};self.calls=[]
  plugin=self.root/'original';plugin.mkdir();(plugin/'plugin.toml').write_text('id="khughitt/prism"\nname="Prism fixture"\nversion="1.0.0"\nplugin_api=22\n[[panel]]\nid="panel"\nentry="panel.luau"\n');(plugin/'panel.luau').write_text('fixture')
  local=self.root/'data/noctalia/plugins';local.mkdir(parents=True);pointer=local/'prism';pointer.symlink_to(plugin)
  self.contract['pluginSource']={'environment':{'NOCTALIA_DATA_HOME':None,'XDG_DATA_HOME':str(self.root/'data')},'home':str(self.root),'plugin_id':'khughitt/prism','pointer_path':str(pointer),'catalog_source':'local'}
  self.contract['expectedSource']=source_binding.bind_source(**self.contract['pluginSource'])
 def tearDown(self):self.tmp.cleanup()
 def write(self,name,value):(self.root/name).write_bytes(encode(value))
 def prepare(self,action='export-ready',plain=False):
  self.session={'sessionId':'s','runId':'r','clockOrigin':'clock','identity':{'activationNonce':'n'},'hostActions':{x:{'argv':['fixture',x]} for x in ('plugins-enable',action)}}
  self.write('session.json',self.session);self.contract['expected']['sessionFileSha256']=hashlib.sha256((self.root/'session.json').read_bytes()).hexdigest()
  actions=['plugins-enable',action] if action=='export-ready' else [action]
  for n,verb in enumerate(actions):
   attempt={'id':'a'+str(n),'action':verb,'phase':'enabled','status':'pending','started':99.+n*.1};self.write('attempt-'+attempt['id']+'.json',attempt)
   self.write('permits/p'+str(n),{'action':verb,'permit':{'id':'p'+str(n),'arguments':self.session['hostActions'][verb],'issuedAt':98.,'expiresAt':110.}})
   if verb=='plugins-enable':
    result=host.response(verb,subprocess.CompletedProcess([],0,'ok\n' if plain else 'ok (exporting in background)\n',''))
    self.write('permits/p'+str(n)+'-result',{'exit':0,'stdout':json.dumps(result),'stderr':''})
    attempt=attempt|{'status':'completed','result':result};self.write('result-'+attempt['id']+'.json',{'action':verb,'result':result,'elapsedSeconds':.1});self.state['receipts'][verb]=result
   self.state['attempts'].append(attempt)
  self.write('state.json',self.state);self.write('contract.json',self.contract)
 def run_host(self,catalogs,regs=(False,True),action='export-ready',cost=.01):
  catalogs=iter(catalogs);regs=iter(regs);output=io.StringIO();errors=io.StringIO()
  def run(argv,**kw):
   args=argv[2:];self.calls.append((args,kw['timeout']));self.now[0]+=cost
   if args==['plugins','list']:
    value=next(catalogs);return subprocess.CompletedProcess(argv,0,('khughitt/prism [local] 1 '+('enabled' if value else 'disabled')+'\n') if type(value) is bool else value,'')
   if args==['panel-close',':']:
    value=next(regs);return subprocess.CompletedProcess(argv,1,'error: unknown panel ":"'+(' (available: khughitt/prism:panel)' if value else '')+'\n','')
   return subprocess.CompletedProcess(argv,0,'ok (exporting in background)\n' if args[1]=='enable' else 'ok\n','')
  with patch.object(sys,'argv',['host.py',action,str(self.root/'contract.json')]),patch.object(host,'source_check',return_value='pinned'),patch.object(host.subprocess,'run',side_effect=run),patch.object(host.time,'monotonic',side_effect=lambda:self.now[0]),patch.object(host.time,'sleep',side_effect=lambda n:self.now.__setitem__(0,self.now[0]+n)),contextlib.redirect_stdout(output),contextlib.redirect_stderr(errors):host.main()
  return json.loads(output.getvalue())
 def test_owned_pending_enable_allows_initial_disabled_without_replay(self):
  self.prepare();result=self.run_host([False,True,True]);self.assertTrue(result['registered']);self.assertEqual(len(result['polls']),3);self.assertFalse(any(a[:2]==['plugins','enable'] for a,t in self.calls))
 def test_restore_owns_its_one_enable(self):
  self.prepare('plugins-restore');result=self.run_host([False,True,True],action='plugins-restore');self.assertTrue(result['registration']['registered']);self.assertEqual(sum(a[:2]==['plugins','enable'] for a,t in self.calls),1)
 def test_plain_ok_stays_strict(self):
  self.prepare(plain=True)
  with self.assertRaises(ValueError):self.run_host([False])
 def test_regression_refuses(self):
  self.prepare()
  with self.assertRaises(ValueError):self.run_host([True,False],(False,))
 def test_unowned_or_stale_enable_refuses_before_ipc(self):
  self.prepare();self.state['attempts'][0]['id']='old';self.write('state.json',self.state)
  with self.assertRaises((ValueError,FileNotFoundError)):self.run_host([False])
  self.assertEqual(self.calls,[])
 def test_forever_pending_and_late_success_timeout(self):
  self.prepare()
  with self.assertRaises(TimeoutError):self.run_host([False]*100,cost=.4)
  self.assertTrue(all(t<=3 for a,t in self.calls));self.assertFalse(any(a[:2]==['plugins','enable'] for a,t in self.calls))
  self.calls=[];self.now[0]=100.
  with self.assertRaises(TimeoutError):self.run_host([True],(True,),cost=2.1)
  self.assertAlmostEqual(self.calls[-1][1],1.9)
 def test_missing_duplicate_and_remote_catalog_fail_immediately(self):
  self.prepare()
  for raw in ('other/plugin [local] 1 enabled\n','khughitt/prism [local] 1 disabled\n'*2,'khughitt/prism [remote] 1 enabled\n','khughitt/prism nonsense\n'):
   self.calls=[]
   with self.assertRaises(ValueError):self.run_host([raw])
   self.assertEqual(len(self.calls),1)
 def test_wrong_session_and_conflicting_receipt_refuse(self):
  self.prepare();self.contract['expected']['runId']='other';self.write('contract.json',self.contract)
  with self.assertRaises(ValueError):self.run_host([False])
  self.assertEqual(self.calls,[])
  self.contract['expected']['runId']='r';self.write('contract.json',self.contract)
  self.write('result-a0.json',{'action':'plugins-enable','result':{'exit':0,'stdout':'ok\n','exportPending':False},'elapsedSeconds':.1})
  with self.assertRaises(ValueError):self.run_host([False])
  self.assertEqual(self.calls,[])
 def test_replayed_export_and_disable_do_not_get_pending_allowance(self):
  self.prepare();self.state['attempts'][-1]['status']='completed';self.write('state.json',self.state)
  with self.assertRaises(ValueError):self.run_host([False])
  self.assertEqual(self.calls,[])
  self.state={'attempts':[],'receipts':{}};self.prepare('plugins-restore');self.contract['priorEnabled']=False;self.write('contract.json',self.contract)
  with self.assertRaises(ValueError):self.run_host([True],action='plugins-restore')
  self.assertEqual(sum(a[:2]==['plugins','disable'] for a,t in self.calls),1)
 def test_source_conflict_refuses_before_mutation(self):
  self.prepare('plugins-restore');self.contract['expectedSource']['panelSha256']='wrong';self.write('contract.json',self.contract)
  with self.assertRaises(ValueError):self.run_host([True],action='plugins-restore')
  self.assertEqual(self.calls,[])

 def test_consumed_enable_raw_result_cannot_conflict(self):
  self.prepare();self.write('permits/p0-result',{'exit':0,'stdout':'{}','stderr':''})
  with self.assertRaises(ValueError):self.run_host([True],(True,))
  self.assertEqual(self.calls,[])

if __name__=='__main__':unittest.main()
