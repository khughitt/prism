"""Independent terminal raw reread; never mutates controller/capture state."""
import hashlib,importlib.util,json,sys,time
from pathlib import Path
from host import require,load

def verify(code,root,expected):
 code=Path(code);root=Path(root);sys.path.insert(0,str(code))
 spec=importlib.util.spec_from_file_location('pilot_controller',code/'controller.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 cap=c.module('pilot_capture',code/'capture.py');session=load(root/'session.json');state=load(root/'state.json');receipt=load(root/'receipt.json')
 require(hashlib.sha256((root/'session.json').read_bytes()).hexdigest()==expected['sessionFileSha256'],'session bytes changed')
 for k in ('sessionId','runId','clockOrigin'):require(session[k]==expected[k],'wrong session '+k)
 identity=session['identity'];require(identity['activationNonce']==expected['activationNonce'],'wrong activation nonce')
 require(identity['runId']==session['runId'] and identity['clockOrigin']==session['clockOrigin'],'identity/session mismatch')
 aborted=receipt.get('exitReason')=='stop'
 require(state['phase'] in (('stopped','restoring','restored') if aborted else ('complete','restoring','restored')) and (aborted or not state['invalid']),'terminal controller state required; uncertain effects need root recovery')
 require(receipt==state['receipts']['collectorExited'],'collector final receipt changed')
 require(receipt['runId']==session['runId'] and receipt['clockOrigin']==session['clockOrigin'] and receipt['collectorStarted']==state['stamps']['collectorStarted'],'collector ownership mismatch')
 require(receipt.get('error') is None and (aborted or receipt.get('integrityComplete') is True and receipt.get('exitReason')=='finish'),'invalid terminal receipt')
 if aborted:require(state['protocolComplete'] is False and state['coldProtocolComplete'] is False and receipt['integrityComplete'] is False,'abort must remain incomplete')
 require(set(receipt['processes'])=={'server','wrapper','collector'},'owned identities missing')
 require(not any(cap.same_process(x) for x in receipt['processes'].values()),'owned collector still alive')
 if session['environment']=='live' and not aborted:require(receipt['wrapperEnded']>=state['stamps']['finishSent'],'collector exited before finish')
 manifest_before=(root/'manifest.json').read_bytes()
 normalized,context=c.inspect_run(root,receipt,None if aborted else state['finishAudit'])
 if aborted:
  require(context['captureAudit']['complete'] is False and context['captureAudit']['budgetErrors']==0,'invalid abort raw audit')
  manifest=load(root/'manifest.json');held=manifest['current'];last=manifest['segments'][-1]
  if session['environment']=='live':require(manifest['log']==load(session['collectorConfig'])['log'],'wrong live source log')
  require(held['generation']==last['generation'] and held['dev']==last['dev'] and held['inode']==last['inode'] and held['offset']==last['endOffset'],'abort source/archive mismatch')
  paths=[Path(manifest['log']),Path(manifest['log']+'.1')]
  def owned():return [p for p in paths if p.exists() and (p.stat().st_dev,p.stat().st_ino)==(held['dev'],held['inode'])]
  matches=owned();require(len(matches)==1,'abort source lost or ambiguous; root manual recovery required')
  with matches[0].open('rb',buffering=0) as source:
   import os
   before=os.fstat(source.fileno());require(before.st_size==held['offset'],'uncaptured abort source tail; root manual recovery required')
   source.seek(last['startOffset']);raw=source.read(last['bytes']);after=os.fstat(source.fileno())
   require(raw==(root/last['path']).read_bytes(),'abort source bytes differ')
   def stamp(st):return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
   require(stamp(before)==stamp(after)==stamp(matches[0].stat()) and owned()==matches,'abort source changed during verification')
 else:
  stable=lambda audit:{k:v for k,v in audit.items() if k not in ('snapshotStarted','snapshotEnded','snapshotRetries')}
  require(stable(context['captureAudit'])==stable(state['finalAudit']) and context['captureAudit']['complete'] and context['captureAudit']['budgetErrors']==0,'final raw audit changed/incomplete')
  require(normalized==state['inspection'],'final normalization/certificate changed')
 require(manifest_before==(root/'manifest.json').read_bytes(),'manifest changed during final drain')
 require(len(normalized['certificates'])==1 and c.drained(normalized),'physical drain incomplete')
 certificate=normalized['certificates'][0];require(certificate['activationNonce']==expected['activationNonce'],'certificate nonce mismatch')
 rows=normalized['events'];handoffs=[r for r in rows if r['class']=='handoff'];require(handoffs,'terminal closed handoff missing')
 boundary=c.analyze.handoff_boundary(rows,handoffs[-1]);require(boundary and boundary['marker']['recordId']==rows[-1]['recordId'],'terminal close/flush/marker tail incomplete')
 reference=(context['recovery'] or context['cards'][identity['activationNonce']])['reference']
 require(c.analyze.exact_reference(boundary['snapshot']['handoffReference'],reference),'final physical reference changed')
 return {'scope':'physical-only-abort' if aborted else 'complete-collection','protocolComplete':False if aborted else state['protocolComplete'],'physicalDrainComplete':True,'ownedProcessesReaped':True,'activationNonce':identity['activationNonce'],'runId':session['runId'],'sessionId':session['sessionId'],'clockOrigin':session['clockOrigin'],'rawManifestSha256':context['rawManifestSha256'],'collectorReceiptSha256':c.digest(c.encoded(receipt)),'certificateSha256':c.digest(c.encoded(certificate)),'rawSha256':context['captureAudit']['rawSha256'],'observedAt':time.monotonic()}
if __name__=='__main__':
 contract=load(sys.argv[1]);print(json.dumps(verify(contract['codeRoot'],contract['runRoot'],contract['expected']),sort_keys=True))
