import importlib.util, os, tempfile, unittest, host
from pathlib import Path
class Source(unittest.TestCase):
 def test_actual_discovered_entry_not_equivalent_resolved_link(self):
  spec=importlib.util.spec_from_file_location('source_binding',Path(__file__).with_name('source_binding.py'))
  if not Path(spec.origin).exists():self.fail('no actual-source binding; old pointer/catalog predicates admit the wrong entry')
  m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);data=root/'data/noctalia/plugins';data.mkdir(parents=True);config=root/'config';config.mkdir();original=root/'original';original.mkdir();candidate=root/'candidate';candidate.mkdir()
   for target,text in ((original,'original'),(candidate,'candidate')):
    (target/'plugin.toml').write_text('id="khughitt/prism"\nname="Prism fixture"\nversion="1.0.0"\nplugin_api=22\n[[panel]]\nid="panel"\nentry="panel.luau"\n');(target/'panel.luau').write_text(text)
   actual=data/'prism';actual.symlink_to(original);wrong=config/'prism';wrong.symlink_to(original)
   args={'environment':{'NOCTALIA_DATA_HOME':None,'XDG_DATA_HOME':str(root/'data')},'home':str(root),'plugin_id':'khughitt/prism','pointer_path':str(actual),'catalog_source':'local'}
   before=m.bind_source(**args);self.assertEqual(before['resolvedDirectory'],str(original))
   # Even equal targets are separate pointer entries; old candidate+catalog+registration predicates pass.
   with self.assertRaises(ValueError):m.bind_source(**(args|{'pointer_path':str(wrong)}))
   wrong.unlink();wrong.symlink_to(candidate)
   self.assertEqual(os.readlink(wrong),str(candidate));self.assertTrue(host.enabled('khughitt/prism [local] 1 enabled\n'));self.assertIn(host.PANEL,host.registration('error: unknown panel ":" (available: khughitt/prism:panel)\n'))
   with self.assertRaises(ValueError):m.bind_source(**(args|{'pointer_path':str(wrong)}))
   actual.unlink();actual.symlink_to(candidate);after=m.bind_source(**args)
   self.assertNotEqual(before['panelSha256'],after['panelSha256'])
   with self.assertRaises(ValueError):m.bind_source(**args,expected=before)
   actual.unlink();actual.symlink_to(original);self.assertEqual(m.bind_source(**args,expected=before),before)
   for key,value in [('plugin_id','wrong/id'),('catalog_source','remote')]:
    with self.assertRaises(ValueError):m.bind_source(**(args|{key:value}))
   duplicate=data/'duplicate';duplicate.symlink_to(original)
   with self.assertRaises(ValueError):m.bind_source(**args)
   duplicate.unlink()
   for key in ('literalTarget','panelSha256','manifestSha256'):
    with self.assertRaises(ValueError):m.bind_source(**args,expected=before|{key:'wrong'})
   manifest_path=original/'plugin.toml';valid=manifest_path.read_text()
   for changed in (valid.replace('name="Prism fixture"\n',''),valid.replace('id="khughitt/prism"','id="other/plugin"'),valid+'[[panel]]\nid="panel"\nentry="panel.luau"\n'):
    manifest_path.write_text(changed)
    with self.assertRaises(ValueError):m.bind_source(**args)
   manifest_path.write_text(valid)
   for environment,home,expected_root in [({'NOCTALIA_DATA_HOME':str(root/'override'),'XDG_DATA_HOME':str(root/'data')},str(root),root/'override/noctalia/plugins'),({'NOCTALIA_DATA_HOME':'','XDG_DATA_HOME':''},str(root),root/'.local/share/noctalia/plugins')]:
    self.assertEqual(m.local_root(environment,home),expected_root)
   with self.assertRaises(ValueError):m.local_root({'NOCTALIA_DATA_HOME':'relative','XDG_DATA_HOME':None},str(root))
if __name__=='__main__':unittest.main()
