import copy, hashlib, importlib.util, json, os, unittest
from pathlib import Path
import host, source_binding, reconcile
spec=importlib.util.spec_from_file_location('pending_fixture',Path(__file__).with_name('pending-enable-check.py'));pf=importlib.util.module_from_spec(spec);spec.loader.exec_module(pf)
class Phases(unittest.TestCase):
 def setUp(self):
  self.fx=pf.Pending();self.fx.setUp();self.pointer=Path(self.fx.contract['pluginSource']['pointer_path']);self.original=os.readlink(self.pointer);self.before=copy.deepcopy(self.fx.contract['expectedSource'])
  candidate=self.fx.root/'candidate';candidate.mkdir();(candidate/'plugin.toml').write_bytes((Path(self.original)/'plugin.toml').read_bytes());(candidate/'panel.luau').write_text('new activation source')
  self.candidate=str(candidate);self.point(self.candidate);self.after=source_binding.bind_source(**self.fx.contract['pluginSource']);self.point(self.original)
 def tearDown(self):self.fx.tearDown()
 def point(self,value):self.pointer.unlink();self.pointer.symlink_to(value)
 def test_original_candidate_original_action_contracts(self):
  for action,where,binding in [('panel-close',self.original,self.before),('plugins-disable',self.original,self.before),('plugins-enable',self.candidate,self.after),('panel-open',self.candidate,self.after),('panel-close',self.candidate,self.after),('plugins-disable',self.candidate,self.after)]:
   self.point(where);self.fx.state={'attempts':[],'receipts':{}};self.fx.prepare(action);self.fx.contract['expectedSource']=binding;self.fx.write('contract.json',self.fx.contract);result=self.fx.run_host([],action=action);self.assertEqual(result['exit'],0)
  self.point(self.original);self.fx.contract['expectedSource']=self.before;self.assertEqual(host.source_observation(self.fx.contract),self.before)
 def test_pointer_reconciliation_uses_observed_endpoint_and_hashes(self):
  f=self.fx;f.prepare('pointer-swap');spec={'path':str(self.pointer),'from':self.original,'to':self.candidate};f.session['hostActions']['pointer-swap']=spec;f.write('session.json',f.session);f.contract['expected']['sessionFileSha256']=hashlib.sha256((f.root/'session.json').read_bytes()).hexdigest();f.write('permits/p0',{'action':'pointer-swap','permit':{'id':'p0','arguments':spec,'issuedAt':98,'expiresAt':110}});f.write('permits/p0-pointer',{'what':str(self.pointer),'from':self.original,'to':self.candidate})
  f.contract['pointerSources']={'from':self.before,'to':self.after};f.contract['expectedSource']=self.after
  self.assertEqual(reconcile.reconcile(f.contract,'pointer-swap')['outcome'],'not-applied')
  self.point(self.candidate);self.assertEqual(reconcile.reconcile(f.contract,'pointer-swap')['outcome'],'completed')
  (Path(self.candidate)/'panel.luau').write_text('conflict')
  with self.assertRaises(ValueError):reconcile.reconcile(f.contract,'pointer-swap')
if __name__=='__main__':unittest.main()
