"""Pure local-discovery binding from pinned Noctalia source; no host IPC or mutation.

FileUtils::dataDir -> localSourceRoot -> applyPluginSourcesToRegistry (local last),
PluginRegistry::scanDir/resolve. Root supplies the running shell environment.
This binds files/pointer entries only; raw activation identity still gates the card.
"""
import hashlib, os, re, tomllib
from pathlib import Path

def require(ok,message):
 if not ok:raise ValueError(message)
def local_root(environment,home):
 require(all(k in environment for k in ('NOCTALIA_DATA_HOME','XDG_DATA_HOME')),'explicit running-shell data environment required')
 require(all(environment[k] is None or isinstance(environment[k],str) for k in ('NOCTALIA_DATA_HOME','XDG_DATA_HOME')),'invalid shell environment')
 require(isinstance(home,str) and Path(home).is_absolute() and environment.get('HOME',home)==home,'explicit consistent shell home required')
 base=environment['NOCTALIA_DATA_HOME'] or environment['XDG_DATA_HOME'] or str(Path(home)/'.local/share')
 require(Path(base).is_absolute(),'relative data root unsupported')
 return Path(os.path.normpath(base))/'noctalia/plugins'
def bind_source(environment,home,plugin_id,pointer_path,catalog_source,expected=None):
 require(plugin_id=='khughitt/prism' and catalog_source=='local','unsupported plugin/source precedence')
 root=local_root(environment,home);matches=[]
 for entry in sorted(root.iterdir()):
  if not entry.is_dir() or not (entry/'plugin.toml').is_file():continue
  raw=(entry/'plugin.toml').read_bytes();manifest=tomllib.loads(raw.decode())
  if manifest.get('id')==plugin_id:matches.append((entry,raw,manifest))
 require(len(matches)==1,'missing/duplicate local plugin identity')
 entry,raw,manifest=matches[0]
 require(Path(pointer_path).is_absolute() and Path(os.path.normpath(pointer_path))==entry,'action pointer is not discovered plugin entry')
 require(entry.is_symlink(),'discovered entry is not the authorized symlink')
 literal=os.readlink(entry);resolved=entry.resolve(strict=True)
 require(isinstance(manifest.get('name'),str) and manifest['name'] and isinstance(manifest.get('version'),str) and re.fullmatch(r'(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)',manifest['version']),'missing/invalid plugin name or version')
 panels=manifest.get('panel',[])
 require(manifest.get('plugin_api')==22 and len([p for p in panels if p.get('id')=='panel'])==1,'unsupported API or missing/duplicate panel identity')
 panel=next(p for p in panels if p.get('id')=='panel')['entry'];relative=Path(panel)
 require(not relative.is_absolute() and '..' not in relative.parts and relative.parts,'unsupported panel source path')
 source=(entry/relative).resolve(strict=True);require(source.is_relative_to(resolved),'panel source escapes plugin directory')
 data=source.read_bytes()
 require(entry.resolve(strict=True)==resolved and os.readlink(entry)==literal and (entry/'plugin.toml').read_bytes()==raw and source.read_bytes()==data,'discovered source changed during binding')
 binding={'pluginId':plugin_id,'catalogSource':'local','localRoot':str(root),'pointerEntry':str(entry),'literalTarget':literal,'resolvedDirectory':str(resolved),'manifestSha256':hashlib.sha256(raw).hexdigest(),'panelEntry':panel,'panelSha256':hashlib.sha256(data).hexdigest()}
 if expected is not None:require(binding==expected,'discovered source differs from expected binding')
 return binding
