"""Read-only private inventory and noncircular proposal verification."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
N=Path(__file__).resolve().parent;M=Path(sys.argv[1]);output=Path(sys.argv[2]);os.umask(0o077)
def load(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def encode(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def inventory(root):return {str(f.relative_to(root)):{'symlink':os.readlink(f)} if f.is_symlink() else {'sha256':sha(f)} for f in root.rglob('*') if f.is_file() or f.is_symlink()}
m=load(M)
assert m['authorized'] is False and m['runnable'] is False
for file,value in m['inventory'].items():assert sha(file)==value,file
assert [e['label'] for e in m['activations']]==['B1','C1','C2','B2']
identities=[]
for e in m['activations']:
    s=load(e['session']);assert sha(e['session'])==e['sessionSha256']==hashlib.sha256(encode(s)).hexdigest()
    assert sha(e['collector'])==e['collectorSha256'];assert not Path(e['runRoot']).exists()
    for key,file in e['contracts'].items():
        assert sha(file)==e['contractSha256'][key]
        ct=load(file);assert ct['expected']['sessionFileSha256']==e['sessionSha256']
        assert file not in s['artifactSha256']
    for file,value in s['artifactSha256'].items():assert sha(file)==value
    identity=s['identity'];identities.append(identity)
    assert identity['coldPairs']==1 and identity['launchPairs']==(1 if e['label'] in ('B1','C1') else 0)
    assert s['collectorConfig']==str(Path(e['runRoot'])/'run.json')
assert len({i['activationNonce'] for i in identities})==4 and len({i['runId'] for i in identities})==4
assert not Path(m['outer']['runRoot']).exists()
for file in ('actual','actual-review.json','actual-owner-approval.json'):assert not (N/file).exists()
for key,value in load(N/'preserved-before.json').items():assert inventory(Path(value['root']))==value['inventory'],key
S=Path(load(N/'inputs.json')['corrected']);accepted=load(S/'new-input-inventory.json')
for key,value in accepted.items():assert sha(S/key)==value,key
code={k[5:]:v for k,v in accepted.items() if k.startswith('code/')}
code_digest=hashlib.sha256(encode(code)).hexdigest()
assert len(code)==58 and code_digest=='4ea47695846dbcdf1d2dff5bf703486ccfe38da597a71d56e314d0abb89fdfce'
workspace=Path(m['repo'])/'.superpowers/sdd/2026-10-13-panel-budget-capture-recovery'
prep=Path((workspace/'task-6-prep-path.txt').read_text().strip());original=load(S/'original-input-inventory.json')
for key,value in original.items():assert sha(((S.parent.parent if key.startswith('code/') else prep)/key))==value,key
original_code={k[5:]:v for k,v in original.items() if k.startswith('code/')}
original_digest=hashlib.sha256(encode(original_code)).hexdigest()
assert original_digest=='4203ac5942263fcda74d5f741549674ecb0194345012b575229d5d0409ed5b32'
for file in N.glob('*.py'):compile(file.read_bytes(),str(file),'exec')
# Enter the real front door with the frozen exact packet. Missing actual authority
# must reject before it creates any live namespace or actual permit directory.
result=subprocess.run([m['interpreters']['python'],'-B',str(N/'packet_driver.py'),'--master',str(M),'--master-sha',sha(M),'start','--label','B1'],capture_output=True,text=True,timeout=10)
assert result.returncode!=0 and 'actual-review.json' in result.stderr
assert not (N/'actual').exists() and not any(Path(e['runRoot']).exists() for e in m['activations'])
proof={'passed':True,'masterSha256':sha(M),'inventoryCount':len(m['inventory']),'activations':4,'noncircularCanonicalSessions':True,
       'code58Digest':code_digest,'original54Digest':original_digest,'correctedFailedAndRootInputsUnchanged':True,
       'original69InputsUnchanged':True,'liveFrontDoorRejectedWithoutActualReviewAndApproval':True,'noLiveNamespacesOrPermitsCreated':True}
with output.open('x') as f:json.dump(proof,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(proof,sort_keys=True))
