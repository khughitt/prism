"""Synthetic integration regressions; real Controller/Guard/RootHost/dispatch/helpers.

Only process/clock/owner facts and the external process boundary are fixtures.
No actual review, approval or host command is created or invoked.
"""
import contextlib, copy, hashlib, importlib.util, io, json, os, pathlib, subprocess, sys, tempfile, time, types, unittest, uuid
from unittest.mock import patch
P=pathlib.Path
N=P(__file__).resolve().parent
INPUT=json.loads((N/'inputs.json').read_text());S=P(INPUT['corrected']);OLD=P(INPUT['priorPacket'])
sys.path[:0]=[str(N/'helpers'),str(S/'code')]
def mod(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
D=mod('round5_driver',P(os.environ.get('TEST_DRIVER',str(N/'packet_driver.py'))))
C=mod('round5_controller',S/'code/controller.py')
H=mod('round5_host',N/'helpers/host.py')
CLOCK=mod('round5_clock',S/'code/clock-gate.py')
def load(p):return json.loads(P(p).read_bytes())
def sha(p):return hashlib.sha256(P(p).read_bytes()).hexdigest()

class Fixture:
    def __init__(self,base=None):
        self.tmp=tempfile.TemporaryDirectory(prefix='synthetic-round5-') if base is None else None
        self.base=P(self.tmp.name) if self.tmp else P(base)
        if not self.tmp:self.base.mkdir(mode=0o700)
        self.root=self.base/'run';self.root.mkdir();(self.base/'actual').mkdir()
        self.master=self.base/'master.json';self.commands=[];self.notes=[];self.observations=[]
        self.fd=20;self.log=self.base/'cache/noctalia/noctalia.log';self.log.parent.mkdir(parents=True);self.log.write_text('synthetic log\n')
        self.environment={'HOME':str(self.base),'XDG_CACHE_HOME':str(self.base/'cache'),'NOCTALIA_DATA_HOME':str(self.base/'data'),'XDG_DATA_HOME':None}
        self.process={'pid':43210,'startTicks':1234,'bootId':'synthetic-boot'}
        self.running={'pid':43210,'startTicks':1234,'sha256':'binary-hash','buildId':'binary-build'}
        self.installed={'path':'/synthetic/bin/noctalia','sha256':'binary-hash','buildId':'binary-build','package':'noctalia synthetic'}
        self.proof={'schema':2,'environment':'live','synthetic':True,'sessionId':'synthetic-group','observed':{
            'bootId':'synthetic-boot','running':self.running,'installed':self.installed,
            'sourceRevision':CLOCK.REVISION,'sourceFiles':CLOCK.SOURCE_HASHES,'pythonMonotonic':'clock_gettime(CLOCK_MONOTONIC)'},
            'binding':{'rootSessionId':'synthetic-group','sourceRevision':CLOCK.REVISION,'binarySha256':'binary-hash','package':'noctalia synthetic','noHostClockOverride':True,'linuxClock':'CLOCK_MONOTONIC','originOffsetSeconds':0},
            'excerpts':{k:{'fileSha256':v,'firstLine':1,'text':'synthetic excerpt'} for k,v in CLOCK.SOURCE_HASHES.items()}}
        self.historical={'origins':['host-monotonic:synthetic-old'],'controllerOrigin':'host-monotonic:synthetic-old','probeOrigin':'synthetic-probe','controllerTimestamp':1.01,'probeTimestamp':1}
        self.desc={'process':self.process,'log':{'path':str(self.log),'fd':20,'dev':self.log.stat().st_dev,'inode':self.log.stat().st_ino},
                   'capacityBytes':1048576,'backupCount':1,'maximumLineBytes':8192,'sourceFile':str(self.base/'log.cpp'),'sourceFileSha256':''}
        (self.base/'log.cpp').write_text('synthetic pinned logger');self.desc['sourceFileSha256']=sha(self.base/'log.cpp')
        self.sources={}
        # Copy the frozen source facts; keep the real sentinel hash validator.
        self.sentinel_source=self.base/'sentinel-source'
        pinned=P(load(OLD/'proposals-final/B1-source-check@original.json')['sourceRoot'])
        for name,digest in load(N/'helpers/sentinel-source.json')['sha256'].items():
            target=self.sentinel_source/name;target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes((pinned/name).read_bytes());assert sha(target)==digest
        H.source_check(self.sentinel_source)
        local=self.base/'data/noctalia/plugins';local.mkdir(parents=True);self.pointer=local/'prism'
        self.pluginSource={'environment':self.environment,'home':str(self.base),'plugin_id':'khughitt/prism','pointer_path':str(self.pointer),'catalog_source':'local'}
        for name in ('original','active'):
            dest=self.base/name;dest.mkdir();(dest/'plugin.toml').write_text('id = "khughitt/prism"\nname = "Prism"\nversion = "1.0.0"\nplugin_api = 22\n[[panel]]\nid = "panel"\nentry = "panel.luau"\n');(dest/'panel.luau').write_text('-- synthetic '+name+'\n')
            self.pointer.symlink_to(str(dest));self.sources[name]=H.source_binding.bind_source(**self.pluginSource);self.pointer.unlink()
        self.pointer.symlink_to(str(self.base/'original'))
        actions={}
        for action in ('panel-close','panel-open','plugins-enable','plugins-disable','export-ready','plugins-restore','restore-verify','final-drain','reconcile-pointer-swap','reconcile-pointer-restore'):
            actions[action]={'argv':[str(P(sys.executable).resolve()),'-B',str(P(D.__file__).resolve()),'dispatch',str(self.master),'B1',action],'timeoutSeconds':5,'json':True}
        actions['pointer-swap']={'path':str(self.pointer),'from':str(self.base/'original'),'to':str(self.base/'active')}
        actions['pointer-restore']={'path':str(self.pointer),'from':str(self.base/'active'),'to':str(self.base/'original')}
        actions['checkpoint-authorize']={}
        self.session={'sessionId':'synthetic-group','runId':'synthetic-run','clockOrigin':'synthetic-clock','environment':'synthetic','identity':{'activationNonce':'synthetic-nonce'},'hostActions':actions}
        sess=self.base/'frozen-session.json';session_sha=C.immutable(sess,self.session)
        self.entry={'label':'B1','runRoot':str(self.root),'session':str(sess),'sessionSha256':session_sha,'contracts':{},'contractSha256':{},'sourceContracts':{}}
        expected={k:self.session[k] for k in ('sessionId','runId','clockOrigin')}|{'activationNonce':'synthetic-nonce','sessionFileSha256':session_sha}
        for phase in ('original','active'):
            for action in list(actions)+['source-check']:
                key=action+'@'+phase;p=self.base/(key+'.json')
                ct={'runRoot':str(self.root),'expected':expected,'pluginSource':self.pluginSource,'expectedSource':self.sources[phase],
                    'sourceRoot':str(self.sentinel_source),'originalPointer':str(self.base/'original'),'priorEnabled':True,'action':action,'sourcePhase':phase}
                if action.startswith('reconcile-pointer-'):
                    a=actions[action.removeprefix('reconcile-')];ct['pointerSources']={k:self.sources['original' if a[k]==str(self.base/'original') else 'active'] for k in ('from','to')}
                self.entry['contracts'][key]=str(p);self.entry['contractSha256'][key]=C.immutable(p,ct)
                if action=='source-check':self.entry['sourceContracts'][phase]=str(p)
        for name,value in [('proof',self.proof),('source',{'environment':self.environment}),('log',self.desc)]:C.immutable(self.base/(name+'.json'),value)
        self.m={'sessionId':'synthetic-group','preparedAt':time.monotonic()-1,'helpers':str(N/'helpers'),'code':str(S/'code'),
                'interpreters':{'python':str(P(sys.executable).resolve())},'activations':[self.entry],
                'sourceProof':str(self.base/'proof.json'),'sourceObservation':str(self.base/'source.json'),'logObservation':str(self.base/'log.json'),'r2Root':'synthetic-history',
                'steps':{'pre':36,'post':21,'recovery':20,'finish':67},'inventory':{},'logReobservation':{'attempts':8,'elapsedSeconds':.25,'pollSeconds':.01}}
        self.master_sha=C.immutable(self.master,self.m)
        self.approval={'kind':'approval','author':'root-controller','synthetic':True,'approved':True,'sessionId':'synthetic-group','masterSha256':self.master_sha,'receivedAt':time.monotonic(),
            'labels':['B1','C1','C2','B2'],'provenance':{'human':True,'harness':'codex','rootSessionId':'synthetic-root','messageId':'synthetic-message'}}
        C.immutable(self.base/'actual-owner-approval.json',self.approval)
        self.review={'accepted':True,'synthetic':True,'masterSha256':self.master_sha};C.immutable(self.base/'actual-review.json',self.review)
        self.driver=D.Driver.__new__(D.Driver);self.driver.root=self.base;self.driver.master=self.master;self.driver.master_sha=self.master_sha;self.driver.m=self.m
        self.driver.c=C;self.driver.host=H;self.driver.clock=CLOCK;self.driver.note=self.notes.append
        self.obj=C.Controller(self.root,self.session,D.Guard(self.driver,self.entry,self.session))
        self.real_run=subprocess.run;self.real_readlink=os.readlink;self.real_read_bytes=P.read_bytes;self.real_read_text=P.read_text;self.before_dispatch=None;self.extra_external=None
        self.enabled=True;self.pending=False;self.log_sequence=[]
    def close(self):
        if self.tmp:self.tmp.cleanup()
    def read_bytes(self,path):
        if str(path)=='/proc/43210/environ':return '\0'.join(k+'='+v for k,v in self.environment.items() if v is not None).encode()
        return self.real_read_bytes(path)
    def readlink(self,path,*args,**kwargs):
        if str(path)=='/proc/43210/fd/20':
            if self.log_sequence:
                item=self.log_sequence.pop(0)
                if isinstance(item,Exception):raise item
                return item
            return str(self.log)
        return self.real_readlink(path,*args,**kwargs)
    def fact(self,proof,source,descriptor):
        if self.log_sequence:
            item=self.log_sequence.pop(0)
            if isinstance(item,Exception):raise item
            if item is None:return {'process':self.process,'running':self.running,'installedPath':self.installed['path'],'environment':self.environment,'active':None,'descriptors':[]}
            if isinstance(item,dict):return item
        st=self.log.stat();identity={'dev':st.st_dev,'inode':st.st_ino}
        return {'process':self.process,'running':self.running,'installedPath':self.installed['path'],'environment':self.environment,
                'active':identity,'descriptors':[{'fd':self.fd,'path':str(self.log),'identity':identity,'writable':True}]}
    def owner_view(self,path):
        value=load(path)
        # Explicit test adapter for synthetic human facts; production's real entry
        # rejects these exact on-disk fixtures. All other receipt checks run intact.
        if P(path) in (self.base/'actual-review.json',self.base/'actual-owner-approval.json'):return value|{'synthetic':False}
        return value
    def external(self,argv,**kwargs):
        if 'dispatch' in argv and str(self.master) in argv:
            if self.before_dispatch:self.before_dispatch(argv[-1])
            out=io.StringIO();err=io.StringIO()
            try:
                with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):D.dispatch(str(self.master),argv[-2],argv[-1])
                return subprocess.CompletedProcess(argv,0,out.getvalue(),err.getvalue())
            except (ValueError,OSError,KeyError,TimeoutError) as e:return subprocess.CompletedProcess(argv,1,out.getvalue(),err.getvalue()+str(e))
        if argv[:2]==['/usr/bin/noctalia','msg']:
            command=argv[2:];self.commands.append(command)
            if command==['plugins','list']:stdout='khughitt/prism [local] 1.0.0 '+('enabled' if self.enabled else 'disabled')+'\n';rc=0
            elif command==['panel-close',':']:stdout='error: unknown panel ":"'+(' (available: khughitt/prism:panel)' if self.enabled else '')+'\n';rc=1
            elif command in (['plugins','enable','khughitt/prism'],['plugins','disable','khughitt/prism']):
                self.enabled=command[1]=='enable';stdout='ok (exporting in background)\n' if self.enabled and self.pending else 'ok\n';rc=0
            elif command in (['panel-close','khughitt/prism:panel'],['panel-open','khughitt/prism:panel']):stdout='ok\n';rc=0
            else:raise AssertionError('unhandled synthetic IPC '+repr(argv))
            return subprocess.CompletedProcess(argv,rc,stdout,'')
        if self.extra_external:return self.extra_external(argv,**kwargs)
        raise AssertionError('external command not isolated: '+repr(argv))
    def exec(self,exe,argv):
        path=P(argv[1] if argv[1]!='-B' else argv[2]);args=argv[2:] if argv[1]!='-B' else argv[3:]
        helper=mod('synthetic_exec_'+uuid.uuid4().hex,path)
        with patch.object(sys,'argv',[str(path),*args]):
            if path.name=='host.py':helper.main()
            elif path.name=='reconcile.py':print(json.dumps(helper.reconcile(helper.load(args[0]),args[1]),sort_keys=True))
            elif path.name=='drain.py':
                ct=helper.load(args[0]);print(json.dumps(helper.verify(ct['codeRoot'],ct['runRoot'],ct['expected']),sort_keys=True))
            else:raise AssertionError('unexpected helper '+str(path))
    @contextlib.contextmanager
    def active(self):
        with contextlib.ExitStack() as stack:
            for context in (patch.object(D,'load',side_effect=self.owner_view),patch.object(CLOCK,'observe',return_value=self.proof['observed']),
                    patch.object(CLOCK,'historical',return_value=self.historical),patch.object(P,'read_bytes',lambda path:self.read_bytes(path)),
                    patch.object(P,'read_text',lambda path,*a,**kw:'' if str(path)=='/proc/43210/task/43210/children' else self.real_read_text(path,*a,**kw)),patch.object(os,'readlink',self.readlink),patch.object(subprocess,'run',side_effect=self.external),patch.object(os,'execv',side_effect=self.exec),
                    patch.dict(os.environ,{'CODEX_THREAD_ID':'synthetic-root'})):
                stack.enter_context(context)
            if hasattr(D,'log_facts'):stack.enter_context(patch.object(D,'log_facts',side_effect=self.fact))
            yield self
    def invoke(self,action):
        auth=self.driver.batch(self.entry,self.session,[action]);return self.obj.invoke(action,auth)

class Regressions(unittest.TestCase):
    def setUp(self):self.f=Fixture();self.addCleanup(self.f.close)
    def test_overlapping_close_permits_are_bound_to_distinct_attempts(self):
        f=self.f
        with f.active():
            f.invoke('panel-close');first=f.obj.state['attempts'][-1]
            f.invoke('panel-close');second=f.obj.state['attempts'][-1]
        self.assertEqual(f.commands,[['panel-close','khughitt/prism:panel']]*2)
        self.assertLess(second['started']-first['started'],55)
        self.assertEqual(len(list(f.root.glob('dispatch-*.json'))),2)
    def test_reconciled_swap_without_original_result_allows_next_dispatch(self):
        f=self.f
        with f.active():
            original=C.immutable
            def interrupted(path,value):
                if P(path).name.startswith('result-') and value.get('action')=='pointer-swap':raise OSError('synthetic crash after pointer effect')
                return original(path,value)
            with patch.object(C,'immutable',side_effect=interrupted):
                with self.assertRaises(OSError):f.invoke('pointer-swap')
            target=f.obj.state['attempts'][-1]
            f.obj.reconcile(f.driver.batch(f.entry,f.session,['reconcile-pointer-swap']),target['id'])
            self.assertFalse((f.root/('result-'+target['id']+'.json')).exists())
            self.assertEqual(f.obj.state['attempts'][0]['reconciliation']['outcome'],'completed')
            f.invoke('panel-close')
    def test_rotation_gap_then_new_descriptor_passes_audit(self):
        f=self.f;f.fd=21
        f.log_sequence=[None] if hasattr(D,'log_facts') else [FileNotFoundError('synthetic rotation close/reopen gap')]
        with f.active():f.driver.audit(f.entry)
    def test_ineligible_interim_activation_restores_outer(self):
        f=self.f;obj=f.obj;obj.state.update(protocolComplete=True,invalid=[],stamps={'initialCompleteReceived':50,'initialCardIssued':40})
        obj.restore=lambda auth:None
        for name,value in [('driver-finish',{'began':90}),('driver-start',{'began':50}),('receipt',{}),('default-socket-before',None),('driver-pre',{'elapsedSeconds':30,'ceilingSeconds':36}),('driver-post',{'elapsedSeconds':22,'ceilingSeconds':21})]:C.immutable(f.root/(name+'.json'),value)
        f.m['outer']={'journal':str(f.base/'outer-journal.json')};C.immutable(f.base/'outer-journal.json',{'stage':'restored'})
        calls=[];f.driver.outer=lambda action:calls.append(action) or {'timerRestored':True};f.driver.controller=lambda label:(obj,f.entry,f.session)
        with patch.object(f.driver,'audit'),patch.object(f.driver,'batch'),patch.object(D,'default_socket',return_value=None),patch.object(D.time,'monotonic',return_value=100),patch.object(C,'read_capture',return_value=([],{'budgetErrors':0,'rawSha256':'synthetic'})):
            result=f.driver.restore('B1')
        self.assertEqual(calls,['restore']);self.assertFalse(result['collectionGate'])

class Boundaries(unittest.TestCase):
    def fixture(self):
        f=Fixture();self.addCleanup(f.close);return f
    def test_binding_refuses_missing_tampered_conflicting_unconsumed_or_wrong_owner(self):
        for defect in ('missing','attempt','session','spec','late-issue','unconsumed','conflict','auth-hash','expired'):
            with self.subTest(defect=defect):
                f=self.fixture()
                def corrupt(action):
                    a=load(f.root/'state.json')['attempts'][-1];p=f.root/('binding-'+a['id']+'.json');v=load(p)
                    if defect=='missing':p.unlink();return
                    if defect=='attempt':v['attemptId']='other-attempt'
                    if defect=='session':v['sessionId']='other-session'
                    if defect=='auth-hash':v['authorizationSha256']='other-hash'
                    if defect=='unconsumed':(f.root/'permits'/v['permitId']).unlink();return
                    if defect=='conflict':C.immutable(f.root/'binding-other.json',v);return
                    if defect in ('spec','late-issue','expired'):
                        auth=P(v['authorization']);value=load(auth);permit=value['permits'][0]
                        if defect=='spec':permit['arguments']={'argv':['wrong-spec']}
                        if defect=='late-issue':permit['issuedAt']=a['started']+1
                        if defect=='expired':permit['expiresAt']=a['started']-1
                        auth.write_bytes(C.encoded(value));v['authorizationSha256']=sha(auth)
                        (f.root/'permits'/v['permitId']).write_bytes(C.encoded({'action':action,'permit':permit,'authorizationSha256':v['authorizationSha256']}))
                    p.write_bytes(C.encoded(v))
                f.before_dispatch=corrupt
                with f.active():
                    with self.assertRaises(ValueError):f.invoke('panel-close')
                self.assertEqual(f.commands,[])
    def test_real_subprocess_dispatch_and_exec_helper_keep_close_bindings(self):
        f=self.fixture();shim=f.base/'synthetic-python-boundary';shim.mkdir();ipc=f.base/'synthetic-ipc.jsonl'
        code="""import json,os,pathlib,subprocess
+original_read=pathlib.Path.read_bytes
+review=REVIEW_PATH
+def read(path):
+ raw=original_read(path)
+ if str(path)==review:
+  value=json.loads(raw);assert value['synthetic'] is True;value['synthetic']=False;return json.dumps(value).encode()
+ return raw
+pathlib.Path.read_bytes=read
+original_run=subprocess.run
+def run(argv,**kwargs):
+ if argv[:2]==['/usr/bin/noctalia','msg']:
+  assert argv[2:]==['panel-close','khughitt/prism:panel'],argv
+  with open(IPC_PATH,'a') as stream:stream.write(json.dumps({'synthetic':True,'argv':argv})+'\\n')
+  return subprocess.CompletedProcess(argv,0,'ok\\n','')
+ return original_run(argv,**kwargs)
+subprocess.run=run
+""".replace('\n+','\n').replace('REVIEW_PATH',repr(str(f.base/'actual-review.json'))).replace('IPC_PATH',repr(str(ipc)))
        (shim/'sitecustomize.py').write_text(code)
        external=f.external
        def transport(argv,**kw):
            if 'dispatch' in argv and str(f.master) in argv:
                return f.real_run(argv,**(kw|{'env':os.environ|kw.get('env',{})|{'PYTHONPATH':str(shim)}}))
            return external(argv,**kw)
        f.external=transport
        with f.active():
            f.invoke('panel-close');first=f.obj.state['attempts'][-1]
            f.invoke('panel-close');second=f.obj.state['attempts'][-1]
        self.assertLess(second['started']-first['started'],55)
        self.assertEqual(len(ipc.read_text().splitlines()),2)
        self.assertEqual(len(list(f.root.glob('dispatch-*.json'))),2)
        self.assertTrue(load(f.base/'actual-review.json')['synthetic'])
    def test_reusing_authorization_for_new_attempt_refuses_before_second_effect(self):
        f=self.fixture()
        with f.active():
            auth=f.driver.batch(f.entry,f.session,['panel-close']);f.obj.invoke('panel-close',auth)
            with self.assertRaisesRegex(ValueError,'already consumed'):f.obj.invoke('panel-close',auth)
        self.assertEqual(len(f.commands),1)
    def test_dispatch_immutable_claim_refuses_second_entry(self):
        f=self.fixture();real=f.exec
        def execute(exe,argv):
            real(exe,argv)
            with self.assertRaises(FileExistsError):D.dispatch(str(f.master),'B1','panel-close')
        f.exec=execute
        with f.active():f.invoke('panel-close')
        self.assertEqual(len(f.commands),1)
    def test_pending_enable_previous_result_selects_exact_binding_with_overlap(self):
        f=self.fixture();f.pending=True
        with f.active():
            f.invoke('plugins-enable');f.invoke('plugins-enable');result=f.invoke('export-ready')
        self.assertTrue(result['registered']);self.assertEqual(sum(x==['plugins','enable','khughitt/prism'] for x in f.commands),2)
        previous=f.obj.state['attempts'][-2];self.assertEqual(result['enableOwner']['attemptId'],previous['id'])
    def test_pending_enable_rejects_conflicting_previous_raw_result(self):
        f=self.fixture();f.pending=True
        with f.active():
            f.invoke('plugins-enable');a=f.obj.state['attempts'][-1];b=load(f.root/('binding-'+a['id']+'.json'))
            (f.root/'permits'/(b['permitId']+'-result')).write_text(json.dumps({'exit':0,'stdout':'{}','stderr':''}))
            before=len(f.commands)
            with self.assertRaises(ValueError):f.invoke('export-ready')
        self.assertEqual(len(f.commands),before)
    def reconcile_pointer(self,f,action,outcome):
        original=C.immutable
        def interrupted(path,value):
            if P(path).name.startswith('result-') and value.get('action')==action:raise OSError('synthetic lost original result')
            return original(path,value)
        with patch.object(C,'immutable',side_effect=interrupted):
            with self.assertRaises(OSError):f.invoke(action)
        target=f.obj.state['attempts'][-1]
        if outcome=='not-applied':
            f.pointer.unlink();f.pointer.symlink_to(f.session['hostActions'][action]['from'])
        f.obj.reconcile(f.driver.batch(f.entry,f.session,['reconcile-'+action]),target['id'])
        self.assertEqual(target['reconciliation']['outcome'],outcome)
        return target
    def test_reconciliation_completed_and_not_applied_swap_restore_audit_and_dispatch(self):
        for action in ('pointer-swap','pointer-restore'):
            for outcome in ('completed','not-applied'):
                with self.subTest(action=action,outcome=outcome):
                    f=self.fixture()
                    with f.active():
                        if action=='pointer-restore':f.invoke('pointer-swap')
                        target=self.reconcile_pointer(f,action,outcome)
                        phase=D.source_phase(f.root,None,load(f.entry['sourceContracts']['original']),H)
                        self.assertEqual(phase,'active' if (action=='pointer-swap')==(outcome=='completed') else 'original')
                        f.driver.audit(f.entry);f.invoke('panel-close');f.invoke('plugins-disable')
                        if phase=='active':f.invoke('pointer-restore')
                        self.assertEqual(os.readlink(f.pointer),str(f.base/'original'))
                        self.assertFalse((f.root/('result-'+target['id']+'.json')).exists())
    def test_reconciliation_tampered_binding_result_order_or_outcome_refuses(self):
        for defect in ('raw','outcome','target','ordering','permit','session','missing-recon','receipt','unresolved','original-duration'):
            with self.subTest(defect=defect):
                f=self.fixture()
                with f.active():
                    target=self.reconcile_pointer(f,'pointer-swap','completed');a=f.obj.state['attempts'][-1];state=load(f.root/'state.json')
                    if defect=='raw':
                        binding=load(f.root/('binding-'+a['id']+'.json'));p=f.root/'permits'/(binding['permitId']+'-result');v=load(p);v['stdout']='{}';p.write_bytes(C.encoded(v))
                    if defect=='outcome':state['attempts'][0]['status']='not-applied'
                    if defect=='target':state['attempts'][0]['reconciliation']['attemptId']='other'
                    if defect=='ordering':
                        p=f.root/('result-'+a['id']+'.json');v=load(p);v['elapsedSeconds']=1000;p.write_bytes(C.encoded(v))
                    if defect=='permit':(f.root/('binding-'+a['id']+'.json')).unlink()
                    if defect=='session':(f.root/'session.json').write_bytes((f.root/'session.json').read_bytes()+b' ')
                    if defect=='missing-recon':state['attempts']=state['attempts'][:1]
                    if defect=='receipt':state['receipts']['pointer-swap']={}
                    if defect=='unresolved':state['attempts'][0]['status']='uncertain'
                    if defect=='original-duration':C.immutable(f.root/('result-'+target['id']+'.json'),{'action':'pointer-swap','result':state['receipts']['pointer-swap'],'elapsedSeconds':1000})
                    C.atomic(f.root/'state.json',state)
                    with self.assertRaises((ValueError,OSError,KeyError)):f.driver.audit(f.entry)
    def test_log_reobservation_same_new_reused_fd_and_failures(self):
        for case in ('same','new','reused-old','process','binary','path','ambiguous','mismatch','environment','settings','source','absent','late'):
            with self.subTest(case=case):
                f=self.fixture();good=f.fact(None,None,None);bad=copy.deepcopy(good)
                if case in ('same','new','reused-old'):
                    f.fd=20 if case=='same' else 21;f.log_sequence=[None]
                elif case=='process':bad['process']['startTicks']+=1
                elif case=='binary':bad['running']['sha256']='wrong'
                elif case=='path':bad['descriptors'][0]['path']='/wrong/log'
                elif case=='ambiguous':bad['descriptors'].append(copy.deepcopy(bad['descriptors'][0]))
                elif case=='mismatch':bad['descriptors'][0]['identity']={'dev':0,'inode':0}
                elif case=='environment':bad['environment']['HOME']='/other'
                elif case=='settings':f.desc['capacityBytes']=2;C.atomic(f.base/'log.json',f.desc)
                elif case=='source':(f.base/'log.cpp').write_text('changed')
                elif case=='absent':f.log_sequence=[None]*8
                if case not in ('same','new','reused-old','absent'):f.log_sequence=[bad]
                with f.active():
                    if case=='late':
                        real=f.driver.record
                        def slow(*args,**kwargs):real(*args,**kwargs);time.sleep(.26)
                        f.driver.record=slow
                    if case in ('same','new','reused-old'):f.driver.audit(f.entry)
                    else:
                        with self.assertRaises((ValueError,TimeoutError)):f.driver.audit(f.entry)
                if case in ('same','new','reused-old','absent','late'):
                    rows=[load(x) for x in (f.base/'actual').glob('*.json')];observations=[x for x in rows if x['kind']=='log-observation']
                    self.assertGreaterEqual(len(observations),1)
                    self.assertTrue(all('elapsedSeconds' in x for x in observations))
    def test_real_proc_scan_ignores_reused_old_fd_and_finds_new_active_file(self):
        f=self.fixture();pid=os.getpid();fields=P(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        proof={'observed':{'running':{'pid':pid,'startTicks':int(fields[19])}}};first=f.log.open('ab');old=first.fileno()
        try:
            facts=D.log_facts(proof,{},f.desc);self.assertEqual([x['fd'] for x in facts['descriptors']],[old])
            first.close()
            with (f.base/'unrelated').open('wb') as unrelated,f.log.open('ab') as active:
                self.assertEqual(unrelated.fileno(),old);self.assertNotEqual(active.fileno(),old)
                facts=D.log_facts(proof,{},f.desc);self.assertEqual([x['fd'] for x in facts['descriptors']],[active.fileno()]);self.assertEqual(facts['descriptors'][0]['identity'],facts['active'])
        finally:first.close()
    def test_synthetic_owner_files_cannot_pass_real_front_door(self):
        f=self.fixture()
        with self.assertRaises(ValueError):f.driver.authority()
        with self.assertRaises(ValueError):D.validate_owner(f.approval,'approval',{'sessionId':'synthetic-group','masterSha256':f.master_sha},f.m['preparedAt'],time.monotonic())

class CleanupBudgets(unittest.TestCase):
    def run_case(self,label,pre=30,post=20,finish=10,full=50,outer_failure=False,analysis_failure=False):
        f=Fixture();self.addCleanup(f.close);now=[100.];obj=f.obj
        obj.state.update(protocolComplete=True,invalid=[],stamps={'initialCompleteReceived':50,'initialCardIssued':40});obj.restore=lambda auth:None
        for name,value in [('driver-finish',{'began':now[0]-finish}),('driver-start',{'began':now[0]-full-10}),('receipt',{}),('default-socket-before',None),('driver-pre',{'elapsedSeconds':pre,'ceilingSeconds':36}),('driver-post',{'elapsedSeconds':post,'ceilingSeconds':21})]:C.immutable(f.root/(name+'.json'),value)
        f.m['outer']={'journal':str(f.base/'outer-journal.json')};C.immutable(f.base/'outer-journal.json',{'stage':'paused'});calls=[]
        def outer(action):
            calls.append(action);now[0]+=3
            if outer_failure:raise ValueError('synthetic outer failure')
            C.atomic(f.base/'outer-journal.json',{'stage':'restored'});return {'timerRestored':True}
        f.driver.outer=outer;f.driver.controller=lambda label:(obj,f.entry,f.session);f.driver.verdict=lambda:load(f.root/'driver-result.json')
        with patch.object(f.driver,'audit'),patch.object(f.driver,'batch'),patch.object(D,'default_socket',return_value=None),patch.object(D.time,'monotonic',side_effect=lambda:now[0]),patch.object(C,'read_capture',side_effect=ValueError('synthetic final read failure') if analysis_failure else None,return_value=([],{'budgetErrors':0,'rawSha256':'synthetic'})):
            result=f.driver.restore(label)
        return result,calls
    def test_final_read_failure_still_restores_known_outer_obligation(self):
        result,calls=self.run_case('B1',analysis_failure=True);self.assertEqual(calls,['restore']);self.assertTrue(result['restored']);self.assertFalse(result['collectionGate']);self.assertIsNone(result['budgetErrors'])
    def test_each_interim_group_failure_and_full_overrun_restore_outer(self):
        for label in ('B1','C1','C2'):
            for excess in ({'pre':37},{'post':22},{'finish':68},{'full':301}):
                with self.subTest(label=label,excess=excess):
                    result,calls=self.run_case(label,**excess)
                    self.assertEqual(calls,['restore']);self.assertFalse(result['collectionGate']);self.assertTrue(result['wholeGroupRestored']);self.assertFalse(result['outerRestorationRequired'])
                    self.assertEqual(result['completeControllerSeconds'],excess.get('full',50)+3)
    def test_eligible_interim_keeps_explicit_outer_obligation(self):
        result,calls=self.run_case('B1');self.assertEqual(calls,[]);self.assertTrue(result['collectionGate']);self.assertTrue(result['activationRestored']);self.assertFalse(result['restored']);self.assertTrue(result['outerRestorationRequired'])
    def test_b2_restores_outer_and_counts_cleanup_overrun(self):
        result,calls=self.run_case('B2',finish=66);self.assertEqual(calls,['restore']);self.assertTrue(result['restored']);self.assertFalse(result['collectionGate']);self.assertEqual(result['groups'][-1]['elapsedSeconds'],69)
    def test_outer_failure_has_no_false_restored_claim(self):
        result,calls=self.run_case('C1',post=22,outer_failure=True);self.assertEqual(calls,['restore']);self.assertFalse(result['restored']);self.assertFalse(result['collectionGate']);self.assertTrue(result['outerRestorationRequired']);self.assertIn('outer failure',result['outerError'])

class VerdictTiming(unittest.TestCase):
    def test_final_group_analysis_can_only_remove_eligibility(self):
        for full,finish,prior_eligible in ((299,10,True),(50,66,True),(50,10,False),(50,10,True)):
            with self.subTest(full=full,finish=finish,prior=prior_eligible):
                f=Fixture();self.addCleanup(f.close);now=[100.];f.m['activations']=[]
                for label in ('B1','C1','C2','B2'):
                    root=f.base/label;root.mkdir();f.m['activations'].append({'label':label,'runRoot':str(root)})
                    for name,value in [('session',{'identity':{'activationNonce':label}}),('receipt',{}),('restoration',{}),('clock-verified',{}),('state',{'stamps':{'initialCompleteReceived':50,'initialCardIssued':40}}),('driver-start',{'began':100-full-10}),('driver-result',{'collectionGate':prior_eligible,'activationRestored':True,'wholeGroupRestored':label=='B2','finishBegan':100-finish})]:C.immutable(root/(name+'.json'),value)
                    (root/'polls.json').write_text('')
                f.m['outer']={'journal':str(f.base/'outer-journal.json')};C.immutable(f.base/'outer-journal.json',{'stage':'restored'})
                def analyze(*args):now[0]+=2;return {'synthetic':True}
                with patch.object(D.time,'monotonic',side_effect=lambda:now[0]),patch.object(C,'inspect_run',return_value=({}, {'cards':{},'authorizations':{}})),patch.object(C,'read_capture',return_value=([],{'complete':True,'budgetErrors':0})),patch.object(C.analyze,'normalize',side_effect=analyze),patch.object(C,'session_verdict',return_value={'verdict':{'accepted':False}}):result=f.driver.verdict()
                self.assertEqual(result['finalControllerSecondsIncludingAnalysisAndOuterRestoration'],full+2)
                self.assertEqual(result['collectionGate'],full==50 and finish==10 and prior_eligible)
                self.assertTrue(result['restored'])

if __name__=='__main__':unittest.main()
