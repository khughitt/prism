"""Root-invoked four-card pilot orchestration; importing performs no host action."""
import argparse, hashlib, importlib.util, json, math, os, signal, subprocess, sys, time, uuid, stat
from pathlib import Path

def require(ok, why):
    if not ok: raise ValueError(why)

def validate_owner(receipt, kind, binding, issued, now):
    require(receipt.get('kind') == kind and receipt.get('author') == 'root-controller'
            and receipt.get('synthetic') is False, 'actual Root receipt required')
    require(all(receipt.get(k) == v for k,v in binding.items()), 'receipt identity/card/master mismatch')
    provenance = receipt.get('provenance', {})
    require(provenance.get('human') is True and provenance.get('harness') == 'codex'
            and provenance.get('rootSessionId') and provenance.get('messageId'), 'actual human provenance absent')
    received = receipt.get('receivedAt')
    require(type(received) in (int,float) and math.isfinite(received) and issued <= received <= now,
            'reply chronology mismatch')
    return receipt

def load(path): return json.loads(Path(path).read_bytes())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def imported(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def default_socket():
    path=Path(os.environ.get('TMUX_TMPDIR','/tmp'))/('tmux-'+str(os.getuid()))/'default'
    if not path.exists():return None
    st=path.lstat();return {'dev':st.st_dev,'inode':st.st_ino,'uid':st.st_uid,'mode':st.st_mode}

def log_facts(proof,source,descriptor):
    """Read metadata only; the collector exclusively owns log-byte/lineage checks."""
    pid=proof['observed']['running']['pid'];proc=Path('/proc')/str(pid)
    def process():
        fields=(proc/'stat').read_text().rsplit(')',1)[1].split()
        require(fields[0]!='Z','running log process exited')
        return {'process':{'pid':pid,'startTicks':int(fields[19]),'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip()},
            'running':{'pid':pid,'startTicks':int(fields[19]),'sha256':sha(proc/'exe')},
            'installedPath':str((proc/'exe').resolve(strict=True)),
            'environment':dict(row.split('=',1) for row in (proc/'environ').read_bytes().decode().split('\0') if row)}
    before=process();path=Path(descriptor['log']['path']);matches=[];gone=[]
    require(not path.is_symlink(),'active log path is a symlink')
    def identity(path):
        value=path.stat();require(stat.S_ISREG(value.st_mode),'active log is not a regular file')
        return {'dev':value.st_dev,'inode':value.st_ino}
    try:active=identity(path)
    except FileNotFoundError:active=None
    for fd in sorted((proc/'fd').iterdir(),key=lambda p:int(p.name)):
        try:
            target=os.readlink(fd)
            if target!=str(path):continue
            file_identity=identity(fd)
            flags=[row.split()[1] for row in (proc/'fdinfo'/fd.name).read_text().splitlines() if row.startswith('flags:')]
            require(len(flags)==1,'ambiguous log descriptor flags')
            matches.append({'fd':int(fd.name),'path':target,'identity':file_identity,'writable':bool(int(flags[0],8)&os.O_ACCMODE)})
        except FileNotFoundError:gone.append(int(fd.name))
    try:after=identity(path)
    except FileNotFoundError:after=None
    require(process()==before,'running process changed during log observation')
    return before|{'active':active,'activeAfter':after,'descriptors':matches,'disappeared':gone}

def validate_log_facts(facts,proof,source,descriptor):
    observed=proof['observed'];expected={'pid':observed['running']['pid'],'startTicks':observed['running']['startTicks'],'bootId':observed['bootId']}
    require(descriptor['process']==expected and facts['process']==expected,'log process identity changed')
    require(all(facts['running'][k]==observed['running'][k] for k in ('pid','startTicks','sha256')) and facts['installedPath']==observed['installed']['path'],'running log binary changed')
    require(all(facts['environment'].get(k)==v for k,v in source['environment'].items()),'running source environment changed')
    environment=facts['environment'];cache=environment.get('XDG_CACHE_HOME') or str(Path(environment['HOME'])/'.cache')
    require(str(Path(cache)/'noctalia/noctalia.log')==descriptor['log']['path'],'unapproved log path/settings')
    matches=facts['descriptors'];require(len(matches)<=1,'ambiguous active log descriptor')
    if facts.get('activeAfter',facts['active'])!=facts['active']:return False
    if not matches or facts['active'] is None:return False
    active=matches[0]
    require(active['path']==descriptor['log']['path'] and active['identity']==facts['active'] and active['writable'] is True,'log descriptor/path identity mismatch')
    return True

def source_phase(root,attempt,contract,host):
    """Consume exact owned direct or reconciled pointer results, never a pointer guess."""
    state=load(root/'state.json');session=load(root/'session.json');phase='original';attempts=state['attempts']
    require(len({a['id'] for a in attempts})==len(attempts),'duplicate attempt identity')
    stop=len(attempts) if attempt is None else next((i for i,a in enumerate(attempts) if a==attempt),-1)
    require(stop>=0,'owned attempt absent')
    boundary=time.monotonic() if attempt is None else attempt['started']
    def direct(a,limit):
        permit,binding=host.bound_attempt(contract,a);raw=load(root/('result-'+a['id']+'.json'))
        require(a['status']=='completed' and raw['action']==a['action'] and raw['result']==a['result'],'durable result changed')
        elapsed=raw['elapsedSeconds']
        require(type(elapsed) in (int,float) and math.isfinite(elapsed) and elapsed>=0 and binding['boundAt']<=a['started']+elapsed<=limit,'result ordering changed')
        latest=[x for x in attempts if x['action']==a['action'] and x['status']=='completed'][-1]
        if latest['id']==a['id']:require(state['receipts'][a['action']]==raw['result'],'state receipt changed')
        return permit,raw['result']
    for index,prior in enumerate(attempts[:stop]):
        action=prior['action']
        if action not in ('pointer-swap','pointer-restore'):continue
        require(prior['status'] in ('completed','not-applied'),'unresolved pointer source phase')
        spec=session['hostActions'][action]
        inverse=session['hostActions']['pointer-restore' if action=='pointer-swap' else 'pointer-swap']
        require(spec['path']==inverse['path'] and spec['from']==inverse['to'] and spec['to']==inverse['from'] and spec['from']!=spec['to'],'pointer specifications conflict')
        require(phase==('original' if action=='pointer-swap' else 'active'),'pointer history phase conflict')
        expected={'pointer':spec['path'],'from':spec['from'],'to':spec['to']}
        if 'reconciliation' in prior:
            permit,binding=host.bound_attempt(contract,prior)
            reconciled=prior['reconciliation']
            matches=[(i,a) for i,a in enumerate(attempts[:stop]) if a['action']=='reconcile-'+action and a.get('result',{}).get('attemptId')==prior['id']]
            require(len(matches)==1,'missing/ambiguous owned reconciliation')
            ri,ra=matches[0];require(ri>index and binding['boundAt']<=ra['started'],'reconciliation ordering changed')
            rp,value=direct(ra,attempts[ri+1]['started'] if ri+1<stop else boundary)
            raw=load(str(rp)+'-result')
            require(raw['exit']==0 and json.loads(raw['stdout'])==value==reconciled,'reconciliation raw/durable receipt differs')
            require(value=={'attemptId':prior['id'],'action':action,'outcome':prior['status'],'receipt':expected if prior['status']=='completed' else {},'attemptPhase':prior['phase'],'permitSha256':sha(permit)},'reconciliation target/action/outcome changed')
            original=root/('result-'+prior['id']+'.json')
            if original.exists():
                require(prior['status']=='completed','not-applied contradicts original result')
                result=load(original);require(result['action']==action and result['result']==expected,'original result contradicts reconciliation')
                elapsed=result['elapsedSeconds']
                require(type(elapsed) in (int,float) and math.isfinite(elapsed) and elapsed>=0 and binding['boundAt']<=prior['started']+elapsed<=ra['started'],'original result/reconciliation ordering changed')
            if prior['status']=='not-applied':continue
            require(state['receipts'][action]==expected,'reconciled pointer receipt changed')
        else:
            permit,result=direct(prior,attempts[index+1]['started'] if index+1<stop else boundary)
            require(result==expected,'pointer result differs from exact specification')
        journal=load(str(permit)+'-pointer')
        require(journal=={'what':spec['path'],'from':spec['from'],'to':spec['to'],'restore':spec['from'],'how':'fresh authorized pointer operation with inverse literal targets'},'pointer intent provenance changed')
        phase='active' if action=='pointer-swap' else 'original'
    return phase

def dispatch(master_path, label, action):
    """Frozen argv endpoint. It only delegates to reviewed fixed helpers."""
    m=load(master_path);entry=next(x for x in m['activations'] if x['label']==label)
    review=load(Path(master_path).parent/'actual-review.json')
    require(review.get('accepted') is True and review.get('synthetic') is False and review.get('masterSha256')==sha(master_path), 'dispatch master lacks actual review binding')
    root=Path(entry['runRoot']);session=load(root/'session.json');state=load(root/'state.json')
    require(sha(root/'session.json')==entry['sessionSha256'],'dispatch session changed')
    pending=state['attempts'][-1]
    require(pending['status']=='pending' and pending['action']==action,'dispatch lacks pending owned attempt')
    helper=Path(m['helpers']);sys.path.insert(0,str(helper));host=imported('packet_fixed_host',helper/'host.py')
    anchor=pending
    if action.startswith('reconcile-'):
        target=action.removeprefix('reconcile-')
        unresolved=[a for a in state['attempts'][:-1] if a['action']==target and a['status'] in ('pending','uncertain')]
        require(len(unresolved)==1,'ambiguous reconciliation action phase');anchor=unresolved[0]
    phase=source_phase(root,anchor,load(entry['sourceContracts']['original']),host)
    key=action+'@'+phase;contract=Path(entry['contracts'][key]);expected=entry['contractSha256'][key]
    require(sha(contract)==expected,'dispatch contract changed')
    ct=load(contract)
    # The reviewed validator checks the frozen pending attempt and its consumed exact permit.
    owner,_=host.owned_attempt(ct,action)
    if action.startswith('reconcile-'):
        argv=[m['interpreters']['python'],'-B',str(helper/'reconcile.py'),str(contract),target]
    elif action=='final-drain':argv=[m['interpreters']['python'],'-B',str(helper/'drain.py'),str(contract)]
    else:argv=[m['interpreters']['python'],'-B',str(helper/'host.py'),action,str(contract)]
    spec=session['hostActions'][action]
    require(spec['argv']==[m['interpreters']['python'],'-B',str(Path(__file__).resolve()),'dispatch',str(Path(master_path).resolve()),label,action], 'dispatch argv differs')
    issuance={'owner':owner,'sessionSha256':entry['sessionSha256'],'contractSha256':expected,'argv':argv,'issuedAt':time.monotonic()}
    with (root/('dispatch-'+pending['id']+'.json')).open('xb') as issued:
        os.chmod(issued.name,0o600);issued.write((json.dumps(issuance,sort_keys=True)+'\n').encode());issued.flush();os.fsync(issued.fileno())
    # exec preserves the outer RootHost timeout and stdout/stderr receipt boundary.
    os.execv(argv[0],argv)

class Guard:
    def __init__(self,driver,entry,session):
        self.driver,self.entry,self.session=driver,entry,session
        self.root=Path(entry['runRoot'])
    def invoke(self,action,authorization,arguments):
        self.driver.audit(self.entry, action)
        require(arguments==self.session['hostActions'][action],'arguments differ from frozen session')
        self.driver.host.bind_attempt(load(self.entry['sourceContracts']['original']),action,authorization,arguments)
        result=self.driver.c.RootHost(self.root,self.session).invoke(action,authorization,arguments)
        self.driver.record('effect-result',label=self.entry['label'],action=action,result=result)
        if action in ('pointer-swap','pointer-restore','rotation-pause','rotation-resume'):
            self.driver.note(action+' '+json.dumps(result,sort_keys=True)+'; inverse '+json.dumps(self.session['hostActions'].get('pointer-restore' if action.startswith('pointer-') else 'rotation-resume'),sort_keys=True))
        return result

class Driver:
    def __init__(self,master,expected_sha):
        self.master=Path(master);require(sha(self.master)==expected_sha,'reviewed master hash mismatch')
        self.m=load(master);self.master_sha=expected_sha;self.root=self.master.parent
        require(Path(sys.executable).resolve()==Path(self.m['interpreters']['python']), 'unpinned Python interpreter')
        os.environ.update(self.m['env'])
        sys.path.insert(0,self.m['code']);sys.path.insert(0,self.m['helpers'])
        self.c=imported('packet_controller',Path(self.m['code'])/'controller.py')
        self.cap=imported('packet_capture',Path(self.m['code'])/'capture.py')
        self.host=imported('packet_host',Path(self.m['helpers'])/'host.py')
        self.clock=imported('packet_clock',Path(self.m['code'])/'clock-gate.py')
    def entry(self,label):return next(x for x in self.m['activations'] if x['label']==label)
    def record(self,kind,**data):
        live=self.root/'actual';require(live.is_dir(),'actual root not initialized')
        self.c.immutable(live/(str(time.monotonic_ns())+'-'+uuid.uuid4().hex+'.json'),dict(kind=kind,monotonic=time.monotonic(),**data))
    def note(self,text):
        result=subprocess.run([self.m['tasksBinary'],'note','prism-7ed2d3',text],cwd=self.m['repo'],capture_output=True,text=True,timeout=10)
        require(result.returncode==0,'task note failed; retain actual mutation record: '+result.stderr)
    def authority(self):
        review=load(self.root/'actual-review.json')
        require(review.get('accepted') is True and review.get('synthetic') is False and review.get('masterSha256')==self.master_sha,'fresh complete-packet review absent')
        receipt=load(self.root/'actual-owner-approval.json')
        validate_owner(receipt,'approval',{'sessionId':self.m['sessionId'],'masterSha256':self.master_sha},self.m['preparedAt'],time.monotonic())
        require(receipt.get('approved') is True and receipt.get('labels')==['B1','C1','C2','B2'],'four-card approval absent')
        actual_thread=os.environ.get('CODEX_THREAD_ID') or os.environ.get('CODEX_SESSION_ID')
        require(actual_thread and receipt['provenance']['rootSessionId'] in (actual_thread,'codex:'+actual_thread),'driver must run in the authorizing Root session')
        return receipt
    def audit(self,entry=None,action=None):
        self.authority();require(sha(self.master)==self.master_sha,'master changed')
        for file,value in self.m['inventory'].items():require(sha(file)==value,'inventory changed: '+file)
        proof=load(self.m['sourceProof']);require(proof['sessionId']==self.m['sessionId'],'prospective group mismatch')
        self.clock.verify(proof,self.clock.observe(proof),self.clock.historical(self.m['r2Root']))
        self.observe_log(proof)
        if entry is not None:
            root=Path(entry['runRoot']);phase='original'
            if (root/'state.json').exists():
                state=load(root/'state.json');ct=load(entry['sourceContracts']['original'])
                unresolved=[a for a in state['attempts'] if a['action'] in ('pointer-swap','pointer-restore') and a['status'] in ('pending','uncertain')]
                if unresolved and action and action.startswith('reconcile-'):
                    require(len(unresolved)==1 and action=='reconcile-'+unresolved[0]['action'],'ambiguous pointer reconciliation')
                    source_phase(root,unresolved[0],ct,self.host)
                    self.host.bound_attempt(ct,unresolved[0])
                    spec=load(entry['session'])['hostActions'][unresolved[0]['action']]
                    literal=os.readlink(spec['path']);require(literal in (spec['from'],spec['to']),'pointer outside exact owned endpoints')
                    phase='original' if literal==ct['originalPointer'] else 'active'
                else:
                    current=state['attempts'][-1] if state['attempts'] and state['attempts'][-1]['status']=='pending' else None
                    phase=source_phase(root,current,ct,self.host)
            contract=load(entry['sourceContracts'][phase]);self.host.source_observation(contract)
        self.record('audit',label=entry['label'] if entry else None,action=action)
    def observe_log(self,proof):
        source=load(self.m['sourceObservation']);descriptor=load(self.m['logObservation']);limit=self.m['logReobservation']
        require(limit=={'attempts':8,'elapsedSeconds':.25,'pollSeconds':.01},'unreviewed log reobservation bound')
        require(descriptor['capacityBytes']==1048576 and descriptor['backupCount']==1 and descriptor['maximumLineBytes']==8192,'unapproved log settings')
        require(sha(descriptor['sourceFile'])==descriptor['sourceFileSha256'],'pinned logger source changed')
        began=time.monotonic()
        for number in range(1,limit['attempts']+1):
            at=time.monotonic();facts=None
            try:
                facts=log_facts(proof,source,descriptor);ready=validate_log_facts(facts,proof,source,descriptor)
            except (OSError,ValueError,KeyError,TypeError) as error:
                self.record('log-observation',attempt=number,began=at,elapsedSeconds=time.monotonic()-began,facts=facts,error=str(error));raise
            self.record('log-observation',attempt=number,began=at,elapsedSeconds=time.monotonic()-began,facts=facts,ready=ready)
            elapsed=time.monotonic()-began
            if elapsed>limit['elapsedSeconds']:
                self.record('log-reobservation-refused',observations=number,elapsedSeconds=elapsed,reason='elapsed bound exhausted (non-preemptive I/O)')
                raise TimeoutError('log reobservation elapsed bound exhausted (non-preemptive I/O)')
            if ready:return facts
            if number<limit['attempts']:time.sleep(min(limit['pollSeconds'],max(0,limit['elapsedSeconds']-elapsed)))
        self.record('log-reobservation-refused',observations=limit['attempts'],elapsedSeconds=time.monotonic()-began,reason='attempt bound exhausted')
        raise TimeoutError('log reobservation attempt bound exhausted')
    def batch(self,entry,session,actions):
        self.audit(entry,actions[0] if len(actions)==1 else None);now=time.monotonic();token=uuid.uuid4().hex
        value={'approved':True,'author':'root-controller','sessionId':session['sessionId'],'runId':session['runId'],
               'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
               'permits':[{'id':uuid.uuid4().hex,'action':a,'arguments':session['hostActions'][a],'issuedAt':now,'expiresAt':now+55} for a in actions],
               'provenance':{'masterSha256':self.master_sha,'approvalSha256':sha(self.root/'actual-owner-approval.json')}}
        path=self.root/'actual'/('authorization-'+token+'.json');self.c.immutable(path,value);return path
    def controller(self,label):
        entry=self.entry(label);session=load(entry['session']);host=Guard(self,entry,session)
        return self.c.Controller.resume(entry['runRoot'],host),entry,session
    def wait(self,obj,kind,limit):
        root=obj.root;end=time.monotonic()+limit;observations=[]
        while True:
            path=root/('receipt.json' if kind=='exit' else 'heartbeat.json')
            value=load(path) if path.exists() else None
            observations.append({'at':time.monotonic(),'value':value})
            if value:
                require(all(value.get(k)==obj.session[k] for k in ('runId','clockOrigin')),'wait identity mismatch')
                require(value.get('error') is None and value.get('sourceObservationFailure') is None,'collector failure during bounded wait')
                if kind=='exit':
                    done='wrapperEnded' in value and not any(self.cap.same_process(p) for p in value['processes'].values())
                else:
                    require(value.get('exitReason')=='running','collector stopped during readiness')
                    done=kind=='start' or value.get('lastSequence')==obj.state['sequence']
                if done:
                    self.c.immutable(root/('wait-'+kind+'-'+uuid.uuid4().hex+'.json'),{'observations':observations});return value
            if time.monotonic()>=end:
                self.c.immutable(root/('wait-failed-'+kind+'-'+uuid.uuid4().hex+'.json'),{'observations':observations})
                raise TimeoutError('bounded '+kind+' wait exhausted')
            time.sleep(.05)
    def checkpoint(self,obj,entry,session,candidate=None):
        authorization=self.batch(entry,session,['checkpoint-authorize'])
        obj.invoke('checkpoint-authorize',authorization);obj.control('ready');self.wait(obj,'ready',3)
        if candidate is not None:obj.ready(candidate,obj.state['sequence'])
    def start(self,label):
        began=time.monotonic();entry=self.entry(label);self.audit(entry)
        if label=='B1':self.outer('begin')
        require(load(self.m['outer']['journal'])['stage']=='paused','outer pause absent')
        if label!='B1':
            prior=self.m['activations'][['B1','C1','C2','B2'].index(label)-1]
            require(load(Path(prior['runRoot'])/'driver-result.json')['collectionGate'] is True,'previous activation not eligible')
        root=Path(entry['runRoot']);root.mkdir(mode=0o700);session=load(entry['session'])
        obj=self.c.Controller(root,session,Guard(self,entry,session))
        cfg=load(entry['collector']);self.c.immutable(root/'run.json',cfg);self.c.immutable(root/'RUN.json',cfg)
        self.c.immutable(root/'driver-start.json',{'began':began,'masterSha256':self.master_sha})
        self.c.immutable(root/'default-socket-before.json',default_socket())
        auth=self.batch(entry,session,['rotation-snapshot','rotation-pause','state-snapshot','state-clear','panel-close','plugins-disable','pointer-swap','collector-launch'])
        obj.prepare(auth);obj.collector_started(self.wait(obj,'start',5))
        obj.activate(self.batch(entry,session,['plugins-enable','export-ready','panel-open']))
        # Poll publication once, then only the reviewed reader may retry its byte snapshot.
        self.checkpoint(obj,entry,session)
        events,candidate=self.c.read_capture(root/'manifest.json')
        require(events and any(e['class']=='open' for e in events),'fresh activation/open absent')
        require(candidate['budgetErrors']==0,'startup budget error; administrative abort required')
        bundle=load(session['snapshotBundle']);ct=load(entry['sourceContracts']['active'])
        current=self.host.state_verify(ct,'cleared')
        self.c.verify_initial(session['identity'],events[0],bundle,current,session['buildRoot'],load(session['referenceSnapshot']) if session.get('referenceSnapshot') else None)
        self.checkpoint(obj,entry,session,candidate)
        elapsed=time.monotonic()-began
        self.c.immutable(root/'driver-pre.json',{'elapsedSeconds':elapsed,'ceilingSeconds':self.m['steps']['pre']})
        require(elapsed<=self.m['steps']['pre'],'startup prospective ceiling exhausted; administrative abort required')
        obj.issue_initial(events[0],bundle['saved'],{},self.m['initialRemainingReserve'])
        self.c.immutable(root/'driver-card.json',{'issuedAt':obj.state['stamps']['initialCardIssued'],'masterSha256':self.master_sha,'cardId':session['identity']['cardId']})
        hb=load(root/'heartbeat.json')
        return {'card':(root/'owner-card.txt').read_text(),'label':label,'collector':hb,'deadline':hb['collectorStarted']+2100,
                'pointer':os.readlink(ct['pointerPath']),'inverse':session['hostActions']['pointer-restore'],
                'rotationJournal':self.m['outer']['journal'],'next':'Root publishes card and parks with actual identities; only actual owner reply resumes completion'}
    def complete(self,label,reply_path):
        obj,entry,session=self.controller(label);self.audit(entry)
        reply=load(reply_path);validate_owner(reply,'completion',{'sessionId':self.m['sessionId'],'runId':session['runId'],
            'cardId':session['identity']['cardId'],'masterSha256':self.master_sha},obj.state['stamps']['initialCardIssued'],time.monotonic())
        return self.completed_reply(obj,entry,session,reply)
    def completed_reply(self,obj,entry,session,reply):
        """Continue an independently validated actual reply; CLI always uses complete."""
        label=entry['label']
        self.c.immutable(obj.root/'actual-reply.json',reply)
        obj.clock=lambda:reply['receivedAt'];obj.owner_complete(reply['provenance']['messageId']);obj.clock=time.monotonic
        obj.invoke('panel-close',self.batch(entry,session,['panel-close']))
        self.checkpoint(obj,entry,session)
        normal,context=self.c.inspect_run(obj.root);obj.checked(normal)
        self.c.immutable(obj.root/'driver-checked.json',{'normalized':normal,'context':context})
        self.c.immutable(obj.root/'driver-post.json',{'elapsedSeconds':time.monotonic()-reply['receivedAt'],'ceilingSeconds':self.m['steps']['post']})
        # A short collection stays short. Recovery requires its own newly reviewed gate.
        return self.finish(label)
    def finish(self,label):
        began=time.monotonic();obj,entry,session=self.controller(label);self.audit(entry)
        self.c.immutable(obj.root/'driver-finish.json',{'began':began})
        normal,context=self.c.inspect_run(obj.root,prefix=obj.state['inspectionAudit'])
        obj.finish(self.batch(entry,session,['finish-authorize']),normal)
        receipt=self.wait(obj,'exit',5);obj.exited(receipt,self.cap.same_process)
        return self.restore(label)
    def restore(self,label):
        obj,entry,session=self.controller(label);self.audit(entry)
        began=load(obj.root/'driver-finish.json')['began'];receipt=load(obj.root/'receipt.json')
        obj.restore(self.batch(entry,session,['final-drain','panel-close','plugins-disable','pointer-restore','plugins-restore','state-restore','rotation-resume','restore-verify']))
        analysis_error=None;audit=None
        try:
            require(default_socket()==load(obj.root/'default-socket-before.json'),'default tmux endpoint changed; preserve evidence')
            rows,audit=self.c.read_capture(obj.root/'manifest.json',receipt)
        except Exception as error:analysis_error=str(error)
        start=load(obj.root/'driver-start.json')['began'];owner=obj.state['stamps']['initialCompleteReceived']-obj.state['stamps']['initialCardIssued']
        pre=load(obj.root/'driver-pre.json');post=load(obj.root/'driver-post.json')
        def elapsed_status():
            now=time.monotonic();elapsed=now-start-owner
            groups=[pre,post,{'elapsedSeconds':now-began,'ceilingSeconds':self.m['steps']['finish']}]
            eligible=analysis_error is None and elapsed<=300 and all(g['elapsedSeconds']<=g['ceilingSeconds'] for g in groups) and not obj.state['invalid'] and obj.state['protocolComplete']
            return elapsed,groups,eligible
        elapsed,groups,eligible=elapsed_status()
        must_restore=label=='B2' or not eligible;outer_verified=False;outer_error=None
        def restore_outer():
            nonlocal outer_verified,outer_error
            try:
                result=self.outer('restore')
                require(result.get('timerRestored') is True and load(self.m['outer']['journal'])['stage']=='restored','outer restoration not verified')
                outer_verified=True
            except Exception as error:outer_error=str(error)
        if must_restore:restore_outer()
        # Cleanup belongs to this activation's finish and full allowance. A prior
        # overrun cannot become eligible after cleanup or later group analysis.
        elapsed,groups,final_eligible=elapsed_status()
        if not final_eligible and not must_restore:
            must_restore=True;restore_outer();elapsed,groups,final_eligible=elapsed_status()
        eligible=eligible and final_eligible and outer_error is None
        result={'label':label,'restored':outer_verified,'activationRestored':True,'wholeGroupRestored':outer_verified,
                'outerRestorationRequired':not outer_verified,'outerDisposition':'verified-original' if outer_verified else 'manual-recovery' if must_restore else 'paused-for-next-authorized-card',
                'outerError':outer_error,'analysisError':analysis_error,'collectionGate':eligible,'protocolComplete':obj.state['protocolComplete'],
                'performance':'inconclusive n1','completeControllerSeconds':elapsed,'budgetErrors':audit['budgetErrors'] if audit else None,
                'rawSha256':audit['rawSha256'] if audit else None,'noRecoveryIssued':True,'groups':groups,'finishBegan':began}
        self.c.immutable(obj.root/'driver-result.json',result)
        return self.verdict() if label=='B2' and outer_verified else result
    def reconcile(self,label,attempt_id):
        obj,entry,session=self.controller(label)
        attempt=next(a for a in obj.state['attempts'] if a['id']==attempt_id)
        action='reconcile-'+attempt['action']
        obj.reconcile(self.batch(entry,session,[action]),attempt_id)
        return {'resolved':attempt_id,'state':obj.state,'collectionEligible':False}
    def abort(self,label,reason):
        """Root administrative invalid abort. Never creates an owner reply or drain."""
        obj,entry,session=self.controller(label);obj.resolved();self.audit(entry)
        root=obj.root;self.c.immutable(root/'administrative-stop.json',{'author':'root-controller','reason':reason,'at':time.monotonic(),
            'masterSha256':self.master_sha,'ownerCardIssued':(root/'owner-card.txt').exists(),'protocolComplete':False})
        done=obj.state['receipts']
        if 'collector-launch' in done:
            existing=load(root/'receipt.json')
            already_reaped='wrapperEnded' in existing and set(existing.get('processes',{}))=={'server','wrapper','collector'} and not any(self.cap.same_process(p) for p in existing['processes'].values())
            if already_reaped:
                receipt=existing
                require(receipt['runId']==session['runId'] and receipt['clockOrigin']==session['clockOrigin']
                    and receipt['collectorStarted']==obj.state['receipts']['collectorStarted']['collectorStarted']
                    and receipt['processes']==obj.state['receipts']['collectorStarted']['processes'],'reaped receipt ownership mismatch')
            else:
                obj.invoke('stop-authorize',self.batch(entry,session,['stop-authorize']));obj.control('stop')
                receipt=self.wait(obj,'exit',5)
                require(receipt['exitReason']=='stop' and receipt['integrityComplete'] is False,'administrative stop has unexpected receipt')
            require(set(receipt['processes'])=={'server','wrapper','collector'},'administrative process identity incomplete')
            # Strict byte reread is retained as invalid evidence, never a completion certificate.
            events,audit=self.c.read_capture(root/'manifest.json',receipt)
            self.c.immutable(root/'administrative-capture.json',{'receipt':receipt,'audit':audit})
        # No unknown effects can reach restoration. Failed export observation can first
        # be reconciled through the fixed helper with its original action phase.
        if 'plugins-enable' in done:obj.invoke('panel-close',self.batch(entry,session,['panel-close']))
        phase='active' if 'pointer-swap' in done and 'pointer-restore' not in done else 'original'
        contract=load(entry['sourceContracts'][phase]);binding=self.host.source_observation(contract)
        proof=load(self.m['sourceProof']);pid=proof['observed']['running']['pid']
        children=Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
        # A live host child could still be applying a panel command: require Root
        # inspection instead of guessing its origin or killing it.
        require(not children,'manual recovery: running host has children; preserve identities and inspect exact commands')
        current=self.host.state_verify(contract,'cleared') if 'state-clear' in done else None
        self.c.immutable(root/'administrative-restore-precheck.json',{'sourceBinding':binding,'hostChildren':children,'current':current,
            'actualClose':done.get('panel-close'),'noNormalDrain':True,'at':time.monotonic()})
        actions=[]
        if 'plugins-enable' in done:actions.append('plugins-disable')
        if phase=='active':actions.append('pointer-restore')
        if 'plugins-disable' in done:actions.append('plugins-restore')
        if 'state-clear' in done:actions.append('state-restore')
        if 'rotation-pause' in done:actions.append('rotation-resume')
        actions.append('restore-verify')
        for action in actions:
            obj.invoke(action,self.batch(entry,session,[action]))
            if action=='plugins-disable':
                require(not Path(f'/proc/{pid}/task/{pid}/children').read_text().split(),'manual recovery: host children remain after disable')
        self.outer('restore')
        require(default_socket()==load(root/'default-socket-before.json'),'default tmux endpoint changed during invalid abort')
        self.c.immutable(root/'administrative-restoration.json',{'restored':True,'protocolComplete':False,'coldProtocolComplete':False,
            'collectionGate':False,'scope':'Root administrative invalid restoration only','verification':obj.state['receipts']['restore-verify'],
            'completeControllerSeconds':time.monotonic()-load(root/'driver-start.json')['began'],'at':time.monotonic()})
        return load(root/'administrative-restoration.json')
    def outer(self,action):
        entry=self.m['outer'];session=load(entry['session']);root=Path(entry['runRoot'])
        if action=='begin':root.mkdir(mode=0o700);self.c.immutable(root/'session.json',session)
        names=['rotation-snapshot','rotation-pause'] if action=='begin' else ['rotation-resume','rotation-verify']
        auth=self.batch(entry,session,names)
        for name in names:
            if action=='restore' and (root/(name+'.json')).exists():continue
            self.audit();result=self.c.RootHost(root,session).invoke(name,auth,session['hostActions'][name])
            self.c.immutable(root/(name+'.json'),result)
            self.note('OUTER '+name+' '+json.dumps(result,sort_keys=True)+'; journal '+entry['journal'])
        return load(root/(names[-1]+'.json'))
    def verdict(self):
        parts=[]
        for entry in self.m['activations']:
            root=Path(entry['runRoot']);session=load(root/'session.json');receipt=load(root/'receipt.json');normal,ctx=self.c.inspect_run(root,receipt)
            events,audit=self.c.read_capture(root/'manifest.json',receipt)
            parts.append({'events':events,'identities':[session['identity']],'cards':ctx['cards'],'authorizations':ctx['authorizations'],
                'receipts':[receipt],'restoration':[load(root/'restoration.json')],'clock':load(root/'clock-verified.json'),
                'audit':audit,'polls':[json.loads(x) for x in (root/'polls.json').read_text().splitlines()]})
        merged={key:sum((p[key] for p in parts),[]) for key in ('events','identities','receipts','restoration')}
        cards={k:v for p in parts for k,v in p['cards'].items()};auth={k:v for p in parts for k,v in p['authorizations'].items()}
        normal=self.c.analyze.normalize(merged['events'],merged['identities'],cards,auth)
        clock={'activations':{i['activationNonce']:p['clock'] for p in parts for i in p['identities']}}
        observations={'complete':all(p['audit']['complete'] for p in parts),'budgetErrors':sum(p['audit']['budgetErrors'] for p in parts),'polls':sum((p['polls'] for p in parts),[])}
        verdict=self.c.session_verdict(normal,merged['identities'],merged['receipts'],merged['restoration'],clock,observations)
        require(verdict['verdict']['accepted'] is False,'n1 must remain performance inconclusive')
        self.c.immutable(self.root/'actual'/'ordered-verdict.json',verdict)
        last=self.entry('B2');root=Path(last['runRoot']);state=load(root/'state.json')
        elapsed=time.monotonic()-load(root/'driver-start.json')['began']-(state['stamps']['initialCompleteReceived']-state['stamps']['initialCardIssued'])
        last_finish=load(root/'driver-result.json')['finishBegan']
        result={'ordered':verdict,'performance':'inconclusive n1','accepted':False,'nextStageEligible':False,
            'restored':load(self.m['outer']['journal'])['stage']=='restored' and load(root/'driver-result.json')['wholeGroupRestored'] and all(load(Path(e['runRoot'])/'driver-result.json')['activationRestored'] for e in self.m['activations']),
            'collectionGate':elapsed<=300 and time.monotonic()-last_finish<=self.m['steps']['finish'] and all(load(Path(e['runRoot'])/'driver-result.json')['collectionGate'] for e in self.m['activations']),
            'finalControllerSecondsIncludingAnalysisAndOuterRestoration':elapsed}
        self.c.immutable(self.root/'actual'/'pilot-result.json',result);return result

def main():
    os.umask(0o077)
    if len(sys.argv)>1 and sys.argv[1]=='dispatch':dispatch(*sys.argv[2:]);return
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--master',required=True);parser.add_argument('--master-sha',required=True)
    parser.add_argument('action',choices=('start','complete','finish','restore','verdict','abort','reconcile','outer-restore'));parser.add_argument('--label',choices=('B1','C1','C2','B2'));parser.add_argument('--reply');parser.add_argument('--reason');parser.add_argument('--attempt')
    a=parser.parse_args();driver=Driver(a.master,a.master_sha);driver.authority()
    actual=driver.root/'actual';actual.mkdir(mode=0o700,exist_ok=True)
    if a.action=='complete':require(a.reply,'actual completion receipt required');result=driver.complete(a.label,a.reply)
    elif a.action=='abort':require(a.reason,'Root administrative abort reason required');result=driver.abort(a.label,a.reason)
    elif a.action=='reconcile':require(a.attempt,'exact unresolved attempt id required');result=driver.reconcile(a.label,a.attempt)
    elif a.action in ('start','finish','restore'):result=getattr(driver,a.action)(a.label)
    elif a.action=='outer-restore':result=driver.outer('restore')
    else:result=driver.verdict()
    print(json.dumps(result,sort_keys=True))

if __name__=='__main__':main()
