"""Fixed pilot host commands. Invocation is root-owned; importing has no host effects."""
import hashlib,importlib.util,json,math,os,re,subprocess,sys,time
import source_binding
from pathlib import Path
HERE=Path(__file__).resolve().parent
PLUGIN='khughitt/prism';PANEL=PLUGIN+':panel';SENTINEL=':'
ARGV={'panel-close':['panel-close',PANEL],'panel-open':['panel-open',PANEL],
      'plugins-disable':['plugins','disable',PLUGIN],'plugins-enable':['plugins','enable',PLUGIN]}
def require(ok,message):
 if not ok:raise ValueError(message)
def load(p):return json.loads(Path(p).read_text())
def response(action,result):
 require(action in ARGV,'unsupported host action')
 allowed=['ok\n']+(['ok (exporting in background)\n'] if action=='plugins-enable' else [])
 require(result.returncode==0 and result.stdout in allowed,'Noctalia command failed or unexpected response')
 return {'stdout':result.stdout,'stderr':result.stderr,'exit':result.returncode,'exportPending':result.stdout=='ok (exporting in background)\n'}
def registration(text):
 match=re.fullmatch(r'error: unknown panel ":"(?: \(available: ([^\n]+)\))?\n',text)
 require(match is not None,'unexpected registration response')
 ids=match[1].split(', ') if match[1] else []
 require(len(ids)==len(set(ids)) and SENTINEL not in ids,'duplicate or registered sentinel')
 require(all(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*(?:/[A-Za-z0-9][A-Za-z0-9_.-]*:[A-Za-z0-9][A-Za-z0-9_.-]*)?',x) for x in ids),'malformed panel id')
 return ids
def enabled(text):
 rows=[line for line in text.splitlines() if line.split(' ',1)[0]==PLUGIN]
 require(len(rows)==1,'plugin catalog identity missing/duplicated')
 parts=rows[0].split()
 require(len(parts)>=4 and re.fullmatch(r'\[[^\s\[\]]+\]',parts[1]) and parts[3] in ('enabled','disabled'),'malformed plugin catalog entry')
 require('incompatible' not in parts,'plugin incompatible')
 return parts[3]=='enabled'
def source_check(source):
 proof=load(HERE/'sentinel-source.json');source=Path(source)
 for name,sha in proof['sha256'].items():require(hashlib.sha256((source/name).read_bytes()).hexdigest()==sha,'sentinel source proof changed: '+name)
 return proof['revision']
def remaining(deadline):
 left=deadline-time.monotonic()
 if left<=0:raise TimeoutError('registration action deadline exceeded')
 return left
def ipc(args,deadline=None):
 timeout=3 if deadline is None else min(3,remaining(deadline))
 started=time.monotonic()
 result=subprocess.run(['/usr/bin/noctalia','msg',*args],capture_output=True,text=True,timeout=timeout)
 print(json.dumps({'ipcObservation':{'args':args,'started':started,'ended':time.monotonic(),'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}},sort_keys=True),file=sys.stderr,flush=True)
 if deadline is not None:remaining(deadline) # Never accept a late success.
 return result
def registry(source,deadline=None):
 source_check(source);result=ipc(['panel-close',SENTINEL],deadline)
 require(result.returncode==1,'sentinel did not return expected IPC error exit')
 return {'registered':PANEL in registration(result.stdout),'stdout':result.stdout,'stderr':result.stderr,'exit':result.returncode,'observedAt':time.monotonic()}
def catalog(deadline=None):
 result=ipc(['plugins','list'],deadline);require(result.returncode==0,'plugin catalog query failed')
 state=enabled(result.stdout);row=next(line for line in result.stdout.splitlines() if line.split(' ',1)[0]==PLUGIN)
 return {'enabled':state,'source':row.split()[1][1:-1],'stdout':result.stdout,'stderr':result.stderr,'observedAt':time.monotonic()}
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def encoded(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def private(path):
 st=Path(path).stat();require(st.st_uid==os.getuid() and st.st_mode&0o777==0o600,'authorization/binding must be private and owned')
def attempt_context(contract,attempt):
 root=Path(contract['runRoot']);session_raw=(root/'session.json').read_bytes();session=json.loads(session_raw);expected=contract['expected'];state=load(root/'state.json')
 require(hashlib.sha256(session_raw).hexdigest()==expected['sessionFileSha256'] and session_raw==encoded(session),'session changed or noncanonical')
 require(all(session[k]==expected[k] for k in ('sessionId','runId','clockOrigin')) and session['identity']['activationNonce']==expected['activationNonce'],'action ownership mismatch')
 require(sum(a['id']==attempt['id'] for a in state['attempts'])==1 and attempt in state['attempts'],'wrong/stale owned attempt')
 frozen=load(root/('attempt-'+attempt['id']+'.json'))
 require(frozen['status']=='pending' and all(attempt[k]==frozen[k] for k in ('id','action','phase','started')),'attempt provenance changed')
 return root,session,state,frozen

def authorization_for(root,session,attempt,authorization,bound_at):
 private(authorization);auth=load(authorization)
 require(auth.get('approved') is True and auth.get('author')=='root-controller' and auth.get('sessionId')==session['sessionId'] and auth.get('runId')==session['runId'] and auth.get('bootId')==Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'fresh root session authorization required')
 permits=[p for p in auth['permits'] if p['action']==attempt['action']]
 require(len(permits)==1,'missing/ambiguous preissued exact action permit')
 permit=permits[0];token=permit['id']
 require(isinstance(token,str) and token and all(c.isalnum() or c=='-' for c in token),'invalid permit id')
 require(permit['arguments']==session['hostActions'][attempt['action']],'permit specification changed')
 require(all(type(x) in (int,float) and math.isfinite(x) for x in (permit['issuedAt'],permit['expiresAt'],attempt['started'],bound_at)),'invalid permit/attempt timing')
 require(permit['issuedAt']<=attempt['started']<=bound_at<=permit['expiresAt']<=permit['issuedAt']+60,'permit not preissued/current at binding')
 return permit

def bind_attempt(contract,action,authorization,arguments):
 root=Path(contract['runRoot']);attempt=load(root/'state.json')['attempts'][-1]
 require(attempt['status']=='pending' and attempt['action']==action,'current pending owned action absent')
 root,session,state,frozen=attempt_context(contract,attempt)
 require(arguments==session['hostActions'][action],'binding specification changed')
 now=time.monotonic();authorization=Path(authorization).resolve(strict=True)
 permit=authorization_for(root,session,attempt,authorization,now)
 require(not (root/'permits'/permit['id']).exists(),'permit already consumed')
 for old in root.glob('binding-*.json'):require(load(old)['permitId']!=permit['id'],'permit already bound to an attempt')
 value={k:contract['expected'][k] for k in ('sessionId','runId','clockOrigin','activationNonce')}
 value.update(schema=1,action=action,attemptId=attempt['id'],attemptSha256=digest(root/('attempt-'+attempt['id']+'.json')),
   sessionSha256=digest(root/'session.json'),authorization=str(authorization),authorizationSha256=digest(authorization),permitId=permit['id'],boundAt=now)
 with (root/('binding-'+attempt['id']+'.json')).open('xb') as f:
  os.chmod(f.name,0o600);f.write(encoded(value));f.flush();os.fsync(f.fileno())
 return value

def bound_attempt(contract,attempt):
 root,session,state,frozen=attempt_context(contract,attempt)
 path=root/('binding-'+attempt['id']+'.json');private(path);binding=load(path)
 expected={k:contract['expected'][k] for k in ('sessionId','runId','clockOrigin','activationNonce')}
 require(all(binding.get(k)==v for k,v in expected.items()) and binding.get('schema')==1 and binding.get('action')==attempt['action'] and binding.get('attemptId')==attempt['id'],'attempt/authorization binding identity changed')
 require(binding['sessionSha256']==digest(root/'session.json') and binding['attemptSha256']==digest(root/('attempt-'+attempt['id']+'.json')),'binding session/attempt provenance changed')
 authorization=Path(binding['authorization']);require(digest(authorization)==binding['authorizationSha256'],'bound authorization changed')
 permit=authorization_for(root,session,attempt,authorization,binding['boundAt']);require(permit['id']==binding['permitId'],'bound permit changed')
 require([p.name for p in root.glob('binding-*.json') if load(p)['permitId']==permit['id']]==[path.name],'conflicting attempt bindings')
 used=root/'permits'/permit['id'];private(used)
 require(load(used)=={'action':attempt['action'],'permit':permit,'authorizationSha256':binding['authorizationSha256']},'exact bound authorization not consumed')
 return used,binding

def owned_attempt(contract,action,previous=False):
 root=Path(contract['runRoot']);state=load(root/'state.json');attempts=state['attempts']
 require(attempts and attempts[-1]['status']=='pending','current owned action absent')
 if previous:require(len(attempts)>=2 and attempts[-1]['action']=='export-ready','enable receipt must immediately precede export-ready')
 attempt=attempts[-2 if previous else -1]
 require(attempt['action']==action and attempt['status']==('completed' if previous else 'pending'),'wrong/stale owned action')
 permitpath,binding=bound_attempt(contract,attempt)
 owner={k:contract['expected'][k] for k in ('sessionId','runId','clockOrigin','activationNonce')}
 owner.update(action=action,attemptId=attempt['id'],permitSha256=digest(permitpath),bindingSha256=digest(root/('binding-'+attempt['id']+'.json')))
 if previous:
  # The observing action must itself own an independently consumed permit.
  bound_attempt(contract,attempts[-1])
  durable=load(root/('result-'+attempt['id']+'.json'))
  require(durable['action']==action and durable['result']==attempt['result']==state['receipts'][action],'enable receipt differs from owned durable result')
  elapsed=durable['elapsedSeconds'];require(type(elapsed) in (int,float) and math.isfinite(elapsed) and elapsed>=0 and attempt['started']+elapsed<=attempts[-1]['started'],'enable receipt does not precede observation action')
  raw_result=load(str(permitpath)+'-result')
  require(raw_result['exit']==0 and json.loads(raw_result['stdout'])==durable['result'],'enable consumed raw result conflicts with durable receipt')
  owner['receiptSha256']=digest(root/('result-'+attempt['id']+'.json'));owner['permitResultSha256']=digest(str(permitpath)+'-result')
  return owner,durable['result']
 return owner,None

def source_observation(contract):
 return source_binding.bind_source(**contract['pluginSource'],expected=contract['expectedSource'])

def wait_registration(source,expected,deadline,enable_receipt=None,contract=None):
 require(type(expected) is bool,'expected registration state missing')
 pending=False
 if enable_receipt is not None:
  require(contract is not None,'pending enable requires owned contract')
  owner,result=enable_receipt
  require(owner['action'] in ('plugins-enable','plugins-restore') and all(owner[k]==contract['expected'][k] for k in ('sessionId','runId','clockOrigin','activationNonce')) and owner['attemptId'] and owner['permitSha256'],'unowned pending enable')
  require(result['exit']==0 and result['stdout'] in ('ok\n','ok (exporting in background)\n') and result['exportPending']==(result['stdout']=='ok (exporting in background)\n'),'invalid owned enable response')
  pending=expected and result['exportPending']
 polls=[];seen_enabled=False
 while True:
  remaining(deadline);started=time.monotonic()
  binding=source_observation(contract) if contract is not None else None
  cat=catalog(deadline)
  if contract is not None:require(cat['source']=='local','catalog source conflicts with discovered local entry')
  initial_pending=pending and not seen_enabled and cat['enabled'] is False
  require(cat['enabled'] is expected or initial_pending,'plugin catalog conflicts with expected registration')
  seen_enabled |= cat['enabled']
  reg=None if initial_pending else registry(source,deadline)
  poll={'started':started,'ended':time.monotonic(),'catalog':cat,'registration':reg}
  if binding is not None:poll['sourceBinding']=binding
  polls.append(poll)
  print(json.dumps({'registrationPoll':poll},sort_keys=True),file=sys.stderr,flush=True)
  remaining(deadline)
  if reg is not None and reg['registered'] is expected:return reg|{'polls':polls,'deadline':deadline,'enableOwner':enable_receipt[0] if enable_receipt else None}
  time.sleep(min(.1,remaining(deadline)))

def rotation(code):
 spec=importlib.util.spec_from_file_location('rotation_guard',Path(code)/'rotation-guard.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 return mod.snapshot()
def timer_restored(journal,observed):
 require(journal['stage']=='restored','rotation journal not restored')
 before=journal['before']
 for name in ('timer','service'):require(observed[name]['config']==before[name]['config'],'rotation configuration changed')
 expected=before['timer']['state'] if before['timer']['state']['active']=='inactive' else journal['resumedState']
 require(observed['timer']['state']==expected and expected['active']==before['timer']['state']['active'],'timer activation not restored')
 require(observed['service']['state']['active']=='inactive' and observed['service']['result']=='success','rotation service not settled successfully')
 require(observed['timer']['subState']==('waiting' if expected['active']=='active' else 'dead'),'timer not settled')
def verify_restoration(contract,state,observed,journal):
 require(state.get('documentsEqual') is True and state.get('scratchExact') is True and state.get('canonicalMatchesExpected') is True and state.get('activeMatchesExpected') is True,'partial state restoration')
 require(observed['pointer']==contract['originalPointer'],'literal pointer not restored')
 require(observed['sourceBinding']==contract['expectedSource'] and observed['catalogReceipt']['source']==observed['sourceBinding']['catalogSource']=='local','restored catalog source conflicts with bound local source')
 require(type(contract['priorEnabled']) is bool and observed['enabled'] is contract['priorEnabled'] and observed['registered'] is contract['priorEnabled'],'plugin activation/registration not restored')
 timer_restored(journal,observed['rotation'])
 return {'documentsEqual':True,'scratchExact':True,'canonicalMatchesExpected':True,'activeMatchesExpected':True,'pointerExact':True,'pluginStateExact':True,'timerExact':True,'observedAt':time.monotonic()}
def state_verify(contract,mode):
 require(set(contract['stateEnvironment'])=={'PRISM_CONFIG_DIR','PRISM_STATE_DIR'} and all(isinstance(x,str) and Path(x).is_absolute() for x in contract['stateEnvironment'].values()),'explicit absolute config/state directories required')
 result=subprocess.run(['node',str(HERE/'state-verify.mjs'),mode,contract['snapshotBundle']],env=os.environ|contract['stateEnvironment']|{'PRISM_TASK3_REPO':contract['repo']},capture_output=True,text=True,timeout=10)
 require(result.returncode==0,'independent state verification failed: '+result.stderr)
 return json.loads(result.stdout)
def observe(contract):
 reg=registry(contract['sourceRoot']);cat=catalog()
 return {'sourceBinding':source_observation(contract),'pointer':os.readlink(contract['pointerPath']),'enabled':cat['enabled'],'registered':reg['registered'],'rotation':rotation(contract['codeRoot']),'registrationReceipt':reg,'catalogReceipt':cat,'observedAt':time.monotonic()}
def main():
 deadline=time.monotonic()+4 # One second margin under the existing five-second outer action timeout.
 action=sys.argv[1];contract=load(sys.argv[2])
 if action in ARGV:
  source_observation(contract);result=response(action,ipc(ARGV[action],deadline))
 elif action=='export-ready':
  receipt=owned_attempt(contract,'plugins-enable',previous=True)
  result=wait_registration(contract['sourceRoot'],True,deadline,receipt,contract)
 elif action=='plugins-restore':
  require(type(contract['priorEnabled']) is bool,'prior enabled state missing')
  owner,_=owned_attempt(contract,'plugins-restore');source_observation(contract)
  verb='plugins-enable' if contract['priorEnabled'] else 'plugins-disable';result=response(verb,ipc(ARGV[verb],deadline))
  result['registration']=wait_registration(contract['sourceRoot'],contract['priorEnabled'],deadline,(owner,result) if contract['priorEnabled'] else None,contract)
 elif action=='current':result=state_verify(contract,'cleared')
 elif action=='restore-verify':result=verify_restoration(contract,state_verify(contract,'restored'),observe(contract),load(contract['rotationJournal']))
 else:raise ValueError('unknown fixed host command')
 print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
