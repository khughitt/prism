"""One short schema2 lifecycle through real Guard/batch/RootHost/dispatch/helpers.

Owner/process/clock facts and external IPC/Node state/systemctl effects are synthetic.
Source discovery, all binding validation, rotation guard, collector and controller run.
"""
import contextlib, copy, io, json, os, runpy, signal, subprocess, sys, time, uuid
from pathlib import Path
from unittest.mock import patch
import round5_check as t
N=t.N;S=t.S;C=S/'code';os.umask(0o077)
SOURCE_SHA={name:t.sha(N/name) for name in ('packet_driver.py','helpers/host.py')}
f=t.Fixture(N/('integrated-'+uuid.uuid4().hex));d=f.driver;cap=t.mod('integrated_capture',C/'capture.py');d.cap=cap
builder=t.mod('integrated_builder',C/'frozen-task2/build.py')
readonly=t.load(Path(t.INPUT['readonlyInputs'])/'packet-inputs-v3.json');model=t.load(readonly['currentDescribe']);cli=readonly['repo']+'/bin/prism'
modelpath=f.base/'model.lua';modelpath.write_text('return '+builder.lua(model)+'\n')
f.m['activations']=[];f.m['initialRemainingReserve']=135;owned=[];bundles={};initial={};active_root=None
timer={'active':True,'activeEnter':'1','inactiveEnter':'0'}
real_immutable=t.C.immutable
def immutable(path,value):
    # Keep every synthetic authorization labelled in its original immutable bytes.
    if Path(path).name.startswith('authorization-'):value=value|{'synthetic':True}
    return real_immutable(path,value)
def done(argv,value):return subprocess.CompletedProcess(argv,0,json.dumps(value,sort_keys=True)+'\n','')
def execute(argv,env=None):
    args=argv[1:];args=args[1:] if args and args[0]=='-B' else args
    out=io.StringIO();err=io.StringIO()
    with patch.dict(os.environ,env or {},clear=False),patch.object(sys,'argv',args),contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
        if args[0]=='-c':
            sys.argv=['-c',*args[2:]];exec(args[1],{})
        else:runpy.run_path(args[0],run_name='__main__')
    return subprocess.CompletedProcess(argv,0,out.getvalue(),err.getvalue())
def external(argv,**kw):
    global active_root
    if argv[:2]==['/usr/bin/systemctl','--user']:
        args=argv[2:];unit=args[-1];is_timer=unit.endswith('.timer')
        if args[0]=='show':
            active=timer['active'] if is_timer else False
            values={'LoadState':'loaded','ActiveState':'active' if active else 'inactive','SubState':'waiting' if active else 'dead',
                'UnitFileState':'enabled','NeedDaemonReload':'no','FragmentPath':'/synthetic/'+unit,'DropInPaths':'',
                'Triggers':'wali-rotate.service' if is_timer else '', 'Unit':'wali-rotate.service',
                'ActiveEnterTimestampMonotonic':timer['activeEnter'] if is_timer else '0',
                'InactiveEnterTimestampMonotonic':timer['inactiveEnter'] if is_timer else '0','Result':'success'}
            return subprocess.CompletedProcess(argv,0,''.join(k+'='+v+'\n' for k,v in values.items()),'')
        if args[0]=='cat':return subprocess.CompletedProcess(argv,0,'synthetic unit '+unit+'\n','')
        if args[0] in ('start','stop'):
            assert is_timer;timer['active']=args[0]=='start';timer['activeEnter' if timer['active'] else 'inactiveEnter']=str(time.monotonic_ns());return subprocess.CompletedProcess(argv,0,'','')
        raise AssertionError(argv)
    args=argv[1:];args=args[1:] if args and args[0]=='-B' else args
    if args and (args[0]==str(C/'rotation-guard.py') or args[0]=='-c'):return execute(argv,kw.get('env'))
    if args and args[0]==str(C/'capture.py'):
        config=t.load(args[-1]);assert config['environment']=='synthetic' and config['socket'].startswith('prism-budget-capture-synthetic-')
        return f.real_run(argv,**kw)
    if args and args[0]==str(C/'snapshot.mjs'):
        root=Path(args[1]).parent;bundle=bundles[str(root)]
        t.C.immutable(root/'snapshot-bundle.json',bundle);t.C.immutable(root/'saved-state.json',bundle['saved'])
        t.C.immutable(root/'clock-verified.json',{'synthetic':True,'verified':False})
        return done(argv,{'snapshot':str(root/'snapshot-bundle.json'),'readOnly':True})
    if args and args[0]==str(C/'state.mjs'):return done(argv,{'synthetic':True,'stateAction':args[1]})
    if args and args[0]==str(N/'helpers/state-verify.mjs'):
        bundle=t.load(args[2]);saved=bundle['saved']
        return done(argv,{'runtime':{'active':saved['runtime']['active'],'scratch':{}},'canonical':saved['profiles'][saved['pair']['P']],
            'documentsEqual':True,'scratchExact':True,'canonicalMatchesExpected':True,'activeMatchesExpected':True})
    raise AssertionError('unhandled isolated external command '+repr(argv))
f.extra_external=external
original_external=f.external
def intercepted(argv,**kw):
    if argv==['/usr/bin/noctalia','msg','plugins','enable','khughitt/prism'] and str(active_root) in initial:
        with f.log.open('ab',buffering=0) as stream:stream.write(Path(initial.pop(str(active_root))).read_bytes());os.fsync(stream.fileno())
    return original_external(argv,**kw)
f.external=intercepted
def run(argv,**kw):
    result=f.real_run(argv,cwd=readonly['repo'],capture_output=True,text=True,timeout=20,**kw)
    assert result.returncode==0,(argv,result.stdout,result.stderr);return result
def freeze_master():
    t.C.atomic(f.master,f.m);f.master_sha=t.sha(f.master);d.master_sha=f.master_sha
    f.approval.update(masterSha256=f.master_sha,receivedAt=time.monotonic());f.review['masterSha256']=f.master_sha
    t.C.atomic(f.base/'actual-owner-approval.json',f.approval);t.C.atomic(f.base/'actual-review.json',f.review)
def outer_packet(name):
    root=f.base/name;session={'sessionId':f.m['sessionId'],'runId':'synthetic-'+name,'hostActions':{}}
    for action in ('snapshot','pause','resume'):
        session['hostActions']['rotation-'+action]={'argv':[sys.executable,'-B',str(C/'rotation-guard.py'),action,str(root/'journal.json')],'timeoutSeconds':5,'json':True,'env':{'PRISM_ROTATION_RETRY_APPROVED':'yes'}}
    session['hostActions']['rotation-verify']={'argv':[sys.executable,'-B','-c',"import sys,json;sys.path.insert(0,sys.argv[1]);import host;observed=host.rotation(sys.argv[2]);host.timer_restored(host.load(sys.argv[3]),observed);print(json.dumps({'timerRestored':True,'observation':observed}))",str(N/'helpers'),str(C),str(root/'journal.json')],'timeoutSeconds':5,'json':True}
    path=f.base/(name+'-session.json');t.C.immutable(path,session)
    f.m['outer']={'label':'outer','runRoot':str(root),'journal':str(root/'journal.json'),'session':str(path),'sourceContracts':f.m['activations'][0]['sourceContracts']}
def prepare(label,variant,block,launch,scenario='handoff'):
    uid=label+'-'+uuid.uuid4().hex[:6];root=f.base/('run-'+uid);built=f.base/('build-'+uid);prefix=f.base/('producer-'+uid);nonce='synthetic-'+uuid.uuid4().hex
    run([sys.executable,'-B',str(C/'frozen-task2/build.py'),'--baseline','9bf4e8e920c005f8a4d1666b32b4e1a516856ac2','--candidate','e7384b0d7ab3e8e935cdf0776043839441132af5','--cli',cli,'--output',str(built),'--nonce',nonce,'--block',block,'--cold-pairs','1','--launch-pairs',str(launch),'--stage','stage1','--environment','synthetic','--run-id',nonce,'--clock-origin','synthetic-clock-'+nonce])
    run(['/usr/bin/lua',str(C/'controller-producer.lua'),str(built),str(modelpath),str(C/'frozen-task2/test_encode.lua'),cli,scenario,variant,str(prefix)],env=os.environ|{'FIXTURE_START':str(time.monotonic()+3)})
    meta=t.load(str(prefix)+'-meta.json');identity=t.load(built/variant/'identity.json');values={p['key']:p['value'] for p in meta['initialModel']['params']};P=meta['initialModel']['active']['profile'];Q=next(x for x in model['profiles'] if x!=P)
    bundles[str(root)]={'saved':{'documents':{},'pair':{'P':P,'Q':Q},'profiles':{P:values,Q:copy.deepcopy(values)},'runtime':{'active':meta['initialModel']['active'],'scratch':{'synthetic':1}},'uneditedNumeric':[{'key':'glass.inactive.roughness'}]},'resolverSources':{},'definitions':{p['key']:{k:p[k] for k in ('type','range') if k in p} for p in model['params']}}
    initial[str(root)]=str(prefix)+'-initial.log'
    cfg={'schema':2,'environment':'synthetic','runId':identity['runId'],'clockOrigin':identity['clockOrigin'],'socket':'prism-budget-capture-synthetic-'+uuid.uuid4().hex,'deadlineSeconds':2700,'pollSeconds':.1,'maxGapSeconds':2,'log':str(f.log)}
    for key in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[key]=str(root/(key+'.json'))
    cfgfile=f.base/(uid+'-collector.json');t.C.immutable(cfgfile,cfg);owned.append((root,cfg))
    session=copy.deepcopy(f.session);actions=session['hostActions'];session.update(runId=identity['runId'],clockOrigin=identity['clockOrigin'],identity=identity,pilot=True,buildRoot=str(built/variant),steps=f.m['steps'],snapshotBundle=str(root/'snapshot-bundle.json'))
    for action,spec in actions.items():
        if 'argv' in spec:spec['argv'][-2]=label
    for action in ('snapshot','pause','resume'):
        actions['rotation-'+action]={'argv':[sys.executable,'-B',str(C/'rotation-guard.py'),action,str(root/'rotation-journal.json')],'timeoutSeconds':5,'json':True,'env':{'PRISM_ROTATION_RETRY_APPROVED':'yes'}}
    actions['state-snapshot']={'argv':['node',str(C/'snapshot.mjs'),str(root/'snapshot-bundle.json'),str(root/'saved-state.json')],'timeoutSeconds':5,'json':True}
    for action in ('clear','restore'):actions['state-'+action]={'argv':['node',str(C/'state.mjs'),action,str(root/'saved-state.json')],'timeoutSeconds':5,'json':True}
    actions['collector-launch']={'argv':[sys.executable,'-B',str(C/'capture.py'),'launch',str(root/'run.json')],'timeoutSeconds':10,'json':False}
    actions['finish-authorize']={};actions['stop-authorize']={}
    target=built/variant/'plugin';actions['pointer-swap']['to']=str(target);actions['pointer-restore']['from']=str(target)
    f.pointer.unlink();f.pointer.symlink_to(target);active=t.H.source_binding.bind_source(**f.pluginSource);f.pointer.unlink();f.pointer.symlink_to(str(f.base/'original'))
    sess=f.base/(uid+'-session.json');session_sha=t.C.immutable(sess,session)
    entry={'label':label,'runRoot':str(root),'session':str(sess),'collector':str(cfgfile),'sessionSha256':session_sha,'contracts':{},'contractSha256':{},'sourceContracts':{}}
    expected={k:session[k] for k in ('sessionId','runId','clockOrigin')}|{'activationNonce':identity['activationNonce'],'sessionFileSha256':session_sha}
    for phase,source in (('original',f.sources['original']),('active',active)):
        for action in list(actions)+['source-check']:
            key=action+'@'+phase;path=f.base/(uid+'-'+key+'.json')
            ct={'synthetic':True,'runRoot':str(root),'expected':expected,'pluginSource':f.pluginSource,'expectedSource':source,'sourceRoot':str(f.sentinel_source),'codeRoot':str(C),
                'originalPointer':str(f.base/'original'),'pointerPath':str(f.pointer),'priorEnabled':True,'action':action,'sourcePhase':phase,
                'repo':readonly['repo'],'stateEnvironment':{'PRISM_CONFIG_DIR':str(f.base/'config'),'PRISM_STATE_DIR':str(f.base/'state')},'snapshotBundle':str(root/'snapshot-bundle.json'),'rotationJournal':str(root/'rotation-journal.json')}
            entry['contracts'][key]=str(path);entry['contractSha256'][key]=t.C.immutable(path,ct)
            if action=='source-check':entry['sourceContracts'][phase]=str(path)
    f.m['activations'].append(entry);return entry,meta
def stopped(signum,frame):raise SystemExit(128+signum)
for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,stopped)
results=[]
try:
    for label,variant,block,launch in [('B1','baseline','1',1),('C1','candidate','1',1),('C2','candidate','2',0),('B2','baseline','2',0)]:
        entry,meta=prepare(label,variant,block,launch)
        if label=='B1':outer_packet('outer-normal')
        freeze_master();active_root=Path(entry['runRoot'])
        with f.active(),patch.object(t.C,'immutable',side_effect=immutable):
            card=d.start(label);obj,entry,session=d.controller(label)
            delay=meta['initialReply']-time.monotonic()+.02
            if delay>0:time.sleep(delay)
            result=d.completed_reply(obj,entry,session,{'synthetic':True,'receivedAt':meta['initialReply'],'provenance':{'messageId':'synthetic-'+label}})
        own=t.load(active_root/'driver-result.json');assert own['activationRestored'] and own['collectionGate'];assert own['wholeGroupRestored']==(label=='B2')
        results.append(result);print('PASS integrated normal',label,'collection',own['collectionGate'],'whole-group-restored',own['wholeGroupRestored'],flush=True)
    assert results[-1]['collectionGate'] and not results[-1]['accepted'] and not results[-1]['nextStageEligible'] and timer['active']
    for mode in ('short','abort'):
        f.m['activations']=[];entry,meta=prepare('B1','baseline','1',1,'shortlaunch-gainpass-handoff' if mode=='short' else 'handoff');outer_packet('outer-'+mode);freeze_master();active_root=Path(entry['runRoot'])
        with f.active(),patch.object(t.C,'immutable',side_effect=immutable):
            if mode=='short':
                d.start('B1');obj,entry,session=d.controller('B1');delay=meta['initialReply']-time.monotonic()+.02
                if delay>0:time.sleep(delay)
                result=d.completed_reply(obj,entry,session,{'synthetic':True,'receivedAt':meta['initialReply'],'provenance':{'messageId':'synthetic-short'}})
                assert result['restored'] and not result['collectionGate'] and result['noRecoveryIssued'];assert not (active_root/'recovery.json').exists()
            else:
                real=f.extra_external
                def wrong_current(argv,**kw):
                    value=real(argv,**kw)
                    if len(argv)>2 and argv[1]==str(N/'helpers/state-verify.mjs') and argv[2]=='cleared':return done(argv,json.loads(value.stdout)|{'canonical':{'wrong':1}})
                    return value
                f.extra_external=wrong_current
                try:d.start('B1');raise AssertionError('wrong initial current accepted')
                except ValueError as error:assert 'canonical' in str(error),str(error)
                finally:f.extra_external=real
                assert not (active_root/'owner-card.txt').exists()
                result=d.abort('B1','synthetic pre-card wrong reference');assert result['restored'] and not result['collectionGate']
                assert not (active_root/'initialCompleteReceived.json').exists() and not (active_root/'restoration.json').exists()
        assert timer['active'];print('PASS integrated',mode,'restored; no fabricated normal outcome',flush=True)
    assert SOURCE_SHA=={name:t.sha(N/name) for name in SOURCE_SHA}
    t.C.immutable(f.base/'integrated-result.json',{'synthetic':True,'sourceSha256':SOURCE_SHA,'normalActivations':4,'shortAndAdministrativeAbort':True,'realGuardBatchRootHostDispatchHelpers':True,'result':results[-1],
        'externalIPCCalls':len(f.commands),'taskNotesIsolated':len(f.notes),'ownerAdapter':'Synthetic receipt files reject at unadapted actual authority; only isolated test reads supply schema-compatible human facts.'})
finally:
    cleanup=[]
    for root,cfg in owned:
        ids=t.load(root/'identities.json') if (root/'identities.json').exists() else {}
        if ids.get('server') and cap.same_process(ids['server']):cap.tmux(cfg,'kill-server',check=False)
        end=time.monotonic()+5
        while any(cap.same_process(x) for x in ids.values()) and time.monotonic()<end:time.sleep(.02)
        remaining={k:v for k,v in ids.items() if cap.same_process(v)};cleanup.append({'root':str(root),'processes':ids,'remaining':remaining});assert not remaining
    t.C.immutable(f.base/'cleanup.json',{'synthetic':True,'actors':cleanup});print('CLEANUP',len(cleanup),'owned actor groups, none remaining',flush=True)
print('PASS integrated synthetic lifecycle',f.base,flush=True)
