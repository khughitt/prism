"""Prepare immutable proposals only. Does not create actual/live state or authority."""
import hashlib, importlib.util, json, os, shutil, sys, time
from pathlib import Path
N=Path(__file__).resolve().parent;os.umask(0o077)
def load(p):return json.loads(Path(p).read_bytes())
def encoded(v):return (json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    with Path(p).open('xb') as f:f.write(encoded(v))
    return sha(p)
inputs=load(N/'inputs.json');S=Path(inputs['corrected']);R=Path(inputs['readonlyInputs']);I=load(R/'packet-inputs-v3.json')
old=load(I['oldPacket']);oldsession=load(old['activations'][0]['session']);observation=load(I['pluginObservation']);source=load(I['sourceObservation'])
code=S/'code';helpers=N/'helpers';driver=N/'packet_driver.py';proposal=N/sys.argv[1];proposal.mkdir(mode=0o700)
masterpath=N/(sys.argv[1]+'-master.json')
interpreters={'python':old['interpreters']['python3'],'node':old['interpreters']['node'],'lua':'/usr/bin/lua','bash':'/usr/bin/bash','tmux':'/usr/bin/tmux','noctalia':'/usr/bin/noctalia','systemctl':'/usr/bin/systemctl'}
interpreters={k:str(Path(v).resolve()) for k,v in interpreters.items()}
env=I['stateEnvironment']|{'PATH':str(Path(interpreters['node']).parent)+':/usr/bin:/bin','TMUX_TMPDIR':'/tmp','PRISM_TASK3_REPO':I['repo'],'PYTHONDONTWRITEBYTECODE':'1'}
original=observation['expectedOriginalSource'];pluginSource=observation['pluginSource']
assert source['pointerPath']==pluginSource['pointer_path']==original['pointerEntry']
assert observation['priorEnabled'] is True and observation['registered'] is True
assert load(I['sourceUniqueness'])['selectedEntries']==[original['pointerEntry']]
proof=load(I['sourceProof']);assert proof['sessionId']==I['prospectiveSessionId']==proof['binding']['rootSessionId']
boot=load(I['clockVerified'])['clockOrigin'];builds=load(N/'builds.json')
# These are proposed whole-group allowances, never maximum filesystem durations.
steps={'pre':36,'post':21,'recovery':20,'finish':67}
reserve={'kind':'prospective-ceilings-not-measurements','groups':steps,'sumSeconds':144,'reserveSeconds':180,
 'approvalSecondsAvailable':120,'initialRemainingReserve':135,'recoveryRemainingReserve':109,
 'reader':{'normalActiveCalls':6,'normalTerminalCallsBeforeGroupVerdict':3,'additionalTerminalCallsPerActivationAtGroupVerdict':2,'attemptsPerCall':8,'elapsedCheckSeconds':.25,'preemptive':False},
 'repeatedActions':{'panel-close':3,'plugins-disable':2,'checkpoint-authorize':3},
 'counts':{'normalControllerActions':24,'outerActionsAcrossGroup':4,'driverInventoryClockAuditsPerActivation':36,'additionalControllerSetupInventoryClockChecks':1,'extraOuterAuditsOnB1AndB2':3,
           'dispatchOwnedReceiptChecks':11,'sourceBindingsFromHelpersMinimum':11,'additionalRegistrationPollsAreCountedByActualElapsed':True,'freshOwnerReceipts':1,'currentLockedRead':1},
 'historical':load(Path(inputs['failedPacket'])/'reserve-provenance-v1.json')['historical'],
 'readonly':{'catalogSeconds':observation['catalogSeconds'],'registrySeconds':observation['registrySeconds'],'staticInventoryHashComponent':load(N/'inventory-component-timing.json')},
 'groupOperations':{
 'pre':['Root source/clock/full artifact preflight including bounded recorded log descriptor reobservation', '24 total attempt-to-authorization bindings and consumed checks across all groups; source-phase direct/reconciliation provenance at every audit/dispatch','outer snapshot/pause B1','inner snapshot/pause','fresh locked snapshot+clear','original close+disable','exact swap','collector launch+bounded start','active enable/export/open','publication ready+ack','candidate read+verify_initial+locked current','new checkpoint ready+ack+coverage','issue card'],
 'post':['actual receipt validation and owner_complete', 'all post source/clock/inventory/log audits and exact current/previous authorization provenance','active physical close','new checkpoint and bounded ack','external inspect plus internal checked','short-class classification'],
 'recovery':['reserved separately: fresh Root decision/approval/packet','at most one combined packet; no automatic issuance','new open/readiness/reply/close/check actions must be reviewed before use'],
 'finish':['external inspect plus internal finish','fresh finish permit/control','exit/reap bounded wait and internal exited terminal read','final-drain independent terminal read','second active close+disable','inverse pointer','original plugins-restore pending-enable registration','locked state restore','inner inactive rotation restore','independent restoration verification','outer original resume+verification B2 or safe stop','normal ordered analysis and final actual elapsed', 'eligibility before preserving outer pause; restore original outer state on post/finish/full failure and count cleanup', 'up to8 log metadata observations per audit, .25s elapsed checks after synchronous work, one error record on exhaustion; no hard I/O cap']},
 'round5Accounting':{
  'normalPerActivation':{'controllerAttemptsAndBindingWrites':24,'preissuedPermitBatches':8,'driverAudits':36,'sourcePhaseEvaluations':46,'directPointerReceiptValidations':42,'dispatchesAndExclusiveClaims':11,'dispatchOrHelperConsumedBindingValidations':14,'canonicalSessionReadsAtEachBindingValidation':True},
  'outerAcrossGroup':{'RootHostActions':4,'additionalDriverAudits':6,'additionalPreissuedBatches':2,'exactOriginalVerification':1},
  'logReobservation':{'perDriverAudit':True,'maximumAttemptsPerAudit':8,'elapsedCheckSecondsPerAudit':.25,'pollSeconds':.01,'processBinaryEnvironmentChecksPerAttempt':2,'descriptorScanAndActivePathStatBeforeAfterPerAttempt':True,'immutableObservationRecordsPerAttempt':1,'extraFailureRecord':1,'maximumNormalGroupAuditAttempts':1200,'nonPreemptive':True},
  'bindingOperations':['read canonical frozen session/state/attempt','private preissued authorization plus exact permit and issuance/expiry checks','scan prior binding identities for reuse/conflict','exclusive fsynced attempt-to-authorization binding','RootHost consumes immutable exact permit','dispatch validates binding plus consumed authorization and reserves exclusive dispatch record','previous-enable validates its own raw result and current export authorization','source phase validates frozen attempt/consumed authorization/pointer journal/result; reconciliation separately validates its own raw result and chronology'],
  'dynamic':['registration/source polls and current/receipt reads','ready/wrapper bounded observations and per-observation records','retry count and actual elapsed for log close/reopen transitions','source phase validation grows with recorded attempts; reconciliation adds original plus observation attempt proofs','all restore retries/new batches, administrative stop, outer verification and final ordered analysis consume actual elapsed'],
  'qualification':'Counts cover the normal live front door. Synthetic continuation omits one completion authority audit per activation, so its observed35/38 audits do not replace36/39 live counts. All new work is inside the unchanged whole-group ceilings, with no additional seed or approval allowance.'},
 'qualification':'Existing historical broad intervals and earlier helper component timings are retained as historical only. Synthetic lifecycle times fund no live reserve. All actual time including setup, audits, analysis and outer restoration is counted; overruns invalidate collection while cleanup continues. Synchronous filesystem work has no claimed hard bound.'}
write(proposal/'reserve.json',reserve)
base_inventory={str(p):sha(p) for d in (code,helpers) for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
base_inventory|={p:sha(p) for p in interpreters.values()}
base_inventory|={str(file):sha(file) for file in N.glob('*.py')}
for name,expected in source['sourceSha256'].items():
    file=Path(original['resolvedDirectory'])/name;assert sha(file)==expected;base_inventory[str(file)]=expected
for file in (Path(I['repo'])/'bin/prism',* (Path(I['repo'])/'src').rglob('*.mjs')):base_inventory[str(file)]=sha(file)
for name in ('packet-inputs-v3.json','source-observation.json','source-proof-prospective.json','clock-readonly-verified.json','current-log-descriptor.json','local-discovery-uniqueness.json','current-plugin-observation.json','describe-current.stdout','describe-current-receipt.json'):
    base_inventory[str(R/name)]=sha(R/name)
for name in source['discoverySourceSha256']:
    file=Path(proof['sourceRoot'])/name;assert sha(file)==source['discoverySourceSha256'][name];base_inventory[str(file)]=sha(file)
logger=load(I['logObservation']);assert sha(logger['sourceFile'])==logger['sourceFileSha256'];base_inventory[logger['sourceFile']]=logger['sourceFileSha256']
base_inventory[str(proposal/'reserve.json')]=sha(proposal/'reserve.json')
master={'schema':1,'kind':'complete-inert-prospective-n1-packet','runnable':False,'authorized':False,'preparedAt':time.monotonic(),
 'sessionId':I['prospectiveSessionId'],'repo':I['repo'],'code':str(code),'helpers':str(helpers),'interpreters':interpreters,
 'tasksBinary':str(Path(shutil.which('tasks')).resolve()),'env':env,'sourceProof':I['sourceProof'],'sourceObservation':I['sourceObservation'],'logObservation':I['logObservation'],'r2Root':oldsession['r2Root'],
 'initialRemainingReserve':135,'recoveryRemainingReserve':109,'steps':steps,'reserve':str(proposal/'reserve.json'),
 'logReobservation':{'attempts':8,'elapsedSeconds':.25,'pollSeconds':.01},
 'limits':{'initial':1200,'recovery':600,'collector':2100,'controller':300,'minimumApproval':120},'activations':[]}
base_inventory[master['tasksBinary']]=sha(master['tasksBinary'])
command=lambda argv,timeout=5,extra=None:{'argv':argv,'timeoutSeconds':timeout,'json':True,'env':env|(extra or {})}
for ordinal,b in enumerate(builds,1):
    label=b['label'];root=Path(b['runRoot']);built=Path(b['buildRoot']);identity=load(built/'identity.json')
    assert identity['environment']=='live' and identity['clockOrigin']==boot and identity['coldPairs']==1
    plugin=built/'plugin';candidate=original|{'literalTarget':str(plugin),'resolvedDirectory':str(plugin),'manifestSha256':sha(plugin/'plugin.toml'),'panelSha256':sha(plugin/'panel.luau')}
    entry={'label':label,'runRoot':str(root),'session':str(proposal/(label+'-session.json')),'collector':str(proposal/(label+'-collector.json')),'contracts':{},'contractSha256':{},'sourceContracts':{}}
    actions={a:{} for a in ('checkpoint-authorize','finish-authorize','stop-authorize','recovery-authorize')}
    for a in ('panel-close','panel-open','plugins-disable','plugins-enable','export-ready','plugins-restore','final-drain','restore-verify'):
        actions[a]=command([interpreters['python'],'-B',str(driver),'dispatch',str(masterpath),label,a],15 if a=='final-drain' else 45 if a=='restore-verify' else 5)
    actions['pointer-swap']={'path':original['pointerEntry'],'from':original['literalTarget'],'to':str(plugin)}
    actions['pointer-restore']={'path':original['pointerEntry'],'from':str(plugin),'to':original['literalTarget']}
    for a in ('snapshot','pause','resume'):
        actions['rotation-'+a]=command([interpreters['python'],'-B',str(code/'rotation-guard.py'),a,str(root/'rotation-journal.json')],30 if a=='snapshot' else 90,{} if a=='snapshot' else {'PRISM_ROTATION_RETRY_APPROVED':'yes'})
    actions['state-snapshot']=command([interpreters['node'],str(code/'snapshot.mjs'),str(root/'snapshot-bundle.json'),str(root/'saved-state.json')],30)
    for a in ('clear','restore'):actions['state-'+a]=command([interpreters['node'],str(code/'state.mjs'),a,str(root/'saved-state.json')],30,{'PRISM_TASK3_APPROVED':'yes'})
    actions['collector-launch']=command([interpreters['python'],'-B',str(code/'capture.py'),'launch',str(root/'run.json')],30);actions['collector-launch']['json']=False
    for action in list(actions):
        if action.endswith('-authorize'):continue
        a='reconcile-'+action;actions[a]=command([interpreters['python'],'-B',str(driver),'dispatch',str(masterpath),label,a],45)
    cfg=load(old['activations'][ordinal-1]['collector'])
    cfg.update(runId=identity['runId'],clockOrigin=boot,log=load(I['logObservation'])['log']['path'],socket='prism-budget-capture-'+identity['activationNonce'])
    for key in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[key]=str(root/(key+'.json'))
    entry['collectorSha256']=write(entry['collector'],cfg)
    inventory=base_inventory|{str(f):sha(f) for f in built.parent.rglob('*') if f.is_file()}
    inventory[entry['collector']]=entry['collectorSha256']
    session={'schema':2,'sessionId':master['sessionId'],'runId':identity['runId'],'clockOrigin':boot,'environment':'live','identity':identity,
      'pilot':True,'activationOrdinal':ordinal,'buildRoot':str(built),'collectorConfig':str(root/'run.json'),'snapshotBundle':str(root/'snapshot-bundle.json'),
      'sourceProof':I['sourceProof'],'r2Root':oldsession['r2Root'],'rateMeasurement':oldsession['rateMeasurement'],'steps':steps,'hostActions':actions,'artifactSha256':inventory}
    if ordinal>1:session.update(referenceSnapshot=str(Path(builds[0]['runRoot'])/'saved-state.json'),outgoingState=str(Path(builds[ordinal-2]['runRoot'])/'state.json'))
    entry['sessionSha256']=write(entry['session'],session)
    expected={k:session[k] for k in ('sessionId','runId','clockOrigin')};expected.update(activationNonce=identity['activationNonce'],sessionFileSha256=entry['sessionSha256'])
    common={'kind':'prospective-no-authority','repo':I['repo'],'codeRoot':str(code),'sourceRoot':proof['sourceRoot'],'snapshotBundle':session['snapshotBundle'],
      'savedState':str(root/'saved-state.json'),'runRoot':str(root),'pointerPath':original['pointerEntry'],'originalPointer':original['literalTarget'],
      'priorEnabled':observation['priorEnabled'],'rotationJournal':str(root/'rotation-journal.json'),'stateEnvironment':I['stateEnvironment'],'pluginSource':pluginSource,'expected':expected}
    for phase,binding in [('original',original),('active',candidate)]:
        for action in [a for a in actions if 'dispatch' in actions[a].get('argv',[])]+['source-check']:
            key=action+'@'+phase;file=proposal/(label+'-'+key+'.json');ct=common|{'action':action,'sourcePhase':phase,'expectedSource':binding}
            if action in ('reconcile-pointer-swap','reconcile-pointer-restore'):
                ct['pointerSources']={'from':original,'to':candidate} if action.endswith('swap') else {'from':candidate,'to':original}
            entry['contracts'][key]=str(file);entry['contractSha256'][key]=write(file,ct)
            if action=='source-check':entry['sourceContracts'][phase]=str(file)
    master['activations'].append(entry)
outer_root=N/'live-outer';outer_session={'sessionId':master['sessionId'],'runId':'outer-'+N.name,'hostActions':{}}
for action in ('snapshot','pause','resume'):
    outer_session['hostActions']['rotation-'+action]=command([interpreters['python'],'-B',str(code/'rotation-guard.py'),action,str(outer_root/'journal.json')],45 if action=='snapshot' else 90,{} if action=='snapshot' else {'PRISM_ROTATION_RETRY_APPROVED':'yes'})
outer_session['hostActions']['rotation-verify']=command([interpreters['python'],'-B','-c',"import sys,json;sys.path.insert(0,sys.argv[1]);import host;observed=host.rotation(sys.argv[2]);host.timer_restored(host.load(sys.argv[3]),observed);print(json.dumps({'timerRestored':True,'observation':observed}))",str(helpers),str(code),str(outer_root/'journal.json')],45)
master['outer']={'label':'outer','runRoot':str(outer_root),'journal':str(outer_root/'journal.json'),'session':str(proposal/'outer-session.json'),'sourceContracts':master['activations'][0]['sourceContracts']}
write(master['outer']['session'],outer_session)
master['inventory']=base_inventory|{str(f):sha(f) for f in proposal.rglob('*') if f.is_file()}|{str(f):sha(f) for b in builds for f in Path(b['buildRoot']).parent.rglob('*') if f.is_file()}
write(masterpath,master);write(N/(sys.argv[1]+'-master-hash.json'),{'sha256':sha(masterpath)})
assert not any(Path(x['runRoot']).exists() for x in master['activations']) and not outer_root.exists()
print('PASS inert four-card materialization; sessions -> contracts -> master noncircular; reserve144->180 leaves120')
