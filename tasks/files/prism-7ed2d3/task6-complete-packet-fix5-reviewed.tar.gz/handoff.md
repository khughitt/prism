# Task6 corrective round5/5: inert packet handoff

Authoritative private master: proposals-reviewed-master.json, SHA256 e5e350b811316114eed31053935ace7a678ee734544a8795048731eeded4d388.
Driver/helper hashes are in source-inventory.json. Original54/new58 and accepted
v2 helpers, prior472 packet, failed packets and Root readonly inputs are unchanged.
Other master files in this new directory are retained drafts, never authority.

Root owns the scoped review, cap adjudication, fresh actual observations and human
permission. No actual review/approval/permits/live namespace is supplied. The same
Root prospective source/clock group is retained; all four build/run/card nonces are
new. root-commands.txt is conditional reference, never an unconditional script.

The Guard now writes one exclusive immutable binding after the Controller creates
its exact pending attempt and before unchanged RootHost consumes the preissued
permit. The fixed helper requires that exact authorization/session/attempt/spec
binding and consumed record. Previous-enable lookup requires its own binding and
raw durable result. Replay, overlapping conflicting bindings and issuance after the
attempt fail. No window-expiry wait or latest-permit fallback exists.

Source phase consumes exact direct pointer results or independently validated
reconciliation attempt/result/raw-consumed receipt. Completed and not-applied are
separate. Missing original result files are supported only via the exact completed
reconciliation; no fabricated result is written. Existing reconciliation and
manual-recovery restrictions remain.

Each audit reobserves the exact pinned process and active log descriptor/path.
Recorded metadata-only attempts tolerate close/reopen gaps and new descriptor
numbers. Eight attempts, .25s elapsed checks and .01s polls are prospective bounds
between synchronous operations, not preemptive I/O guarantees. Wrong process,
binary, environment, logger settings, ambiguity, descriptor/path conflict or late
success refuses. Collector rotation and byte-lineage checks are unchanged.

Normal per-activation restoration has activationRestored=true. Eligible interim
cards retain an explicit outerRestorationRequired obligation and restored=false.
Any protocol/group/full eligibility failure restores and verifies the exact original
outer state, then counts cleanup in final elapsed. B2 always restores outer state.
A failure gives outerError/manual-recovery and never a false restored claim. Final
group analysis is counted and can only remove eligibility. No automatic next card
is allowed after an ineligible result.

All prior owner10s-visible guidance, 20/10/35min windows, 300s controller/120s approval
and n1-inconclusive rules remain. Reserve seed36+21+20+67=144, reserve180 leaves120;
there is no additional seed margin. Source audits, log reobservations, binding reads,
fsyncs, dispatch/receipt checks, retries, analysis and outer cleanup are included in
those whole-group proposals. Readonly hash times are components only; synthetic
timing provides no live allowance.

Synthetic checks retain the real Guard/batch/RootHost/dispatch/helper methods.
The complete lifecycle uses an in-process transport for external process execution
so only isolated IPC/Node state/systemctl facts are supplied; all source discovery,
receipt/permit validation and rotation guard code runs. A separate test launches
real dispatch and exec helper Python processes for overlapping closes, isolating
only review-file reads and the lowest Noctalia IPC command. Synthetic review/owner
files stay marked synthetic on disk and fail the unadapted actual front door.

Root next audits these exact files and the reserve, dispatches the final scoped
review, then adjudicates the existing cap before any fresh permission. No fulln5,
Task7, performance claim, actual host use or task closure is authorized here.

The final qualification also copies all eight frozen sentinel source files into
each isolated fixture and runs the unchanged source hash validator during helper
registration. No source validator is replaced by a constant return.
