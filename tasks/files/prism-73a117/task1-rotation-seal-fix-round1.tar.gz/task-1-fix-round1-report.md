
# Corrective round1/5 — Important I1 rotation sealing race

Base reviewed commit51e221e. Root received the read-only review from
codex/gpt-6-astra and recorded round1 Important1 Minor2 before this assignment.
This correction addresses I1 only; M1/M2 stay deferred in the controller ledger.
Task resumed with tasks start; trial-arm exit0: not enrolled. Root claims untouched.

## Reproduction and correction

I verified the static finding through deterministic real tempfile writes, instrumented
only at method boundaries. A late outgoing append after _append, _prefix or _archives
could be absorbed into the old post-validation snapshot without capture. A captured
prefix mutation after _prefix or _archives could similarly reach a successful finish.
Five of eight cases reproduced the false integrity=true verdict on the frozen reviewed
logs.py. Prefix mutation after _append and both late-transition cases already refused.

Changed production-private code only in logs.py; added tests only in capture-check.py.
log-check.py, capture.py and capture-wrapper.sh remain byte-identical to reviewed code.
_append now returns the source stat it verified while consuming exactly through its
captured end. poll retains that anchor, requires anchor size==captured cursor and current
descriptor equality, compares the full-prefix validation snapshot to it, then rechecks
outgoing descriptor/path after archives validation. It keeps the outgoing descriptor
open through new-generation setup/append and checks both descriptor/path against the
SAME anchor before closing it. It never takes a later unverified outgoing snapshot.
Changes anywhere in that validation/transition interval latch failed and prevent finish.

New covering tests:
- CaptureCheck.test_rotation_seal_rejects_late_append
- CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation
Their subcases inject after outgoing append, after outgoing prefix validation, after
archive validation, and after new-generation append immediately before the final
transition check. Each requires actual injection, a refused poll, preserved captured
archive/source bytes, latched failure, rejected finish and false manifest completion.

## Exact commands/results

RED command:
`python3 "$CAPTURE_ROOT/code/capture-check.py" CaptureCheck.test_rotation_seal_rejects_late_append CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation`
Against verified frozen reviewed logs.py: exit1, two tests with five failing subcases,
each `AssertionError: True is not false ... finish certified integrity`.
Full output below and proofs/sealing-red.log in the fix archive.

Focused GREEN: identical command on fixed code, exit0; all eight injected cases refuse.
Covering GREEN:
`python3 "$CAPTURE_ROOT/code/capture-check.py" CaptureCheck` — exit0,16 tests.
`python3 "$CAPTURE_ROOT/code/log-check.py"` — exit0, original plus persistent owner and
A→B→A calibration groups. Incremental read meter still7 source bytes /0 sealed bytes.
Complete command outputs below and in the fix archive.
`just check`, `tasks check`, `git diff --check` — all exit0, empty output; no task warnings.
No unchanged package suite or lifecycle/tmux smoke repeated; source change is isolated
to collector sealing, covered by collector/inherited checks. No production files changed.

## Self-review and scope limits

I checked all _append callers and test spies: existing call sites may ignore the new
private return; poll uses it as the validated anchor. Successful first-offset/rotation /
A→B→A paths still pass, with no per-poll archive read increase. The outgoing descriptor
closes in finally even if new-generation opening/appending/validation fails; the new
owned descriptor remains available to Capture.close. Early-window refusal leaves the
old cursor/evidence intact; transition-window refusal preserves newly appended evidence
but latches the active Capture incomplete. A fresh activation still refuses prior state.

No additional Important/Critical issue found in this scope. Root must obtain scoped
independent re-review before dependent work. M1/M2 deliberately not modified. Capture
integrity still does not certify protocol settlement or live cadence/performance.
No live IPC, desktop, plugin pointer, timer/profile change, external write, long run or
subagent occurred. All checks/processes finished. host-load --section session exit0:
`session kitty-2680783-0.scope: nothing left running`.

## Fix archive and exact source identities

Unique attachment: tasks/files/prism-73a117/task1-rotation-seal-fix-round1.tar.gz.
Includes all five exact fixed code files, reviewed-to-fix.diff (full reviewed-original
→fix textual diff), preserved-to-fix.diff (complete original collector→fix diff), fixed
and reviewed SHA256 inventories, exact RED/GREEN outputs, gate records, this fix report,
fresh synthetic measurement-payload equality proof and SHA256SUMS. No private raw
originals or model/describe values. All19 preserved inputs were rehashed unchanged.
Original attachment kept byte-identical: SHA256
273f7be1436dea49ea92d7baac1c6b6b7d5023267a21502368c14ee179aca0fe (44598 bytes).
Private fixed sources remain at CAPTURE_ROOT/code; authoritative review workspace is
.worktrees/panel-budget. Worker parks waiting on root scoped re-review and does not close
the task. Reviewed originals remain at the controller-frozen task-1-reviewed-code path.

Fixed code hashes:

- `logs.py`: `f52bd8ff7a88b9c24c3005a00b97b10c3201bed2800c41fec912a80db5965292`
- `log-check.py`: `2fd27a21fb8a44c8860b3ae025a442cac0720d36a749491721c8403526422af3`
- `capture.py`: `5e42973c1d65429f81c29d578d373040fd8f008cc11fd80b160613167ad444c9`
- `capture-wrapper.sh`: `3d45f3e6e5edc63080e98b9580bafcbe44c52f5cbed5787068622e7a82761a74`
- `capture-check.py`: `4ac62e9607a02fa91076e3cbe8ab4cb40b2bb13bd746cdf7bcf50979b327c59e`

## Focused sealing RED

```text
SEAL_RACE late_transition append refused; evidence preserved; finish incomplete
SEAL_RACE after_append prefix refused; evidence preserved; finish incomplete
SEAL_RACE late_transition prefix refused; evidence preserved; finish incomplete
test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) ... 
  test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) (stage='after_append') ... FAIL
  test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) (stage='after_prefix') ... FAIL
  test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) (stage='after_archives') ... FAIL
test_rotation_seal_rejects_late_prefix_mutation (__main__.CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation) ... 
  test_rotation_seal_rejects_late_prefix_mutation (__main__.CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation) (stage='after_prefix') ... FAIL
  test_rotation_seal_rejects_late_prefix_mutation (__main__.CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation) (stage='after_archives') ... FAIL

======================================================================
FAIL: test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) (stage='after_append')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 122, in test_rotation_seal_rejects_late_append
    with self.subTest(stage=stage):self.sealing_race(stage,'append')
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 111, in sealing_race
    self.assertFalse(complete,f'{stage}/{change}: an unchecked outgoing change was sealed and finish certified integrity')
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: True is not false : after_append/append: an unchecked outgoing change was sealed and finish certified integrity

======================================================================
FAIL: test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) (stage='after_prefix')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 122, in test_rotation_seal_rejects_late_append
    with self.subTest(stage=stage):self.sealing_race(stage,'append')
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 111, in sealing_race
    self.assertFalse(complete,f'{stage}/{change}: an unchecked outgoing change was sealed and finish certified integrity')
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: True is not false : after_prefix/append: an unchecked outgoing change was sealed and finish certified integrity

======================================================================
FAIL: test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) (stage='after_archives')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 122, in test_rotation_seal_rejects_late_append
    with self.subTest(stage=stage):self.sealing_race(stage,'append')
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 111, in sealing_race
    self.assertFalse(complete,f'{stage}/{change}: an unchecked outgoing change was sealed and finish certified integrity')
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: True is not false : after_archives/append: an unchecked outgoing change was sealed and finish certified integrity

======================================================================
FAIL: test_rotation_seal_rejects_late_prefix_mutation (__main__.CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation) (stage='after_prefix')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 125, in test_rotation_seal_rejects_late_prefix_mutation
    with self.subTest(stage=stage):self.sealing_race(stage,'prefix')
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 111, in sealing_race
    self.assertFalse(complete,f'{stage}/{change}: an unchecked outgoing change was sealed and finish certified integrity')
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: True is not false : after_prefix/prefix: an unchecked outgoing change was sealed and finish certified integrity

======================================================================
FAIL: test_rotation_seal_rejects_late_prefix_mutation (__main__.CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation) (stage='after_archives')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 125, in test_rotation_seal_rejects_late_prefix_mutation
    with self.subTest(stage=stage):self.sealing_race(stage,'prefix')
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 111, in sealing_race
    self.assertFalse(complete,f'{stage}/{change}: an unchecked outgoing change was sealed and finish certified integrity')
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: True is not false : after_archives/prefix: an unchecked outgoing change was sealed and finish certified integrity

----------------------------------------------------------------------
Ran 2 tests in 0.136s

FAILED (failures=5)
```

## Focused sealing GREEN

```text
SEAL_RACE after_append append refused; evidence preserved; finish incomplete
SEAL_RACE after_prefix append refused; evidence preserved; finish incomplete
SEAL_RACE after_archives append refused; evidence preserved; finish incomplete
SEAL_RACE late_transition append refused; evidence preserved; finish incomplete
SEAL_RACE after_append prefix refused; evidence preserved; finish incomplete
SEAL_RACE after_prefix prefix refused; evidence preserved; finish incomplete
SEAL_RACE after_archives prefix refused; evidence preserved; finish incomplete
SEAL_RACE late_transition prefix refused; evidence preserved; finish incomplete
test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) ... ok
test_rotation_seal_rejects_late_prefix_mutation (__main__.CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation) ... ok

----------------------------------------------------------------------
Ran 2 tests in 0.106s

OK
```

## Collector covering GREEN

```text
READ_METER source_bytes=7 sealed_archive_bytes=0
SEAL_RACE after_append append refused; evidence preserved; finish incomplete
SEAL_RACE after_prefix append refused; evidence preserved; finish incomplete
SEAL_RACE after_archives append refused; evidence preserved; finish incomplete
SEAL_RACE late_transition append refused; evidence preserved; finish incomplete
SEAL_RACE after_append prefix refused; evidence preserved; finish incomplete
SEAL_RACE after_prefix prefix refused; evidence preserved; finish incomplete
SEAL_RACE after_archives prefix refused; evidence preserved; finish incomplete
SEAL_RACE late_transition prefix refused; evidence preserved; finish incomplete
test_append_failure (__main__.CaptureCheck.test_append_failure) ... ok
test_archive_mutation_during_checkpoint (__main__.CaptureCheck.test_archive_mutation_during_checkpoint) ... ok
test_boolean_generation_refusal (__main__.CaptureCheck.test_boolean_generation_refusal) ... ok
test_generation_refusal (__main__.CaptureCheck.test_generation_refusal) ... ok
test_incremental_after_rotation (__main__.CaptureCheck.test_incremental_after_rotation) ... ok
test_interrupted_append_reopen (__main__.CaptureCheck.test_interrupted_append_reopen) ... ok
test_missing_archive (__main__.CaptureCheck.test_missing_archive) ... ok
test_prefix_mutation_and_regrown_copytruncate (__main__.CaptureCheck.test_prefix_mutation_and_regrown_copytruncate) ... ok
test_reopen_validates_once (__main__.CaptureCheck.test_reopen_validates_once) ... ok
test_rotation_seal_rejects_late_append (__main__.CaptureCheck.test_rotation_seal_rejects_late_append) ... ok
test_rotation_seal_rejects_late_prefix_mutation (__main__.CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation) ... ok
test_same_size_prefix_mutation (__main__.CaptureCheck.test_same_size_prefix_mutation) ... ok
test_sealed_archive_mutation_and_missing (__main__.CaptureCheck.test_sealed_archive_mutation_and_missing) ... ok
test_second_rotation_refusal (__main__.CaptureCheck.test_second_rotation_refusal) ... ok
test_source_changes_during_read (__main__.CaptureCheck.test_source_changes_during_read) ... ok
test_truncation (__main__.CaptureCheck.test_truncation) ... ok

----------------------------------------------------------------------
Ran 16 tests in 0.272s

OK
```

## Inherited covering GREEN

```text
PASS log calibration: first activation offset, rename rotation, exact bytes/order, repeat no duplicates, missing inode/copytruncate refusal, portable preserves every measurement payload byte
PASS reuse/integrity calibration: deterministic A to B to A, unique ordered generations, repeat exact; corrupted/missing archive, changed source prefix and invalid generation refuse before archive/manifest writes
PASS persistent owner: exclusive activation offset, incremental append/idempotence, finish integrity only
PASS persistent A to B to A: all ordered bytes retained without reopening the collector
```
