Task1 corrective round1, scoped solely to Important I1 rotation sealing race.
Full fixed code is code/. reviewed-to-fix.diff is the exact reviewed original-to-fix
textual delta; preserved-to-fix.diff includes the complete original collector change.
SHA256SUMS inventories every payload; reviewed/fixed code inventories permit exact
private-source matching. The original attachment remains byte-identical and is not
replaced. No private original logs or model/describe values are included.

Focused calibration:
python3 code/capture-check.py CaptureCheck.test_rotation_seal_rejects_late_append CaptureCheck.test_rotation_seal_rejects_late_prefix_mutation
Covering calibration:
python3 code/capture-check.py CaptureCheck
python3 code/log-check.py

RED: five of eight deterministic late outgoing source changes sealed unchecked and
then finish certified integrity=true on reviewed code. GREEN: all eight refuse,
preserve outgoing captured/source bytes, latch capture failure and forbid finish.
The fix anchors sealing to the source snapshot validated while consuming bytes;
requires exact captured end; checks after prefix/archive validation; holds the outgoing
source descriptor through the new-generation transition; checks descriptor/path against
that same anchor before closing. No late snapshot is absorbed as validated evidence.

Sixteen CaptureCheck tests and original/persistent log calibration groups are green.
Lifecycle code and log-check.py are unchanged; no tmux/lifecycle smoke repeated in this
round. No package/production source changed; no package suite repeated. M1/M2 are
controller-deferred minor findings and intentionally outside this corrective scope.
Integrity only: Task2/controller still owns panel/protocol settlement. All original
live/rehearsal/time/cadence gates remain. No live/desktop/host/external action occurred.
