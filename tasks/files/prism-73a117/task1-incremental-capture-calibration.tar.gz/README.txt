Task 1 incremental capture foundation (synthetic calibration only)

Portable code is in code/; collector.diff contains every code change from the
validated preserved inputs and full new files. SHA256SUMS covers every payload.
No private model/describe values, owner logs or preserved raw originals are included.
Measurement-payload-equality.json is an exact byte proof over a fresh synthetic
schema2 nonce. Smoke JSON files contain synthetic data and redacted temporary paths.

Run private scripts through their interpreters:
python3 code/capture-check.py
python3 code/log-check.py

Create each run directory exclusively at CAPTURE_ROOT/runs/<unique-run-id>/,
mode0700, files0600, then write RUN.json there. Required schema2 fields:
schema=2, runId, socket=prism-budget-capture-<fresh-nonce>, log (explicit path),
manifest, deadlineSeconds (live2100 or synthetic2700), pollSeconds<=2,
maxGapSeconds<=10 and >=pollSeconds, clockOrigin (host monotonic clock identity),
environment (live|synthetic), control, receipt, heartbeat, polls, identities.
All six output/control paths are distinct absolute paths within the RUN directory.
The controller must tighten poll/gap bounds to the measured fill-time rule.

bash code/capture-wrapper.sh <absolute RUN.json>
starts a short launcher; exit0 means launched, not complete. The Python wrapper /
deadline owner lives inside the isolated named tmux capture pane. The collector is
its recorded child, and no interpreter starts per poll. The empty config and
exit-unattached off / exit-empty on / remain-on-exit off are tested. Linux PID,
startTicks and bootId identities qualify cleanup. No default server change occurs.

Atomically replace control with {"sequence":1,"command":"ready"}, increasing
sequence exactly once each new command. Ready checkpoints integrity only. A
replacement replaying identical bytes is refused. Finish requires controller
confirmation of Task2's cardSettled and operation-qualified drain first; it then
polls, fully checkpoints, exits and reaps. Stop and any failure/signal yield incomplete.
An unchanged consumed command file may remain in place between polls.

Wait for terminal receipt.exitReason rather than the short launcher's exit.
Only integrityComplete=true in the final wrapper receipt certifies captured byte
integrity. protocolComplete is deliberately absent and belongs to Task2/controller.
The manifest keeps integrityComplete=false; its digests and cursors are durable
byte evidence, not a separately trusted completion flag. The initial receipt is
incomplete, so an unexpected wrapper death cannot imply completion.

logs.Capture.poll() only reads new source bytes; rotation seals outgoing ranges
through full validation. checkpoint(reason) hashes every archive and the current
captured source prefix, then checks archive metadata again. It returns integrity
complete only for finish. logs.collect remains a deliberate one-shot offline
validation. Reopening verifies every saved byte once and restores its incremental
hash; a run activation refuses any prior manifest instead of resuming.

Limits: concurrent source mutation during a descriptor read is conservatively
refused; files are preserved for investigation. Metadata checks on ordinary polls
are followed by full digest/source checks at explicit checkpoints. SIGKILL/power
loss cannot run a finalizer; the initial incomplete receipt remains authoritative.
Only seconds-long synthetic smokes ran. No live IPC, desktop or host pointers used.
