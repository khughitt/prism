"""Synthetic capture calibration; removing incremental reads or refusals must fail."""
import importlib.util
import json
import os
import signal
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
import logs

CODE=Path(__file__).parent
class Meter:
    def __init__(self,log,sealed): self.log,self.sealed=log,sealed;self.reset()
    def reset(self): self.source_bytes=self.sealed_archive_bytes=0
    def open(self,path,*args,**kwargs):
        f=self.real_open(path,*args,**kwargs);meter=self
        class Handle:
            def __getattr__(self,k): return getattr(f,k)
            def __enter__(self): return self
            def __exit__(self,*args): return f.__exit__(*args)
            def read(self,*args):
                b=f.read(*args)
                if path.name.startswith(meter.log.name): meter.source_bytes+=len(b)
                if path in meter.sealed: meter.sealed_archive_bytes+=len(b)
                return b
        return Handle()

class CaptureCheck(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='prism-capture-check-');self.root=Path(self.tmp.name);self.log=self.root/'synthetic.log';self.manifest=self.root/'manifest.json';self.log.write_bytes(b'ignored\n');logs.start(self.log,self.manifest)
    def tearDown(self):
        if hasattr(self,'c'):self.c.close()
        self.tmp.cleanup()
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
    def append(self,b):
        with self.log.open('ab') as f:f.write(b)
    def evidence(self):return {p.name:p.read_bytes() for p in self.root.iterdir() if p.name.startswith(('manifest','segment'))}
    def refusal(self,fn):
        before=self.evidence()
        with self.assertRaises((AssertionError,ValueError,OSError)):fn()
        self.assertEqual(self.evidence(),before,'refusal must not repair evidence')
        self.assertFalse(self.c.integrity_complete)
    def test_incremental_after_rotation(self):
        meter=Meter(self.log,set());meter.real_open=Path.open
        with patch.object(Path,'open',lambda path,*args,**kwargs:meter.open(path,*args,**kwargs)):
            c=self.capture();self.append(b'first\n');c.poll();self.log.rename(self.log.with_name(self.log.name+'.1'));self.log.write_bytes(b'');paths=c.poll();meter.sealed=set(paths[:-1]);meter.reset()
            self.append(b'second\n');c.poll()
        self.assertEqual(meter.source_bytes,7);self.assertEqual(meter.sealed_archive_bytes,0)
        self.assertEqual(b''.join(p.read_bytes() for p in c.poll()),b'first\nsecond\n');self.assertTrue(c.checkpoint('finish')['integrityComplete']);print('READ_METER source_bytes=7 sealed_archive_bytes=0')
    def test_prefix_mutation_and_regrown_copytruncate(self):
        c=self.capture();self.append(b'first\n');c.poll();self.log.write_bytes(b'ignored\nBROKEN\nlonger\n');c.poll();self.refusal(lambda:c.checkpoint('finish'))
    def test_same_size_prefix_mutation(self):
        c=self.capture();self.append(b'first\n');c.poll();self.log.write_bytes(b'ignored\nxxxxx\n');self.refusal(lambda:c.checkpoint('finish'))
    def test_truncation(self):
        c=self.capture();self.append(b'first\n');c.poll();self.log.write_bytes(b'');self.refusal(c.poll)
    def test_sealed_archive_mutation_and_missing(self):
        c=self.capture();self.append(b'first\n');old=c.poll()[0];self.log.rename(self.log.with_name(self.log.name+'.1'));self.log.write_bytes(b'second\n');c.poll();old.write_bytes(b'xxxxxx');self.refusal(lambda:c.checkpoint('finish'))
    def test_archive_mutation_during_checkpoint(self):
        c=self.capture();self.append(b'first\n');archive=c.poll()[0];manifest=self.manifest.read_bytes();read=c.source.read
        def mutate(*args):
            b=read(*args);archive.write_bytes(b'xxxxxx');return b
        with patch.object(c.source,'read',mutate):
            with self.assertRaises((AssertionError,ValueError,OSError)):c.checkpoint('finish')
        self.assertEqual(self.manifest.read_bytes(),manifest);self.assertEqual(archive.read_bytes(),b'xxxxxx');self.assertFalse(c.integrity_complete)
    def test_missing_archive(self):
        c=self.capture();self.append(b'first\n');p=c.poll()[0];p.unlink();self.refusal(lambda:c.checkpoint('finish'))
    def test_interrupted_append_reopen(self):
        c=self.capture();self.append(b'first\n');p=c.poll()[0];c.close()
        with p.open('ab') as f:f.write(b'unpublished')
        self.refusal(lambda:logs.Capture(self.manifest))
    def test_generation_refusal(self):
        c=self.capture();self.append(b'first\n');c.poll();c.close();s=json.loads(self.manifest.read_text());s['segments'][0]['generation']=2;self.manifest.write_text(json.dumps(s));self.refusal(lambda:logs.Capture(self.manifest))
    def test_boolean_generation_refusal(self):
        c=self.capture();self.append(b'first\n');c.poll();c.close();s=json.loads(self.manifest.read_text());s['current']['generation']=True;self.manifest.write_text(json.dumps(s));self.refusal(lambda:logs.Capture(self.manifest))
    def test_source_changes_during_read(self):
        c=self.capture();self.append(b'first\n');original=c.source.read
        def changed(*args):
            b=original(*args);self.append(b'racing\n');return b
        with patch.object(c.source,'read',changed):self.refusal(c.poll)
    def test_second_rotation_refusal(self):
        c=self.capture();self.append(b'first\n');c.poll();self.log.rename(self.log.with_name(self.log.name+'.2'));self.log.write_bytes(b'third\n');self.refusal(c.poll)
    def test_append_failure(self):
        c=self.capture();self.append(b'first\n');c.poll();self.append(b'second\n')
        with patch.object(logs,'save',side_effect=OSError('injected publish failure')):
            with self.assertRaises(OSError):c.poll()
        self.assertFalse(c.integrity_complete);c.close();self.refusal(lambda:logs.Capture(self.manifest))
    def test_reopen_validates_once(self):
        c=self.capture();self.append(b'first\n');paths=c.poll();c.close();meter=Meter(self.log,set(paths));meter.real_open=Path.open
        with patch.object(Path,'open',lambda path,*args,**kwargs:meter.open(path,*args,**kwargs)):c=self.capture()
        self.assertEqual(meter.sealed_archive_bytes,6,'reopen must read each saved byte once to validate and restore its hash')
        self.append(b'second\n');c.poll();self.assertEqual(b''.join(p.read_bytes() for p in c.poll()),b'first\nsecond\n');self.assertTrue(c.checkpoint('finish')['integrityComplete'])

class LifecycleCheck(unittest.TestCase):
    def module(self):
        spec=importlib.util.spec_from_file_location('capture',CODE/'capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
    def test_live_deadline_injected_clock(self):
        m=self.module();self.assertTrue(m.expired(2100,0,lambda:2100));self.assertFalse(m.expired(2100,0,lambda:2099.9))
    def test_command_replay_unknown(self):
        m=self.module()
        for command,last in [({'sequence':1,'command':'ready'},1),({'sequence':3,'command':'ready'},1),({'sequence':2,'command':'bogus'},1),({'sequence':True,'command':'ready'},0)]:
            with self.assertRaises((AssertionError,ValueError)):m.command(command,last)
        self.assertEqual(m.command({'sequence':2,'command':'finish'},1),'finish')
    def inprocess(self,advance,environment='synthetic',control=None,poll_advance=0,replay=False):
        m=self.module()
        with tempfile.TemporaryDirectory(prefix='prism-clock-check-') as td:
            r=Path(td);log=r/'synthetic.log';log.write_bytes(b'old\n');cfg={'schema':2,'runId':'clock-check','socket':'prism-budget-capture-clock-check','log':str(log),'manifest':str(r/'manifest.json'),'deadlineSeconds':2100 if environment=='live' else 2700,'pollSeconds':.05,'maxGapSeconds':10,'clockOrigin':'linux-monotonic','environment':environment}
            cfg.update({k:str(r/(k+'.json' if k!='polls' else k+'.jsonl')) for k in ('control','receipt','heartbeat','polls','identities')});rp=r/'RUN.json';rp.write_text(json.dumps(cfg));(r/'wrapper-ready.json').write_text('{}');(r/'identities.json').write_text(json.dumps({'wrapper':m.process(os.getpid())}))
            if control:(r/'control.json').write_text(json.dumps(control))
            now=[time.monotonic()]
            sleeps=[0]
            def sleep(seconds):
                now[0]+=advance;sleeps[0]+=1
                if replay:
                    d=control if sleeps[0]==1 else {'sequence':2,'command':'stop'}
                    temp=r/'control.tmp';temp.write_text(json.dumps(d));temp.replace(r/'control.json')
            real_poll=m.logs.Capture.poll
            def timed_poll(c):
                result=real_poll(c);now[0]+=poll_advance;return result
            traps={sig:signal.getsignal(sig) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
            try:
                with patch.object(m.time,'monotonic',lambda:now[0]),patch.object(m.time,'sleep',sleep),patch.object(m.logs.Capture,'poll',timed_poll):
                    code=m.run_collector(rp)
            finally:
                for sig,handler in traps.items():signal.signal(sig,handler)
            receipt=json.loads((r/'collector-receipt.json').read_text());self.assertEqual(code,1);self.assertFalse(receipt['integrityComplete']);self.assertFalse(json.loads((r/'manifest.json').read_text())['integrityComplete']);self.assertTrue((r/'polls.jsonl').read_text().strip());return receipt
    def test_deadline_receipt_injected_clock(self):
        self.assertEqual(self.inprocess(2100,'live')['exitReason'],'deadline')
    def test_gap_receipt_injected_clock(self):
        receipt=self.inprocess(11);self.assertEqual(receipt['exitReason'],'failure');self.assertIn('poll gap',receipt['error'])
    def test_start_to_start_gap_includes_work(self):
        self.assertIn('poll gap',self.inprocess(2,poll_advance=9)['error'])
    def test_identical_atomic_command_replay_refuses(self):
        receipt=self.inprocess(1,control={'sequence':1,'command':'ready'},replay=True)
        self.assertIn('sequence',receipt['error'] or '')
    def test_unknown_control_receipt(self):
        self.assertEqual(self.inprocess(0,control={'sequence':1,'command':'unknown'})['exitReason'],'failure')
    def wait(self,p,check,seconds=8):
        deadline=time.monotonic()+seconds
        while time.monotonic()<deadline:
            if p.exists():
                try:
                    d=json.loads(p.read_text())
                    if check(d):return d
                except json.JSONDecodeError:pass
            time.sleep(.025)
        self.fail('receipt not reached: '+str(p))
    def smoke(self,mode):
        with tempfile.TemporaryDirectory(prefix='prism-capture-smoke-') as td:
            r=Path(td);log=r/'synthetic.log';log.write_bytes(b'old\n');socket='prism-budget-capture-'+str(os.getpid())+'-'+mode+'-'+str(time.monotonic_ns());run={'schema':2,'runId':socket,'socket':socket,'log':str(log),'manifest':str(r/'manifest.json'),'deadlineSeconds':2700,'pollSeconds':.05,'maxGapSeconds':2,'clockOrigin':'linux-monotonic','environment':'synthetic','control':str(r/'control.json'),'receipt':str(r/'receipt.json'),'heartbeat':str(r/'heartbeat.json'),'polls':str(r/'polls.jsonl'),'identities':str(r/'identities.json')};rp=r/'RUN.json';rp.write_text(json.dumps(run));p=subprocess.Popen(['bash',str(CODE/'capture-wrapper.sh'),str(rp)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            default=Path(os.environ.get('TMUX_TMPDIR','/tmp'))/f'tmux-{os.getuid()}'/'default'
            def default_snapshot():
                if not default.exists():return None
                st=default.stat();return (st.st_dev,st.st_ino,st.st_mtime_ns,st.st_ctime_ns,subprocess.check_output(['tmux','-L','default','list-sessions'],text=True))
            default_before=default_snapshot()
            producer=None
            try:
                hb=self.wait(r/'heartbeat.json',lambda d:d.get('collectorStarted') is not None)
                ids=json.loads((r/'identities.json').read_text());self.assertNotEqual(ids['wrapper']['pid'],p.pid,'deadline wrapper must live inside named tmux, never the launcher exec')
                self.assertEqual(int(subprocess.check_output(['tmux','-L',socket,'display-message','-p','-t','capture:0','#{pane_pid}'],text=True)),ids['wrapper']['pid'])
                opts=subprocess.check_output(['tmux','-L',socket,'show-options','-s'],text=True);self.assertIn('exit-unattached off',opts);self.assertIn('exit-empty on',opts)
                self.assertEqual(subprocess.check_output(['tmux','-L',socket,'show-options','-gv','remain-on-exit'],text=True).strip(),'off')
                producer_script=r/'producer.py'
                producer_script.write_text("import json,os,sys,time\nfrom pathlib import Path\nimport capture\nPath(sys.argv[1]).write_text(json.dumps(capture.process(os.getpid())))\ntime.sleep(10)\n")
                import shlex
                invocation=shlex.join(['env','PYTHONPATH='+str(CODE),'python3',str(producer_script),str(r/'producer.json')])
                subprocess.run(['tmux','-L',socket,'new-window','-d','-t','capture','-n','producer',invocation],check=True)
                producer=self.wait(r/'producer.json',lambda d:True)
                # The same socket/run must refuse, preserving the active server and receipt.
                before=(r/'receipt.json').read_bytes()
                duplicate=subprocess.run(['bash',str(CODE/'capture-wrapper.sh'),str(rp)],capture_output=True)
                self.assertNotEqual(duplicate.returncode,0);self.assertEqual((r/'receipt.json').read_bytes(),before);self.assertTrue(self.module().same_process(ids['server']))
                with log.open('ab') as f:f.write(b'startup\nfinal\n')
                if mode=='kill':subprocess.run(['tmux','-L',socket,'kill-server'],check=True)
                elif mode in ('signal','interrupt','hangup'):os.kill(ids['wrapper']['pid'],{'signal':signal.SIGTERM,'interrupt':signal.SIGINT,'hangup':signal.SIGHUP}[mode])
                else:
                    control={'sequence':1,'command':'ready'};(r/'control.tmp').write_text(json.dumps(control));(r/'control.tmp').replace(r/'control.json');self.wait(r/'heartbeat.json',lambda d:d.get('lastSequence')==1)
                    control={'sequence':2,'command':mode};(r/'control.tmp').write_text(json.dumps(control));(r/'control.tmp').replace(r/'control.json')
                out,err=p.communicate(timeout=8);receipt=self.wait(r/'receipt.json',lambda d:d.get('exitReason')!='starting');
                deadline=time.monotonic()+3;m=self.module()
                while any(m.same_process(i) for i in json.loads((r/'identities.json').read_text()).values()) and time.monotonic()<deadline:time.sleep(.01)
                self.assertEqual(receipt['integrityComplete'],mode=='finish',(receipt,out,err));self.assertNotIn('protocolComplete',receipt)
                identities=json.loads((r/'identities.json').read_text());m=self.module()
                for role,identity in identities.items():self.assertFalse(m.same_process(identity),(role,identity))
                self.assertFalse(m.same_process(producer),'synthetic producer must be gone')
                self.assertEqual(default_snapshot(),default_before,'default tmux server changed')
                self.assertNotEqual(subprocess.run(['tmux','-L',socket,'has-session'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode,0)
                if mode=='finish':
                    state=json.loads((r/'manifest.json').read_text());self.assertEqual(b''.join((r/s['path']).read_bytes() for s in state['segments']),b'startup\nfinal\n')
                intervals=[json.loads(l) for l in (r/'polls.jsonl').read_text().splitlines()];self.assertTrue(intervals);self.assertTrue(all(x['end']>=x['start'] for x in intervals));print('SMOKE',mode,'exit',p.returncode,'integrityComplete',receipt['integrityComplete'],'identities reaped')
                if os.environ.get('CAPTURE_CHECK_PROOFS'):
                    dest=Path(os.environ['CAPTURE_CHECK_PROOFS'])/mode;dest.mkdir(mode=0o700,parents=True,exist_ok=True)
                    for name in ('RUN.json','manifest.json','receipt.json','heartbeat.json','identities.json','collector-receipt.json','polls.jsonl','producer.json'):
                        source=r/name
                        if source.exists():
                            target=dest/name;target.write_text(source.read_text().replace(str(r),'<synthetic-run>'));target.chmod(0o600)
                    (dest/'cleanup.json').write_text(json.dumps({'defaultServerUnchanged':True,'recordedProcessesGone':True,'syntheticProducerGone':True,'namedSocketGone':True,'launcherExited':True})+'\n')
            finally:
                subprocess.run(['tmux','-L',socket,'kill-server'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                if p.poll() is None:p.terminate();p.communicate(timeout=8)
    def test_finish_smoke(self):self.smoke('finish')
    def test_stop_smoke(self):self.smoke('stop')
    def test_kill_server_smoke(self):self.smoke('kill')
    def test_signal_smoke(self):self.smoke('signal')
    def test_interrupt_smoke(self):self.smoke('interrupt')
    def test_hangup_smoke(self):self.smoke('hangup')

if __name__=='__main__':unittest.main(verbosity=2)
