# Task 1 implementer report

Status: implemented; independent root review remains. Task prism-73a117.
Authoritative worktree: .worktrees/panel-budget.
PLAN_BASE: 3768ebce5e23e937e7c0d9e2472d5a1e0488e8c2.
Controller supplied green baseline574 plus Lua; unchanged package suite not repeated
per the binding brief. No production source changes. Trial-arm exit0: not enrolled.

## Inputs / private source

CAPTURE_ROOT: CAPTURE_ROOT
PRESERVED: PRESERVED
Private task sources: CAPTURE_ROOT/code/{logs.py,log-check.py,capture.py,capture-wrapper.sh,capture-check.py}.
All19 selected inputs validated against sibling preserved manifest before copying;
originals rehashed unchanged after implementation. Private directories0700/files0600.
Model/describe fixtures validated83 params /12 devices /23 profiles. Frozen-task2 and
unchanged state/rotation scripts copied privately for subsequent tasks, not modified.
All12 baseline/candidate source hashes verified against git blobs, and all6 current
production source hashes match frozen candidate. Baseline9bf4e8e920c005f8a4d1666b32b4e1a516856ac2;
candidate e7384b0d7ab3e8e935cdf0776043839441132af5. JSON hash proofs included.

## Changes

logs.start keeps exclusive initial offset/generation creation and adds schema2.
Capture owns source/archive descriptors, incremental hash and validated cursor.
Ordinary polls read only delta bytes; archive metadata, source identity/size and
both descriptor snapshots protect append. Generation archive naming is exactly
segment-{generation:06d}-{dev}-{inode}.raw. Rotation validates outgoing ranges before
sealing, and ambiguous/multiple rotations refuse with evidence preserved. A→B→A
reuse retains ordered bytes in distinct archives with one persistent collector.

Explicit checkpoints ready/rotation/settled/finish fully hash every archive and the
current captured source prefix, rechecking archive metadata afterward. Failure never
repairs evidence. Offline reopen validates every saved archive byte once and restores
its hash; actual run activations refuse a prior manifest instead of resuming it.
The manifest completion flag stays false; completion authority is the terminal receipt.

Atomic command files require increasing integer sequences, exactly last+1, and
ready/finish/stop. Metadata versions detect identical-byte atomic replay. Unchanged
consumed files may remain. Ready requests integrity checkpoint only; finish checkpoints
and exits cleanly; stop is incomplete. Task1 never parses operation IDs or certifies
panel settlement. Controller must establish Task2 cardSettled and operation-qualified
drain before finish. protocolComplete is deliberately absent from receipts.

Durable JSONL intervals record runId/start/end/clockOrigin/bytes/checkpoint/error.
Gaps are start-to-start (including previous work), and excessive work duration also
refuses. Rotation checkpoints are identified. Wrapper/collector deadlines use host
monotonic collectorStarted: live2100 or synthetic2700, with no extra environment flag.

Shell entrypoint execs a SHORT launcher which exits after server start. Python wrapper /
deadline owner lives INSIDE the isolated named tmux capture pane, and launches its
one collector child there. There is no long-lived yielded exec owner and no per-poll
interpreter. Empty tmux config, exit-unattached off, exit-empty on, remain-on-exit off.
Root accepted Python TERM/INT/HUP handlers and EXIT-equivalent finally ownership in
place of delayed foreground shell traps. Cleanup uses recorded PID/startTicks/bootId
and only the recorded named socket. Initial receipt is incomplete. Finish requires
successful checkpoint plus clean collector exit before wrapper certifies integrity.
A short bounded exit grace resolves the receipt-before-exit race. Stop, deadline,
gaps, signals, named kill-server and unexpected exit cannot certify integrity.

## RED→GREEN evidence

Primary RED command: `python3 "$CAPTURE_ROOT/code/capture-check.py"`, exit1.
logs imported successfully; missing logs.Capture is the intended target RED.
The full initial run also had missing lifecycle files and timeout failures; those
are incidental and not accepted as the target RED. Full initial output is below and
in proofs/capture-red-full.log; focused missing-Capture output in capture-red.log.

Additional focused REDs, all exit1, subsequently corrected:

- `python3 "$CAPTURE_ROOT/code/capture-check.py" LifecycleCheck.test_finish_smoke`
  `AssertionError: 1656613 == 1656613 : deadline wrapper must live inside named tmux, never the launcher exec`
- `python3 "$CAPTURE_ROOT/code/capture-check.py" LifecycleCheck.test_deadline_receipt_injected_clock`
  `AssertionError: 'failure' != 'deadline'` (bound real clock replaced by runtime injectable clock).
- `python3 "$CAPTURE_ROOT/code/capture-check.py" CaptureCheck.test_boolean_generation_refusal`
  `AssertionError: (<class 'AssertionError'>, <class 'ValueError'>, <class 'OSError'>) not raised`
- `python3 "$CAPTURE_ROOT/code/capture-check.py" CaptureCheck.test_reopen_validates_once`
  `AssertionError: 12 != 6 : reopen must read each saved byte once to validate and restore its hash`
- `python3 "$CAPTURE_ROOT/code/capture-check.py" LifecycleCheck.test_start_to_start_gap_includes_work`
  `AssertionError: 'poll gap' not found in 'collector deadline expired during work'`
- `python3 "$CAPTURE_ROOT/code/capture-check.py" LifecycleCheck.test_identical_atomic_command_replay_refuses`
  `AssertionError: 'sequence' not found in ''`
- `python3 "$CAPTURE_ROOT/code/capture-check.py" CaptureCheck.test_archive_mutation_during_checkpoint`
  `AssertionError: (<class 'AssertionError'>, <class 'ValueError'>, <class 'OSError'>) not raised`

An intermediate full run exposed finish receipt integrity=false despite exitReason=finish:
wrapper terminated the collector between receipt publication and process exit. A
bounded successful-exit wait fixed it. Source/descriptor races also have refusal checks.

Final GREEN (exit0):
`CAPTURE_CHECK_PROOFS="$CAPTURE_ROOT/proofs/smokes" python3 "$CAPTURE_ROOT/code/capture-check.py"`
`python3 "$CAPTURE_ROOT/code/log-check.py"`
27 capture checks plus original and persistent log calibrations, including A→B→A.
Read meter: steady post-rotation poll7 new source bytes /0 sealed archive bytes;
offline reopen6/6 saved archive bytes exactly once. Full GREEN output below.

Six seconds-long tmux smokes: ready→finish, ready→stop, kill-server, TERM, INT, HUP.
Each checks effective options, wrapper equals capture pane PID and differs from short
launcher PID, duplicate socket refusal without disturbing active evidence, default
server snapshot unchanged, no live matching wrapper/collector/server/synthetic producer,
and no named socket. Each owns cleanup in finally. Durable synthetic JSON receipts,
polls and identity/cleanup records are included in proofs/smokes (paths redacted).
Launcher exit0 means launch only; final receipt supplies integrity verdict.
Injected monotonic tests exercise live2100 expiry, idle gaps and work-inclusive gaps;
unknown/replayed commands produce incomplete receipts. No35-minute sleep was used.

Repository gates `just check`, `tasks check`, `git diff --check`: exit0, empty output.
Task warnings: none. All tests/checks/processes finished. host-load --section session,
exit0: `session kitty-2680783-0.scope: nothing left running`.

## Self-review and limits

I checked every brief requirement against final code/calibrations and corrected the
redundant reopen read, late checkpoint archive race, start-to-start gap, identical
command replay and successful collector-exit race. No remaining Critical/Important
issue is known; independent root review remains authoritative. No subagent was spawned.

Ordinary polls rely on metadata; full digest/source-prefix verification is explicit
at checkpoints/seals. Concurrent source mutation during a descriptor read is
conservatively refused, so busy write races may invalidate an activation. Evidence
is preserved. SIGKILL/power loss cannot run a finalizer; initial incomplete receipt
prevents completion claims. No real Noctalia IPC, desktop, plugin pointer, owner
slider/profile action, host timer/profile change, long rehearsal or external write.
Live cadence still needs later preflight tightening to poll<=min(2,T/4), gap<=min(10,T/2).
Capture integrity does not imply protocol settlement, correctness or performance acceptance.

## Portable archive / handoff

Attachment: tasks/files/prism-73a117/task1-incremental-capture-calibration.tar.gz.
Contains code/, full collector.diff, synthetic calibration receipts/output/cleanup,
README, portable report, SHA256 inventory and fresh synthetic measurement-payload
byte equality proof. No private model/describe values or raw owner originals included.
The reader verifies every inventoried payload and exact archive/private code equality.
Private copies remain at CAPTURE_ROOT for review. Root owns review/disposition/closure.
Worker parks waiting on agent naming root review and .worktrees/panel-budget, never
closes this child task or changes root claims. Nothing remains running.

## Input SHA256 inventory

- `describe-private.json`: `ac722d2bb45c65038656d8d299f3a2e464b68d9973d3fd62ea90d96d46399b7d`
- `frozen-task2/analysis_check.py`: `f7c83cb63094f891265375188d09288b34fad2b05374df5637dd5adac0fb5cac`
- `frozen-task2/analyze.py`: `f99987fdea96a1cd6c2f6feed138a65093c3c2bdeccb89acc780b8e1cbde7f14`
- `frozen-task2/baseline-identity.json`: `6e84411f79b3b715e0dad581cf8f056fa17997d35c25b1603e2554f39a776ca2`
- `frozen-task2/build.py`: `5139c64228eb02d6a687cd82d16c23ee6c2427c0c284087e2bc9fb838b0fd74c`
- `frozen-task2/integrity-check.py`: `0120c6212248d2e87c8c220b48e2aa7c152ed190b0d256bf7ae02eb4f1920091`
- `frozen-task2/pilot-fixture.json`: `276964c4203f7178630929c326506a863d65d79c46a586c73ae6228bba4ea845`
- `frozen-task2/probe.lua`: `1d7143bc705517f417bece76a211e70128f97f09bcaf8291b0073e10a9f4a099`
- `frozen-task2/self-check.lua`: `067d393069756af6b7491095020b21e7bab3e0eacaa5bea74f8f011b54cd7d07`
- `frozen-task2/tail.lua`: `92521407aa74e883c64542d825baf9a18b3a0cf5d95d3fd20de98041789adcb7`
- `frozen-task2/task-1-candidate-identity.json`: `dd4bb5066bd14dca94c2dda35aa0eec4f48176e23be8ba973622d43092cdd5ad`
- `frozen-task2/test_encode.lua`: `f7ece8eb7f34fd66bf1866ea0781253665a4685946da07814ef074c4886c0123`
- `log-check.py`: `b80e94e089ce28ec14b43619519f0037510c4a0e23f7b1b79c65deae08617876`
- `logs.py`: `4f9914a82a815aa429118d17e50e67ce44d9bc953de22d20ac5af8334fa4341f`
- `model-private.lua`: `d501a317f97cd0c33bb2bd04049badc676116fed423cff0e408e45930775e9f7`
- `rotation-guard-check.py`: `bb15ebe2084cd34b3d027964cb54f8c676873b05bfa16effdc99601a8e697c22`
- `rotation-guard.py`: `9d2460048359d2abb4e96aa1f804b45cb4021cc482ff12d3704369e0b89c8350`
- `state-check.mjs`: `d294a76948f2e7d6af38cffb02f579ec0ed1a437ba5e38482358b9ec36d4fbff`
- `state.mjs`: `98479352a46f6c56524060f6c84335e7d69eff0ff539ac65c4137c7fb46425c9`

## Output code SHA256 inventory

- `logs.py`: `1251eaae2a98f8fbac7cebe132704bcb475b76530b0d3b480e0dc415225dfc13`
- `log-check.py`: `2fd27a21fb8a44c8860b3ae025a442cac0720d36a749491721c8403526422af3`
- `capture.py`: `5e42973c1d65429f81c29d578d373040fd8f008cc11fd80b160613167ad444c9`
- `capture-wrapper.sh`: `3d45f3e6e5edc63080e98b9580bafcbe44c52f5cbed5787068622e7a82761a74`
- `capture-check.py`: `3be40eafcbb01f0c22054d2486690fd3bc0dcbe1109d136a0d8315138bd17503`

## Full primary RED

```text
test_append_failure (__main__.CaptureCheck.test_append_failure) ... ERROR
test_generation_refusal (__main__.CaptureCheck.test_generation_refusal) ... ERROR
test_incremental_after_rotation (__main__.CaptureCheck.test_incremental_after_rotation) ... ERROR
test_interrupted_append_reopen (__main__.CaptureCheck.test_interrupted_append_reopen) ... ERROR
test_missing_archive (__main__.CaptureCheck.test_missing_archive) ... ERROR
test_prefix_mutation_and_regrown_copytruncate (__main__.CaptureCheck.test_prefix_mutation_and_regrown_copytruncate) ... ERROR
test_reopen_validates_once (__main__.CaptureCheck.test_reopen_validates_once) ... ERROR
test_same_size_prefix_mutation (__main__.CaptureCheck.test_same_size_prefix_mutation) ... ERROR
test_sealed_archive_mutation_and_missing (__main__.CaptureCheck.test_sealed_archive_mutation_and_missing) ... ERROR
test_second_rotation_refusal (__main__.CaptureCheck.test_second_rotation_refusal) ... ERROR
test_truncation (__main__.CaptureCheck.test_truncation) ... ERROR
test_command_replay_unknown (__main__.LifecycleCheck.test_command_replay_unknown) ... ERROR
test_finish_smoke (__main__.LifecycleCheck.test_finish_smoke) ... FAIL
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=5>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=3>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
test_kill_server_smoke (__main__.LifecycleCheck.test_kill_server_smoke) ... FAIL
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=5>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=3>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
test_live_deadline_injected_clock (__main__.LifecycleCheck.test_live_deadline_injected_clock) ... ERROR
test_signal_smoke (__main__.LifecycleCheck.test_signal_smoke) ... FAIL
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=5>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=3>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
test_stop_smoke (__main__.LifecycleCheck.test_stop_smoke) ... FAIL
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=5>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.14/unittest/case.py:668: ResourceWarning: unclosed file <_io.BufferedReader name=3>
  with outcome.testPartExecutor(self):
ResourceWarning: Enable tracemalloc to get the object allocation traceback

======================================================================
ERROR: test_append_failure (__main__.CaptureCheck.test_append_failure)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 70, in test_append_failure
    c=self.capture();self.append(b'first\n');c.poll();self.append(b'second\n')
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_generation_refusal (__main__.CaptureCheck.test_generation_refusal)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 66, in test_generation_refusal
    c=self.capture();self.append(b'first\n');c.poll();c.close();s=json.loads(self.manifest.read_text());s['segments'][0]['generation']=2;self.manifest.write_text(json.dumps(s));self.refusal(lambda:logs.Capture(self.manifest))
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_incremental_after_rotation (__main__.CaptureCheck.test_incremental_after_rotation)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 46, in test_incremental_after_rotation
    c=self.capture();self.append(b'first\n');c.poll();self.log.rename(self.log.with_name(self.log.name+'.1'));self.log.write_bytes(b'');paths=c.poll();meter=Meter(self.log,set(paths[:-1]));meter.real_open=Path.open
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_interrupted_append_reopen (__main__.CaptureCheck.test_interrupted_append_reopen)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 62, in test_interrupted_append_reopen
    c=self.capture();self.append(b'first\n');p=c.poll()[0];c.close()
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_missing_archive (__main__.CaptureCheck.test_missing_archive)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 60, in test_missing_archive
    c=self.capture();self.append(b'first\n');p=c.poll()[0];p.unlink();self.refusal(lambda:c.checkpoint('finish'))
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_prefix_mutation_and_regrown_copytruncate (__main__.CaptureCheck.test_prefix_mutation_and_regrown_copytruncate)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 52, in test_prefix_mutation_and_regrown_copytruncate
    c=self.capture();self.append(b'first\n');c.poll();self.log.write_bytes(b'ignored\nBROKEN\nlonger\n');c.poll();self.refusal(lambda:c.checkpoint('finish'))
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_reopen_validates_once (__main__.CaptureCheck.test_reopen_validates_once)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 75, in test_reopen_validates_once
    c=self.capture();self.append(b'first\n');c.poll();c.close();c=self.capture();self.append(b'second\n');c.poll();self.assertEqual(b''.join(p.read_bytes() for p in c.poll()),b'first\nsecond\n');self.assertTrue(c.checkpoint('finish')['integrityComplete'])
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_same_size_prefix_mutation (__main__.CaptureCheck.test_same_size_prefix_mutation)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 54, in test_same_size_prefix_mutation
    c=self.capture();self.append(b'first\n');c.poll();self.log.write_bytes(b'ignored\nxxxxx\n');self.refusal(lambda:c.checkpoint('finish'))
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_sealed_archive_mutation_and_missing (__main__.CaptureCheck.test_sealed_archive_mutation_and_missing)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 58, in test_sealed_archive_mutation_and_missing
    c=self.capture();self.append(b'first\n');old=c.poll()[0];self.log.rename(self.log.with_name(self.log.name+'.1'));self.log.write_bytes(b'second\n');c.poll();old.write_bytes(b'xxxxxx');self.refusal(lambda:c.checkpoint('finish'))
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_second_rotation_refusal (__main__.CaptureCheck.test_second_rotation_refusal)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 68, in test_second_rotation_refusal
    c=self.capture();self.append(b'first\n');c.poll();self.log.rename(self.log.with_name(self.log.name+'.2'));self.log.write_bytes(b'third\n');self.refusal(c.poll)
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_truncation (__main__.CaptureCheck.test_truncation)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 56, in test_truncation
    c=self.capture();self.append(b'first\n');c.poll();self.log.write_bytes(b'');self.refusal(c.poll)
  File "CAPTURE_ROOT/code/capture-check.py", line 36, in capture
    def capture(self):self.c=logs.Capture(self.manifest);return self.c
                             ^^^^^^^^^^^^
AttributeError: module 'logs' has no attribute 'Capture'

======================================================================
ERROR: test_command_replay_unknown (__main__.LifecycleCheck.test_command_replay_unknown)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 83, in test_command_replay_unknown
    m=self.module()
  File "CAPTURE_ROOT/code/capture-check.py", line 79, in module
    spec=importlib.util.spec_from_file_location('capture',CODE/'capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
                                                                                                                     ~~~~~~~~~~~~~~~~~~~~~~~^^^
  File "<frozen importlib._bootstrap_external>", line 759, in exec_module
  File "<frozen importlib._bootstrap_external>", line 896, in get_code
  File "<frozen importlib._bootstrap_external>", line 954, in get_data
FileNotFoundError: [Errno 2] No such file or directory: 'CAPTURE_ROOT/code/capture.py'

======================================================================
ERROR: test_live_deadline_injected_clock (__main__.LifecycleCheck.test_live_deadline_injected_clock)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 81, in test_live_deadline_injected_clock
    m=self.module();self.assertTrue(m.expired(2100,0,lambda:2100));self.assertFalse(m.expired(2100,0,lambda:2099.9))
  File "CAPTURE_ROOT/code/capture-check.py", line 79, in module
    spec=importlib.util.spec_from_file_location('capture',CODE/'capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
                                                                                                                     ~~~~~~~~~~~~~~~~~~~~~~~^^^
  File "<frozen importlib._bootstrap_external>", line 759, in exec_module
  File "<frozen importlib._bootstrap_external>", line 896, in get_code
  File "<frozen importlib._bootstrap_external>", line 954, in get_data
FileNotFoundError: [Errno 2] No such file or directory: 'CAPTURE_ROOT/code/capture.py'

======================================================================
FAIL: test_finish_smoke (__main__.LifecycleCheck.test_finish_smoke)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 119, in test_finish_smoke
    def test_finish_smoke(self):self.smoke('finish')
                                ~~~~~~~~~~^^^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 101, in smoke
    hb=self.wait(r/'heartbeat.json',lambda d:d.get('collectorStarted') is not None)
  File "CAPTURE_ROOT/code/capture-check.py", line 96, in wait
    self.fail('receipt not reached: '+str(p))
    ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: receipt not reached: <synthetic-temp>/prism-capture-smoke-mrhacozu/heartbeat.json

======================================================================
FAIL: test_kill_server_smoke (__main__.LifecycleCheck.test_kill_server_smoke)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 121, in test_kill_server_smoke
    def test_kill_server_smoke(self):self.smoke('kill')
                                     ~~~~~~~~~~^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 101, in smoke
    hb=self.wait(r/'heartbeat.json',lambda d:d.get('collectorStarted') is not None)
  File "CAPTURE_ROOT/code/capture-check.py", line 96, in wait
    self.fail('receipt not reached: '+str(p))
    ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: receipt not reached: <synthetic-temp>/prism-capture-smoke-jhr26c18/heartbeat.json

======================================================================
FAIL: test_signal_smoke (__main__.LifecycleCheck.test_signal_smoke)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 122, in test_signal_smoke
    def test_signal_smoke(self):self.smoke('signal')
                                ~~~~~~~~~~^^^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 101, in smoke
    hb=self.wait(r/'heartbeat.json',lambda d:d.get('collectorStarted') is not None)
  File "CAPTURE_ROOT/code/capture-check.py", line 96, in wait
    self.fail('receipt not reached: '+str(p))
    ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: receipt not reached: <synthetic-temp>/prism-capture-smoke-eza7_rvq/heartbeat.json

======================================================================
FAIL: test_stop_smoke (__main__.LifecycleCheck.test_stop_smoke)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "CAPTURE_ROOT/code/capture-check.py", line 120, in test_stop_smoke
    def test_stop_smoke(self):self.smoke('stop')
                              ~~~~~~~~~~^^^^^^^^
  File "CAPTURE_ROOT/code/capture-check.py", line 101, in smoke
    hb=self.wait(r/'heartbeat.json',lambda d:d.get('collectorStarted') is not None)
  File "CAPTURE_ROOT/code/capture-check.py", line 96, in wait
    self.fail('receipt not reached: '+str(p))
    ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: receipt not reached: <synthetic-temp>/prism-capture-smoke-bx7woz6k/heartbeat.json

----------------------------------------------------------------------
Ran 17 tests in 32.130s

FAILED (failures=4, errors=13)
```

## Full final capture GREEN

```text
READ_METER source_bytes=7 sealed_archive_bytes=0
SMOKE finish exit 0 integrityComplete True identities reaped
SMOKE hangup exit 0 integrityComplete False identities reaped
SMOKE interrupt exit 0 integrityComplete False identities reaped
SMOKE kill exit 0 integrityComplete False identities reaped
SMOKE signal exit 0 integrityComplete False identities reaped
SMOKE stop exit 0 integrityComplete False identities reaped
test_append_failure (__main__.CaptureCheck.test_append_failure) ... ok
test_archive_mutation_during_checkpoint (__main__.CaptureCheck.test_archive_mutation_during_checkpoint) ... ok
test_boolean_generation_refusal (__main__.CaptureCheck.test_boolean_generation_refusal) ... ok
test_generation_refusal (__main__.CaptureCheck.test_generation_refusal) ... ok
test_incremental_after_rotation (__main__.CaptureCheck.test_incremental_after_rotation) ... ok
test_interrupted_append_reopen (__main__.CaptureCheck.test_interrupted_append_reopen) ... ok
test_missing_archive (__main__.CaptureCheck.test_missing_archive) ... ok
test_prefix_mutation_and_regrown_copytruncate (__main__.CaptureCheck.test_prefix_mutation_and_regrown_copytruncate) ... ok
test_reopen_validates_once (__main__.CaptureCheck.test_reopen_validates_once) ... ok
test_same_size_prefix_mutation (__main__.CaptureCheck.test_same_size_prefix_mutation) ... ok
test_sealed_archive_mutation_and_missing (__main__.CaptureCheck.test_sealed_archive_mutation_and_missing) ... ok
test_second_rotation_refusal (__main__.CaptureCheck.test_second_rotation_refusal) ... ok
test_source_changes_during_read (__main__.CaptureCheck.test_source_changes_during_read) ... ok
test_truncation (__main__.CaptureCheck.test_truncation) ... ok
test_command_replay_unknown (__main__.LifecycleCheck.test_command_replay_unknown) ... ok
test_deadline_receipt_injected_clock (__main__.LifecycleCheck.test_deadline_receipt_injected_clock) ... ok
test_finish_smoke (__main__.LifecycleCheck.test_finish_smoke) ... ok
test_gap_receipt_injected_clock (__main__.LifecycleCheck.test_gap_receipt_injected_clock) ... ok
test_hangup_smoke (__main__.LifecycleCheck.test_hangup_smoke) ... ok
test_identical_atomic_command_replay_refuses (__main__.LifecycleCheck.test_identical_atomic_command_replay_refuses) ... ok
test_interrupt_smoke (__main__.LifecycleCheck.test_interrupt_smoke) ... ok
test_kill_server_smoke (__main__.LifecycleCheck.test_kill_server_smoke) ... ok
test_live_deadline_injected_clock (__main__.LifecycleCheck.test_live_deadline_injected_clock) ... ok
test_signal_smoke (__main__.LifecycleCheck.test_signal_smoke) ... ok
test_start_to_start_gap_includes_work (__main__.LifecycleCheck.test_start_to_start_gap_includes_work) ... ok
test_stop_smoke (__main__.LifecycleCheck.test_stop_smoke) ... ok
test_unknown_control_receipt (__main__.LifecycleCheck.test_unknown_control_receipt) ... ok

----------------------------------------------------------------------
Ran 27 tests in 4.082s

OK
```

## Full final inherited log GREEN

```text
PASS log calibration: first activation offset, rename rotation, exact bytes/order, repeat no duplicates, missing inode/copytruncate refusal, portable preserves every measurement payload byte
PASS reuse/integrity calibration: deterministic A to B to A, unique ordered generations, repeat exact; corrupted/missing archive, changed source prefix and invalid generation refuse before archive/manifest writes
PASS persistent owner: exclusive activation offset, incremental append/idempotence, finish integrity only
PASS persistent A to B to A: all ordered bytes retained without reopening the collector
```
