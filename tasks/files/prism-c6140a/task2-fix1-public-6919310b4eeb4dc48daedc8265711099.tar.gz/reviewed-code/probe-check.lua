local mode=arg[5] or 'all';arg[5]='harness'
local root=assert(arg[0]:match('^(.*)/')); local H=dofile(root..'/frozen-task2/self-check.lua')
local base=arg[1];local host,copy,up,button=H.host,H.copy,H.up,H.button
local function records(h) local r=copy(h.emitted);for _,e in ipairs(up(h.env.onFrameTick,'diagnosticBuffer')) do r[#r+1]=e end;return r end
local function lastRecord(h,class) local r=records(h);for i=#r,1,-1 do if r[i].class==class then return r[i] end end;error('missing '..class) end
local function countExpanded(state) local n=0;for _,v in pairs(state.expanded) do if v==true then n=n+1 end end;return n end
local serial=0
local function deliver(h) serial=serial+1;local response=copy(H.success);response.stdout='unique response '..serial;h.launches[#h.launches].callback(response) end
local function drain(h) for _=1,250 do if not h.frame then return end;h.env.onFrameTick(16);local pair=up(h.env.onFrameTick,'diagnosticPair');if pair and pair.pending and pair.frameDone then h.launches[#h.launches].callback(H.success) end end;error('not finite') end
local function slider(h) for _,n in ipairs(H.nodes(h.tree)) do if n.kind=='slider' and n.props.key=='glass.inactive.roughness:slider' then return n end end;error('slider missing') end
local function finish(h) button(h,'Sample diagnostics').props.onClick();drain(h) end
local tests={}
tests.expansion=function(h,variant)
 local plain=host(base..'/'..variant..'/source',false,true)
 local before=h.decodes;button(h,'Sample diagnostics').props.onClick()
 assert(countExpanded(h.state)==#h.state.structure.rack.cards,'administrative expansion missing')
 assert(h.decodes==before,'click decoded')
 h.tick();local ready=lastRecord(h,'ready');assert(ready.allRackExpanded)
 local reference=lastRecord(h,'acceptedReference');assert(ready.referenceId==reference.recordId and reference.valid and reference.recordId<ready.recordId,'ready initial reference missing')
 h.tick();assert(h.decodes==before+1);h.tick();assert(lastRecord(h,'coldRender').rendered)
 assert(H.tree(h)==H.tree(plain),'measured tree differs');assert(not button(h,'Sample diagnostics'))
end
tests.endpoints=function(h)
 local clock=0;h.env.os={clock=function() clock=clock+0.001;return clock end}
 h.env.onKey('j',true)
 local callbacks,renders=0,0
 for _,e in ipairs(records(h)) do if e.timestamp<1 and (e.scope=='callback' or e.scope=='render') then
  assert(e.startTimestamp and e.endTimestamp,'exact target endpoints missing')
  assert(e.endTimestamp>=e.startTimestamp and e.timestamp>e.endTimestamp)
  assert(e.elapsedMs==(e.endTimestamp-e.startTimestamp)*1000)
  if e.scope=='callback' then callbacks=callbacks+1 else renders=renders+1 end
 end end
 assert(callbacks>0 and renders>0)
 local callback=lastRecord(h,'input');assert(callback.scope=='callback' and callback.startTimestamp==0.001 and callback.endTimestamp==0.005 and callback.timestamp==0.006)
 local render;for _,e in ipairs(records(h)) do if e.class=='input' and e.scope=='render' then render=e end end
 assert(render.startTimestamp==0.002 and render.endTimestamp==0.003 and render.timestamp==0.004)
end
tests.references=function(h)
 finish(h);local s=slider(h);s.props.onChange(s.props.value+0.01);h.tick();s.props.onDragEnd();deliver(h);deliver(h);h.tick();drain(h)
 local ref=lastRecord(h,'acceptedReference');assert(ref.valid and ref.acceptGeneration>0)
 local values,held={},{};for _,p in ipairs(h.state.model.params) do values[p.key]=p.value;for _,layer in ipairs(p.held) do if layer=='scratch' then held[#held+1]=p.key end end end;table.sort(held)
 assert(H.canonical(ref.values)==H.canonical(values));assert(H.canonical(ref.heldScratchKeys)==H.canonical(held))
 assert(ref.startTimestamp<=ref.endTimestamp and ref.endTimestamp<ref.timestamp)
 local done=lastRecord(h,'operationDone');assert(done.operationId==ref.operationId and done.callbackIdTarget and done.renderIdTarget and done.referenceId==ref.recordId)
 for _,kind in ipairs({'number','string','boolean'}) do
  local changed=copy(ref.values);local found=false
  for _,p in ipairs(h.state.model.params) do if type(p.value)==kind then changed[p.key]=kind=='number' and p.value+0.01 or (kind=='boolean' and not p.value or '#123456');found=true;break end end
  assert(found and H.canonical(changed)~=H.canonical(ref.values),'reference exact mismatch was hidden')
 end
end
tests.races=function(h)
 finish(h);local s=slider(h);s.props.onChange(s.props.value+0.01);h.tick();s.props.onDragEnd();h.env.onClose();deliver(h);deliver(h);h.env.onOpen({});deliver(h);h.tick();drain(h)
 for _,e in ipairs(records(h)) do assert(e.class~='operationDone','closed release falsely completed') end
 local h2=host(base..'/'..lastRecord(h,'activation').variant..'/plugin',true,true);finish(h2)
 h2.env.onKey('1',true);local enqueued=h2.state.enqueued;h2.env.onKey('2',true);assert(h2.state.enqueued==enqueued,'P guard changed')
 local requests=0;for _,e in ipairs(records(h2)) do if e.class=='operationRequested' and e.operationKind=='profile' then requests=requests+1 end end;assert(requests==1,'ignored P created operation')
 h2.env.onClose();deliver(h2);deliver(h2);h2.env.onOpen({});deliver(h2);h2.tick();drain(h2)
 for _,e in ipairs(records(h2)) do assert(e.class~='operationDone' and e.class~='profileRender','closed Q falsely qualified') end
end
tests.supersede=function(h)
 finish(h);h.env.onKey('1',true);deliver(h);deliver(h);h.tick()
 h.env.onKey('2',true);assert(h.state.selectionPending,'new input delayed');deliver(h);deliver(h);h.tick();drain(h)
 local invalid=false;for _,e in ipairs(records(h)) do if e.class=='acceptedReference' and not e.valid and e.reason=='superseded' then invalid=true end end
 assert(invalid,'superseded Q reference not invalidated')
end
tests.collapse=function(h)
 button(h,'Sample diagnostics').props.onClick();h.tick();h.tick();h.state.expanded[h.state.structure.rack.cards[1].device]=false;h.tick()
 assert(lastRecord(h,'coldRender').targetEligible==false,'collapsed target admitted')
end
tests.settlement=function(h)
 drain(h);for _,e in ipairs(records(h)) do assert(e.class~='cardSettled','initial idle settled a card') end
 finish(h);local done=lastRecord(h,'cardSettled');assert(done.eligibleDrain and #done.requestedOperationIds>0 and done.bufferEmpty)
 assert(not button(h,'Sample diagnostics'),'initial sequence offered twice')
end
local order={'expansion','endpoints','references','races','supersede','collapse','settlement'}
for _,name in ipairs(order) do if mode=='all' or mode==name then for _,variant in ipairs(arg[6] and {arg[6]} or {'baseline','candidate'}) do local h=host(base..'/'..variant..'/plugin',true,name~='expansion');tests[name](h,variant)
 if name~='endpoints' then drain(h) end
 local file=assert(io.open(base..'/'..variant..'/probe-'..name..'-fake.log','w'));file:write(table.concat(h.logs,'\n')..'\n');file:close() end;print('PASS '..name..' both source revisions') end end
if mode=='recovery' then
 for _,variant in ipairs({'baseline','candidate'}) do
  local h=host(base..'/'..variant..'/plugin',true,true);finish(h)
  local recovery=assert(button(h,'Approved recovery'),'missing recovery administrative button')
  local identity=lastRecord(h,'activation')
  h.manifest={schema=2,approved=false,runId=identity.runId,activationNonce=identity.activationNonce,cardId=identity.cardId..'-recovery',replacementFor=lastRecord(h,'cardSettled').requestedOperationIds,coldPairs=1,launchPairs=0,operations={}}
  h.env.noctalia.readFile=function() return 'recovery manifest' end
  local decode=h.env.noctalia.json.decode
  h.env.noctalia.json.decode=function(s) if s=='recovery manifest' then return copy(h.manifest) end;return decode(s) end
  local before=h.decodes;recovery.props.onClick();assert(h.decodes==before and not up(h.env.onFrameTick,'diagnosticSequence'),'unauthorized recovery executed')
  for _,field in ipairs({'schema','runId','activationNonce','coldPairs','launchPairs','replacementFor','extra'}) do
   local saved=copy(h.manifest);h.manifest.approved=true
   if field=='extra' then h.manifest.extra=true elseif field=='replacementFor' then h.manifest.replacementFor={'unknown'} else h.manifest[field]='bad' end
   recovery.props.onClick();assert(not up(h.env.onFrameTick,'diagnosticSequence'),'malformed/stale recovery executed '..field);h.manifest=saved
  end
  local original=copy(h.manifest);h.manifest.approved=true;h.manifest.operations={{id=h.manifest.cardId..':cold:1',kind='release',key='glass.inactive.roughness'},{id=h.manifest.cardId..':restore',kind='restore',key='glass.inactive.roughness'}}
  recovery.props.onClick();assert(not up(h.env.onFrameTick,'diagnosticSequence'),'duplicate diagnostic/manual id admitted');h.manifest=original
  h.state.expanded[h.state.structure.rack.cards[1].device]=false
  h.manifest.approved=true;recovery.props.onClick();assert(countExpanded(h.state)==#h.state.structure.rack.cards,'recovery administrative expansion missing');assert(up(h.env.onFrameTick,'diagnosticSequence'),'approved recovery refused')
  assert(not button(h,'Approved recovery'),'recovery control remained during target window')
  drain(h);assert(h.decodes==before+1,'replacement counts wrong')
  local settled=lastRecord(h,'cardSettled');assert(settled.cardId==h.manifest.cardId and settled.activationNonce==identity.activationNonce and #settled.replacementFor>0)
  assert(#settled.requestedOperationIds==1 and settled.requestedOperationIds[1]==h.manifest.cardId..':cold:1','replacement operation set differs')
  recovery.props.onClick();assert(not up(h.env.onFrameTick,'diagnosticSequence'),'recovery accepted twice')
  print('PASS approved/rejected/malformed/stale/exhausted recovery '..variant)
 end
end

if mode=='recovery-manual' then
 for _,variant in ipairs({'baseline','candidate'}) do
  local h=host(base..'/'..variant..'/plugin',true,true);finish(h)
  local identity=lastRecord(h,'activation');local card=identity.cardId..'-combined'
  local key='glass.inactive.roughness';local q=h.model.profiles[1];local p=h.model.profiles[2]
  h.manifest={schema=2,approved=true,runId=identity.runId,activationNonce=identity.activationNonce,cardId=card,replacementFor=lastRecord(h,'cardSettled').requestedOperationIds,coldPairs=0,launchPairs=1,
    operations={{id=card..':release',kind='release',key=key},{id=card..':restore',kind='restore',key=key},{id=card..':Q',kind='profile',profile=q},{id=card..':P',kind='profile',profile=p}}}
  h.env.noctalia.readFile=function() return 'manifest' end;local decode=h.env.noctalia.json.decode
  h.env.noctalia.json.decode=function(s) if s=='manifest' then return copy(h.manifest) end;return decode(s) end
  button(h,'Approved recovery').props.onClick();h.tick()
  for _=1,12 do
    h.env.onFrameTick(16);local pair=up(h.env.onFrameTick,'diagnosticPair');if pair and pair.pending then h.launches[#h.launches].callback(H.success) end
    if not up(h.env.onFrameTick,'diagnosticSequence') and not pair then break end
  end
  drain(h);for _,e in ipairs(records(h)) do assert(e.class~='cardSettled' or e.cardId~=card,'manual requests settled before actions') end
  local s=slider(h);s.props.onChange(s.props.value+0.01);h.tick();s.props.onDragEnd()
  for _,param in ipairs(h.model.params) do if param.key==key then param.held={'scratch'} end end
  deliver(h);deliver(h);h.tick();drain(h)
  local reset;for _,n in ipairs(H.nodes(h.tree)) do if n.props.tooltip=='Revert edit' and n.props.onClick and up(n.props.onClick,'key')==key then reset=n;break end end
  assert(reset,'restore button absent');reset.props.onClick();deliver(h);deliver(h);h.tick();drain(h)
  for i=1,2 do h.env.onKey(tostring(i),true);h.model.active.profile=h.model.profiles[i];deliver(h);deliver(h);h.tick();drain(h) end
  local done=lastRecord(h,'cardSettled');assert(done.cardId==card and #done.requestedOperationIds==6,'combined requested operation set differs')
  for _,op in ipairs(h.manifest.operations) do local found=false;for _,e in ipairs(records(h)) do if e.class=='operationDone' and e.operationId==op.id then found=true end end;assert(found,'missing manifest operation '..op.kind) end
  local file=assert(io.open(base..'/'..variant..'/recovery-manual-fake.log','w'));file:write(table.concat(h.logs,'\n')..'\n');file:close()
  print('PASS one launch/control plus same-key release/restore and exact Q/P manual recovery '..variant)
 end
end
