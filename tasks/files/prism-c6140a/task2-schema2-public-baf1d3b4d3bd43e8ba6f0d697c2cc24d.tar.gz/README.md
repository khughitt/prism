# Task 2 schema2 scratch producer

This public package contains portable scratch scripts, their full preserved-to-new textual diff, frozen production-source calibration copies, immutable generated identities, and PASS/hash inventories. All fake-host measurement records derived from the private owner model remain private, including acceptedReference canonical maps, profile names, and active path references. No private model or describe originals are included. No measurement payload has been rewritten or neutralized.

The private payload hash inventory identifies exact original byte hashes and record-payload hashes; its linked private archive retains the full byte-equality proof and literal command transcript for authorized read-only review. commands-portable.jsonl substitutes path variables for portability and is explicitly not the literal private transcript.

Run scripts via interpreters with fresh exclusively created output directories and new nonces. probe-check.lua takes calibration directory, private or deliberately synthetic fixture path, test encoder, and explicit worktree CLI; optional fifth argument selects a mode. self-check.lua retains its inherited modes. analyze.py is the frozen schema1 historical parser; schema2 producer-shape checks in analysis_check.py are not the Task3 eligibility parser. The collector still proves bytes only.
