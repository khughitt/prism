# Stabilized pilot retry — controller review and fresh permission first

Read `B1-abort-report.md` before changing the environment. The aborted B1 occupied
34.06 minutes and cannot supply a complete four-activation estimate. The old
approximate-ten-minute estimate is not a measured retry duration. There is no
performance, scheduling, keep/revert or acceptance conclusion. Root confirmed
exact Prism restoration before this preparation; the main plugin is enabled and
its original panel closed. Owner requires rotation paused before retry and resumed
on completion/abort. The directive authorizes that scope; fresh retry desktop
permission is still required. Worker performed no timer stop/start or live action.

Use the corrected general runbook for owner phases and exact Prism guards. Current
Noctalia commands are `noctalia msg panel-close khughitt/prism:panel` and
`noctalia msg panel-open khughitt/prism:panel`; disable/enable remain
`noctalia msg plugins disable khughitt/prism` / `... enable khughitt/prism`.
The old plugins panel-close/panel-open forms failed before any write and must not
be reused. Original B1 segments, capture, phases, snapshots and restore proof stay
immutable. Start a separate retry directory and phase file; do not truncate or
append to the original frozen inputs.

```sh
export PRISM_TASK3_REPO="$(realpath .worktrees/panel-budget)"
CLI="$PRISM_TASK3_REPO/bin/prism"
PREP=/tmp/prism-budget-task3-prep
RETRY="$PREP/stabilized-live-r1"
mkdir -p "$RETRY"
# Define a new host-origin stamp function targeting RETRY/phases-private.jsonl.
# Stamp occupancy-start, rotation-pause-start BEFORE these actual host actions.
```

After root's independent rotation-guard review and fresh retry permission:

```sh
python3 "$PREP/rotation-guard.py" snapshot "$RETRY/rotation-private.json"
PRISM_ROTATION_RETRY_APPROVED=yes python3 "$PREP/rotation-guard.py" pause "$RETRY/rotation-private.json" > "$RETRY/rotation-paused-private.json"
```

The helper saves prior active/inactive state, activation-boundary timestamps,
enabled/disabled state, fragment/drop-in identity and exact raw timer/service unit
text. Runtime action is STOP on `wali-rotate.timer` only. It never disables units,
changes unit config or kills/stops the service. It verifies inactive/dead timer and
waits naturally for any in-flight `wali-rotate.service` to become inactive with
success (30s service wait, 10s maximum per systemctl command). Config/enablement and
activation state are guarded before each mutation and while waiting. Stop/start
intent is persisted before the command, followed by the owned stopped/restarted
state, so interruption/failure is visible in the journal.

No Prism baseline/reference may be taken for use until pause returns timerPaused,
serviceInactive and configurationPreserved true. Then stamp rotation-pause-end and
take fresh snapshots with the current-profile comparison helper:

```sh
node "$PREP/state.mjs" snapshot "$RETRY/prism-current-pair-saved-private.json"
"$CLI" describe --json > "$RETRY/prism-current-pair-describe-private.json"
```

P is the actual existing active profile. Each existing profile is resolved once;
Q excludes P and has the greatest number of differing canonical values, using
sorted profile name order for ties. Require more than half of canonical values
changed in both directions; no viable pair or missing P fails before any Prism
write/capture. Root announces chosen P/Q from the saved snapshot; no setup profile
switch or extra owner action is introduced. On 2026-10-13 the initial explicit
Aurora pair failed 30/83; root restored the timer without capture, then authorized
this deterministic selection policy. Latest read-only P=dark-wish-ii/Q=glass12
changes 52/83 and passes. That preflight is not authority for a later reference.

Use the fresh scratch map and saved canonical profiles[P] for the selected
unedited enabled `glass.inactive.distortionScale` inside Distortion detail row.
Current preflight value 0.17→0.19, range 0.01–2 / step 0.01, release binding, no UI gate
or requirement/attenuation, glass/focus split enabled, bypass false and unfocused
mix 0.3. Reverify all 83 param/12 card ids and actual cleared-P gates before prompts.
Take P/Q labels and slider value from the fresh snapshot, never old aquamarine2,
Aurora or 0.08 captions. The profile phase remains one saved P→saved Q→saved P cycle
per activation, using the same already-approved action counts. Root then guarded
clear/apply and four reload/identity/readiness/owner phases. Any independent or
manual wallpaper/reference change still stops the run despite timer stabilization.

Four NEW unlaunched copy paths (one cold each, launch/control only B1/C1):

| Phase | COPY | Activation nonce |
| --- | --- | --- |
| B1 | /tmp/prism-budget-task3-prep/stabilized/block1/baseline | task3-stable-retry-1-902be183-baseline |
| C1 | /tmp/prism-budget-task3-prep/stabilized/block1/candidate | task3-stable-retry-1-902be183-candidate |
| C2 | /tmp/prism-budget-task3-prep/stabilized/block2/candidate | task3-stable-retry-2-5bc69e24-candidate |
| B2 | /tmp/prism-budget-task3-prep/stabilized/block2/baseline | task3-stable-retry-2-5bc69e24-baseline |

`stabilized-copies-portable.json` holds exact source/plugin hashes and identities.
Run the general runbook’s selected-copy verifier with that manifest argument;
its old copies-portable.json/table is superseded for this retry.
Source commits and instrumentation are unchanged from clean-reviewed a89fd28.
All old copies/nonces are excluded from this new reference, even the unstarted
ones. Verify copy bytes and marker/reset/readiness/drain flags before each phase.
Use logs.py with RETRY/B1 etc and offsets after outgoing disable, before incoming
enable. Keep outgoing probe installed until owner confirms completion/stop and
all real writes/describe/pairs/callbacks/log buffers drain. No time estimate is a
cutoff or permission to add owner actions. Strict final analysis never discards a
partial record; a monitor may wait for transport completion, not normalize final
evidence. n=1 retry still cannot accept the candidate or relax the n≥5 gates.

On completion, abort or a pause/setup failure: preserve journal and raw partial
inputs. Restore exact Prism profile/scratch/raw documents/canonical values, preserve
latest wallpaper, restore original plugin link and reload main, verifying before
resuming rotation. If no Prism write occurred, verify Prism remained unchanged.
Then:

```sh
# Stamp rotation-resume-start only AFTER exact Prism restoration.
PRISM_ROTATION_RETRY_APPROVED=yes python3 "$PREP/rotation-guard.py" resume "$RETRY/rotation-private.json" > "$RETRY/rotation-restored-private.json"
# After resume succeeds, take latest Prism snapshot and compare saved profile,
# exact scratch and raw docs, with canonical values under the current wallpaper.
node "$PREP/state.mjs" snapshot "$RETRY/post-resume-private.json"
# Stamp rotation-resume-end and occupancy-end; record host-load --section session.
```

Prior-active timer is started; prior-inactive timer stays inactive without any
stop/start calls. Enablement and exact unit configuration remain unchanged.
Starting a prior-active timer may immediately trigger an overdue rotation; helper
waits naturally for that service completion before post-resume snapshot. Verify
again latest wallpaper/profile/scratch/raw docs/canonical values; preserve this
newer independent wallpaper and report it, rather than writing the old wallpaper
back. Record timer stop/start from/to/restoration recipe in task notes at the moment.

A service timeout/failure refuses setup and leaves `paused-awaiting-service` plus
owned paused state for guarded restoration. `resumed-awaiting-service` supports a
later bounded completion wait without issuing another start. Command failure or
interruption at `pause-issued`/`resume-issued` is uncertain: inspect fresh read-only
unit state and journal; do not blindly repeat or fabricate an owned state. An
unrelated config/enablement/activation conflict stops automation before overwriting
it. Root reports the specific conflict and resolves it with the owner; the helper
never undoes somebody else's change. Never kill the service to satisfy a timeout.
No retry follows automatically; completed partial evidence is analyzed and exact
restoration/rotation status reported before another fresh permission request.



Root restored its first paused timer after the failed 30/83 pair; resource is clean
before the next approved pause. Root owns actual pause/service drain, fresh saved
comparison, capture and exact Prism/timer restoration. Old r1 snapshots and journals
stay immutable; use distinct filenames/journal for the next owned pause, and never
reuse the worker-only preflight as an authoritative baseline.
