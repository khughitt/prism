Frozen stabilized r2 incomplete evidence and private collector correction.

No formal acceptance: n=1, C2 Q profileRender missing, B2 records1290..2385 lost.
Original malformed fragment and manifest order retained. Separate live tail proves
final drain only. Do not concatenate/reconstruct/sort these into a repaired run.
Old capture schemas are diagnosis-only and refuse corrected collection.
No original owner runtime/profile/base/unit bytes included. Transport paths are
normalized; every raw prism-budget payload is unchanged. Original-file hashes refer
to private raw originals, not normalized transport. Root owns independent review,
written design revision and any later fresh host permission; no retry authorized.
