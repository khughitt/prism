import hashlib,json,os,sys
from pathlib import Path

def save(manifest,state):
    temp=manifest.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(manifest)

def start(log,manifest):
    log=Path(log);manifest=Path(manifest);assert not manifest.exists(),'refuse to overwrite capture manifest'
    stat=log.stat();save(manifest,{'log':str(log),'current':{'dev':stat.st_dev,'inode':stat.st_ino,'offset':stat.st_size,'generation':1},'nextGeneration':2,'segments':[]})

def collect(manifest):
    manifest=Path(manifest);state=json.loads(manifest.read_text());log=Path(state['log']);held=state['current']
    assert 'generation' in held and 'nextGeneration' in state,'capture lacks generation identity; preserve old evidence and start a fresh capture'
    segments=state['segments'];generations=[s['generation'] for s in segments]
    assert generations==list(range(1,len(segments)+1)) and held['generation'] in (len(segments),len(segments)+1) and state['nextGeneration']==held['generation']+1,'invalid segment generations'
    archived={}
    for segment in segments:
        expected=f"segment-{segment['generation']:06d}-{segment['dev']}-{segment['inode']}.raw"
        assert segment['path']==expected,'invalid segment path'
        path=manifest.parent/expected;assert path.is_file(),'archive missing; preserve capture and investigate'
        data=path.read_bytes()
        assert len(data)==segment['bytes'] and hashlib.sha256(data).hexdigest()==segment['sha256'] and segment['endOffset']==segment['startOffset']+len(data),'archive integrity failure; preserve capture and investigate'
        archived[segment['generation']]=data
    matches=[p for p in log.parent.glob(log.name+'*') if p.is_file() and (p.stat().st_dev,p.stat().st_ino)==(held['dev'],held['inode'])]
    assert len(matches)==1,'saved log inode missing or ambiguous; stop, preserve capture and investigate rotation'
    old=matches[0];assert old==log or old==log.with_name(log.name+'.1'),'multiple rotations between collections; stop before dropping an intervening segment'
    writes={}
    def read(file,cursor):
        generation=cursor['generation']
        if generation in archived:
            segment=segments[generation-1]
            assert (segment['dev'],segment['inode'],segment['endOffset'])==(cursor['dev'],cursor['inode'],cursor['offset']),'cursor does not match saved segment'
        else:
            assert generation==len(segments)+1,'invalid next segment generation'
            segment={'path':f"segment-{generation:06d}-{cursor['dev']}-{cursor['inode']}.raw",'generation':generation,'dev':cursor['dev'],'inode':cursor['inode'],'startOffset':cursor['offset']}
            assert not (manifest.parent/segment['path']).exists(),'new segment archive already exists; preserve capture and investigate'
            segments.append(segment)
        with file.open('rb') as stream:
            stat=os.fstat(stream.fileno());assert (stat.st_dev,stat.st_ino)==(cursor['dev'],cursor['inode']),'log rotated during open; retry collection'
            assert stat.st_size>=cursor['offset'],'log truncated; stop without resetting offset'
            stream.seek(segment['startOffset']);data=stream.read(stat.st_size-segment['startOffset'])
            assert len(data)==stat.st_size-segment['startOffset'],'log truncated during read'
            prior=archived.get(generation,b'');assert data[:len(prior)]==prior,'log prefix changed; stop without rewriting saved evidence'
            segment.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),endOffset=stat.st_size)
            writes[manifest.parent/segment['path']]=data;cursor['offset']=stat.st_size
    read(old,held)
    live=log.stat()
    if (live.st_dev,live.st_ino)!=(held['dev'],held['inode']):
        assert old!=log,'log rotated while collecting; preserve raw capture and investigate before proceeding'
        held={'dev':live.st_dev,'inode':live.st_ino,'offset':0,'generation':state['nextGeneration']};state['nextGeneration']+=1;state['current']=held
        read(log,held)
        previous=old.stat();assert (previous.st_dev,previous.st_ino)==(state['segments'][-2]['dev'],state['segments'][-2]['inode']),'second rotation during collection; preserve capture and investigate'
    # Validate both sources and all prior archives before touching any captured bytes.
    # Interrupted writes fail integrity next time; they never silently repair evidence.
    for path,data in writes.items():
        temp=path.with_suffix('.tmp');temp.write_bytes(data);temp.replace(path)
    save(manifest,state)
    return [manifest.parent/s['path'] for s in segments]

def portable(data,prefixes):
    marker=b'prism-budget ';before=[line.split(marker,1)[1] for line in data.splitlines() if marker in line]
    lines=[]
    for line in data.splitlines(keepends=True):
        header,sep,payload=line.partition(marker)
        for prefix in prefixes:header=header.replace(prefix.encode(),b'<private>')
        lines.append(header+sep+payload)
    result=b''.join(lines);assert [line.split(marker,1)[1] for line in result.splitlines() if marker in line]==before
    assert all(prefix.encode() not in result for prefix in prefixes),'private prefix inside measurement payload; preserve raw and stop before attaching'
    return result

if __name__=='__main__':
    if sys.argv[1]=='start':start(Path(sys.argv[2]),Path(sys.argv[3]))
    else:
        assert sys.argv[1]=='collect','use start LOG MANIFEST or collect MANIFEST'
        print('\n'.join(str(p) for p in collect(Path(sys.argv[2]))))
