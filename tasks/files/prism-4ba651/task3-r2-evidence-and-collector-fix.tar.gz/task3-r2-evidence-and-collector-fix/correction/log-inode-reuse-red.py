"""Reproduce the collector overwrite using its frozen pre-fix module."""
import importlib.util,runpy,sys
from pathlib import Path
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location('logs',root/'logs-inode-bug-preserved.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);sys.modules['logs']=m
runpy.run_path(str(root/'log-check.py'),run_name='__main__')
