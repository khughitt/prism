import tempfile,json
from pathlib import Path
from logs import start,collect,portable
with tempfile.TemporaryDirectory(prefix='prism-log-check-') as tmp:
    root=Path(tmp);log=root/'noctalia.log';manifest=root/'capture.json'
    log.write_bytes(b'old ignored log\n');start(log,manifest)
    first=b'prism-budget {"activationNonce":"fresh-B1","recordId":1}\n'
    with log.open('ab') as f:f.write(first)
    paths=collect(manifest)
    assert b''.join(p.read_bytes() for p in paths)==first,'first startup record must be collected from saved offset'
    log.rename(root/'noctalia.log.1');second=b'private /home/example/secret\nprism-budget {"activationNonce":"fresh-B1","recordId":2}\n';log.write_bytes(second)
    paths=collect(manifest);assert b''.join(p.read_bytes() for p in paths)==first+second
    assert b''.join(p.read_bytes() for p in collect(manifest))==first+second,'collection must not duplicate records'
    cleaned=portable(first+second,['/home/example'])
    assert b'/home/example' not in cleaned and first in cleaned
    try:portable(b'prism-budget {"private":"/home/example"}\n',['/home/example'])
    except AssertionError as err:assert 'payload' in str(err)
    else:raise AssertionError('private measurement payload must refuse attachment, not mutate identity')
    log.write_bytes(b'')
    try:collect(manifest)
    except AssertionError as err:assert 'truncated' in str(err)
    else:raise AssertionError('copytruncate must refuse rather than lose records')
    log.write_bytes(second);log.unlink()
    try:collect(manifest)
    except AssertionError as err:assert 'missing' in str(err)
    else:raise AssertionError('lost inode must refuse rather than silently reset offset')
print('PASS log calibration: first activation offset, rename rotation, exact bytes/order, repeat no duplicates, missing inode/copytruncate refusal, portable preserves every measurement payload byte')

# Deterministic inode reuse; actual file bytes/open/rename remain temporary.
import os
from unittest.mock import patch
real_stat=Path.stat;real_fstat=os.fstat
with tempfile.TemporaryDirectory(prefix='prism-log-reuse-check-') as tmp:
    root=Path(tmp);log=root/'noctalia.log';manifest=root/'capture.json';mapping={}
    def mapped(stat):
        values=list(stat);values[1]=mapping.get((stat.st_dev,stat.st_ino),stat.st_ino)
        return os.stat_result(values)
    def fake_stat(path,*args,**kwargs):return mapped(real_stat(path,*args,**kwargs))
    def fake_fstat(fd):return mapped(real_fstat(fd))
    def write(data,inode):
        log.write_bytes(data);s=real_stat(log);mapping[(s.st_dev,s.st_ino)]=inode
    first=b'prism-budget {"recordId":1}\n';second=b'prism-budget {"recordId":2}\n';third=b'prism-budget {"recordId":3}\n'
    with patch.object(Path,'stat',fake_stat),patch.object(os,'fstat',fake_fstat):
        write(b'',101);start(log,manifest)
        with log.open('ab') as f:f.write(first)
        collect(manifest)
        log.rename(root/'noctalia.log.1');write(second,202);collect(manifest)
        (root/'noctalia.log.1').unlink();log.rename(root/'noctalia.log.1');write(third,101)
        paths=collect(manifest)
        assert b''.join(p.read_bytes() for p in paths)==first+second+third,'A to B to A inode reuse must preserve all ordered generations'
        state=json.loads(manifest.read_text())
        assert [s['generation'] for s in state['segments']]==[1,2,3]
        assert len({s['path'] for s in state['segments']})==3
        assert b''.join(p.read_bytes() for p in collect(manifest))==first+second+third
        def refused(message):
            before=manifest.read_bytes();raw={p:p.read_bytes() for p in paths}
            try:collect(manifest)
            except AssertionError as err:assert message in str(err),(message,str(err))
            else:raise AssertionError('missing integrity refusal: '+message)
            assert manifest.read_bytes()==before and {p:p.read_bytes() for p in paths}==raw
        original=paths[0].read_bytes();paths[0].write_bytes(b'x'*len(original));refused('archive integrity');paths[0].write_bytes(original)
        original=log.read_bytes();log.write_bytes(b'x'*len(original));refused('log prefix changed');log.write_bytes(original)
        original=manifest.read_bytes();broken=json.loads(original);broken['segments'][1]['generation']=1;manifest.write_text(json.dumps(broken));refused('segment generations');manifest.write_bytes(original)
        original=paths[1].read_bytes();paths[1].unlink()
        before=manifest.read_bytes()
        try:collect(manifest)
        except AssertionError as err:assert 'archive missing' in str(err)
        else:raise AssertionError('missing archive must refuse')
        assert manifest.read_bytes()==before;paths[1].write_bytes(original)
print('PASS reuse/integrity calibration: deterministic A to B to A, unique ordered generations, repeat exact; corrupted/missing archive, changed source prefix and invalid generation refuse before archive/manifest writes')
