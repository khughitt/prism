"""Analyze only the frozen r2 evidence; never recollect, repair or pool runs."""
import collections, hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
root=Path(__file__).parent
source=root/'r2-evidence-preserved'
out=root/'r2-analysis-private';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('shared_analysis',root/'frozen-task2/analyze.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
phases=[('B1','block1/baseline'),('C1','block1/candidate'),('C2','block2/candidate'),('B2','block2/baseline')]
summary={'verdict':{'comparison':'inconclusive','accepted':False,'return_to_design':True},'observedBudgetErrors':0,'budgetErrorsComplete':False,'budgetMonitoringScope':'Root observed zero in captured/newly polled windows and final live drain; B2 missing interval is unobserved.','activations':{}}
for phase,copy in phases:
    manifest=json.loads((source/phase/'capture.json').read_text())
    paths=[source/phase/s['path'] for s in manifest['segments']]
    identity=root/'stabilized'/copy/'identity.json'
    cmd=[sys.executable,str(root/'frozen-task2/analyze.py')]
    for p in paths:cmd+=['--log',str(p)]
    cmd+=['--identity',str(identity),'--budget-errors','0','--output',str(out/(phase+'-strict-private.json'))]
    if phase=='B2':
        # Strict parser only: do not supply a guessed whole-activation budget count.
        cmd=[sys.executable,'-c',"import runpy,sys; runpy.run_path(sys.argv[1])['read_rotated'](sys.argv[2:])",str(root/'frozen-task2/analyze.py'),*[str(p) for p in paths]]
    result=subprocess.run(cmd,text=True,capture_output=True)
    (out/(phase+'-strict-command-private.json')).write_text(json.dumps(cmd,indent=2)+'\n')
    (out/(phase+'-strict.log')).write_text(result.stdout+result.stderr)
    print(phase,'strict exit',result.returncode)
    if phase!='B2':
        assert result.returncode==0
        parsed=json.loads((out/(phase+'-strict-private.json')).read_text())
        events=parsed['events'];ids={e['recordId'] for e in events}
        assert ids==set(range(1,len(events)+1))
        values=parsed['blocks'][events[0]['block']][events[0]['variant']]
        summary['activations'][phase]={'strictExit':0,'records':len(events),'completeRecordSet':True,'budgetErrorsComplete':True,'validClasses':{k:{'count':len(values.get(k,[])),'valuesMs':values.get(k,[])} for k in a.CLASSES},'launch':parsed['launch'],'intervals':parsed['intervals'],'exclusions':dict(collections.Counter(e['reason'] for e in parsed['exclusions'])),'verdict':parsed['verdict']}
    else:
        assert result.returncode!=0 and 'JSONDecodeError' in result.stderr
        # Only the intact original prefix is normalized; it is not complete B2 evidence.
        prefix=a.normalize(a.read_rotated(paths[:2]),[json.loads(identity.read_text())]);values=a.target_blocks(prefix)['2']['baseline']
        (out/'B2-prefix-private.json').write_text(json.dumps(prefix,indent=2)+'\n')
        per_segment=[];observed=[]
        for p in paths:
            events=[];bad=[]
            for n,line in enumerate(p.read_bytes().splitlines(),1):
                if b'prism-budget ' not in line:continue
                try:events.append(json.loads(line.split(b'prism-budget ',1)[1]))
                except json.JSONDecodeError as err:bad.append({'line':n,'error':str(err)})
            observed+=events
            per_segment.append({'path':p.name,'bytes':p.stat().st_size,'records':len(events),'firstRecord':events[0]['recordId'],'lastRecord':events[-1]['recordId'],'malformed':bad})
        # Separate raw tail diagnostics: never concatenate or normalize these as a repaired activation.
        tail=[]
        for name in ['noctalia.log.1','latest-complete-live-log.raw']:
            tail+=a.read_rotated([source/'B2/inode-reuse-preserved'/name])
        ids={e['recordId'] for e in observed+tail}
        last=max(ids);missing=set(range(1,last+1))-ids
        assert missing==set(range(1290,2386))
        profile=[e for e in tail if e['class']=='profileRender' and e['scope']=='callback' and e['complete'] and e['rendered'] and e['diagnosticsHidden'] and not e['interference']]
        drain=json.loads((source/'B2/final-drain-private.json').read_text());assert drain in tail and drain['eligibleDrain'] and drain['bufferEmpty'] and drain['bufferCount']==0
        summary['activations'][phase]={'strictExit':result.returncode,'completeRecordSet':False,'budgetErrorsComplete':False,'segments':per_segment,'intactPrefixRecords':1289,'prefixValidClasses':{k:{'count':len(values.get(k,[])),'valuesMs':values.get(k,[])} for k in a.CLASSES},'prefixLaunch':a.pairs(prefix),'missingRecordRangeInclusive':[1290,2385],'missingRecordCount':len(missing),'knownUniqueRecords':len(ids),'latestRecord':last,'tailRanges':[[3492,4597],[4598,4632]],'tailProfileRenderDiagnostics':profile,'finalDrainRecord':drain['recordId'],'finalDrainValid':True,'limitations':'Third archive overwrote an earlier inode occurrence, appears before 2386..3491 in manifest and ends with malformed fragment after last complete record3779. Prefix/tail diagnostics are not a repaired complete activation.'}
stamps=[json.loads(line) for line in (source/'phases-private.jsonl').read_text().splitlines()]
assert len({s['clockOrigin'] for s in stamps})==1
by={s['phase']:s['seconds'] for s in stamps}
summary['duration']={'occupancySeconds':by['occupancy-end']-by['occupancy-start'],'setupSeconds':by['setup-end']-by['setup-start'],'restoreSeconds':by['restore-end']-by['restore-start'],'activations':{},'handsWindowSeconds':sum(s['seconds']-by[s['phase'][:-3]+'start'] for s in stamps if '-hands' in s['phase'] and s['phase'].endswith('-end')),'handsMeaning':'Prompt/wait windows, not actual active hands time.','estimatorReady':False,'estimatorLimitations':['No analysis-end phase stamp','C2 Q action lacks profileRender','B2 capture missing 1096 records; no complete matched pilot'],'estimateMinutes':None}
for phase,_ in phases:
    summary['duration']['activations'][phase]={k+'Seconds':by[phase+'-'+k+'-end']-by[phase+'-'+k+'-start'] for k in ['reloadExpand','diagnostics','releaseRestore','profileRoundTrip']}
summary['limitations']=['Only one cold/release per activation and one launch/control each in block1; n>=5 acceptance coverage absent','C2 has one profileRender (P), Q render absent; canonical verification is not a render sample','B2 corrupted/incomplete raw stream; formal whole-pilot budget count unknown','No keep/revert, causal scheduling claim, pooled run or full-size acceptance','Root reports main pointer/plugin/panel, exact runtime/profile/scratch/docs/canonical and prior timer restored; worker did not mutate host']
(out/'r2-summary-private.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Occupancy seconds',summary['duration']['occupancySeconds'],'minutes',summary['duration']['occupancySeconds']/60)
print('B2 missing 1096 records; whole-pilot inconclusive/accepted=false/return_to_design=true; no estimator')

# Preserve separate raw diagnostics and record estimator gaps without repairing B2.
summary=json.loads((out/'r2-summary-private.json').read_text());seen={}
for name in ['segment-66319-4462703.raw','segment-66319-4462537.raw','inode-reuse-preserved/noctalia.log.1','inode-reuse-preserved/latest-complete-live-log.raw']:
    for line in (source/'B2'/name).read_bytes().splitlines():
        if b'prism-budget ' not in line:continue
        try:e=json.loads(line.split(b'prism-budget ',1)[1])
        except json.JSONDecodeError:continue
        if e['class']=='profileRender' and e['scope']=='callback':
            if e['recordId'] in seen:assert seen[e['recordId']]['event']==e
            else:seen[e['recordId']]={'event':e,'firstFoundIn':name}
summary['activations']['B2']['separateRawProfileDiagnostics']=list(seen.values())
saved=json.loads((source/'prism-saved-private.json').read_text());post=json.loads((source/'post-resume-private.json').read_text())
assert post['runtime']['active']['profile']==saved['runtime']['active']['profile'] and post['runtime']['scratch']==saved['runtime']['scratch'] and post['documents']==saved['documents']
for phase,_ in phases:
    for file in ['restored-test-private.json','final-reference-private.json']:
        j=json.loads((source/phase/file).read_text());assert j['runtime']['active']==saved['runtime']['active'] and j['runtime']['scratch']=={} and j['documents']==saved['documents'] and j['canonical']==saved['canonical']
    q=json.loads((source/phase/'profileQ-private.json').read_text());assert q['runtime']['active']['profile']==saved['pair']['Q'] and q['runtime']['scratch']=={} and q['canonical']==saved['profiles'][saved['pair']['Q']]
summary['restoration']={'savedProfile':'dark-wish-ii','savedScratchKeys':0,'rawProfileBaseDocumentsEqual':True,'perActivationRestoredCanonicalEqual':True,'eachQSnapshotCanonicalEqual':True,'postResumeProfileScratchDocumentsEqual':True,'wallpaperChangedAfterResume':post['runtime']['active']['wallpaper']!=saved['runtime']['active']['wallpaper'],'rootReportedPointerPluginPanelTimerRestored':True}
measured={phase:v['intervals'] for phase,v in summary['activations'].items() if phase!='B2'}
measured['B2']=a.intervals(json.loads((out/'B2-prefix-private.json').read_text()))
draft={'setupSeconds':summary['duration']['setupSeconds'],'restoreSeconds':summary['duration']['restoreSeconds'],'analysisSeconds':None,'activations':[],'launchPairSeconds':[],'controlPairSeconds':[]}
for phase,v in summary['duration']['activations'].items():
    draft['activations'].append({'activation':phase,'reloadExpandSeconds':v['reloadExpandSeconds'],'coldPairSeconds':next(x['seconds'] for x in measured[phase] if x['class']=='coldPairInterval'),'releaseRestoreSeconds':v['releaseRestoreSeconds'],'profileRoundTripSeconds':v['profileRoundTripSeconds'] if phase in ('B1','C1') else None})
    for interval in measured[phase]:
        if interval['class']=='pairInterval':draft['controlPairSeconds' if interval['pairId'].endswith('-control') else 'launchPairSeconds'].append(interval['seconds'])
summary['duration']['estimatorObservedDraftOnly']=draft
summary['duration']['estimatorLimitations']=['analysisSeconds missing: analysis-start is last stamp, no clean analysis-end; current diagnosis/correction time is not clean full-run analysis duration','activations[2].profileRoundTripSeconds lacks successful Q profileRender despite 559.988s observed owner-action window','activations[3].profileRoundTripSeconds action window exists and two separate raw profile spans remain, but 1096 missing records prevent complete activation/gate certification','Other scalar phase durations, all four coldPairInterval spans, two launchPairInterval spans and two controlPairInterval spans are preserved; prompt/wait windows are not actual hands time or proof of future throughput','B2 releaseRestoreSeconds is a recorded owner-action window with independently verified scratch/canonical restoration, but incomplete callback evidence cannot supply full acceptance coverage']
(out/'r2-summary-private.json').write_text(json.dumps(summary,indent=2)+'\n')
print('r2 restoration/canonical/Q snapshots verified; explicit null analysis/C2-profile/B2-profile estimator fields; no estimator called')
