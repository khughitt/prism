# Fixed B1 → C1 → C2 → B2 pilot — controller only

Prepared only; no host action or live latency verdict. Approximately ten minutes is
an initial permission estimate, not a measured prediction or cutoff. Root owns the
fresh permission, all IPC, pointer mutations, runtime writes, phase prompts and
restoration. No nested host is configured in this repository. Fake calibration is
not host acceptance. The controller confirmed the scoped review of a89fd28 clean. Copies from 8911851
are superseded, calibration-only and must not be installed. Final copies below
use a89fd28 instrumentation; live installation still requires fresh permission.

Suggested owner permission prompt:
“May I use the desktop for an approximately ten-minute pilot? I will temporarily
clear your freshly saved scratch edits, load four isolated Prism runtimes in
baseline/candidate/candidate/baseline order, ask you to expand all twelve rack
cards after each reload, run one cold sample each, ask for one two-second slider
drag/release and its Revert edit and one aquamarine→Aurora→aquamarine cycle per
runtime, and run one launch/control pair on the first baseline and candidate. I
will analyze the pilot and restore the original plugin, exact saved profile and
scratch, preserving any newer wallpaper. This small pilot cannot accept the
candidate; a longer run needs separate permission based on its measured duration.”

From the main checkout, set the explicit CLI and private preparation directory:

```sh
export PRISM_TASK3_REPO="$(realpath .worktrees/panel-budget)"
CLI="$PRISM_TASK3_REPO/bin/prism"
PREP=/tmp/prism-budget-task3-prep
SCRIPTS="$PREP/frozen-task2"
LOG="${XDG_CACHE_HOME:-$HOME/.cache}/noctalia/noctalia.log"
PLUGIN="${XDG_DATA_HOME:-$HOME/.local/share}/noctalia/plugins/prism"
command -v prism
test ! -e "$PREP/original-plugin-link-private.txt" && readlink "$PLUGIN" > "$PREP/original-plugin-link-private.txt"
cat "$PREP/original-plugin-link-private.txt"
```

The shared `prism` launcher was observed to resolve outside the worktree; never
repoint it. The original plugin link resolves to the main checkout's
`integrations/noctalia-plugin`. Save the literal `readlink` output privately before
changing it; never overwrite this original pointer record between activations.
Each pointer mutation gets a task note naming what/from/to/restore at that moment.
Do not use shared launching/config/service pointers for the CLI.

Take a monotonic phase stamp before and after each controller/owner phase, with
explicit hands-on intervals as well as occupancy intervals. Use one host origin;
never subtract these host stamps from Luau `os.clock` stamps:

```sh
export PRISM_PHASE_ORIGIN="host-monotonic:$(cat /proc/sys/kernel/random/boot_id)"
stamp() {
  python3 -c 'import os,json,sys,time; print(json.dumps({"clockOrigin":os.environ["PRISM_PHASE_ORIGIN"],"phase":sys.argv[1],"seconds":time.monotonic()}))' "$1" >> "$PREP/phases-private.jsonl"
}
```


After fresh desktop/setup permission, take a fresh locked snapshot:

```sh
stamp occupancy-start
stamp setup-start
node "$PREP/state.mjs" snapshot "$PREP/live-saved-private.json"
"$CLI" describe --json > "$PREP/live-describe-private.json"
```

Inspect that snapshot before clearing. Require saved active profile P=aquamarine,
eligible=true, both changed-key lists longer than half the canonical parameter
count, all raw profile/base bytes present, and CLI model canonical values equal
saved.canonical. If state changed, stop and recheck/reselect with the owner; the old
seven-key scratch list is not setup authority. Reconfirm `glass.inactive.roughness`
is an unedited visible enabled release slider in this fresh snapshot/model.
Under computed P with no scratch, preflight verified glass.enabled=true,
glass.focusSplit=true, Backdrop/refraction bypass=false, unfocused ior=1.16>1,
no bypassed source attenuating Backdrop, no card requirement and no ui.when gate.
It is the Backdrop card’s unfocused Blur mix cell with effectiveDrag=release.
Reverify those conditions against the actual cleared model before prompts. Current
preflight recommends 0.21→0.23, then its own **Revert edit** button, not CLI `set`
back to 0.21. Both directions differ on 51/83 values in the present preflight.

The write helper requires a deliberate controller-only approval environment:

```sh
PRISM_TASK3_APPROVED=yes node "$PREP/state.mjs" clear "$PREP/live-saved-private.json" > "$PREP/clear-private.json"
"$CLI" apply --json > "$PREP/clear-apply-private.json"
```

Wait for command completion and drain, then `stamp setup-end`, before any snapshot comparison or pointer
change. `clear` guards exact semantic and raw runtime, every profile/base byte,
active P and eligibility; it writes scratch with existing `writeScratch` under
`withLock`. Do not switch profiles with test scratch present: explicit profile
selection can fold it into the outgoing profile document. Returning an original
redundant scratch value through CLI `set` loses it; never do that.

For each A in B1,C1,C2,B2, stamp A-reloadExpand-start/end,
A-releaseRestore-start/end, A-profileRoundTrip-start/end, and hands-start/end
around each owner interaction. Stamp analysis and final restore boundaries and
occupancy-start/end. Setup starts before the live snapshot, not after the example
above; use the example commands in the actual phase order.

Before every swap, freeze the outgoing full capture, restore P and empty test
scratch/canonical reference, and verify final drain while the outgoing probe still
runs. A failed drain stops sampling; never change the pointer first. Use the new
reviewed Task2 readiness/drain record schema, including zero buffered records,
queue idle, no describe, drag, pending render/pair/sequence/refresh flags and all
expected expanded device ids. Preserve startup separately from naturally warm
readiness. The owner confirms each phase completed before a swap, including C1→C2.
The amended schema supplies `class=ready` with readyEligible=true before cold setup,
and `class=drain` with eligibleDrain=true after the final idle flush. Check
queueIdle=true; queuePendingCount=0; queueInFlight=false; describeRunning=false;
dragEmpty=true; renderPending=false; refreshPending/refreshAfterDrag/
describeInvalidated/selectionPending=false; modelReady/open=true;
errorText=false, help=false; allRackExpanded=true; sorted expandedIds==rackIds==
fresh expected ids. At ready, pairEmpty=true and sequencePhase=setup; at drain,
pairEmpty=true, comparisonCallbacksComplete=true, sequenceComplete=true,
bufferEmpty=true and bufferCount=0. Also verify currentProfile=P and external
locked canonical/scratch reference. Startup requires initialRenderPending=false,
initialPairEmpty=true, initialModel/Structure/Memo/Drag/QueueEmpty=true and
initialEnqueued=0. Readiness is observer work outside timed target callbacks; do
not count ready/drain/observerSnapshot as target timings.

```sh
noctalia msg plugins panel-close khughitt/prism
noctalia msg plugins disable khughitt/prism
# COPY is the selected literal B1/C1/C2/B2 root from identities below.
FROM="$(readlink "$PLUGIN")"
tasks note prism-4ba651 "host pointer: Noctalia prism link from $FROM to $COPY/plugin; restore literal original-plugin-link-private.txt"
test -L "$PLUGIN"
ln -sfn "$COPY/plugin" "$PLUGIN"
test "$(readlink -f "$PLUGIN")" = "$(realpath "$COPY/plugin")"
python3 "$SCRIPTS/integrity-check.py" --copies "$(dirname "$COPY")" \
  --baseline-identity "$SCRIPTS/baseline-identity.json" \
  --candidate-identity "$SCRIPTS/task-1-candidate-identity.json" \
  --model "$PREP/live-describe-private.json"
# Exact transformed plugin hashes must also match copies-portable.json; command below.
# Set A to the next literal activation name; save offset only AFTER outgoing disable.
mkdir -p "$PREP/live/$A"
python3 "$PREP/logs.py" start "$LOG" "$PREP/live/$A/capture.json"
noctalia msg plugins enable khughitt/prism
# Wait for completion/export readiness, then:
noctalia msg plugins panel-open khughitt/prism
python3 "$PREP/logs.py" collect "$PREP/live/$A/capture.json"
```

Incoming log offsets are saved after outgoing disable completes and before enable/open;
never include outgoing callbacks in the next activation’s parser input.
The reviewed builder uses fresh activation nonces per block/copy. Reject old/missing
nonce, variant/commit/hash mismatch, missing initial reset state or unexpanded ids.
Confirm current P, empty scratch and exact block canonical reference under lock.
Fresh snapshot device ids are backdrop, distortion, refraction, fringing,
directionalBlur, saturation, noise, tint, aurora, reflection, edgeHighlight,
iridescence. Stop on any independent wallpaper/profile/reference change; do not
silently absorb the change into one variant. Do not use warm opening/expansion as cold.

Minimal owner phase prompts, once per activation:

1. “This is [B1/C1/C2/B2]. Expand every rack card, then say ready.” Verify identities,
   readiness and reference; click **Sample diagnostics** once. It hides its control,
   emits readiness before timed work, runs exactly one cold pair and (B1/C1 only)
   one launch plus one control. Wait for finite sequence completion and final drain.
2. “Drag Unfocused blur for about two seconds to a different value, release, then
   wait for me.” Stamp prompt/action and real write/describe/deferred completion.
   After drain: “Click that slider’s Revert edit, then wait.” Verify scratch empty,
   canonical P reference and another completed write/describe/deferred.
3. “Select Aurora, wait for me; then select aquamarine and wait.” Both switches are
   real panel profile actions. Verify both changed canonical directions, mark their
   describes/profile renders explicitly and drain. Confirm phase complete.

Collect after every phase and before swaps:

```sh
python3 "$PREP/logs.py" collect "$PREP/live/$A/capture.json"
```

Collector archives by device/inode from saved offset with no fixed tail. Repeated
collection is idempotent. It refuses truncation, lost inode or more than one
rotation between collections; stop and analyze retained segments before retrying.
Collect often enough that `.1` is still the outgoing inode. Keep first and final
records. Parse each activation’s ordered raw segments with its own identity;
combine all four captures only after verifying order and identity. Existing parser
requires the observed host budget-error count, never an assumed zero:

```sh
python3 "$SCRIPTS/analyze.py" --log FIRST_RAW --log NEXT_RAW --offset 0 \
  --identity B1_IDENTITY --identity C1_IDENTITY --identity C2_IDENTITY \
  --identity B2_IDENTITY --budget-errors OBSERVED_COUNT --output "$PREP/pilot-verdict-private.json"
```

List every raw segment in capture/creation order; omit NEXT_RAW only if none.
Use callback-scope target lists; nested cold describes do not enter changed-describe
or deferred classes. Pair reports keep controls and completion-state groups separate,
invalid raw records/reasons preserved. n=1 stays **inconclusive**, accepted=false,
return_to_design=true; no latency or scheduling conclusion follows from preparation.

Construct `measured-pilot-private.json` with the existing estimator’s exact fields:
setupSeconds, restoreSeconds, analysisSeconds; activations in B1/C1/C2/B2 order,
each with reloadExpandSeconds/coldPairSeconds/releaseRestoreSeconds/
profileRoundTripSeconds; launchPairSeconds and controlPairSeconds lists from
accepted `pairInterval` records, including command waits. Read coldPairSeconds
from each `coldPairInterval`, using only that record’s Luau clockOrigin.
Controller/owner phase differences come only from the host monotonic origin.
Record actual pilot total occupancy and hands time separately. No null value,
fixture duration, or guessed interval is a measured input.

```sh
python3 "$SCRIPTS/analyze.py" --pilot "$PREP/measured-pilot-private.json" > "$PREP/full-estimate-private.json"
```

A fixture self-check yields 9 minutes (416 seconds before the named 25% allowance,
520 after it). That fixture is not a live estimate. The actual full-session request
must name measured pilot result and derived duration, 20 cold renders, 20 releases
plus restores, 24 profile switches, ten launch pairs and ten controls, four reloads,
analysis and exact restoration. A retry or extension needs fresh permission.

Before parking/stopping, root waits for every write/describe/diagnostic command,
freezes logs and verifies drain, closes/disables the probe, restores the literal
original link, then restores runtime using the guard (current P + empty scratch):

```sh
# Record pointer restoration immediately; ORIGINAL is the saved literal link text.
ORIGINAL="$(cat "$PREP/original-plugin-link-private.txt")"
tasks note prism-4ba651 "host pointer: restore Noctalia prism link from $(readlink "$PLUGIN") to $ORIGINAL"
ln -sfn "$ORIGINAL" "$PLUGIN"
test "$(readlink "$PLUGIN")" = "$ORIGINAL"
PRISM_TASK3_APPROVED=yes node "$PREP/state.mjs" restore "$PREP/live-saved-private.json" > "$PREP/restore-private.json"
"$CLI" apply --json > "$PREP/restore-apply-private.json"
# Verify original link, then re-enable/open main plugin and verify fresh reload.
# Snapshot again, compare profile/base bytes and exact saved scratch/active P;
# latest independent wallpaper is retained and canonical checked for that wallpaper.
host-load --section session
```

Stop on specific profile/base/raw-byte or unexpected test-scratch conflicts without
overwriting unrelated edits. The helper stores raw runtime bytes for diagnostics;
restoration asserts exact runtime values/scratch, not JSON whitespace. Original
profile/base documents are never rewritten by the helper. If newer wallpaper
changes canonical values, report it explicitly; recomputed canonical restoration
is checked against saved original profile/scratch plus the latest wallpaper.

Raw snapshots/logs stay private. For portable logs, `logs.portable` redacts only
transport headers/nonmeasurement lines and asserts every `prism-budget` payload
byte unchanged; it refuses a private prefix in a measurement payload. Raw profile
bytes and wallpaper paths do not belong in attachments. Attach reviewed scripts,
identity manifests, frozen normalized measurement input/output and report through
`tasks attach`. Do not close Task3 without real evidence and its evidence review.

## Final copy identities

Task2 artifact a89fd285a5f104ccfc21d06d2b0234ea55a9efd3 was independently reviewed clean.
Instrumentation SHA256: `9e92f80e44beea68ef3318eba78ada68b2f67140997a202425addc5b6c501e29`.

| Activation | COPY | Nonce | Cold/launch/control counts |
| --- | --- | --- | --- |
| B1 | `/tmp/prism-budget-task3-prep/block1/baseline` | `task3-pilot-final-1-a86c73fb-baseline` | 1/1/1 |
| C1 | `/tmp/prism-budget-task3-prep/block1/candidate` | `task3-pilot-final-1-a86c73fb-candidate` | 1/1/1 |
| C2 | `/tmp/prism-budget-task3-prep/block2/candidate` | `task3-pilot-final-2-6f974d21-candidate` | 1/0/0 |
| B2 | `/tmp/prism-budget-task3-prep/block2/baseline` | `task3-pilot-final-2-6f974d21-baseline` | 1/0/0 |

B1/B2 baseline commit `9bf4e8e920c005f8a4d1666b32b4e1a516856ac2`, panel SHA256
`c265bff9c59004d1c6d4c77e091a21e1273e02f71aea6c11ecb0e47c6de3be79`.
C1/C2 candidate commit `e7384b0d7ab3e8e935cdf0776043839441132af5`, panel SHA256
`1cf22bf94f7881711450871f1d419b35d17dfa34141baf734c98a5cd58580ee7`.
Source six-module hashes and exact transformed plugin hashes live in
`copies-portable.json`; exact raw identities/transform manifests remain at COPY.
Only the attachment CLI path spelling is normalized to the explicit worktree
relative path; all nonce/variant/commit/source hash/count fields are unchanged.

Before enabling each selected copy, verify its exact transformed bytes and identity:

```sh
python3 - "$PREP/copies-portable.json" "$COPY" "$CLI" <<'PYVERIFY'
import hashlib,json,sys
from pathlib import Path
copy=Path(sys.argv[2]);held=next(c for c in json.loads(Path(sys.argv[1]).read_text())['copies'] if c['copy']==str(copy))
actual=json.loads((copy/'identity.json').read_text());expected=held['identity']
assert {k:v for k,v in actual.items() if k!='cli'}=={k:v for k,v in expected.items() if k!='cli'}
assert actual['cli']==str(Path(sys.argv[3]).resolve())
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (copy/'plugin').iterdir()}==held['pluginSha256']
print('PASS selected copy identity and exact plugin bytes')
PYVERIFY
```
