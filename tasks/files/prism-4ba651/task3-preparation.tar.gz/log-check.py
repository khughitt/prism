import tempfile,json
from pathlib import Path
from logs import start,collect,portable
with tempfile.TemporaryDirectory(prefix='prism-log-check-') as tmp:
    root=Path(tmp);log=root/'noctalia.log';manifest=root/'capture.json'
    log.write_bytes(b'old ignored log\n');start(log,manifest)
    first=b'prism-budget {"activationNonce":"fresh-B1","recordId":1}\n'
    with log.open('ab') as f:f.write(first)
    paths=collect(manifest)
    assert b''.join(p.read_bytes() for p in paths)==first,'first startup record must be collected from saved offset'
    log.rename(root/'noctalia.log.1');second=b'private /home/example/secret\nprism-budget {"activationNonce":"fresh-B1","recordId":2}\n';log.write_bytes(second)
    paths=collect(manifest);assert b''.join(p.read_bytes() for p in paths)==first+second
    assert b''.join(p.read_bytes() for p in collect(manifest))==first+second,'collection must not duplicate records'
    cleaned=portable(first+second,['/home/example'])
    assert b'/home/example' not in cleaned and first in cleaned
    try:portable(b'prism-budget {"private":"/home/example"}\n',['/home/example'])
    except AssertionError as err:assert 'payload' in str(err)
    else:raise AssertionError('private measurement payload must refuse attachment, not mutate identity')
    log.write_bytes(b'')
    try:collect(manifest)
    except AssertionError as err:assert 'truncated' in str(err)
    else:raise AssertionError('copytruncate must refuse rather than lose records')
    log.write_bytes(second);log.unlink()
    try:collect(manifest)
    except AssertionError as err:assert 'missing' in str(err)
    else:raise AssertionError('lost inode must refuse rather than silently reset offset')
print('PASS log calibration: first activation offset, rename rotation, exact bytes/order, repeat no duplicates, missing inode/copytruncate refusal, portable preserves every measurement payload byte')
