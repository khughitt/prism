import json,sys
from pathlib import Path

def save(manifest,state):
    temp=manifest.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(manifest)

def start(log,manifest):
    log=Path(log);manifest=Path(manifest);assert not manifest.exists(),'refuse to overwrite capture manifest'
    stat=log.stat();save(manifest,{'log':str(log),'current':{'dev':stat.st_dev,'inode':stat.st_ino,'offset':stat.st_size},'segments':[]})

def collect(manifest):
    manifest=Path(manifest);state=json.loads(manifest.read_text());log=Path(state['log']);held=state['current']
    matches=[p for p in log.parent.glob(log.name+'*') if p.is_file() and (p.stat().st_dev,p.stat().st_ino)==(held['dev'],held['inode'])]
    assert len(matches)==1,'saved log inode missing or ambiguous; stop, preserve capture and investigate rotation'
    # shortcut: collect before a second rotation; refuse and reconcile archived logs if polling falls behind.
    old=matches[0];assert old==log or old==log.with_name(log.name+'.1'),'multiple rotations between collections; stop before dropping an intervening segment'
    def read(file,cursor):
        with file.open('rb') as stream:
            import os
            stat=os.fstat(stream.fileno());assert (stat.st_dev,stat.st_ino)==(cursor['dev'],cursor['inode']),'log rotated during open; retry collection'
            assert stat.st_size>=cursor['offset'],'log truncated; stop without resetting offset'
            archive=manifest.parent/f"segment-{cursor['dev']}-{cursor['inode']}.raw"
            if not any(s['path']==archive.name for s in state['segments']):
                state['segments'].append({'path':archive.name,'dev':cursor['dev'],'inode':cursor['inode'],'startOffset':cursor['offset']})
            start=next(s['startOffset'] for s in state['segments'] if s['path']==archive.name)
            stream.seek(start);data=stream.read(stat.st_size-start)
            assert len(data)==stat.st_size-start,'log truncated during read'
            archive.write_bytes(data)
            cursor['offset']=stat.st_size
    read(old,held)
    live=log.stat()
    if (live.st_dev,live.st_ino)!=(held['dev'],held['inode']):
        assert old!=log,'log rotated while collecting; preserve raw capture and investigate before proceeding'
        held={'dev':live.st_dev,'inode':live.st_ino,'offset':0};state['current']=held;read(log,held)
    save(manifest,state)
    return [manifest.parent/s['path'] for s in state['segments']]

def portable(data,prefixes):
    marker=b'prism-budget ';before=[line.split(marker,1)[1] for line in data.splitlines() if marker in line]
    lines=[]
    for line in data.splitlines(keepends=True):
        header,sep,payload=line.partition(marker)
        for prefix in prefixes:header=header.replace(prefix.encode(),b'<private>')
        lines.append(header+sep+payload)
    result=b''.join(lines);assert [line.split(marker,1)[1] for line in result.splitlines() if marker in line]==before
    assert all(prefix.encode() not in result for prefix in prefixes),'private prefix inside measurement payload; preserve raw and stop before attaching'
    return result

if __name__=='__main__':
    if sys.argv[1]=='start':start(Path(sys.argv[2]),Path(sys.argv[3]))
    else:
        assert sys.argv[1]=='collect','use start LOG MANIFEST or collect MANIFEST'
        print('\n'.join(str(p) for p in collect(Path(sys.argv[2]))))
