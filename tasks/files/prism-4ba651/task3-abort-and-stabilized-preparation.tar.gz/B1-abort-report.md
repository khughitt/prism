# Aborted B1 pilot — partial evidence

Only B1 ran. Independent wallpaper rotation changed the reference during its
release phase; root stopped and completed restoration before any new environment
change. The strict final parser exited 0 on all three complete archived segments
and exactly reproduced the original frozen verdict. No line was discarded in
final analysis. The controller's live monitor alone tolerated a partial final
transport line; its monitoring rule was not substituted for the strict parser.

`comparison=inconclusive`, `accepted=false`, `return_to_design=true`.
Exploratory baseline callback elapsed times: cold 17.958679 ms (n=1),
release 19.539410 ms (n=1), dirty drag ticks n=34
(median 7.445245, maximum 9.778421 ms).
Changed-describe and following deferred-render lists have four callbacks each;
they are not a completed matched collection under the interfered reference.
Profile-render has no samples. C1, C2 and B2 never started. The controller observed
zero budget errors; the parser was given that explicit observed count.

The single valid pending-state launch pair has immediate/frame difference
18.046922 ms; its single valid done-state control has difference 3.392931 ms.
Both groups are n=1/primary=false. These are separate exploratory observations,
not matched evidence for a token gain, command effect, scheduling hypothesis,
regression, keep or revert decision. Callback os.clock is elapsed time, not
measured thread CPU or GC duration. A cold n=1 result cannot accept or compensate
for release, and the candidate remains unaccepted.

Host-monotonic occupancy was 2043.468 seconds
(34.06 minutes), versus the initial approximate
ten-minute pilot permission estimate. Setup 227.915s,
B1 reload/expansion 364.612s, diagnostic owner/
settling window 337.586s, release/revert/interference
window 1110.362s, final Prism restoration
2.994s. Logged hands-labelled expansion/release/revert
windows total 1234.611s;
these include waits, so they are not measured active hands time. The analysis-end
stamp is absent. The cold interval was 0.034452s, launch interval 0.221722s and control
interval 0.021175s within their own Luau origin, including command completion.
Never subtract these from host-monotonic timestamps.

A full four-activation estimate cannot be computed: three activations, all profile
round trips and a completed analysis duration are missing. No durations are guessed,
no single B1 pace is multiplied across the missing phases, and no estimator JSON
with invented fields is emitted. Read this partial result before a retry; it already
shows that desktop occupancy cannot safely be promised as an actual ten minutes.

Restoration was verified against saved baseline/restore/snapshot: profile
`aquamarine2`, exact 12 owner scratch values, raw profile/base document bytes and
recorded canonical values. Latest independent wallpaper was preserved. Root reports
original main plugin pointer restored, original panel closed/plugin enabled and
no session process. Portable raw-log redaction changes only transport/nonmeasurement
text; every prism-budget payload byte is asserted unchanged. Original private
segments, baseline, phases and restoration files remain unmodified.

Follow-up preparation: owner requested wallpaper rotation pause for the retry and
resume after exact Prism restoration. Prepare a fixed wali-rotate.timer guard;
root reviews it and obtains fresh retry permission before stop/start. No causal
performance fix or further production code follows from this incomplete run.
