# Task 3 preparation — incomplete, controller host gate

Status: BLOCKED on root’s independent rotation-guard review and fresh retry
permission. The approved first run stopped after B1 due to wallpaper interference;
root completed exact restoration before this preparation. No worker live action.
Task2 source remains frozen and clean-reviewed; Task3 remains incomplete. This is preparation, not Task 3 completion.
No live Noctalia IPC, focus/window action, screen capture, pointer swap, real
runtime/scratch write or production code change occurred. The controller owns
fresh desktop/setup permission, live phases, swaps, restoration and final evidence.
The measurement child and its parents remain open. Candidate remains unaccepted;
no live keep/revert, latency, scheduling or acceptance verdict exists.

## Prepared artifacts and authority

Private preparation root: `/tmp/prism-budget-task3-prep` (mode 0700). Runtime/raw
profile/base bytes, owner scratch and wallpaper paths remain private there. The
portable preflight summary excludes owner keys and raw bytes. Fresh snapshots
must be retaken after permission; present snapshots are read-only preflight only.

Frozen source: baseline `9bf4e8e920c005f8a4d1666b32b4e1a516856ac2`, candidate
`e7384b0d7ab3e8e935cdf0776043839441132af5`. The explicit worktree CLI is
`.worktrees/panel-budget/bin/prism`; the shared CLI launcher was verified to
resolve outside this worktree and was left unchanged. The original plugin link
still resolves to the main checkout's `integrations/noctalia-plugin`; literal
link text was saved privately. No configured nested plugin host was found in the
repository. Lua fake checks cannot supply in-host acceptance.

Fresh locked preflight uses `withLock`, `readRuntime`, `loadStore`, `loadLayers`
and the existing canonical resolver. P=aquamarine and Q=Aurora differ on 51/83
canonical values with empty test scratch in both directions, improving on the
older 50/83 seed. All raw profile/base documents and canonical values are saved.
The current owner scratch has seven keys; their identities are kept private.

The recommended release slider is `glass.inactive.roughness` (Unfocused blur),
0.21→0.23 then its own Revert edit. It was unedited in the fresh snapshot. Under
computed P with scratch cleared, glass and focus split are enabled, Backdrop and
refraction are not bypassed, unfocused ior 1.16>1, no bypassed source attenuates
Backdrop, no card requirement/UI gate closes it, and effectiveDrag is release.
It is Backdrop's unfocused Blur mix cell. The controller must verify these same
gates against the actual cleared model before owner prompts.

`state.mjs` is a private fixed-pilot helper. It snapshots exact runtime/scratch,
raw runtime/profile/base bytes and canonical P/Q values under the existing store
lock. Clear refuses unless fresh saved P/eligibility, exact runtime bytes/values
and all document bytes still match. Restore requires P, empty test scratch and
byte-equal documents, then uses the existing runtime write without normalizing
scratch. It preserves the latest wallpaper and checks exact saved scratch and
recomputed canonical values. It never rewrites profile/base documents. Live
write commands require `PRISM_TASK3_APPROVED=yes`, which only the controller sets
after fresh permission. JSON whitespace is captured diagnostically; exact
restoration means runtime values and scratch, plus unchanged raw profile/base
bytes, with the explicitly permitted newer-wallpaper exception.

`logs.py` preserves saved device/inode/offset and archives collected bytes in
rotation order, including first startup/final drain records. It refuses missing
inodes, truncation or more than one rotation between collections. Recollection
is idempotent. Portable normalization changes only transport/nonmeasurement text,
asserts every measurement payload byte unchanged and refuses private prefixes in
measurement payloads. No fixed-length tail, background collector or generic runner
was introduced. Root invokes collection after every phase and before swaps.

`runbook.md` holds the permission prompt, phase prompts, literal original-pointer
capture/restoration, commands, exact startup/readiness/drain gates, empty scratch
and canonical reference guards, host/Luau clock separation and shared estimator
input fields. Setup/profile switching never carries test scratch into a profile.
Incoming offsets are saved after outgoing disable and before enable/open.

## Probe readiness and ordering review

Preparation discovered missing readiness/drain evidence in Task2: startup lacked
render/pair flags, and no record proved expanded ids/current profile, queue/describe/
render/pair/sequence/refresh state or zero buffered records. The controller resumed
Task2 for a scoped correction. Artifact 8911851 added observer snapshots, with
instrumentation SHA256 `85968157946f938c569ea9c23f4b0749b50e01866a112fd98dbcc1538c31966a`.

Four copies of 8911851 were built and calibrated, but the scoped review then found
an Important observer/ordinary-render ordering bug. Those copies are superseded,
calibration-only and not installation-ready. The controller supplied corrected a89fd28 and confirmed a clean scoped review.
The final regenerated copies and checks are recorded below; superseded copies
stay private and cannot be installed.

## Focused RED→GREEN and preparation checks

No production code changed, so its unchanged repository suite was not rerun.
New private helper logic was checked through temporary directories only.

State RED: from the task worktree,
`PRISM_TASK3_REPO="$PWD" node /tmp/prism-budget-task3-prep/state-check.mjs` against
stubbed snapshot returned `AssertionError: snapshot retains redundant scratch
exactly`, actual undefined vs expected original runtime/scratch. Saved in
`state-red.log`. GREEN same command: `PASS state guards: locked exact redundant
scratch snapshot/clear/restore, newer wallpaper preserved, canonical equality,
runtime/profile/scratch/raw-document conflicts refuse before write`.
Calibration additionally refuses ineligible P/Q, wrong saved P and raw-runtime
byte changes before clear. Saved in `state-green.log`.

Log RED: `python3 /tmp/prism-budget-task3-prep/log-check.py` against stub collector
returned `AssertionError: first startup record must be collected from saved offset`.
GREEN same command: `PASS log calibration: first activation offset, rename rotation,
exact bytes/order, repeat no duplicates, missing inode/copytruncate refusal, portable
preserves every measurement payload byte`. Saved in `log-red.log`/`log-green.log`.

Read-only preflight: explicit worktree `bin/prism describe --json` canonical model
matched locked snapshot; 83 parameters, 12 device ids, 23 profiles; pair eligibility
and enabled release-slider assertions passed. Raw model stays private.

8911851-only superseded calibration: reviewed `build.py` built block1 with
cold-pairs 1 / launch-pairs 1 and block2 with cold-pairs 1 / launch-pairs 0. Existing
`integrity-check.py` passed both blocks, exact frozen blobs and reverse transform.
`noctalia plugins lint` passed all four copies (0 errors, 0 warnings), and `luac -p`
passed. Existing readiness fake check passed block2; an exact copy of Task2's
sequence fixture lowered only its trial loop/expected dispositions 10→2 to calibrate
the fixed one-pair block1, passing fresh cold, launch/control reversal, separate
callbacks/frames/command drain, production trees and unchanged model/queue. These
checks do not overrule the independent ordering finding.

Existing `analysis_check.py` passed numeric/MAD/absolute/no-regression/block isolation,
rotation/parser/clock/pair evidence and completion ordering fixtures. Fake block
parser outputs remained `comparison=inconclusive`, `accepted=false`,
`return_to_design=true` with missing classes/n=1. There is no live comparison.

Shared estimator fixture command:
`python3 /tmp/prism-budget-matched-task2/analyze.py --pilot /tmp/prism-budget-matched-task2/pilot-fixture.json`
returned estimateMinutes 9. Its 416 seconds +25%=520 seconds are fixture inputs,
not observed live pilot duration. No actual full-session estimate or latency
verdict is available. Root must measure setup/reloads/cold/real release-restores/
profile cycles/launch-controls/analysis/restoration and report occupancy/hands time.

## Files, self-review, and handoff

Changed repository artifacts: this ignored report and child record through CLI;
private helpers/runbook/calibration logs under the preparation root. No source,
exports, callers, production tests, fixtures, dependency or shared configuration
changes. Portable attachment and child-only preparation commit are being frozen below.
The task remains doing/parked; no task completion is recorded.

Self-review: restoration never uses CLI set for saved scratch; conflict guards
precede writes; incoming capture excludes outgoing runtime markers; rotations stop
before silent data loss; observer/target clocks and timing scopes stay separate;
actual pilot n=1 cannot satisfy original n≥5. Live preparation is explicitly
blocked by clean review and the controller's fresh desktop permission, not a task
closeout. No detached process was launched.

Next controller action: inspect the frozen preparation, obtain fresh approximately-
ten-minute pilot permission, then retake locked snapshot/eligibility and run
B1→C1→C2→B2 with exact restoration. No live action is part of this assignment.


## Final regenerated preparation after clean ordering review

Root confirmed Task2 a89fd285a5f104ccfc21d06d2b0234ea55a9efd3 independently reviewed
clean. Its instrumentation is
`9e92f80e44beea68ef3318eba78ada68b2f67140997a202425addc5b6c501e29`.
Superseded 8911851 copies moved to private `superseded-8911851/` and cannot be
installed. Final frozen scripts live at `/tmp/prism-budget-task3-prep/frozen-task2`;
all are byte-equal to the amended Task2 scripts, with hashes in copies-portable.json.
Baseline/candidate source commits remain exactly the frozen commits above.

| Activation | Exact private copy | Fresh nonce | Cold/launch/control |
| --- | --- | --- | --- |
| B1 | /tmp/prism-budget-task3-prep/block1/baseline | task3-pilot-final-1-a86c73fb-baseline | 1/1/1 |
| C1 | /tmp/prism-budget-task3-prep/block1/candidate | task3-pilot-final-1-a86c73fb-candidate | 1/1/1 |
| C2 | /tmp/prism-budget-task3-prep/block2/candidate | task3-pilot-final-2-6f974d21-candidate | 1/0/0 |
| B2 | /tmp/prism-budget-task3-prep/block2/baseline | task3-pilot-final-2-6f974d21-baseline | 1/0/0 |

Raw identity.json, exact source/plugin code and transforms remain inside each copy.
Portable manifest normalizes only CLI path spelling to
`.worktrees/panel-budget/bin/prism`; asserts all other identity fields unchanged.
It carries exact transformed plugin byte hashes as well as frozen source hashes.
No machine-specific paths enter attachable code/templates; raw model/profile/runtime
snapshots and generated model Lua stay private. Live collection normalization must
keep every raw measurement payload byte unchanged or refuse attachment.

Final checks, observed exit 0:

- Both `frozen-task2/build.py` calls: six frozen blobs each, identical instrumentation,
  explicit worktree copied argv, reverse transform exact; all four unique nonces
  and cold-pairs 1 / launch-pairs 1 only in block1 were asserted.
- Both `frozen-task2/integrity-check.py` calls with current private describe model:
  exact commits/six source blobs, unchanged endDrag/enqueue/nonpanel modules,
  validation anchors fail early, no deoptimization/tracing/API mutation.
- `timeout 30s lua pilot-self-check.lua block1 model-private.lua frozen-task2/test_encode.lua
  "$PWD/bin/prism" sequence`: PASS one cold pair and one launch/control pair on
  each variant, reverse alternation, separate callback/frame/command drain,
  production trees, no model/queue writes. Fixture copied verbatim from amended
  Task2 except sequence trial count/expected dispositions 10→2 and PASS label.
- `timeout 30s lua frozen-task2/self-check.lua block2 model-private.lua
  frozen-task2/test_encode.lua "$PWD/bin/prism" readiness`: PASS startup/reset,
  dedicated pre-target readiness, exact settled/expanded/profile final drain,
  busy refusal/finite chunks/unique retained records and normal frame precedence.
- Same existing checker with `pending-ready`: PASS ordinary accepted describe
  before diagnostic click renders once in the deferred class, retains the readiness
  request, emits ready before cold decode, then cold renders in the next actual
  frame. Both variants exercised; no full calibration repeated.
- `noctalia plugins lint` over all four plugin copies: 0 errors, 0 warnings.
  `luac -p` over all four panel modules exited 0.
- Frozen shared analyzer parsed each block’s fake calibration logs with fresh exact
  identities and explicit fake-host budget-error count 0. Both outputs remain
  comparison=inconclusive, accepted=false, return_to_design=true with n=1/missing
  classes. They are fake evidence only, not a live verdict.
- Runbook's exact transformed-copy verifier passed all four identities/module hash
  sets and refused a temporarily corrupted cloned panel before enable.

Exact commands, inputs, source identities and output logs accompany the preparation
archive; no production suite rerun was needed because no production source changed.
Independent state/log helpers remain unchanged from their prior RED→GREEN results.
The 9-minute estimator fixture remains a fixture; no measured live pilot duration
or full-session estimate exists. Initial approximately-ten-minute pilot permission
is still required and must explicitly cover temporarily clearing freshly saved
scratch and the restoration/desktop phases described by the runbook.

Self-review found no helper/copy issues. The observer ordering defect belongs to
Task2's corrected artifact and clean review; final copy hashes tie to that artifact.
Task3 remains incomplete, candidate unaccepted, and its parent remains open.
Next root action: inspect frozen preparation, obtain fresh pilot permission, retake
locked snapshot/eligibility, then run B1→C1→C2→B2 with canonical/scratch guards,
identity/ready/drain checks, monotonic timestamps, analysis and exact restoration.
No retry, extended run or additional owner action is authorized by preparation.


Final repository gates before the preparation commit: `tasks check` exited 0 with
no errors or warnings; `just check` exited 0 with empty output. Installed pre-commit
hooks use `.githooks`; no hook bypass. No production suite rerun. Parent/task2 notes
and records belong to root and are excluded from staging. Child remains doing and
will be parked waiting on root's fresh desktop approval, never marked done.

Preparation commit: `6213a86 docs(panel): freeze guarded pilot preparation` contains
only `tasks/prism-4ba651.md` and its portable preparation archive. Parent and Task2
records remain unstaged for root. Archive SHA256:
`67d187bb85ebbbd60b5e2b6386d341a575adad7200832eae57e5470f84e644a7`.
Post-commit `tasks show` confirms child still doing, parked waiting on agent/approval,
no claim, with root's fresh permission and measured pilot as the concrete next action.
`host-load --section session`: nothing left running. No process or check continues.
No live store/desktop action, measured latency, acceptance or full-session duration
is implied by this preparation commit. The original Task 6 and Task3 remain open.


## 2026-10-12 approved-pilot adaptation

Owner's fresh Yes authorizes the same four-phase pilot. Before any write/IPC, root
found current active profile aquamarine2, 12 owner scratch keys and 24 profiles.
The previous fixed aquamarine guard correctly refused. Root ruled and announced
P=aquamarine2, Q=Aurora to keep the same eight profile switches without a setup
switch. This is a literal fixed-pilot adaptation, not a configurable framework.

Changed only private state helper/temporary fixture profile names, current runbook,
portable preflight summary and child evidence archive. Root’s preliminary
`/tmp/prism-budget-task3-prep/live-saved-private.json` was never overwritten or
mutated. Worker took a new read-only locked snapshot at
`/tmp/prism-budget-task3-prep/live-aquamarine2-worker-private.json`; root takes a
fresh authoritative `/tmp/prism-budget-task3-prep/live-aquamarine2-saved-private.json`
with amended helper immediately before clear/apply. Raw owner/profile/runtime/model
bytes remain private.

P/Q empty-scratch canonical values differ on 50/83 values in both directions.
The explicit worktree CLI describe matched the locked snapshot, with 83 parameters,
12 cards and 24 profiles. Today’s scratch is excluded when evaluating cleared-P
gates, and its exact 12-key identity map remains private.

Today’s roughness is owner-edited, so it is excluded. Selected replacement:
`glass.inactive.distortionScale`, **Unfocused distortion detail**, in the expanded
Distortion card’s detail row, 0.08→0.10 then its own Revert edit. It is absent from
fresh owner scratch; range 0.01–2, step 0.01, effectiveDrag=release and no ui.when.
Under P with scratch empty, glass/focus split enabled, Distortion bypass false,
unfocused Distortion mix 0.42>0, no card requirement or bypassed attenuating source.
Root verifies those same cleared-model gates before prompting.

Focused changed-helper command:
`PRISM_TASK3_REPO="$PWD" node /tmp/prism-budget-task3-prep/state-check.mjs`.
Observed exit 0 and PASS exact redundant scratch/locked clear/restore, newer-wallpaper
preservation, canonical equality and runtime/profile/scratch/raw-document conflicts.
Only a fixed profile string changed; no new branch/loop or artificial RED added.
`state-aquamarine2-green.log` preserves output. Log helper/test bytes were asserted
unchanged against prior attached archive; their existing RED→GREEN stands, no rerun.

Four unlaunched B1/C1/C2/B2 copies retain exact private identities/nonces, source
commits, source SHA256 and transformed plugin hashes from the clean-reviewed
artifact. All four current hashes and unique nonces were reverified, and fresh
model shape remains compatible. No builder, probe, parser, source code or full
suite changed/reran. The runbook's pre-enable checks use exact source/plugin hashes;
the old integrity fixture's historical 23-profile count is not confused with today’s
24-profile real model. Previous fake n=1 verdict remains inconclusive/unaccepted;
no measurement or timing estimate is claimed.

The same already-approved live scope remains root-owned. Worker stops after the
amended child-only preparation commit and parks waiting on agent for root to inspect
and run the approved pilot, with no new owner permission question. Root owns baseline
snapshot, scratch clear/apply, reloads, owner prompts, logs, real analysis and exact
restoration. Parent tasks remain untouched by this worker.

Adaptation commit: `166b110 docs(panel): adapt approved pilot to current profile`.
Only the child record and `task3-aquamarine2-preparation.tar.gz` are included; root’s
parent records remain unstaged. New archive SHA256:
`937a8edc5443ebce994f300257bda8a8771bf23e49b9380a2c766745e325b85a`.
Fresh `tasks check` and `just check` both exited 0 with empty output/no warnings;
pre-commit hook passed. `tasks show` confirms doing + waiting-on-agent/dependency
park and no claim; root owns the approved live phase. `host-load --section session`
reported nothing left running. No worker check/process continues.


## Aborted B1 analysis and stabilized retry preparation

Full partial report: `/tmp/prism-budget-task3-prep/B1-abort-report.md`. Strict
parser exit 0 on all three complete frozen raw segments reproduced
B1-aborted-verdict-private.json byte-equivalent JSON values. No final event was
removed; partial-line tolerance applied only to root’s live monitor, not analysis.
Portable B1 segments/summary/verdict/phase/stop/restoration artifacts live in
`B1-portable/`, every measurement payload byte unchanged; all original private
files remain untouched. Exact saved profile/12 scratch/raw profile/base documents
and recorded canonical restoration were independently compared. Root restored
main pointer/plugin enabled/panel closed before any retry-environment change.

Exploratory cold 17.958679 ms n=1, release 19.539410 ms n=1, 34 dirty ticks, four
changed describes and four deferred callbacks, no profile renders. One valid
pending launch difference 18.046922 ms and one done control difference 3.392931 ms,
both n=1/nonprimary. Zero budget errors observed by controller. Reference interference,
missing C1/C2/B2 and required sample groups prohibit a matched keep/revert/causal
or scheduling verdict. Comparison inconclusive, accepted=false,
return_to_design=true; candidate unaccepted. Actual occupancy 2043.468s=34.06min;
logged hands windows include waits, not actual active hands time. Missing three
activations, all profile round trips and analysis-end prevents the four-activation
estimator. No guessed timing fields/full-session estimate or acceptance medians.

Owner required rotation pause before retry and resume after completion/abort.
`rotation-guard.py` is fixed to wali-rotate.timer/service and /usr/bin/systemctl.
Snapshot saves prior active/inactive activation boundaries, enablement, fragment/
drop-in identity and exact timer/service unit text. Pause stops only the timer,
asserts inactive/dead and waits naturally for a successful inactive service before
root takes fresh Prism baseline/reference. It never disables, edits config, stops/
kills service or calls walictl. Resume starts timer only if prior active; inactive
stays untouched. It preserves enablement/config and refuses unexpected activation
boundary/config changes before each mutation and during wait. Journaling records
mutation intent before commands and owned paused/resumed state before waiting.
Service wait is 30s with 10s bounded systemctl commands. A failed wait leaves saved
paused/restoration state; an issued command failure is uncertain and requires
root’s read-only reconciliation, never automatic repeat/override. Root verifies
latest wallpaper/Prism exactness again after successful timer resume/service drain.

Real read-only helper snapshot passed timer active/waiting/enabled, service
inactive and both timer intervals 15min. Raw live unit/config/journal remain private;
portable summary carries raw-config hashes. `walictl` resolves through the shared
launcher to dotfiles main; no pointer was changed or program invoked. Actual timer
stop/start requires root’s fresh retry permission and recorded host mutation notes.

Focused RED→GREEN:
`python3 /tmp/prism-budget-task3-prep/rotation-guard-check.py` against stub snapshot
failed `AssertionError: snapshot must save actual timer activation state`.
Implemented fixed guard then passed active stop/start, inactive no-call, natural
busy drain, timeout/recovery, service/stop/start failure, config/enablement and
activation-state conflicts. Further RED intent test failed because command failure
left stage saved; GREEN persists pause-issued/resume-issued before command.
Read-only live smoke then exposed timer-only Unit absent on the service; fake was
corrected to omit it, reproducing `service snapshot must not require timer-only
Unit property`. GREEN uses explicit timer-only config fields and real snapshot
passes. No fallback property defaults or real host mutation. RED outputs in
rotation-red.log, rotation-intent-red.log, rotation-property-red.log; final GREEN
in rotation-green.log. Root receives this helper for an independent scoped review.

New stabilized copies (all old nonces excluded, including previously unstarted):

| Phase | Copy | Nonce |
| --- | --- | --- |
| B1 | /tmp/prism-budget-task3-prep/stabilized/block1/baseline | task3-stable-retry-1-902be183-baseline |
| C1 | /tmp/prism-budget-task3-prep/stabilized/block1/candidate | task3-stable-retry-1-902be183-candidate |
| C2 | /tmp/prism-budget-task3-prep/stabilized/block2/candidate | task3-stable-retry-2-5bc69e24-candidate |
| B2 | /tmp/prism-budget-task3-prep/stabilized/block2/baseline | task3-stable-retry-2-5bc69e24-baseline |

Reviewed frozen builder’s two calls passed exact six-source blobs/reverse transform,
source commits and instrumentation unchanged; finite cold 1 / pairs 1 only block1.
Source/plugin/identity hashes and four unique fresh nonces checked. Four-copy lint
passed 0 errors / 0 warnings. No unchanged probe/fake/full suite rerun. Current private
runbook and tracked plan's corrected Noctalia CLI recipe belong to root and are not
staged by this worker. New focused `stabilized-runbook.md` preserves that corrected
recipe and moves pause/drain before fresh reference, timer resume after exact Prism
restoration, with separate retry capture/phase/snapshot directory and no old data
mutation. It names observed 34.06-minute abort and unknown full duration rather than
reusing ten minutes as measured pace. Timing, matched evidence and acceptance still
require real complete protocol and evidence review.

Next root action: independently review fixed rotation guard, address findings,
obtain fresh stabilized-retry permission, snapshot/pause/drain the timer before
fresh Prism reference, run four new activations with owner phases, drain/restore
Prism, resume only prior-active timer, verify latest wallpaper and exact state,
then resume worker for frozen measured analysis. No further production code or
retry is authorized from preparation itself. Task remains doing, parked waiting
on agent; no parent closure. All worker checks finish before handoff.
