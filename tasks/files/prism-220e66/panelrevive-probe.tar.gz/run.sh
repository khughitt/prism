#!/usr/bin/env bash
# prism-220e66 live probe. Installs probe/panelrevive beside khughitt/prism, runs the
# disable/detect/revive sequence, then removes every trace (trap on EXIT/INT/TERM).
set -u
PROBE=~/.cache/prism-probes/panelrevive
LINK=~/.local/share/noctalia/plugins/panelrevive
SETTINGS=~/.local/state/noctalia/settings.toml
LOG=~/.cache/noctalia/noctalia.log
OUT=~/.cache/prism-probes/out
mkdir -p "$OUT"
cp -p "$SETTINGS" "$OUT/settings.toml.before"
OFFSET=$(stat -c %s "$LOG")
m() { noctalia msg "$@" 2>&1 | sed "s|^|  msg: |"; }
step() { printf '\n== %s %s\n' "$(date +%T.%3N)" "$*"; }

edit_bar() { # add|remove the probe widget in [bar.default].end
  python3 - "$SETTINGS" "$1" <<'PY'
import sys, re
path, mode = sys.argv[1], sys.argv[2]
s = open(path).read()
line = '    "probe/panelrevive:widget",\n'
if mode == "add" and line not in s:
    s = s.replace('    "clock"\n]', line + '    "clock"\n]', 1)
elif mode == "remove":
    s = s.replace(line, '')
open(path, 'w').write(s)
PY
}

cleanup() {
  step cleanup
  m panel-close probe/panelrevive:panel
  edit_bar remove
  m plugins disable probe/panelrevive
  rm -f "$LINK"
  sleep 1
  m config-reload
  sleep 2
  grep -n 'panelrevive' "$SETTINGS" && echo "  WARN: settings still name the probe" || echo "  settings clean of probe"
  diff "$OUT/settings.toml.before" "$SETTINGS" && echo "  settings identical to before" || echo "  settings differ from before (see diff above)"
  tail -c +$((OFFSET + 1)) "$LOG" > "$OUT/log-slice.txt"
  echo "  log slice: $OUT/log-slice.txt ($(wc -l < "$OUT/log-slice.txt") lines)"
}
trap cleanup EXIT
trap 'exit 130' INT TERM

step "A install + enable + place widget"
ln -sfn "$PROBE" "$LINK"
m plugins enable probe/panelrevive
sleep 2
edit_bar add
m config-reload
sleep 3

step "B open panel through the widget (togglePanel, as a click would)"
m plugin probe/panelrevive:widget all toggle
sleep 4

step "C burn the panel past its budget x5"
for i in 1 2 3 4 5; do m plugin probe/panelrevive:panel all burn; sleep 0.3; done
sleep 6

step "D revive from the widget (rewrite panel.luau)"
m plugin probe/panelrevive:widget all revive
sleep 4

step "E close the healthy panel"
m panel-close probe/panelrevive:panel
sleep 2

step "F disable while closed, then open through the widget"
for i in 1 2 3 4 5; do m plugin probe/panelrevive:panel all burn; sleep 0.3; done
sleep 2
m plugin probe/panelrevive:widget all toggle
sleep 5

step "G revive again with the (frozen) panel open"
m plugin probe/panelrevive:widget all revive
sleep 4
