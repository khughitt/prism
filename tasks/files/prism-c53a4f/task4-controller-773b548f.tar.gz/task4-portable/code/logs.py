"""Incremental byte capture. Full integrity belongs to explicit checkpoints."""
import hashlib
import json
import os
import sys
from pathlib import Path


def require(ok, message):
    if not ok: raise AssertionError(message)


def save(manifest, state):
    temp = manifest.with_suffix('.tmp')
    with temp.open('w') as f:
        json.dump(state, f, indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    temp.replace(manifest)


def start(log, manifest):
    log, manifest = Path(log), Path(manifest)
    stat = log.stat()
    state = {'schema':2, 'log':str(log), 'current':{'dev':stat.st_dev, 'inode':stat.st_ino,
             'offset':stat.st_size, 'generation':1}, 'nextGeneration':2, 'segments':[], 'integrityComplete':False}
    # Exclusive creation preserves the activation's original offset.
    with manifest.open('x') as f:
        json.dump(state, f, indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())


def identity(stat): return stat.st_dev, stat.st_ino

def snapshot(stat): return identity(stat) + (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)


class Capture:
    def __init__(self, manifest):
        self.manifest = Path(manifest)
        self.state = json.loads(self.manifest.read_text())
        self.log = Path(self.state['log'])
        self.integrity_complete = False
        self.failed = False
        self.source = self.archive = None
        self.metadata = {}
        try:
            self._structure()
            self._archives()
            self.source = self._source(self.state['current'])
            self._prefix(self.source, self.state['current'])
            self._open_archive()
        except BaseException:
            self.close(); raise

    def _structure(self):
        s, held = self.state, self.state['current']
        require(s.get('schema')==2, 'capture requires schema2')
        require(all(type(held[k]) is int and held[k]>=0 for k in ('dev','inode','offset','generation')) and held['generation']>=1, 'invalid cursor generation/offset')
        segments = s['segments']
        generations = [r['generation'] for r in segments]
        require(generations == list(range(1,len(segments)+1)) and
                held['generation'] in (len(segments),len(segments)+1) and
                s['nextGeneration'] == held['generation']+1, 'invalid segment generations')
        for r in segments:
            require(r['path'] == f"segment-{r['generation']:06d}-{r['dev']}-{r['inode']}.raw", 'invalid segment path')
            require(all(type(r[k]) is int and r[k]>=0 for k in ('generation','dev','inode','bytes','startOffset','endOffset')) and
                    r['endOffset'] == r['startOffset']+r['bytes'], 'invalid segment offsets')
            require(type(r['sha256']) is str and len(r['sha256'])==64, 'invalid segment digest')
        if held['generation'] <= len(segments):
            r = segments[held['generation']-1]
            require((r['dev'],r['inode'],r['endOffset']) == (held['dev'],held['inode'],held['offset']), 'cursor does not match saved segment')

    def _path(self, r): return self.manifest.parent/r['path']
    def paths(self): return [self._path(r) for r in self.state['segments']]

    def _archives(self):
        for r in self.state['segments']:
            p = self._path(r)
            require(p.is_file(), 'archive missing; preserve capture')
            with p.open('rb') as f:
                before=os.fstat(f.fileno()); data=f.read(); after=os.fstat(f.fileno())
            require(snapshot(before)==snapshot(after)==snapshot(p.stat()), 'archive changed during validation')
            digest=hashlib.sha256(data)
            require(len(data)==r['bytes'] and digest.hexdigest()==r['sha256'], 'archive integrity failure; preserve capture')
            if r['generation']==self.state['current']['generation']:self.validated_current_hasher=digest
            self.metadata[p] = snapshot(after)

    def _locate(self, held):
        matches=[p for p in self.log.parent.glob(self.log.name+'*') if p.is_file() and identity(p.stat())==(held['dev'],held['inode'])]
        require(len(matches)==1, 'saved log inode missing or ambiguous; preserve capture')
        require(matches[0] in (self.log,self.log.with_name(self.log.name+'.1')), 'multiple rotations between polls; preserve capture')
        return matches[0]

    def _source(self, held):
        p=self._locate(held); f=p.open('rb')
        try:
            require(identity(os.fstat(f.fileno()))==(held['dev'],held['inode']), 'log rotated during open')
            return f
        except BaseException: f.close(); raise

    def _prefix(self, source, held):
        before=os.fstat(source.fileno())
        require(identity(before)==(held['dev'],held['inode']) and before.st_size>=held['offset'], 'log truncated; preserve capture')
        if held['generation'] <= len(self.state['segments']):
            r=self.state['segments'][held['generation']-1]
            source.seek(r['startOffset']);data=source.read(r['bytes'])
            require(len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256'], 'log prefix changed; preserve capture')
        require(snapshot(before)==snapshot(os.fstat(source.fileno())), 'source changed during checkpoint')
        return before

    def _open_archive(self):
        held=self.state['current'];g=held['generation'];segments=self.state['segments']
        self.hasher=hashlib.sha256()
        if g<=len(segments):
            r=segments[g-1]
            self.hasher=self.validated_current_hasher.copy()
            self.archive=self._path(r).open('ab')
        else:
            r={'path':f"segment-{g:06d}-{held['dev']}-{held['inode']}.raw",'generation':g,'dev':held['dev'],'inode':held['inode'],
               'startOffset':held['offset'],'endOffset':held['offset'],'bytes':0,'sha256':self.hasher.hexdigest()}
            self.archive=self._path(r).open('xb');segments.append(r)
            self.metadata[self._path(r)]=snapshot(os.fstat(self.archive.fileno()))
            save(self.manifest,self.state)

    def _metadata(self):
        for p,expected in self.metadata.items():
            require(p.is_file(), 'archive missing; preserve capture')
            require(snapshot(p.stat())==expected, 'archive integrity metadata changed; preserve capture')
        require(snapshot(os.fstat(self.archive.fileno()))==self.metadata[self._path(self.state['segments'][-1])], 'archive descriptor changed')

    def _append(self, source, held):
        before=os.fstat(source.fileno())
        require(identity(before)==(held['dev'],held['inode']) and before.st_size>=held['offset'], 'log truncated; preserve capture')
        archive_before=os.fstat(self.archive.fileno())
        source.seek(held['offset']);data=source.read(before.st_size-held['offset'])
        require(snapshot(archive_before)==snapshot(os.fstat(self.archive.fileno())), 'archive changed during source read')
        require(len(data)==before.st_size-held['offset'] and snapshot(before)==snapshot(os.fstat(source.fileno())), 'log changed during read')
        r=self.state['segments'][-1]
        require(archive_before.st_size==r['bytes'], 'interrupted archive append')
        if data:
            require(self.archive.write(data)==len(data), 'short archive append');self.archive.flush();os.fsync(self.archive.fileno())
        archive_after=os.fstat(self.archive.fileno())
        require(identity(archive_before)==identity(archive_after) and archive_after.st_size==r['bytes']+len(data), 'archive changed during append')
        self.hasher.update(data);held['offset']+=len(data)
        r.update(bytes=r['bytes']+len(data),endOffset=held['offset'],sha256=self.hasher.hexdigest())
        self.metadata[self._path(r)]=snapshot(archive_after)
        require(snapshot(self._path(r).stat())==snapshot(archive_after), 'archive path changed during append')
        save(self.manifest,self.state)
        return before

    def poll(self):
        require(not self.failed, 'capture already refused; offline investigation only')
        self.integrity_complete=False
        try:
            self._structure();self._metadata();held=self.state['current'];old=self._locate(held)
            outgoing=snapshot(self._append(self.source,held))
            live=self.log.stat()
            if identity(live)!=(held['dev'],held['inode']):
                require(old!=self.log and self._locate(held)==old, 'rotation ambiguous during poll')
                # Keep the snapshot tied to consumed bytes, never absorb a later outgoing write.
                require(outgoing[2]==held['offset'] and snapshot(os.fstat(self.source.fileno()))==outgoing,
                        'outgoing source changed after capture; preserve evidence')
                require(snapshot(self._prefix(self.source,held))==outgoing,
                        'outgoing source changed during seal validation; preserve evidence')
                self._archives()
                require(snapshot(os.fstat(self.source.fileno()))==snapshot(old.stat())==outgoing,
                        'outgoing source changed during seal validation; preserve evidence')
                outgoing_source=self.source;self.archive.close()
                try:
                    held={'dev':live.st_dev,'inode':live.st_ino,'offset':0,'generation':self.state['nextGeneration']}
                    self.state['current']=held;self.state['nextGeneration']+=1
                    self.source=self._source(held);self._open_archive();self._append(self.source,held)
                    require(snapshot(os.fstat(outgoing_source.fileno()))==snapshot(old.stat())==outgoing and
                            identity(self.log.stat())==identity(live), 'outgoing source changed or second rotation during transition; preserve evidence')
                finally:outgoing_source.close()
            else:
                require(old==self.log and identity(self.log.stat())==(held['dev'],held['inode']), 'rotation during poll')
            return self.paths()
        except BaseException:
            self.failed=True;self.integrity_complete=False;raise

    def checkpoint(self, reason):
        require(reason in ('ready','rotation','settled','finish'), 'unknown checkpoint reason')
        require(not self.failed, 'capture already refused; offline investigation only')
        self.integrity_complete=False
        try:
            self._structure();self._metadata();self._archives()
            held=self.state['current'];p=self._locate(held)
            require(p==self.log, 'rotation pending at checkpoint; poll first')
            before=self._prefix(self.source,held)
            require(identity(self.log.stat())==identity(before), 'rotation during checkpoint')
            self._metadata()
            self.integrity_complete=reason=='finish'
            self.state['integrityComplete']=False
            self.state['lastCheckpoint']=reason
            save(self.manifest,self.state)
            return {'integrityComplete':self.integrity_complete,'generations':len(self.state['segments']),'reason':reason}
        except BaseException:
            self.failed=True;self.integrity_complete=False;raise

    def close(self):
        for f in (self.source,self.archive):
            if f is not None and not f.closed:f.close()


# A standalone collect is deliberately an offline full validation, never a live loop.
def collect(manifest):
    c=Capture(manifest)
    try:
        paths=c.poll();c.checkpoint('ready');return paths
    finally:c.close()

def portable(data,prefixes):
    marker=b'prism-budget ';before=[line.split(marker,1)[1] for line in data.splitlines() if marker in line]
    lines=[]
    for line in data.splitlines(keepends=True):
        header,sep,payload=line.partition(marker)
        for prefix in prefixes:header=header.replace(prefix.encode(),b'<private>')
        lines.append(header+sep+payload)
    result=b''.join(lines);assert [line.split(marker,1)[1] for line in result.splitlines() if marker in line]==before
    assert all(prefix.encode() not in result for prefix in prefixes),'private prefix inside measurement payload; preserve raw and stop before attaching'
    return result


if __name__=='__main__':
    if sys.argv[1]=='start':start(Path(sys.argv[2]),Path(sys.argv[3]))
    else:
        require(sys.argv[1]=='collect','use start LOG MANIFEST or collect MANIFEST')
        print('\n'.join(str(p) for p in collect(Path(sys.argv[2]))))
