"""Root-driven card controller. No background polling or implicit host permission."""
import argparse, copy, hashlib, importlib.util, json, math, os, subprocess, sys, time, uuid
from pathlib import Path
HERE=Path(__file__).resolve().parent

def require(ok,why):
    if not ok: raise ValueError(why)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def load(path):return json.loads(Path(path).read_bytes())
def immutable(path,value):
    path=Path(path);raw=encoded(value)
    with path.open('xb') as f:os.chmod(path,0o600);f.write(raw);f.flush();os.fsync(f.fileno())
    return digest(raw)
def atomic(path,value):
    path=Path(path);tmp=path.with_name(path.name+'.'+uuid.uuid4().hex)
    immutable(tmp,value);tmp.replace(path)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
analyze=module('budget_analyze',HERE/'frozen-task2/analyze.py')

def reserve(seconds):
    require(seconds and all(type(x) in (int,float) and math.isfinite(x) and x>=0 for x in seconds),'invalid measured steps')
    result=math.ceil(1.25*sum(seconds));require(result+120<=300,'measured reserve leaves less than120 seconds approval');return result

class Window:
    def __init__(self,started,steps):
        self.stepReserve=reserve(list(steps.values()));self.steps=steps
        self.stamps={'collectorStarted':started};self.invalid=[];self.approval_deadline=None
    def stamp(self,name,now):
        require(name not in self.stamps,'duplicate window stamp')
        require(math.isfinite(now) and now>=max(self.stamps.values()),'window clock/order mismatch')
        self.stamps[name]=now
        if now-self.stamps['collectorStarted']>=2100:self.invalid.append('collector lifetime expired')
        for start,end,cap in [('initialCardIssued','initialCompleteReceived',1200),('recoveryCardIssued','recoveryCompleteReceived',600)]:
            if name==end and now-self.stamps[start]>cap:self.invalid.append(start+' cap exceeded')
        if self.controller_seconds(now)>300:self.invalid.append('controller allowance exceeded')
    def controller_seconds(self,now):
        total=now-self.stamps['collectorStarted']
        for start,end in [('initialCardIssued','initialCompleteReceived'),('recoveryCardIssued','recoveryCompleteReceived')]:
            if start in self.stamps:total-=self.stamps.get(end,now)-self.stamps[start]
        return total
    def valid_reserve(self,remaining,recovery=False):
        names=('recovery','finish') if recovery else ('post','recovery','finish')
        minimum=math.ceil(1.25*sum(v for k,v in self.steps.items() if k in names))
        return type(remaining) in (int,float) and math.isfinite(remaining) and remaining>=minimum
    def can_initial(self,now,remaining):
        return self.valid_reserve(remaining) and not self.invalid and 2100-(now-self.stamps['collectorStarted'])>=1800+remaining and self.controller_seconds(now)+remaining<=300
    def can_issue(self,now,remaining):
        return self.valid_reserve(remaining,True) and not self.invalid and 2100-(now-self.stamps['collectorStarted'])>=600+remaining and self.controller_seconds(now)+remaining<=300
    def request_recovery(self,now,remaining):
        require(self.valid_reserve(remaining,True),'unperformed check reserve missing')
        require('recoveryRequested' not in self.stamps,'one combined recovery only')
        self.stamp('recoveryRequested',now)
        self.approval_deadline=min(self.stamps['collectorStarted']+2100-600-remaining,now+300-self.controller_seconds(now)-remaining)
        require(self.approval_deadline>=now,'no full recovery reservation');return self.approval_deadline
    def approve(self,now,remaining):
        require(self.approval_deadline is not None and now<=self.approval_deadline and self.can_issue(now,remaining),'late approval/full600 unavailable')
        self.stamp('approvalReceived',now)
    def issue_recovery(self,now,remaining):
        require('approvalReceived' in self.stamps and now<=self.approval_deadline and self.can_issue(now,remaining),'recovery packet cannot be shortened')
        self.stamp('recoveryCardIssued',now)

def materialize(manifest,saved,definitions,events,origin_verified):
    """Only the corrected released scalar crosses from probe intent into the oracle."""
    current=saved['pair']['P'];scratch={};operations=[];bindings=[]
    release_ids={op['id'] for op in manifest['operations'] if op['kind']=='release'}
    require(all(e['operationId'] in release_ids for e in events if e['class']=='operationIntent' and e.get('cardId',manifest['cardId'])==manifest['cardId']),'undeclared release intent')
    allowed={p['key'] for p in saved['uneditedNumeric']}
    for op in manifest['operations']:
        kind=op['kind'];expected=copy.deepcopy(saved['profiles'][current])
        if kind=='release':
            key=op['key'];require(key in allowed and key not in scratch,'key not fresh unedited slider')
            intents=[e for e in events if e['class']=='operationIntent' and e['operationId']==op['id']]
            require(len(intents)==1,'missing/duplicate intent');intent=intents[0]
            requests=[e for e in events if e['class']=='operationRequested' and e['operationId']==op['id']]
            ends=[e for e in events if e['class']=='release' and e.get('scope')=='callback' and e.get('callbackId')==intent['releaseCallbackId']]
            require(len(requests)==len(ends)==1,'unbound release intent');request,end=requests[0],ends[0]
            require(request['valid'] is True and request['operationKind']=='release' and request['key']==key and end['operationId']==op['id'],'wrong operation intent')
            require(intent['scope']=='observer' and intent['observer'] is True and intent['callbackId']==0 and intent['key']==key,'wrong key/observer')
            require(request['recordId']<end['recordId']<intent['recordId'] and end['endTimestamp']<=intent['startTimestamp']<=intent['endTimestamp']<=intent['timestamp'],'intent timing/order')
            require(request['acceptGeneration']==end['acceptGeneration']==intent['acceptGeneration'],'stale intent generation')
            refs=[e for e in events if e['class']=='acceptedReference' and e['operationId']==op['id'] and e['valid']]
            require(all(e['recordId']>intent['recordId'] and e['timestamp']>=intent['endTimestamp'] and e['acceptGeneration']>intent['acceptGeneration'] for e in refs),'intent after acceptance')
            text=intent['valueText'];require(isinstance(text,str) and text.strip()==text and text,'bad Queue serialization')
            value=float(text);definition=definitions[key]
            require(type(intent['canonicalValue']) in (float,int) and math.isfinite(value) and value==intent['canonicalValue'],'Queue tostring/canonical disagreement')
            require(definition['type'] in ('int','float') and definition['range'][0]<=value<=definition['range'][1] and (definition['type']!='int' or value.is_integer()),'released value violates frozen definition')
            if value!=expected[key]:scratch[key]=value
            bindings.append({'operationId':op['id'],'recordId':intent['recordId'],'parsedRecordSha256':digest(encoded(intent))})
        elif kind=='restore':
            require(op['key'] in allowed,'wrong restore key');scratch.pop(op['key'],None)
        elif kind=='profile':
            require(not scratch and op['profile'] in (saved['pair']['P'],saved['pair']['Q']) and op['profile']!=current,'invalid profile transition or test scratch')
            current=op['profile'];expected=copy.deepcopy(saved['profiles'][current])
        else:raise ValueError('unknown owner operation')
        expected.update(scratch)
        operations.append(dict(op,expectedReference={'acceptedProfile':current,'acceptedWallpaper':saved['runtime']['active'].get('wallpaper',False),'values':expected,'heldScratchKeys':sorted(scratch)}))
    require(current==saved['pair']['P'] and not scratch,'card does not restore P/test scratch')
    # Gates are determined separately from raw chronology, never copied from accepted describes.
    return {'cardId':manifest['cardId'],'operations':operations,'reference':{'acceptedProfile':current,'acceptedWallpaper':saved['runtime']['active'].get('wallpaper',False),'values':saved['profiles'][current],'heldScratchKeys':[]},'operationGatesComplete':False,'originVerified':origin_verified,'binding':{'manifestSha256':digest(encoded(manifest)),'snapshotSha256':digest(encoded(saved)),'definitionsSha256':digest(encoded(definitions)),'intents':bindings}}

def action_manifest(identity,saved,pilot=False):
    ops=[];counter=identity['coldPairs']+2*identity['launchPairs']
    if identity['stage']=='stage2':
        require(saved['uneditedNumeric'],'no fresh unedited slider')
        key=saved['uneditedNumeric'][0]['key']
        sequence=[{'kind':kind,'key':key} for _ in range(1 if pilot else 5) for kind in ('release','restore')]
        sequence += [{'kind':'profile','profile':saved['pair'][which]} for _ in range(1 if pilot else 3) for which in ('Q','P')]
        for op in sequence:
            counter+=1;ops.append(dict(op,id=f"{identity['cardId']}:action:{counter}"))
    return {'schema':2,'cardId':identity['cardId'],'activationNonce':identity['activationNonce'],'operations':ops}

def owner_card(identity,manifest,saved,recovery=None):
    text=['Wait for Prism controls. Click Sample diagnostics (controls auto-expand). Keep the panel visible for at least5 seconds after the button disappears and controls settle.']
    if recovery:text=['Approved combined recovery: click Recovery diagnostics once, then complete every exact unit below. Replaces: '+', '.join(recovery['replacementFor'])+'.',f"Diagnostic units: cold={recovery['coldPairs']}, launch/control={recovery['launchPairs']}."]
    for op in manifest['operations']:
        if op['kind']=='release':text.append(f"{op['id']}: drag {op['key']} for two seconds, release, and dwell at least2 seconds after release and settlement.")
        elif op['kind']=='restore':text.append(f"{op['id']}: use that slider's own restore; dwell at least2 seconds after settlement.")
        else:text.append(f"{op['id']}: choose {op['profile']}; confirm Prism values change, then dwell at least5 seconds after settlement (including final P).")
    if not manifest['operations']:text.append('No sliders or profile changes.')
    text.append('Confirm once after all actions. Initial card cap20 minutes; separately approved recovery cap10 minutes. Decline any shortened packet.')
    return '\n'.join(text)

def operation_gates(events,manifest,reply_at):
    requests=[e for e in events if e['class']=='operationRequested' and e.get('operationKind') in ('release','restore','profile') and e['cardId']==manifest['cardId']]
    require([e['operationId'] for e in requests]==[op['id'] for op in manifest['operations']],'owner action order/set mismatch')
    previous=None
    for op,request in zip(manifest['operations'],requests):
        field='profile' if op['kind']=='profile' else 'key'
        require(request['valid'] is True and request['operationKind']==op['kind'] and request[field]==op[field],'owner action mismatch')
        if previous:require(request['timestamp']-previous[0]>=previous[1],'dwell too short')
        done=[e for e in events if e['class']=='operationDone' and e['operationId']==op['id']]
        # A lost target remains missing in normalize; owner dwell still has a request endpoint.
        require(len(done)<=1,'duplicate operation completion')
        if op['kind']=='release':
            drags=[e for e in events if e['class']=='input' and e.get('scope')=='callback' and e['timestamp']<request['timestamp'] and (previous is None or e['timestamp']>previous[0])]
            require(drags and request['timestamp']-drags[0]['startTimestamp']>=2,'two-second drag missing')
        previous=(done[0]['timestamp'] if done else request['timestamp'],5 if op['kind']=='profile' else 2)
    if previous:require(reply_at-previous[0]>=previous[1],'final dwell before reply missing')
    settles=[e for e in events if e['class']=='cardSettled' and e['cardId']==manifest['cardId']]
    require(settles and reply_at-settles[0]['timestamp']>=5 if not requests else bool(settles),'diagnostics settled dwell missing')
    return True

class RootHost:
    """Each exact argv requires a fresh, one-use root-controller permit."""
    def __init__(self,root,session):self.root=Path(root);self.session=session
    def invoke(self,action,authorization,arguments):
        auth=load(authorization);now=time.monotonic();boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        require(Path(authorization).stat().st_mode&0o777==0o600 and Path(authorization).stat().st_uid==os.getuid(),'authorization file must be private and owned')
        require(auth.get('approved') is True and auth.get('author')=='root-controller' and auth.get('sessionId')==self.session['sessionId'] and auth.get('runId')==self.session['runId'] and auth.get('bootId')==boot,'fresh root session authorization required')
        permit=next((p for p in auth['permits'] if p['action']==action),None)
        require(permit is not None and permit['arguments']==arguments and 0<=now-permit['issuedAt']<=60 and now<=permit['expiresAt']<=permit['issuedAt']+60,'missing/stale exact action permit')
        token=permit['id'];require(isinstance(token,str) and token and all(c.isalnum() or c=='-' for c in token),'invalid permit id')
        used=self.root/'permits';used.mkdir(mode=0o700,exist_ok=True);immutable(used/token,{'action':action,'permit':permit,'authorizationSha256':digest(Path(authorization).read_bytes())})
        spec=self.session['hostActions'][action];require(spec==arguments,'action argv differs from immutable session')
        if action in ('pointer-swap','pointer-restore'):
            pointer=Path(spec['path']);require(pointer.is_symlink() and os.readlink(pointer)==spec['from'],'plugin pointer conflict; stop without overwriting')
            immutable(used/(token+'-pointer'),{'what':str(pointer),'from':spec['from'],'to':spec['to'],'restore':spec['from'],'how':'fresh authorized pointer operation with inverse literal targets'})
            temp=pointer.with_name(pointer.name+'.'+token);temp.symlink_to(spec['to'])
            try:
                require(pointer.is_symlink() and os.readlink(pointer)==spec['from'],'plugin pointer changed before replacement')
                temp.replace(pointer)
            finally:
                if temp.is_symlink():temp.unlink()
            return {'pointer':str(pointer),'from':spec['from'],'to':os.readlink(pointer)}
        if action in ('finish-authorize','recovery-authorize','checkpoint-authorize','stop-authorize'):return {'authorized':True,'permitId':token}
        result=subprocess.run(spec['argv'],env=os.environ|spec.get('env',{}),capture_output=True,text=True,timeout=spec['timeoutSeconds'])
        immutable(used/(token+'-result'),{'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
        require(result.returncode==0,'host operation failed: '+action)
        return json.loads(result.stdout) if spec.get('json') else {'stdout':result.stdout}

class Controller:
    def __init__(self,root,session,host,clock=time.monotonic):
        require(session['environment'] in ('live','fake-host','synthetic'),'invalid controller environment')
        self.root=Path(root);self.host=host;self.clock=clock;self.session=copy.deepcopy(session)
        immutable(self.root/'session.json',session)
        self.state={'phase':'new','invalid':[],'protocolComplete':False,'stamps':{},'receipts':{},'stepSeconds':{},'sequence':0}
        self.window=None;self.save()
    @classmethod
    def resume(cls,root,host,clock=time.monotonic):
        obj=cls.__new__(cls);obj.root=Path(root);obj.session=load(obj.root/'session.json');obj.state=load(obj.root/'state.json');obj.host=host;obj.clock=clock;obj.window=None
        if obj.state['stamps']:
            obj.window=Window(obj.state['stamps']['collectorStarted'],obj.session['steps']);obj.window.stamps=obj.state['stamps'];obj.window.invalid=obj.state['invalid'];obj.window.approval_deadline=obj.state.get('approvalDeadline')
        return obj
    def save(self):
        if self.window:self.state.update(stamps=self.window.stamps,invalid=self.window.invalid,approvalDeadline=self.window.approval_deadline)
        atomic(self.root/'state.json',self.state)
    def phase(self,*allowed):require(self.state['phase'] in allowed,'wrong controller phase: '+self.state['phase'])
    def invalid(self,reason):
        self.state['invalid'].append(reason);self.state['protocolComplete']=False;self.save();raise ValueError(reason)
    def invoke(self,action,authorization):
        began=time.monotonic()
        try:result=self.host.invoke(action,authorization,self.session.get('hostActions',{}).get(action,{}))
        except BaseException as e:self.invalid(action+': '+str(e))
        self.state['stepSeconds'][action]=time.monotonic()-began;self.state['receipts'][action]=result;self.save();return result
    def control(self,command):
        self.state['sequence']+=1;atomic(self.root/'control.json',{'sequence':self.state['sequence'],'command':command});self.save()
    def prepare(self,authorization):
        self.phase('new')
        if self.session['environment']=='live':
            verify_artifacts(self.session)
            require(type(self.session.get('activationOrdinal')) is int and 1<=self.session['activationOrdinal']<=4,'activation order absent')
            if self.session['activationOrdinal']>1:
                previous=load(self.session['outgoingState'])
                require(previous['phase']=='restored' and previous['protocolComplete'] is True,'outgoing activation not settled/frozen/restored')
                require(self.session.get('referenceSnapshot'),'frozen baseline reference absent')
            gate=module('clock_gate',HERE/'clock-gate.py');proof=load(self.session['sourceProof'])
            require(proof['sessionId']==self.session['sessionId'],'clock proof belongs to another session')
            immutable(self.root/'clock-verified.json',gate.verify(proof,gate.observe(proof),gate.historical(self.session['r2Root'])))
        for action in ('rotation-snapshot','rotation-pause','state-snapshot','state-clear','panel-close','plugins-disable','pointer-swap','collector-launch'):self.invoke(action,authorization)
        self.state['phase']='collector-starting';self.save()
    def collector_started(self,receipt):
        self.phase('collector-starting')
        require(receipt['runId']==self.session['runId'] and receipt['clockOrigin']==self.session['clockOrigin'] and receipt['exitReason']=='running' and type(receipt['collectorStarted']) in (int,float),'collector readiness mismatch')
        self.window=Window(receipt['collectorStarted'],self.session['steps']);self.state['receipts']['collectorStarted']=receipt;self.state['phase']='collector-running';self.save()
    def activate(self,authorization):
        self.phase('collector-running')
        for action in ('plugins-enable','export-ready','panel-open'):self.invoke(action,authorization)
        self.state['phase']='enabled';self.save()
    def issue_initial(self,activation,saved,manifest,remaining):
        self.phase('enabled');now=self.clock()
        require(self.window.can_initial(now,remaining),'remaining lifetime/controller reserve cannot fund1200+600')
        require(all(activation[k] is True for k in ('initialModelEmpty','initialStructureEmpty','initialMemoEmpty','initialDragEmpty','initialQueueEmpty','initialPairEmpty')) and activation['initialRenderPending'] is False and activation['initialEnqueued']==0,'activation not fresh empty runtime')
        identity=self.session['identity'];manifest=manifest or action_manifest(identity,saved,self.session.get('pilot',False))
        immutable(self.root/'action-manifest.json',manifest);immutable(self.root/'saved.json',saved)
        with (self.root/'owner-card.txt').open('x') as f:os.chmod(f.name,0o600);f.write(owner_card(identity,manifest,saved)+'\n')
        self.window.stamp('initialCardIssued',now);self.state['phase']='owner-card';self.save()
    def owner_complete(self,reply_id):
        self.phase('owner-card','recovery-card');require(isinstance(reply_id,str) and reply_id,'actual owner reply required')
        recovery=self.state['phase']=='recovery-card';name='recoveryCompleteReceived' if recovery else 'initialCompleteReceived'
        self.window.stamp(name,self.clock());immutable(self.root/(name+'.json'),{'replyId':reply_id,'receivedAt':self.clock()})
        self.state['phase']='owner-complete';self.save()
    def checked(self,normalized):
        self.phase('owner-complete');self.state['inspection']=normalized
        name='completenessChecked'
        if name not in self.window.stamps:self.window.stamp(name,self.clock())
        self.state['phase']='checked';self.save()
    def request_recovery(self,remaining):
        self.phase('checked');require(not self.state['inspection']['collectionComplete'],'no recovery needed')
        deadline=self.window.request_recovery(self.clock(),remaining);self.state['phase']='awaiting-approval';self.save();return deadline
    def approve_recovery(self,authorization,manifest,remaining):
        self.phase('awaiting-approval');validate_recovery(manifest,self.session['identity'],load(self.root/'action-manifest.json'))
        self.window.approve(self.clock(),remaining)
        require(manifest['approved'] is True and manifest['runId']==self.session['runId'] and manifest['activationNonce']==self.session['identity']['activationNonce'] and manifest['cardId']!=self.session['identity']['cardId'],'stale recovery identity')
        # Authorization is consumed before publishing or exposing the administrative packet.
        self.invoke('recovery-authorize',authorization)
        self.window.issue_recovery(self.clock(),remaining)
        temp=self.root/('recovery-'+uuid.uuid4().hex+'.tmp');immutable(temp,manifest)
        try:os.link(temp,self.root/'recovery.json')
        finally:temp.unlink()
        with (self.root/'recovery-card.txt').open('x') as f:os.chmod(f.name,0o600);f.write(owner_card(self.session['identity'],manifest,load(self.root/'saved.json'),manifest)+'\n')
        self.state['phase']='recovery-card';self.save()
    def finish(self,authorization,normalized):
        self.phase('checked');require(normalized['collectionComplete'] and not self.window.invalid,'protocol settlement incomplete')
        self.invoke('finish-authorize',authorization);self.window.stamp('finishSent',self.clock());self.control('finish');self.state['phase']='finishing';self.save()
    def exited(self,receipt,is_alive,normalized):
        self.phase('finishing')
        self.state['receipts']['collectorExited']=receipt;self.window.stamp('collectorExited',self.clock())
        if self.session['environment']=='live':
            require(set(receipt.get('processes',{}))=={'server','wrapper','collector'},'missing final process identities')
            require(receipt.get('wrapperEnded',0)>=self.window.stamps['finishSent'],'wrapper exited before finish')
        valid=receipt.get('runId')==self.session['runId'] and receipt.get('clockOrigin')==self.session['clockOrigin'] and receipt.get('collectorStarted')==self.window.stamps['collectorStarted'] and receipt.get('integrityComplete') is True and receipt.get('exitReason')=='finish' and receipt.get('error') is None and 'wrapperEnded' in receipt and not any(is_alive(p) for p in receipt['processes'].values())
        if not valid or self.window.invalid or not normalized['collectionComplete'] or not normalized['certificates'] or not all(x['physicalDrainComplete'] for x in normalized['certificates']):self.invalid('final integrity/settlement/exit incomplete')
        self.state['protocolComplete']=True;self.state['phase']='complete';self.save()
    def owner_stop(self,authorization,reply_id):
        require(reply_id and self.state['phase'] not in ('restored','new'),'explicit owner completion/stop required')
        self.invoke('stop-authorize',authorization);self.control('stop')
        self.state['stopReplyId']=reply_id;self.state['phase']='stopping';self.state['protocolComplete']=False;self.save()
    def stopped(self,receipt,is_alive):
        self.phase('stopping');require(receipt['runId']==self.session['runId'] and receipt['clockOrigin']==self.session['clockOrigin'] and 'wrapperEnded' in receipt and not any(is_alive(p) for p in receipt['processes'].values()),'collector not reaped after explicit stop')
        self.state['receipts']['collectorExited']=receipt;self.state['phase']='stopped';self.save()
    def restore(self,authorization):
        self.phase('complete','stopped')
        for action in ('final-drain','panel-close','plugins-disable','pointer-restore','plugins-enable','state-restore','rotation-resume','restore-verify'):self.invoke(action,authorization)
        self.state['phase']='restored';self.save()

def validate_recovery(m,identity,original):
    fields={'schema','approved','runId','activationNonce','cardId','replacementFor','coldPairs','launchPairs','operations'}
    require(set(m)==fields and type(m['schema']) is int and m['schema']==2 and m['approved'] is True,'malformed recovery manifest')
    require(m['runId']==identity['runId'] and m['activationNonce']==identity['activationNonce'] and isinstance(m['cardId'],str) and m['cardId'] and m['cardId']!=original['cardId'],'stale recovery manifest')
    for field in ('coldPairs','launchPairs'):require(type(m[field]) is int and m[field] in (0,1),'excess recovery diagnostic unit')
    prior=analyze.diagnostic_operations(original['cardId'],identity['coldPairs'],identity['launchPairs'])+original['operations']
    prior_ids={op['id'] for op in prior};replaced=m['replacementFor']
    require(isinstance(replaced,list) and replaced and len(set(replaced))==len(replaced) and set(replaced)<=prior_ids,'unknown/duplicate replacement originals')
    ops=m['operations'];require(isinstance(ops,list),'recovery operations must be array')
    for op in ops:
        kind=op.get('kind');field='profile' if kind=='profile' else 'key'
        require(kind in ('release','restore','profile') and set(op)=={'id','kind',field} and all(isinstance(op[k],str) and op[k] for k in op),'malformed recovery operation')
    ids=[op['id'] for op in analyze.diagnostic_operations(m['cardId'],m['coldPairs'],m['launchPairs'])+ops]
    require(ids and len(ids)==len(set(ids)) and not(set(ids)&prior_ids),'empty/reused recovery operation ids')
    releases=[o for o in ops if o['kind']=='release'];restores=[o for o in ops if o['kind']=='restore'];profiles=[o for o in ops if o['kind']=='profile']
    require(len(releases)<=1 and len(releases)==len(restores) and (not releases or releases[0]['key']==restores[0]['key']) and len(profiles) in (0,2) and len({o['profile'] for o in profiles})==len(profiles),'excess/mismatched combined packet')
    return True

def inspect_capture(events,identities,manifests,snapshots,definitions,replies,clock_verified,authorizations):
    cards={};bindings={}
    for identity in identities:
        nonce=identity['activationNonce'];rows=[e for e in events if e['activationNonce']==nonce]
        context=materialize(manifests[nonce],snapshots[nonce],definitions[nonce],rows,clock_verified)
        bindings[nonce]=context.pop('binding')
        try:context['operationGatesComplete']=operation_gates(rows,manifests[nonce],replies[nonce])
        except ValueError:context['operationGatesComplete']=False
        cards[nonce]=context
    normalized=analyze.normalize(events,identities,cards,authorizations)
    return normalized,{'cards':cards,'bindings':bindings,'authorizations':authorizations}

def stage_evidence(normalized,identities,receipts,restoration,clock,observations,stage1=None):
    """Cross-stage facts come from retained certified inputs, not command-line flags."""
    nonces={i['activationNonce'] for i in identities};require(len(receipts)==len(nonces),'missing lifecycle receipts')
    integrity=all(r.get('integrityComplete') is True and r.get('exitReason')=='finish' and r.get('error') is None and r.get('clockOrigin')==i['clockOrigin'] and r.get('runId')==i['runId'] for i,r in zip(identities,receipts))
    require(normalized['stage']==identities[0]['stage'],'captured stage mismatch')
    complete=normalized['collectionComplete'];cold=normalized['coldCollectionComplete'];launch=analyze.pairs(normalized)
    # Error rows are complete-session parser inputs; unknown count is not zero.
    require(type(observations['budgetErrors']) is int and observations['budgetErrors']>=0 and observations['complete'] is True,'complete session error audit absent')
    evidence={'integrityComplete':integrity,'referenceComplete':cold,'identityComplete':cold,'correctnessComplete':cold if normalized['stage']=='stage1' else complete,'errorComplete':True,'correct':cold if normalized['stage']=='stage1' else complete,'budgetErrors':observations['budgetErrors']}
    launch_complete=analyze.launch_groups_complete(launch)
    if normalized['stage']=='stage2':
        require(stage1 is not None,'separate Stage1 certificate required')
        first=analyze.normalize(stage1['events'],stage1['identities'],stage1['cards'],stage1['authorizations'])
        prior,prior_launch=stage_evidence(first,stage1['identities'],stage1['receipts'],stage1['restoration'],stage1['clock'],stage1['observations'])
        prior_blocks=analyze.target_blocks(first)['blocks'];verdict=analyze.decide('stage1',[prior_blocks.get(b,{}) for b in ('1','2')],prior,prior_launch)
        source=lambda items:{(i['block'],i['variant']):(i['sourceCommit'],i['sourceHash'],i['sourceSha256']) for i in items}
        same=source(stage1['identities'])==source(identities)
        restored=all(r.get('restored') is True and r.get('documentsEqual') is True and r.get('scratchExact') is True for r in restoration+stage1['restoration']) and len(restoration)==len(identities) and len(stage1['restoration'])==len(stage1['identities'])
        environments={i['environment'] for i in identities};require(len(environments)==1,'mixed environments')
        evidence.update(stage1Certified=verdict['stage2Eligible'] and first['collectionComplete'] and prior['integrityComplete'] and prior['budgetErrors']==0,launchIdentityComplete=same,launchGroupsComplete=prior_launch,restorationComplete=restored,clockOriginVerified=clock.get('verified') is True and stage1['clock'].get('verified') is True,environment=next(iter(environments)))
        launch_complete=prior_launch and same
    return evidence,launch_complete

def session_verdict(normalized,identities,receipts,restoration,clock,observations,stage1=None):
    evidence,launch=stage_evidence(normalized,identities,receipts,restoration,clock,observations,stage1)
    blocks=analyze.target_blocks(normalized);verdict=analyze.decide(blocks['stage'],[blocks['blocks'].get(b,{}) for b in ('1','2')],evidence,launch)
    if any(i['environment']!='live' for i in identities):verdict['accepted']=False
    return {'verdict':verdict,'evidence':evidence,'launch':analyze.pairs(normalized),'overlap':analyze.overlap_report(normalized,observations['polls'])}

def capture_limits(capacity_bytes,burst_bytes,burst_seconds):
    require(all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in (capacity_bytes,burst_bytes,burst_seconds)),'invalid measured log capacity/rate')
    rate=max(4*1024*1024/60,burst_bytes/burst_seconds);fill=capacity_bytes/rate
    return {'bytesPerSecond':rate,'fileFillSeconds':fill,'pollSeconds':min(2,fill/4),'maxGapSeconds':min(10,fill/2)}

def verify_artifacts(session):
    inventory=session['artifactSha256'];built=Path(session['buildRoot'])
    required={str(built/'plugin'/name) for name in (*session['identity']['sourceSha256'],'plugin.toml')}
    required|={str(HERE/name) for name in ('controller.py','capture.py','logs.py','state.mjs','rotation-guard.py','clock-gate.py','snapshot.mjs','frozen-task2/analyze.py')}
    require(required<=set(inventory),'incomplete immutable build/helper inventory')
    for name,sha in inventory.items():require(digest(Path(name).read_bytes())==sha,'artifact changed: '+name)
    limits=capture_limits(**session['rateMeasurement']);cfg=load(session['collectorConfig'])
    require(cfg['pollSeconds']<=limits['pollSeconds'] and cfg['maxGapSeconds']<=limits['maxGapSeconds'],'poll/checkpoint limits exceed full-burst fill rate')
    require(cfg['runId']==session['runId'] and cfg['clockOrigin']==session['clockOrigin'] and cfg['environment']=='live' and cfg['deadlineSeconds']==2100,'collector session/deadline mismatch')
    return limits

def read_capture(manifest,receipt=None):
    """Read an explicit collector checkpoint, never attach another log follower."""
    path=Path(manifest);before=path.read_bytes();m=json.loads(before);segments=[];raw=b''
    require(m['schema']==2 and m.get('lastCheckpoint') in ('ready','rotation','finish'),'durable checkpoint required')
    for index,row in enumerate(m['segments'],1):
        require(row['generation']==index and Path(row['path']).name==row['path'],'invalid archive generation/path')
        p=path.parent/row['path'];data=p.read_bytes()
        require(len(data)==row['bytes'] and digest(data)==row['sha256'],'archive changed/incomplete checkpoint')
        segments.append(p);raw+=data
    require(before==path.read_bytes(),'collector checkpoint changed during read')
    events=analyze.read_rotated(segments)
    raw_lines={}
    for line in raw.splitlines():
        if b'prism-budget ' in line:
            event=json.loads(line.split(b'prism-budget ',1)[1]);key=event['activationNonce']+':'+str(event['recordId'])
            require(key not in raw_lines,'duplicate raw event');raw_lines[key]=digest(line)
    complete=receipt is not None and receipt.get('integrityComplete') is True and receipt.get('exitReason')=='finish' and receipt.get('error') is None and m['lastCheckpoint']=='finish'
    return events,{'budgetErrors':raw.count(b'exceeded its CPU budget'),'complete':complete,'rawSha256':digest(raw),'bytes':len(raw),'rawLineSha256':raw_lines,'segments':[{'path':r['path'],'sha256':r['sha256']} for r in m['segments']]}

def verify_initial(identity,activation,bundle,current,build_root,reference_snapshot=None):
    require(activation['class']=='activation' and activation['scope']=='activation','initial activation record missing')
    for field in ('activationNonce','runId','cardId','sourceCommit','sourceHash','sourceSha256','stage','clockOrigin','variant','block','environment'):require(activation[field]==identity[field],'initial identity mismatch: '+field)
    built=Path(build_root);require(load(built/'identity.json')==identity,'identity manifest changed')
    for name,sha in identity['sourceSha256'].items():require(digest((built/'source'/name).read_bytes())==sha,'frozen source changed: '+name)
    require(identity['sourceCommit']=={'baseline':'9bf4e8e920c005f8a4d1666b32b4e1a516856ac2','candidate':'e7384b0d7ab3e8e935cdf0776043839441132af5'}[identity['variant']],'unexpected frozen revision')
    saved=bundle['saved']
    if reference_snapshot is not None:
        for key in ('documents','profiles','pair','runtime'):require(saved[key]==reference_snapshot[key],'cross-activation reference conflict: '+key)
    require(current['runtime']['active']==saved['runtime']['active'] and current['runtime']['scratch']=={} and current['canonical']==saved['profiles'][saved['pair']['P']],'P/canonical/test scratch baseline mismatch')
    require(set(bundle['definitions'])==set(current['canonical']),'frozen definition coverage mismatch')
    for name,sha in bundle['resolverSources'].items():require(digest((Path(identity['cli']).parent.parent/'src'/name).read_bytes())==sha,'resolver source changed')
    return True

def inspect_run(root,reply_at):
    root=Path(root);session=load(root/'session.json');identity=session['identity'];bundle=load(session['snapshotBundle']);events,audit=read_capture(root/'manifest.json')
    manifest=load(root/'action-manifest.json');auth={}
    origin_verified=session['environment']!='live'
    if session['environment']=='live':
        clock=load(root/'clock-verified.json');origin_verified=clock.get('verified') is True and clock.get('clockOrigin')==session['clockOrigin'] and clock.get('sessionId')==session['sessionId']
    if (root/'recovery.json').exists():
        recovery=load(root/'recovery.json');state=load(root/'state.json')
        require('recovery-authorize' in state['receipts'] and 'approvalReceived' in state['stamps'],'recovery lacks consumed root permit/approval')
        context=materialize(recovery,bundle['saved'],bundle['definitions'],events,origin_verified)
        auth[identity['activationNonce']]={'manifest':recovery,'ownerApproved':True,'originVerified':context['originVerified'],'operations':context['operations']}
    normalized,context=inspect_capture(events,[identity],{identity['activationNonce']:manifest},{identity['activationNonce']:bundle['saved']},{identity['activationNonce']:bundle['definitions']},{identity['activationNonce']:reply_at},origin_verified,auth)
    for nonce,binding in context['bindings'].items():
        for intent in binding['intents']:intent['rawLineSha256']=audit['rawLineSha256'][nonce+':'+str(intent['recordId'])]
    context['rawManifestSha256']=digest((root/'manifest.json').read_bytes())
    return normalized,context

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('create','prepare','collector-started','activate','issue','reply','inspect','request-recovery','approve-recovery','finish','exited','restore','checkpoint','stop','stopped'));p.add_argument('--run',required=True);p.add_argument('--session');p.add_argument('--authorization');p.add_argument('--input');a=p.parse_args();os.umask(0o077)
    root=Path(a.run);data=load(a.input) if a.input else {}
    if a.action=='create':
        session=load(a.session);root.mkdir(mode=0o700);Controller(root,session,RootHost(root,session));return
    session=load(root/'session.json');obj=Controller.resume(root,RootHost(root,session))
    if a.action in ('prepare','activate','restore'):getattr(obj,a.action)(a.authorization)
    elif a.action=='checkpoint':obj.invoke('checkpoint-authorize',a.authorization);obj.control('ready')
    elif a.action=='stop':obj.owner_stop(a.authorization,data['replyId'])
    elif a.action=='stopped':
        capture=module('budget_capture',HERE/'capture.py');obj.stopped(load(root/'receipt.json'),capture.same_process)
    elif a.action=='collector-started':obj.collector_started(load(root/'heartbeat.json'))
    elif a.action=='issue':
        events,_=read_capture(root/'manifest.json');bundle=load(session['snapshotBundle']);verify_initial(session['identity'],events[0],bundle,load(data['current']),session['buildRoot'],load(session['referenceSnapshot']) if session.get('referenceSnapshot') else None)
        obj.issue_initial(events[0],bundle['saved'],{},data['remainingStepReserve'])
    elif a.action=='reply':obj.owner_complete(data['replyId'])
    elif a.action=='inspect':
        reply=max(v for k,v in obj.window.stamps.items() if k.endswith('CompleteReceived'));normalized,context=inspect_run(root,reply)
        immutable(root/('context-'+uuid.uuid4().hex+'.json'),context);obj.checked(normalized)
    elif a.action=='request-recovery':print(json.dumps({'approvalDeadline':obj.request_recovery(data['finalStepReserve'])}))
    elif a.action=='approve-recovery':obj.approve_recovery(a.authorization,data['manifest'],data['finalStepReserve'])
    elif a.action=='finish':
        normalized,_=inspect_run(root,max(v for k,v in obj.window.stamps.items() if k.endswith('CompleteReceived')));obj.finish(a.authorization,normalized)
    elif a.action=='exited':
        normalized,_=inspect_run(root,max(v for k,v in obj.window.stamps.items() if k.endswith('CompleteReceived')));capture=module('budget_capture',HERE/'capture.py');obj.exited(load(root/'receipt.json'),capture.same_process,normalized)
    print(json.dumps({'phase':obj.state['phase'],'protocolComplete':obj.state['protocolComplete'],'invalid':obj.state['invalid']}))
if __name__=='__main__':main()
