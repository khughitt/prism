"""Neutral fixtures created as calibration inputs; owner records remain private."""
import copy,importlib.util,json,tempfile,sys
from pathlib import Path
s=importlib.util.spec_from_file_location('analysis',Path(__file__).with_name('analyze.py'));a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
REF=dict(acceptedProfile='P',acceptedWallpaper=False,values={'n':1.0,'color':'#123456','enabled':True},heldScratchKeys=[])
I=dict(schema=2,variant='baseline',sourceCommit='a'*40,sourceHash='b'*64,sourceSha256={'panel.luau':'c'*64},activationNonce='neutral-nonce',block='1',stage='stage1',runId='neutral-run',cardId='card',clockOrigin='neutral-clock',environment='synthetic',coldPairs=1,launchPairs=0)
CARD=dict(cardId='card',operations=[],reference=REF,operationGatesComplete=True,originVerified=True)
def fixture(ops=()):
 rows=[];card=copy.deepcopy(CARD);card['operations']=copy.deepcopy(list(ops));cb=0;accepted_generation=0;profile_generation=0
 def event(cls,scope='metadata',**kw):
  nonlocal cb,accepted_generation,profile_generation
  t=(len(rows)+1)*.1
  e={k:v for k,v in I.items() if k not in ('coldPairs','launchPairs')}
  e|=dict(recordId=len(rows)+1,callbackId=cb,class_=cls,scope=scope,elapsedMs=0,rendered=False,accepted=False,pending=False,complete=True,control=False,diagnosticsHidden=True,pairId=False,interference=False,timestamp=t,targetEligible=True,operationId=False,replacementId=False,replacementFor=[],acceptGeneration=accepted_generation,profileGeneration=profile_generation,phase=cls,outcome='none')
  e['class']=e.pop('class_')
  if scope=='observer':e['observer']=True
  if scope in ('callback','render','interval','observer','nativeLaunch','launchHelper'):e|=dict(startTimestamp=t-.01,endTimestamp=t-.006,elapsedMs=4.)
  e.update(kw)
  if scope=='callback' and e['accepted']:accepted_generation=e['acceptGeneration']
  rows.append(e);return e
 def snapshot(cls,requested,refid):
  cbv=dict(observer=True,queueIdle=True,queuePendingCount=0,queueInFlight=False,describeRunning=False,dragEmpty=True,renderPending=False,refreshPending=False,refreshAfterDrag=False,describeInvalidated=False,selectionPending=False,help=False,errorText=False,errorSticky=False,open=True,modelReady=True,pairEmpty=True,pairPending=False,pairFrameDone=False,comparisonCallbacksComplete=True,sequenceComplete=cls=='drain',sequencePhase='setup' if cls=='ready' else False,bufferEmpty=True,bufferCount=0,expandedIds=['rack'],rackIds=['rack'],allRackExpanded=True,currentProfile='P',referenceId=refid,requestedOperationIds=list(requested),readyEligible=cls=='ready',physicalDrain=cls=='drain',eligibleDrain=cls=='drain',startTimestamp=len(rows)*.1+.09,endTimestamp=len(rows)*.1+.094,elapsedMs=4.)
  return event(cls,**cbv)
 event('activation','activation',callbackId=0,initialModelEmpty=True,initialStructureEmpty=True,initialMemoEmpty=True,initialEnqueued=0,initialDragEmpty=True,initialQueueEmpty=True,initialRenderPending=False,initialPairEmpty=True)
 cb=1;event('open','callback',rendered=True)
 cb+=1;event('changedDescribe','callback',accepted=True,acceptGeneration=1)
 cb=2;r=event('acceptedReference','observer',operationId='card:reference',valid=True,reason='superseded',**copy.deepcopy(REF));requested=['card:cold:1'];snapshot('ready',requested,r['recordId'])
 cb=3;event('operationRequested',operationId='card:cold:1',operationKind='cold',valid=True)
 setup=event('coldSetup','callback',operationId='card:cold:1',accepted=True,acceptGeneration=2)
 cb+=1;render=event('coldRender','render',operationId='card:cold:1',rendered=True,acceptGeneration=2)
 event('coldPairInterval','interval',operationId='card:cold:1',acceptGeneration=2,startTimestamp=setup['startTimestamp'],endTimestamp=render['endTimestamp']+.001,elapsedMs=(render['endTimestamp']+.001-setup['startTimestamp'])*1000)
 event('coldRender','callback',operationId='card:cold:1',rendered=True,acceptGeneration=2,startTimestamp=render['startTimestamp']-.001,endTimestamp=render['endTimestamp']+.001,elapsedMs=6.)
 generation=2
 for op in ops:
  requested.append(op['id']);cb+=1
  if op['kind']=='profile':
   profile_generation+=1
   action_render=event('profileAction','render',rendered=True)
   event('profileAction','callback',rendered=True,startTimestamp=action_render['startTimestamp']-.001,endTimestamp=action_render['endTimestamp']+.001,elapsedMs=6.)
   cb+=1
  event('operationRequested',callbackId=0 if op['kind']=='profile' else cb,operationId=op['id'],operationKind=op['kind'],valid=True,key=op.get('key',False),profile=op.get('profile',False),acceptGeneration=generation)
  if op['kind']=='release':
   release_render=event('release','render',operationId=op['id'],rendered=True,acceptGeneration=generation)
   event('release','callback',operationId=op['id'],rendered=True,acceptGeneration=generation,startTimestamp=release_render['startTimestamp']-.001,endTimestamp=release_render['endTimestamp']+.001,elapsedMs=6.)
  generation+=1;cb+=1;event('changedDescribe','callback',operationId=op['id'],accepted=True,acceptGeneration=generation)
  cb+=1;target='profileRender' if op['kind']=='profile' else 'deferredRender'
  render=event(target,'render',operationId=op['id'],rendered=True,acceptGeneration=generation)
  end=event(target,'callback',operationId=op['id'],rendered=True,acceptGeneration=generation,startTimestamp=render['startTimestamp']-.001,endTimestamp=render['endTimestamp']+.001,elapsedMs=6.)
  cb+=1;r=event('acceptedReference','observer',operationId=op['id'],valid=True,reason=False,acceptGeneration=generation,**copy.deepcopy(op['expectedReference']))
  event('operationDone',operationId=op['id'],operationKind=op['kind'],acceptGeneration=generation,referenceId=r['recordId'],callbackIdTarget=end['callbackId'],renderIdTarget=render['recordId'],targetClass=target)
 cb+=1;d=snapshot('drain',list(requested),r['recordId']);event('cardSettled',requestedOperationIds=list(requested),eligibleDrain=True,drainRecordId=d['recordId'],bufferEmpty=True);snapshot('drain',list(requested),r['recordId'])
 return rows,card

def norm(rows,card,auth=None):return a.normalize(rows,[I],{I['activationNonce']:card},{} if auth is None else auth)
def refused(rows,card,auth=None):
 try:r=norm(rows,card,auth)
 except ValueError:return
 assert not r['collectionComplete'],'malformed evidence certified'
rows,card=fixture();n=norm(rows,card);assert n['collectionComplete'] and n['calibration'] and not n['liveCollectionCertified']
print('PASS schema2 neutral complete n1 collection independently inconclusive performance')
for mutation in ('schema1','missing-activation','missing-ready','missing-reference','missing-callback','missing-drain','duplicate','gap','source','clock','partial-end','reverse-end','elapsed','fake-drain','missing-bool'):
 bad=copy.deepcopy(rows)
 if mutation=='schema1':bad[0]['schema']=1
 if mutation=='missing-activation':bad.pop(0)
 if mutation=='missing-ready':bad=[e for e in bad if e['class']!='ready']
 if mutation=='missing-reference':bad=[e for e in bad if e['class']!='acceptedReference']
 if mutation=='missing-callback':bad=[e for e in bad if not(e['scope']=='callback' and e['class']=='coldRender')]
 if mutation=='missing-drain':bad=[e for e in bad if e['class']!='drain']
 if mutation=='duplicate':bad.append(copy.deepcopy(bad[-1]))
 if mutation=='gap':bad[-1]['recordId']+=1
 if mutation=='source':bad[1]['sourceSha256']={'panel.luau':'d'*64}
 if mutation=='clock':bad[1]['clockOrigin']='other-clock'
 if mutation=='partial-end':del bad[1]['endTimestamp']
 if mutation=='reverse-end':bad[1]['endTimestamp']=0
 if mutation=='elapsed':bad[1]['elapsedMs']=3
 if mutation=='fake-drain':
  for e in bad:
   if e['class']=='drain':e['sequenceComplete']=False
 if mutation=='missing-bool':del bad[1]['targetEligible']
 refused(bad,card)
for flag in ('originVerified','operationGatesComplete'):
 c=copy.deepcopy(card);c[flag]=False;refused(rows,c)
Q=copy.deepcopy(REF);Q['acceptedProfile']='Q';Q['values']['n']=2
ops=[dict(id='card:action:1',kind='profile',profile='Q',expectedReference=Q),dict(id='card:action:2',kind='profile',profile='P',expectedReference=REF)]
owner,c=fixture(ops);assert norm(owner,c)['collectionComplete']
for mutation in ('generation','render','callback','reference-value','Q-expected','ignored-P','requested-set','early-settlement'):
 bad=copy.deepcopy(owner);context=copy.deepcopy(c);done=next(e for e in bad if e['class']=='operationDone')
 if mutation=='generation':done['acceptGeneration']+=1
 if mutation=='render':next(e for e in bad if e['recordId']==done['renderIdTarget'])['class']='open'
 if mutation=='callback':done['callbackIdTarget']=1
 if mutation=='reference-value':next(e for e in bad if e['recordId']==done['referenceId'])['values']['n']=3
 if mutation=='Q-expected':del context['operations'][0]['expectedReference']
 if mutation=='ignored-P':bad=[e for e in bad if e['operationId']!=ops[1]['id'] or e['class'] in ('drain','cardSettled')]
 if mutation=='requested-set':
  for e in bad:
   if e['class'] in ('drain','cardSettled'):e['requestedOperationIds']=['card:cold:1']
 if mutation=='early-settlement':
  for e in bad:
   if e['class']=='cardSettled':e['drainRecordId']=4
 refused(bad,context)
assert a.exact_reference(REF,REF|{'values':REF['values']|{'n':1}})
assert not a.exact_reference(REF,REF|{'values':REF['values']|{'enabled':1}})
for field in ('n','color','enabled'):
 changed=copy.deepcopy(REF);changed['values'][field]={'n':1.1,'color':'#123457','enabled':False}[field];assert not a.exact_reference(REF,changed)
# Serialized endpoints, strict touching-boundary overlap, no sample deletion/subtraction.
sample=next(e for e in n['samples'] if e['class']=='coldRender' and e['scope']=='callback');sample=sample|dict(startTimestamp=10.,endTimestamp=11.,elapsedMs=1000.,timestamp=12.)
obs=[dict(runId='neutral-run',checkpoint=False,error=None,clockOrigin='neutral-clock',start=9.,end=10.,bytes=1),dict(runId='neutral-run',checkpoint=False,error=None,clockOrigin='neutral-clock',start=10.5,end=10.6,bytes=2),dict(runId='neutral-run',checkpoint='finish',error=None,clockOrigin='neutral-clock',start=11.,end=12.,bytes=3)]
over=a.overlap_report(n|{'samples':[sample]},obs);assert over['overlapCount']==1 and over['samples'][0]['elapsedMs']==1000 and len(over['observations'])==3
for mutation in ('origin','missing','reverse','unknown'):
 bad=copy.deepcopy(obs)
 if mutation=='origin':bad[0]['clockOrigin']='other'
 if mutation=='missing':del bad[0]['end']
 if mutation=='reverse':bad[0]['end']=8
 if mutation=='unknown':bad[0]['start']=None
 try:a.overlap_report(n|{'samples':[sample]},bad)
 except ValueError:pass
 else:raise AssertionError('invalid overlap accepted '+mutation)
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)/'log';p.write_text('prism-budget {"x":1,"x":2}\n')
 for payload in ('prism-budget {"x":1,"x":2}\n','prism-budget {"x":1','prism-budget {"x":NaN}\n'):
  p.write_text(payload)
  try:a.read_rotated([p])
  except ValueError:pass
  else:raise AssertionError('invalid JSON accepted')
print('PASS strict records/endpoints/source/clock/flags/physical drain; exact Q/P/reference/generation/links/sets; overlap touching boundaries; malformed JSON')

def renumber(rows):
 mapping={e['recordId']:i+1 for i,e in enumerate(rows)}
 for e in rows:
  for key in ('recordId','referenceId','drainRecordId','renderIdTarget'):
   if key in e and e[key] in mapping:e[key]=mapping[e[key]]
 return rows

def recovery_fixture():
 original_ops=[dict(id='card:action:1',kind='release',key='n',expectedReference=REF),dict(id='card:action:2',kind='restore',key='n',expectedReference=REF),dict(id='card:action:3',kind='profile',profile='Q',expectedReference=Q),dict(id='card:action:4',kind='profile',profile='P',expectedReference=REF)]
 originals,c=fixture(original_ops)
 for e in originals:
  if e['class']=='operationDone':e['class']='operationLost'
  if e['class'] in ('deferredRender','profileRender'):e['rendered']=False
 newops=copy.deepcopy(original_ops)
 for index,op in enumerate(newops):op['id']='replacement:manual:'+str(index+1)
 extra,_=fixture(newops)
 extra=[e for e in extra if e['class'] not in ('activation','open') and e['operationId']!='card:cold:1' and not (e['class']=='changedDescribe' and e['operationId'] is False)]
 # Neutral packet is constructed before it is ever serialized.
 for e in extra:
  e['cardId']='replacement';e['replacementId']='replacement';e['replacementFor']=[op['id'] for op in original_ops]
  if e['operationId']=='card:reference':e['operationId']='replacement:reference'
  if e['operationId'] in [op['id'] for op in newops]:pass
  if 'requestedOperationIds' in e:e['requestedOperationIds']=[name for name in e['requestedOperationIds'] if name!='card:cold:1']
  e['callbackId']+=100 if e['callbackId'] else 0;e['acceptGeneration']+=5 if e['class'] in ('acceptedReference','ready') and e['operationId'] in ('replacement:reference',False) else 4;e['profileGeneration']+=2
  if 'callbackIdTarget' in e:e['callbackIdTarget']+=100
  for key in ('timestamp','startTimestamp','endTimestamp'):
   if key in e:e[key]+=100
  for key in ('recordId','referenceId','drainRecordId','renderIdTarget'):
   if key in e:e[key]+=1000
 accepted=copy.deepcopy(originals[-2]);accepted.update(recordId=999,class_='recoveryAccepted',cardId='replacement',replacementId='replacement',replacementFor=[op['id'] for op in original_ops],requestedOperationIds=[op['id'] for op in newops],timestamp=99.,callbackId=99)
 accepted['class']=accepted.pop('class_')
 merged=renumber(originals+[accepted]+extra)
 m=dict(schema=2,approved=True,runId=I['runId'],activationNonce=I['activationNonce'],cardId='replacement',replacementFor=[op['id'] for op in original_ops],coldPairs=0,launchPairs=0,operations=[{k:v for k,v in op.items() if k!='expectedReference'} for op in newops])
 auth={I['activationNonce']:dict(manifest=m,ownerApproved=True,originVerified=True,operations=newops)}
 return merged,c,auth
recovered,c,auth=recovery_fixture();r=norm(recovered,c,auth)
assert r['collectionComplete'] and len(r['certificates'][0]['replacementCredit'])==4
assert any(e['reason']=='no-real-render' for e in r['exclusions'])
for mutation in ('unapproved','missing-auth','second','bad-original','two-colds','changed-reference','unverified'):
 bad=copy.deepcopy(recovered);ac=copy.deepcopy(auth)
 if mutation=='unapproved':ac[I['activationNonce']]['ownerApproved']=False
 if mutation=='missing-auth':ac={}
 if mutation=='unverified':ac[I['activationNonce']]['originVerified']=False
 if mutation=='second':
  added=copy.deepcopy(next(e for e in bad if e['class']=='recoveryAccepted'));added['recordId']=len(bad)+1;added['timestamp']=bad[-1]['timestamp']+1;bad.append(added)
 if mutation=='bad-original':ac[I['activationNonce']]['manifest']['replacementFor']=['unknown']
 if mutation=='two-colds':ac[I['activationNonce']]['manifest']['coldPairs']=2
 if mutation=='changed-reference':
  next(e for e in bad if e['class']=='acceptedReference' and e['operationId']=='replacement:manual:3')['values']['n']=999
 refused(bad,c,ac)
print('PASS combined one-packet release/restore/Q/P replacement credit; original losses/exclusions retained; unauthorized/second/excess/changed-reference refused')
empty_wallpaper=copy.deepcopy(REF);empty_wallpaper['acceptedWallpaper']=''
assert a.exact_reference(empty_wallpaper,empty_wallpaper),'empty JSON wallpaper string is preserved exactly'
startup_idle=copy.deepcopy(rows);startup_idle[1].update(referenceId=False)
print('PASS producer explicit empty wallpaper reference values')
wall=REF|{'acceptedWallpaper':{'id':'neutral-wall','path':'neutral/wall.png'}}
assert a.exact_reference(wall,copy.deepcopy(wall))
assert not a.exact_reference(wall,wall|{'acceptedWallpaper':{'id':'neutral-wall','path':'neutral/other.png'}})
array_ref=REF|{'values':REF['values']|{'apps':['neutral-a','neutral-b']}}
assert a.exact_reference(array_ref,copy.deepcopy(array_ref))
assert not a.exact_reference(array_ref,array_ref|{'values':array_ref['values']|{'apps':['neutral-b','neutral-a']}})
ready_buffer=copy.deepcopy(rows);next(e for e in ready_buffer if e['class']=='ready').update(bufferEmpty=False,bufferCount=2)
assert norm(ready_buffer,card)['collectionComplete'],'ready may contain already completed callbacks whose exact records are fully collected'

def pair_events(state='pending',control=False):
 rows=[];name='neutral-pair';callback=2
 def event(cls,scope,cb,**kw):
  t=(len(rows)+1)*.1
  e={k:v for k,v in I.items() if k not in ('coldPairs','launchPairs')};e|=dict(recordId=len(rows)+1,callbackId=cb,scope=scope,elapsedMs=4.,rendered=scope in ('render','callback'),accepted=False,pending=False,complete=True,control=control,diagnosticsHidden=True,pairId=name,interference=False,timestamp=t,targetEligible=True,operationId='card:control:1' if control else 'card:launch:1',replacementId=False,replacementFor=[],acceptGeneration=1,startTimestamp=t-.01,endTimestamp=t-.006);e['class']=cls;e.update(kw);rows.append(e);return e
 def end(cls,cb,terminal=False):
  linked=[e for e in rows if e['callbackId']==cb and e['scope'] in ('render','nativeLaunch','launchHelper')]
  e=event(cls,'callback',cb,pairId=False if terminal else name,control=False if terminal else control)
  if linked:e.update(startTimestamp=linked[0]['startTimestamp']-.001,endTimestamp=e['endTimestamp']);e['elapsedMs']=(e['endTimestamp']-e['startTimestamp'])*1000
 if not control:
  event('nativeLaunch','nativeLaunch',2,rendered=False);event('launchHelper','launchHelper',2,rendered=False)
 event('pairImmediate','render',2);end('pairImmediate',2)
 if not control and state=='done':event('comparisonCompletionResult','metadata',4,exitCode=0,timedOut=False,stdoutTruncated=False,stderrTruncated=False);end('comparisonCompletion',4)
 event('pairFrame','render',3,pending=state=='pending');event('pairFrameState','metadata',3,completionState=state,pending=state=='pending')
 if control or state=='done':event('pairDone','metadata',3,valid=True,completionState=state);end('pairFrame',3,True)
 else:end('pairFrame',3);event('comparisonCompletionResult','metadata',4,exitCode=0,timedOut=False,stdoutTruncated=False,stderrTruncated=False);event('pairDone','metadata',4,valid=True,completionState=state);end('comparisonCompletion',4,True)
 return rows
for control,state in ((False,'pending'),(False,'done'),(True,'done')):
 ps=pair_events(state,control);assert len(a.structural_pairs(dict(events=ps))['pairs'])==1
 for endpoint in [e for e in ps if e['scope']=='callback']:
  bad=[e for e in ps if e is not endpoint];assert not a.structural_pairs(dict(events=bad))['pairs']
 for mutation in ('state','missing-frame','malformed-result','ineligible','operation','containment'):
  bad=copy.deepcopy(ps)
  if mutation=='state':
   for e in bad:
    if e['class'] in ('pairFrameState','pairDone'):e['completionState']='done' if state=='pending' else 'pending'
    if e['class'] in ('pairFrame','pairFrameState'):e['pending']=state!='pending'
  if mutation=='missing-frame':bad=[e for e in bad if e['class']!='pairFrame']
  if mutation=='malformed-result':
   if control:continue
   next(e for e in bad if e['class']=='comparisonCompletionResult')['timedOut']='false'
  if mutation=='ineligible':bad[0]['targetEligible']=False
  if mutation=='operation':next(e for e in bad if e['class']=='pairFrame')['operationId']='stale'
  if mutation=='containment':next(e for e in bad if e['class']=='pairFrame')['startTimestamp']=0
  assert not a.structural_pairs(dict(events=bad))['pairs'],mutation
print('PASS pending/done/control chronology; every enclosing callback endpoint; no wrong actual operation or interval containment')
if len(sys.argv)>1:
 saved=Path(sys.argv[1]);count=0
 for context_path in sorted((saved/'integration-v2').glob('*-context.json')):
  stem=context_path.name.removesuffix('-context.json');ctx=json.loads(context_path.read_text());payload=saved/'integration-v2'/f'{stem}-payload.log';es=a.read_rotated([payload]);normalized=a.normalize(es,ctx['identities'],ctx['cards'],ctx['authorizations']);assert normalized['collectionComplete'] and normalized['calibration'] and not normalized['liveCollectionCertified'];count+=1
  if stem.startswith('final-pairs'):
   launch=a.pairs(normalized);assert len(launch['pairs'])==10 and not launch['inconclusive']
   for control in (False,True):
    pair_callbacks={e['callbackId'] for e in es if e['pairId']}
    ends=[e for e in es if e['scope']=='callback' and e['pairId'] is False and e['callbackId'] in pair_callbacks]
    assert ends
    for endpoint in ends:
     bad=[e for e in es if e is not endpoint];result=a.structural_pairs(dict(events=bad));assert len(result['pairs'])<10
   for state in ('done','pending'):
    bad=copy.deepcopy(es)
    for e in bad:
     if not e['control']:
      if e['class'] in ('pairFrameState','pairDone'):e['completionState']=state
      if e['class'] in ('pairFrame','pairFrameState'):e['pending']=state=='pending'
    if state=='done':assert all(p['control'] for p in a.structural_pairs(dict(events=bad))['pairs'])
 assert count==8
 print('PASS eight immutable saved schema2 timelines with actual source identities/maps kept private; saved pending callback/terminal-end/chronology mutations')
# Complete buffered callbacks and observer references remain mandatory despite true context flags.
bad=copy.deepcopy(rows);bad[1]['complete']=False;refused(bad,card)
bad=copy.deepcopy(owner);next(e for e in bad if e['class']=='acceptedReference' and e['operationId']==ops[0]['id'])['scope']='metadata';refused(bad,c)
bad=copy.deepcopy(recovered);acc=next(e for e in bad if e['class']=='recoveryAccepted');target=next(e for e in bad if e['class']=='operationRequested' and e['cardId']=='replacement');target['recordId'],acc['recordId']=acc['recordId'],target['recordId'];target['timestamp'],acc['timestamp']=acc['timestamp'],target['timestamp'];refused(bad,c,auth)
owner_rows,owner_card=fixture(ops);assert norm(owner_rows,owner_card)['collectionComplete']
bad=copy.deepcopy(owner_rows);next(e for e in bad if e['class']=='acceptedReference' and e['operationId']==ops[0]['id'])['scope']='metadata';refused(bad,owner_card)
bad=copy.deepcopy(rows);extra=copy.deepcopy(bad[1]);extra.update(recordId=1.5,callbackId=100,class_='input',complete=False,timestamp=.25,startTimestamp=.24,endTimestamp=.244,elapsedMs=4.)
extra['class']=extra.pop('class_');bad.insert(2,extra);renumber(bad);refused(bad,card)

for mutation in ('setup','accept','generation','interval'):
 bad=copy.deepcopy(rows);setup=next(e for e in bad if e['class']=='coldSetup')
 if mutation=='setup':setup['class']='idle'
 if mutation=='accept':setup['accepted']=False
 if mutation=='generation':setup['acceptGeneration']=99
 if mutation=='interval':
  span=next(e for e in bad if e['class']=='coldPairInterval');span['startTimestamp']=0;span['elapsedMs']=span['endTimestamp']*1000
 refused(bad,card)
# A stale current diagnostic id cannot make an opening deferred render into owner evidence.
stale=copy.deepcopy(rows)
for e in stale:
 if e['class']=='coldRender':e['class']='deferredRender'
partial=norm(stale,card);assert not a.target_blocks(partial)['blocks'].get('1',{}).get('baseline',{}).get('deferredRender')
# Certified collection is still short after two lost cold units and one extra cold.
def cold_short_fixture():
 original,_=fixture();prefix=copy.deepcopy(original[:next(i for i,e in enumerate(original) if e['class']=='operationRequested')]);unit=[e for e in original if e['operationId']=='card:cold:1'];suffix=copy.deepcopy(original[-3:]);combined=prefix
 for index in range(1,6):
  new=copy.deepcopy(unit)
  for e in new:
   e['operationId']=f'card:cold:{index}';e['callbackId']+=index*10;e['recordId']+=index*100;e['acceptGeneration']+=index-1
   for key in ('timestamp','startTimestamp','endTimestamp'):
    if key in e:e[key]+=index*10
   if index in (2,3) and e['class']=='coldRender':e['rendered']=False
  combined+=new
 for e in suffix:
  e['recordId']+=1000;e['callbackId']+=100 if e['callbackId'] else 0;e['acceptGeneration']=6
  for key in ('referenceId','drainRecordId'):
   if key=='drainRecordId' and key in e:e[key]+=1000
  for key in ('timestamp','startTimestamp','endTimestamp'):
   if key in e:e[key]+=90
  e['requestedOperationIds']=[f'card:cold:{i}' for i in range(1,6)]
 for e in combined:
  if e['class']=='ready':e['requestedOperationIds']=[f'card:cold:{i}' for i in range(1,6)]
 combined+=suffix
 extra,_=fixture();extra=copy.deepcopy([e for e in extra if e['class'] not in ('activation','open') and not (e['class']=='changedDescribe' and e['operationId'] is False)])
 for e in extra:
  e['cardId']='replacement';e['replacementId']='replacement';e['replacementFor']=['card:cold:2','card:cold:3'];e['operationId']=e['operationId'].replace('card:','replacement:') if isinstance(e['operationId'],str) else False;e['callbackId']+=200;e['recordId']+=2000;e['acceptGeneration']+=5
  for key in ('referenceId','drainRecordId'):
   if key in e:e[key]+=2000
  for key in ('timestamp','startTimestamp','endTimestamp'):
   if key in e:e[key]+=110
  if 'requestedOperationIds' in e:e['requestedOperationIds']=['replacement:cold:1']
 accepted=copy.deepcopy(suffix[1]);accepted.update(recordId=1999,timestamp=109.,cardId='replacement',replacementId='replacement',replacementFor=['card:cold:2','card:cold:3'],requestedOperationIds=['replacement:cold:1']);accepted['class']='recoveryAccepted'
 merged=renumber(combined+[accepted]+extra)
 m=dict(schema=2,approved=True,runId=I['runId'],activationNonce=I['activationNonce'],cardId='replacement',replacementFor=['card:cold:2','card:cold:3'],coldPairs=1,launchPairs=0,operations=[])
 return merged,{I['activationNonce']:dict(manifest=m,ownerApproved=True,originVerified=True,operations=[])}
short_rows,short_auth=cold_short_fixture();old=I['coldPairs'];I['coldPairs']=5
try:
 short=norm(short_rows,card,short_auth);assert not short['collectionComplete'];assert len(short['certificates'][0]['missingOperationIds'])==1
 assert len(a.target_blocks(short)['blocks']['1']['baseline']['coldRender'])==4
finally:I['coldPairs']=old
print('PASS opening-render exclusion; two lost colds remain short after one authorized extra cold')
opening=copy.deepcopy(rows);idx=next(i for i,e in enumerate(opening) if e['class']=='drain');t=opening[idx]['timestamp']-.04
wr=copy.deepcopy(next(e for e in opening if e['class']=='coldRender' and e['scope']=='render'));wr.update(recordId=1000,callbackId=100,class_='deferredRender',timestamp=t,startTimestamp=t-.004,endTimestamp=t-.002,elapsedMs=2.);wr['class']=wr.pop('class_')
wc=copy.deepcopy(wr);wc.update(recordId=1001,scope='callback',timestamp=t+.02,startTimestamp=t-.005,endTimestamp=t+.005,elapsedMs=10.)
opening[idx:idx]=[wr,wc];renumber(opening);pn=norm(opening,card);assert pn['collectionComplete'];assert not a.target_blocks(pn)['blocks']['1']['baseline'].get('deferredRender'),'diagnostic-origin deferred render admitted owner class'

release_rows,release_card=fixture([dict(id='card:action:1',kind='release',key='n',expectedReference=REF)])
assert norm(release_rows,release_card)['collectionComplete']
assert len(a.target_blocks(norm(release_rows,release_card))['blocks']['1']['baseline']['release'])==1
bad=copy.deepcopy(release_rows)
for e in bad:
 if e['class']=='release':e['class']='input'
refused(bad,release_card)
bad=copy.deepcopy(release_rows);next(e for e in bad if e['class']=='release' and e['scope']=='render')['class']='input';refused(bad,release_card)
# A successful original card cannot turn a false approval context into certification.
full_rec,full_card,full_auth=recovery_fixture()
for e in full_rec:
 if e['cardId']=='card' and e['class']=='operationLost':e['class']='operationDone'
 if e['cardId']=='card' and e['class'] in ('deferredRender','profileRender'):e['rendered']=True
full_auth[I['activationNonce']]['ownerApproved']=False
refused(full_rec,full_card,full_auth)
bad=copy.deepcopy(rows)
for e in bad:
 if e['class']=='drain':e['referenceId']=2
refused(bad,card)
bad=copy.deepcopy(owner_rows);wrong=copy.deepcopy(owner_card);wrong['operations'][-1]['expectedReference']=Q
for e in bad:
 if e['class']=='acceptedReference' and e['operationId']==ops[-1]['id']:
  for field in a.REF_FIELDS:e[field]=copy.deepcopy(Q[field])
refused(bad,wrong)
import subprocess
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp);complete,context=fixture()
 objects=dict(identity=I,cards={I['activationNonce']:context},authorizations={},evidence=dict(integrityComplete=True,referenceComplete=True,identityComplete=True,correctnessComplete=True,errorComplete=True,correct=True,budgetErrors=0,launchComplete=False))
 for name,obj in objects.items():(d/name).write_text(json.dumps(obj))
 (d/'log').write_text(''.join('prism-budget '+json.dumps(e)+'\n' for e in complete))
 cmd=[sys.executable,str(Path(__file__).with_name('analyze.py')),'--stage','stage1','--log',str(d/'log'),'--identity',str(d/'identity'),'--cards',str(d/'cards'),'--authorizations',str(d/'authorizations'),'--evidence',str(d/'evidence')]
 result=subprocess.run(cmd,text=True,capture_output=True);assert result.returncode==0,result.stderr;parsed=json.loads(result.stdout);assert parsed['collectionComplete'] and parsed['calibration'] and parsed['verdict']['comparison']=='inconclusive' and not parsed['verdict']['accepted']
 failed=subprocess.run(cmd[:-2],text=True,capture_output=True);assert failed.returncode==2
print('PASS offline CLI explicit context; n1 completeness/performance separation and missing-context refusal')
bad=copy.deepcopy(owner_rows);desc=next(e for e in bad if e['class']=='changedDescribe');bad.remove(desc);done=next(e for e in bad if e['class']=='operationDone');index=bad.index(done)+1;t=done['timestamp']+.02;desc.update(timestamp=t,startTimestamp=t-.005,endTimestamp=t-.001,elapsedMs=4.);bad.insert(index,desc);renumber(bad);refused(bad,owner_card)
native_observations=[dict(runId='neutral-run',clockOrigin='neutral-clock',start=9.,end=10.,bytes=1,checkpoint=False,error=None),dict(runId='neutral-run',clockOrigin='neutral-clock',start=10.5,end=10.6,bytes=2,checkpoint=False,error=None),dict(runId='neutral-run',clockOrigin='neutral-clock',start=11.,end=12.,bytes=3,checkpoint='finish',error=None)]
assert a.overlap_report(n|{'samples':[sample]},native_observations)['overlapCount']==1
for field in ('runId','clockOrigin','checkpoint','error','bytes','end'):
 bad=copy.deepcopy(native_observations)
 bad[0][field]={'runId':'other','clockOrigin':'other','checkpoint':True,'error':'failure','bytes':True,'end':None}[field]
 try:a.overlap_report(n|{'samples':[sample]},bad)
 except ValueError:pass
 else:raise AssertionError('invalid collector row admitted '+field)
print('PASS exact Task1 native collector row schema; run/origin/error/type failures refuse overlap certification')

def stage1_short_launch(candidate_ms):
 template,_=cold_short_fixture();template=[e for e in template if e['cardId']=='card'];renumber(template)
 result=[];identities=[];contexts={}
 for block,variant in ((str(n),v) for n in (1,2) for v in ('baseline','candidate')):
  cardid='card-'+block+'-'+variant;nonce='neutral-'+block+'-'+variant;identity=I|dict(coldPairs=5,launchPairs=1,cardId=cardid,activationNonce=nonce,variant=variant,block=block,clockOrigin='clock-'+nonce)
  identities.append(identity);contexts[nonce]=copy.deepcopy(CARD)|{'cardId':cardid}
  rows=copy.deepcopy(template)
  for e in rows:
   for key in ('cardId','activationNonce','variant','block','clockOrigin'):e[key]=identity[key]
   if isinstance(e['operationId'],str):e['operationId']=e['operationId'].replace('card:',cardid+':')
   if 'requestedOperationIds' in e:e['requestedOperationIds']=[name.replace('card:',cardid+':') for name in e['requestedOperationIds']]+[cardid+':launch:1',cardid+':control:1']
   if e['class']=='coldRender':
    e['rendered']=True
    if e['scope']=='callback':e['elapsedMs']=14. if variant=='baseline' else candidate_ms;e['endTimestamp']=e['startTimestamp']+e['elapsedMs']/1000
  result+=rows
 return result,identities,contexts
short_events,short_identities,short_cards=stage1_short_launch(14.)
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp);(d/'log').write_text(''.join('prism-budget '+json.dumps(e)+'\n' for e in short_events));(d/'cards').write_text(json.dumps(short_cards));(d/'authorizations').write_text('{}');(d/'evidence').write_text(json.dumps(dict(integrityComplete=True,referenceComplete=True,identityComplete=True,correctnessComplete=True,errorComplete=True,correct=True,budgetErrors=0,launchComplete=True)))
 command=[sys.executable,str(Path(__file__).with_name('analyze.py')),'--stage','stage1','--log',str(d/'log'),'--cards',str(d/'cards'),'--authorizations',str(d/'authorizations'),'--evidence',str(d/'evidence')]
 for index,identity in enumerate(short_identities):p=d/('identity'+str(index));p.write_text(json.dumps(identity));command+=['--identity',str(p)]
 cli=subprocess.run(command,text=True,capture_output=True);assert cli.returncode==0,cli.stderr;out=json.loads(cli.stdout)
 assert out['verdict']['comparison']=='revert','complete failing cold evidence suppressed by short launch collection'
short_norm=a.normalize(short_events,short_identities,short_cards,{})
assert not short_norm['collectionComplete'] and short_norm['coldCollectionComplete']
short_events,short_identities,short_cards=stage1_short_launch(12.)
short_norm=a.normalize(short_events,short_identities,short_cards,{})
E=dict(integrityComplete=True,referenceComplete=True,identityComplete=True,correctnessComplete=True,errorComplete=True,correct=True,budgetErrors=0)
aggregation=a.target_blocks(short_norm);assert aggregation['stage']=='stage1'
assert a.decide(aggregation['stage'],[aggregation['blocks'][str(n)] for n in (1,2)],E,False)['comparison']=='inconclusive'
print('PASS related I1 cold collection separated from launch/card completeness: full failing cold CLI reverts; cold pass with short launch stays inconclusive')
# Profile generation transitions cannot be replaced by matching stale labels.
profile_rows,profile_card=fixture(ops);assert norm(profile_rows,profile_card)['collectionComplete']
for mutation in ('stale-profile','skipped-accepted','missing-profile-action'):
 bad=copy.deepcopy(profile_rows)
 if mutation=='stale-profile':
  for e in bad:
   if e['operationId']==ops[0]['id']:e['profileGeneration']=0
 if mutation=='skipped-accepted':
  for e in bad:
   if e['operationId']==ops[0]['id']:e['acceptGeneration']+=1
 if mutation=='missing-profile-action':
  for e in bad:
   if e['class']=='profileAction':e['class']='input'
 refused(bad,profile_card)
# Explicit invalid historical snapshots remain preserved without moving current state backward.
invalid_ref_rows=copy.deepcopy(rows);i=next(i for i,e in enumerate(invalid_ref_rows) if e['class']=='drain');ref=copy.deepcopy(next(e for e in invalid_ref_rows if e['class']=='acceptedReference'));t=invalid_ref_rows[i]['timestamp']-.02
ref.update(recordId=1000,callbackId=100,acceptGeneration=1,valid=False,reason='superseded',acceptedProfile=False,acceptedWallpaper=False,values={},heldScratchKeys=[],timestamp=t,startTimestamp=t-.006,endTimestamp=t-.002,elapsedMs=4.)
invalid_ref_rows.insert(i,ref);renumber(invalid_ref_rows);assert norm(invalid_ref_rows,card)['collectionComplete']
# A mixed stage refuses even with different block/variant positions, and CLI stage is bound to capture.
other=copy.deepcopy(I);other.update(variant='candidate',activationNonce='other',stage='stage2',cardId='other')
try:a.normalize([], [I,other],{}, {})
except ValueError:pass
else:raise AssertionError('mixed capture stages accepted')
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp);complete,context=fixture();objects=dict(identity=I,cards={I['activationNonce']:context},authorizations={},evidence=dict(integrityComplete=True,referenceComplete=True,identityComplete=True,correctnessComplete=True,errorComplete=True,correct=True,budgetErrors=0,launchComplete=True))
 for name,obj in objects.items():(d/name).write_text(json.dumps(obj))
 (d/'log').write_text(''.join('prism-budget '+json.dumps(e)+'\n' for e in complete))
 cmd=[sys.executable,str(Path(__file__).with_name('analyze.py')),'--stage','stage2','--log',str(d/'log'),'--identity',str(d/'identity'),'--cards',str(d/'cards'),'--authorizations',str(d/'authorizations'),'--evidence',str(d/'evidence')]
 cli=subprocess.run(cmd,text=True,capture_output=True);assert cli.returncode!=0 and 'decision stage differs from captured stage' in cli.stderr
print('PASS I2 current accepted/profile transitions and preserved invalid superseded refs; I3 mixed-stage and CLI mismatch refusal')
if len(sys.argv)>1:
 saved=Path(sys.argv[1])/'integration-v2'
 def context(stem):
  ctx=json.loads((saved/(stem+'-context.json')).read_text());events=a.read_rotated([saved/(stem+'-payload.log')]);return events,ctx
 def normalized(events,ctx):return a.normalize(events,ctx['identities'],ctx['cards'],ctx['authorizations'])
 es,ctx=context('final-excluded-fix1-excluded-fake-baseline');report=a.pairs(normalized(es,ctx));assert len(report['pairs'])==2 and sum(not p['control'] for p in report['pairs'])==1
 assert any(x['reason']=='operation-not-certified' for x in report['exclusions'])
 es,ctx=context('final-pairs-periodic-fake-baseline')
 for e in es:
  if e['class']=='operationRequested' and e['operationKind']=='launch':e['valid']=False
 parsed=normalized(es,ctx);report=a.pairs(parsed);assert not parsed['collectionComplete'] and parsed['coldCollectionComplete'] and len(report['pairs'])==5 and all(p['control'] for p in report['pairs']) and report['inconclusive']
 with tempfile.TemporaryDirectory() as temp:
  d=Path(temp);objects=dict(identity=ctx['identities'][0],cards=ctx['cards'],authorizations=ctx['authorizations'],evidence=E|{'launchComplete':True})
  for name,obj in objects.items():(d/name).write_text(json.dumps(obj));(d/name).chmod(0o600)
  (d/'log').write_text(''.join('prism-budget '+json.dumps(e)+'\n' for e in es));(d/'log').chmod(0o600)
  cmd=[sys.executable,str(Path(__file__).with_name('analyze.py')),'--stage','stage1','--log',str(d/'log'),'--identity',str(d/'identity'),'--cards',str(d/'cards'),'--authorizations',str(d/'authorizations'),'--evidence',str(d/'evidence')]
  cli=subprocess.run(cmd,text=True,capture_output=True);assert cli.returncode==0,cli.stderr;result=json.loads(cli.stdout);assert result['launch']['inconclusive'] and not any(g['primary'] and not g['control'] for g in result['launch']['groups'])
 for mutation in ('accepted','profile'):
  es,ctx=context('final-main-probe-references-fake-baseline');req=next(e for e in es if e['class']=='operationRequested' and e['operationKind']=='release');name=req['operationId'];assert req['acceptGeneration']==6
  for e in es:
   if e['operationId']==name:
    if mutation=='accepted':e['acceptGeneration']=0 if e is req else 1
    else:e['profileGeneration']=1
  try:parsed=normalized(es,ctx)
  except ValueError:pass
  else:assert not parsed['collectionComplete'] and not parsed['coldCollectionComplete']
 print('PASS saved I1 exact certified credit and direct/CLI false-primary refusal; I2 matched0→1 after6 and profile generation mutation refusals')
frozen_profile=copy.deepcopy(profile_rows)
for e in frozen_profile:e['profileGeneration']=0
refused(frozen_profile,profile_card)
if len(sys.argv)>1:
 profile_timeline=a.read_rotated([Path(sys.argv[1])/'generation-producer-profile.log']);ordered=sorted(profile_timeline,key=lambda e:e['recordId']);a.generation_timeline(ordered)
 assert max(e['profileGeneration'] for e in ordered)==2 and sum(e['class']=='operationRequested' and e['operationKind']=='profile' for e in ordered)==2
 print('PASS immutable actual Task2 Q/P accepted/profile generation timeline (calibration timeline only)')

# N1: hypothetical live-format contract inputs are generated from neutral values before
# serialization. They test the CLI boundary; they are not live measurement/source proof.
def stage2_contract_capture():
 released=copy.deepcopy(REF);released['values']['n']=1.1;released['heldScratchKeys']=['n']
 operations=[]
 for index in range(5):
  operations += [dict(id=f'card:action:{2*index+1}',kind='release',key='n',expectedReference=released),dict(id=f'card:action:{2*index+2}',kind='restore',key='n',expectedReference=REF)]
 for index in range(3):
  operations += [dict(id=f'card:action:{11+2*index}',kind='profile',profile='Q',expectedReference=Q),dict(id=f'card:action:{12+2*index}',kind='profile',profile='P',expectedReference=REF)]
 colds,_=cold_short_fixture();colds=[e for e in colds if e['cardId']=='card'][:-3]
 for e in colds:
  if e['class']=='coldRender':e['rendered']=True
 owners,card=fixture(operations);begin=next(i for i,e in enumerate(owners) if e['class']=='operationRequested' and e['operationKind']=='release');owners=copy.deepcopy(owners[begin:])
 for e in owners:
  e['acceptGeneration']+=4
  if e['callbackId']:e['callbackId']+=100
  if 'callbackIdTarget' in e:e['callbackIdTarget']+=100
  for key in ('recordId','referenceId','drainRecordId','renderIdTarget'):
   if key in e:e[key]+=10000
  for key in ('timestamp','startTimestamp','endTimestamp'):
   if key in e:e[key]+=100
  if 'requestedOperationIds' in e:e['requestedOperationIds']=[f'card:cold:{i}' for i in range(1,6)]+[op['id'] for op in operations]
 with_drag=[];prior='card:cold:5';count=0
 for e in owners:
  if e['class']=='operationRequested' and e['operationKind']=='release':
   count+=1;t=e['timestamp']-.04;render=copy.deepcopy(next(r for r in owners if r['class']=='release' and r['scope']=='render' and r['operationId']==e['operationId']))
   render.update(recordId=100000+count*2,callbackId=500+count,operationId=prior,timestamp=t,startTimestamp=t-.004,endTimestamp=t-.002,elapsedMs=2.,phase='dragTick');render['class']='dragTick'
   end=copy.deepcopy(render);end.update(recordId=100001+count*2,scope='callback',timestamp=t+.02,startTimestamp=t-.005,endTimestamp=t+.005,elapsedMs=10.);with_drag += [render,end]
  with_drag.append(e)
  if e['class']=='operationDone':prior=e['operationId']
 template=renumber(copy.deepcopy(colds)+with_drag);events=[];identities=[];cards={}
 for block,variant in ((str(n),v) for n in (1,2) for v in ('baseline','candidate')):
  nonce='neutral-stage2-'+block+'-'+variant;identity=I|dict(stage='stage2',environment='live',runId='neutral-stage2-contract',activationNonce=nonce,clockOrigin='clock-'+nonce,block=block,variant=variant,coldPairs=5,launchPairs=0)
  identities.append(identity);cards[nonce]=copy.deepcopy(card)
  for row in template:
   event=copy.deepcopy(row)
   for key in ('stage','environment','runId','activationNonce','clockOrigin','block','variant'):event[key]=identity[key]
   if event['class']=='coldRender' and event['scope']=='callback':event['elapsedMs']=14. if variant=='baseline' else 12.;event['endTimestamp']=event['startTimestamp']+event['elapsedMs']/1000
   events.append(event)
 return events,identities,cards
stage2_events,stage2_identities,stage2_cards=stage2_contract_capture();parsed=a.normalize(stage2_events,stage2_identities,stage2_cards,{})
assert parsed['stage']=='stage2' and parsed['collectionComplete'] and not a.pairs(parsed)['pairs']
aggregation=a.target_blocks(parsed)
assert all(len(aggregation['blocks'][block][variant][kind])>=5 for block in ('1','2') for variant in ('baseline','candidate') for kind in a.CLASSES)
S=E|dict(stage1Certified=True,launchIdentityComplete=True,launchGroupsComplete=True,restorationComplete=True,clockOriginVerified=True,environment='live',launchComplete=True)
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp);(d/'log').write_text(''.join('prism-budget '+json.dumps(e)+'\n' for e in stage2_events));(d/'cards').write_text(json.dumps(stage2_cards));(d/'authorizations').write_text('{}')
 command=[sys.executable,str(Path(__file__).with_name('analyze.py')),'--stage','stage2','--log',str(d/'log'),'--cards',str(d/'cards'),'--authorizations',str(d/'authorizations'),'--evidence',str(d/'evidence')]
 for index,identity in enumerate(stage2_identities):p=d/('identity'+str(index));p.write_text(json.dumps(identity));command+=['--identity',str(p)]
 def cli_evidence(evidence):
  (d/'evidence').write_text(json.dumps(evidence));return subprocess.run(command,text=True,capture_output=True)
 positive=cli_evidence(S);assert positive.returncode==0,positive.stderr;result=json.loads(positive.stdout)
 assert result['verdict']['accepted'] and not result['launch']['pairs'],'Stage2 CLI rejected complete fresh classes because current launchPairs=0'
 for flag in ('stage1Certified','launchIdentityComplete','launchGroupsComplete','launchComplete','restorationComplete','clockOriginVerified'):
  false=cli_evidence(S|{flag:False});assert false.returncode==0,false.stderr;assert not json.loads(false.stdout)['verdict']['accepted'],flag
  missing=dict(S);del missing[flag];assert cli_evidence(missing).returncode!=0,flag
 wrong=cli_evidence(S|{'launchIdentityComplete':'true'});assert wrong.returncode!=0
 wrong_environment=cli_evidence(S|{'environment':'synthetic'});assert wrong_environment.returncode!=0 and 'environment mismatch' in wrong_environment.stderr
print('PASS N1 Stage2 CLI with launchPairs0 and complete external Stage1 boundary; false/missing/source-mismatch/type/environment flags never accept (neutral contract test only)')
