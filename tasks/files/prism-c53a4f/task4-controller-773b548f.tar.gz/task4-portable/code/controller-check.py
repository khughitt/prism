import importlib.util, math, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
assert (ROOT/'controller.py').exists(), 'controller budget/reservation implementation missing'
s=importlib.util.spec_from_file_location('controller',ROOT/'controller.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
def refuses(fn):
 try: fn()
 except (ValueError,AssertionError,PermissionError): return
 raise AssertionError('unsafe operation permitted')
assert c.reserve([100])==125
assert c.reserve([144])==180
refuses(lambda:c.reserve([144.000001]))
w=c.Window(100,{'pre':10,'post':10,'recovery':10,'finish':10})
w.stamp('initialCardIssued',110);w.stamp('initialCompleteReceived',1310);w.stamp('completenessChecked',1320)
assert w.controller_seconds(1320)==20
assert w.request_recovery(1320,30)==1570
refuses(lambda:w.approve(1571,30))
w.approve(1570,30);w.issue_recovery(1570,30)
w.stamp('recoveryCompleteReceived',2170);w.stamp('finishSent',2180);w.stamp('collectorExited',2190)
assert w.controller_seconds(2190)==290
for now,ok in [(1480,False),(1470,True)]:
 x=c.Window(0,{'finish':24});x.stamp('initialCardIssued',1);x.stamp('initialCompleteReceived',1201);x.stamp('completenessChecked',1202)
 if ok: assert x.can_issue(now,30)
 else: assert not x.can_issue(now,30)
x=c.Window(0,{'finish':1});x.stamp('initialCardIssued',1);x.stamp('initialCompleteReceived',1202)
assert x.invalid and x.stamps['initialCompleteReceived']==1202
assert not x.can_issue(2100,1)
assert c.Window(0,{'finish':1}).can_initial(298,2)
assert not c.Window(0,{'finish':1}).can_initial(299,2)
print('PASS reservation boundaries; initial20min; approval wait and full600; expiry retains observations')
import copy,json,tempfile,shutil
assert hasattr(c,'materialize'),'independent operation context missing'
saved={'pair':{'P':'P','Q':'Q'},'runtime':{'active':{'profile':'P'},'scratch':{}},'profiles':{'P':{'a':.2,'b':.5},'Q':{'a':.7,'b':.8}},'uneditedNumeric':[{'key':'a'}]}
defs={'a':{'type':'float','range':[0,1]},'b':{'type':'float','range':[0,1]}}
manifest={'cardId':'c','activationNonce':'n','operations':[{'id':'c:action:1','kind':'release','key':'a'},{'id':'c:action:2','kind':'restore','key':'a'},{'id':'c:action:3','kind':'profile','profile':'Q'},{'id':'c:action:4','kind':'profile','profile':'P'}]}
events=[{'class':'operationRequested','operationKind':'release','valid':True,'operationId':'c:action:1','key':'a','recordId':1,'callbackId':0,'acceptGeneration':4},
 {'class':'release','scope':'callback','operationId':'c:action:1','recordId':2,'callbackId':2,'endTimestamp':10,'acceptGeneration':4},
 {'class':'operationIntent','scope':'observer','observer':True,'callbackId':0,'operationId':'c:action:1','key':'a','recordId':3,'releaseCallbackId':2,'startTimestamp':10.01,'endTimestamp':10.02,'timestamp':10.03,'acceptGeneration':4,'canonicalValue':.21,'valueText':'0.21'},
 {'class':'acceptedReference','valid':True,'operationId':'c:action:1','recordId':4,'timestamp':11,'acceptGeneration':5}]
ctx=c.materialize(manifest,saved,defs,events,True)
assert ctx['operations'][0]['expectedReference']=={'acceptedProfile':'P','acceptedWallpaper':False,'values':{'a':.21,'b':.5},'heldScratchKeys':['a']}
assert ctx['operations'][1]['expectedReference']['heldScratchKeys']==[]
assert ctx['operations'][2]['expectedReference']['values']=={'a':.7,'b':.8}
for field,value in [('key','b'),('canonicalValue',.3),('valueText','0.22'),('acceptGeneration',3),('releaseCallbackId',9),('startTimestamp',9)]:
 bad=copy.deepcopy(events);bad[2][field]=value;refuses(lambda:c.materialize(manifest,saved,defs,bad,True))
refuses(lambda:c.materialize(manifest,saved,defs,events+[events[2]],True))
refuses(lambda:c.materialize(manifest,saved,defs,events[:2]+events[3:],True))
for altered in [{'a':.22,'b':.5},{'a':.21,'b':.6},{'a':.2,'b':.21}]:
 assert not c.analyze.exact_reference(ctx['operations'][0]['expectedReference'],dict(ctx['operations'][0]['expectedReference'],values=altered))
rounded=copy.deepcopy(events);rounded[2].update(canonicalValue=.30000000000000004,valueText='0.30000000000000004')
assert c.materialize(manifest,saved,defs,rounded,True)['operations'][0]['expectedReference']['values']['a']==.30000000000000004
rounded[2]['valueText']='0.3';refuses(lambda:c.materialize(manifest,saved,defs,rounded,True))
print('PASS independent intent oracle; wrong key/value/other param, duplicate/stale/timing, exact Queue serialization refused')
assert (ROOT/'clock-gate.py').exists(),'independent Noctalia clock gate missing'
cg=c.module('clock_gate',ROOT/'clock-gate.py')
actual={'bootId':'new-boot','installed':{'path':'/fixture/noctalia','sha256':'bin','buildId':'build','package':'noctalia 5.2.1-1'},'running':{'pid':123,'startTicks':456,'sha256':'bin','buildId':'build'},'sourceRevision':cg.REVISION,'sourceFiles':cg.SOURCE_HASHES,'pythonMonotonic':'clock_gettime(CLOCK_MONOTONIC)','packageFiles':{'PKGINFO':'pkg','BUILDINFO':'buildinfo'}}
proof={'schema':2,'environment':'live','sessionId':'root-session','observed':actual,'binding':{'rootSessionId':'root-session','sourceRevision':cg.REVISION,'binarySha256':'bin','package':'noctalia 5.2.1-1','noHostClockOverride':True,'linuxClock':'CLOCK_MONOTONIC','originOffsetSeconds':0},'excerpts':{k:{'fileSha256':v,'firstLine':1,'text':'fixture'} for k,v in cg.SOURCE_HASHES.items()}}
historical={'controllerOrigin':'host-monotonic:old-boot','origins':['host-monotonic:old-boot'],'probeOrigin':'historical-nonce','probeTimestamp':294942.885733029,'controllerTimestamp':294942.898069801,'rawSha256':'raw','phasesSha256':'phases'}
assert cg.verify(proof,actual,historical)['clockOrigin']=='host-monotonic:new-boot'
for path,value in [(('observed','bootId'),'bad'),(('observed','running','buildId'),'bad'),(('observed','installed','package'),'bad'),(('binding','linuxClock'),'CLOCK_PROCESS_CPUTIME_ID'),(('binding','noHostClockOverride'),False), (('binding','originOffsetSeconds'),1)]:
 bad=copy.deepcopy(proof);obj=bad
 for key in path[:-1]:obj=obj[key]
 obj[path[-1]]=value;refuses(lambda:cg.verify(bad,actual,historical))
refuses(lambda:cg.verify({},actual,historical))
for timestamp in [294942.884,294945.898]:refuses(lambda:cg.verify(proof,actual,dict(historical,controllerTimestamp=timestamp)))
refuses(lambda:cg.verify(proof,actual,dict(historical,origins=['host-monotonic:other-boot'])))
print('PASS clock source/build/boot/override/missing-proof and historical reverse/offset negatives; old boot remains historical')
assert hasattr(c,'Controller'),'durable host controller missing'
class FakeHost:
 def __init__(self,root):self.root=root;self.actions=[];self.receipts={};self.elapsed=0
 def invoke(self,action,authorization,arguments):
  started=c.time.monotonic();self.actions.append(action)
  result=self.receipts.get(action,{})
  self.elapsed+=c.time.monotonic()-started
  return copy.deepcopy(result)
with tempfile.TemporaryDirectory() as td:
 root=pathlib.Path(td);host=FakeHost(root);now=[100.]
 session={'schema':2,'sessionId':'fake-session','runId':'fake-run','environment':'fake-host','clockOrigin':'host-monotonic:fake-boot','identity':{'schema':2,'stage':'stage1','runId':'fake-run','cardId':'c','activationNonce':'n','coldPairs':1,'launchPairs':0},'steps':{'pre':1,'post':1,'recovery':1,'finish':1}}
 x=c.Controller(root,session,host,lambda:now[0]);x.prepare({'id':'test-auth'})
 assert host.actions[:4]==['rotation-snapshot','rotation-pause','state-snapshot','state-clear']
 x.collector_started({'runId':'fake-run','clockOrigin':session['clockOrigin'],'collectorStarted':100,'exitReason':'running','integrityComplete':False,'processes':{'collector':{'pid':123}}})
 x.activate({'id':'test-auth'})
 assert host.actions.index('collector-launch')<host.actions.index('plugins-enable')
 assert x.state['phase']=='enabled'
 now[0]=110;x.issue_initial({'initialModelEmpty':True,'initialStructureEmpty':True,'initialMemoEmpty':True,'initialDragEmpty':True,'initialQueueEmpty':True,'initialPairEmpty':True,'initialRenderPending':False,'initialEnqueued':0},saved,manifest={},remaining=10)
 assert x.state['phase']=='owner-card' and (root/'owner-card.txt').exists()
 now[0]=120;x.owner_complete('actual-reply-id');x.checked({'collectionComplete':False,'certificates':[]})
 now[0]=121;x.request_recovery(10)
 assert x.state['phase']=='awaiting-approval'
 now[0]=122;x.approve_recovery({'id':'fresh-recovery-auth'}, {'schema':2,'approved':True,'runId':'fake-run','activationNonce':'n','cardId':'recovery','replacementFor':['c:cold:1'],'coldPairs':1,'launchPairs':0,'operations':[]},10)
 assert (root/'recovery.json').exists()
 now[0]=123;x.owner_complete('second-reply-id');x.checked({'collectionComplete':True,'certificates':[{'physicalDrainComplete':True}]})
 refuses(lambda:x.finish({'id':'auth'}, {'collectionComplete':False}))
 x.finish({'id':'auth'},{'collectionComplete':True})
 receipt={'schema':2,'runId':'fake-run','clockOrigin':session['clockOrigin'],'collectorStarted':100,'exitReason':'finish','integrityComplete':True,'error':None,'processes':{},'wrapperEnded':124}
 now[0]=124;x.exited(receipt,lambda _:False,{'collectionComplete':True,'certificates':[{'physicalDrainComplete':True}]})
 assert x.state['protocolComplete'] is True
 x.restore({'id':'auth'});assert host.actions[-3:]==['state-restore','rotation-resume','restore-verify']
 assert json.loads((root/'state.json').read_text())['phase']=='restored'
 if len(sys.argv)>1:
  shutil.copytree(root,pathlib.Path(sys.argv[1])/'fake-host-flow');c.immutable(pathlib.Path(sys.argv[1])/'fake-ipc-actions.json',{'actions':host.actions,'seconds':host.elapsed})
 print('PASS durable fake-host startup/capture/owner reply/recovery/settlement/finish/restore flow')
# Run the real incremental collector on neutral temp log bytes, and feed its archived
# records to the real parser and controller verdict (never a live acceptance).
import ast,subprocess,time
fixture_path=ROOT/'frozen-task2/analysis_check.py'
fixture_ast=ast.parse(fixture_path.read_text());nodes=[]
for node in fixture_ast.body:
 if isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef)):nodes.append(node)
 elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('REF','I','CARD') for t in node.targets):nodes.append(node)
# Only definitions preceding fixture consumer, never execute another suite on import.
ns={'__file__':str(fixture_path)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(fixture_path),'exec'),ns)
rows,card=ns['fixture']();identity=ns['I'];baseline=copy.deepcopy(rows)
with tempfile.TemporaryDirectory() as td:
 root=pathlib.Path(td);log=root/'host.log';log.write_text('old history\n');runid=identity['runId']
 config={'schema':2,'environment':'synthetic','runId':runid,'clockOrigin':identity['clockOrigin'],'socket':'prism-budget-capture-check-'+c.uuid.uuid4().hex,'deadlineSeconds':2700,'pollSeconds':.02,'maxGapSeconds':1,'log':str(log)}
 for key in ('manifest','control','receipt','heartbeat','polls','identities'):config[key]=str(root/(key+'.json'))
 c.immutable(root/'run.json',config);c.immutable(root/'wrapper-ready.json',{});c.immutable(root/'identities.json',{})
 step={};start=time.monotonic();child=subprocess.Popen([sys.executable,str(ROOT/'capture.py'),'run',str(root/'run.json')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 try:
  deadline=time.monotonic()+5
  while not (root/'heartbeat.json').exists() and child.poll() is None and time.monotonic()<deadline:time.sleep(.01)
  assert (root/'heartbeat.json').exists(),'collector startup failed: '+child.communicate(timeout=2)[0]
  step['pre-card']=time.monotonic()-start
  payload=''.join('prism-budget '+json.dumps(e)+'\n' for e in rows)
  burst_started=time.monotonic()
  with log.open('a') as f:f.write(payload);f.flush();c.os.fsync(f.fileno())
  burst_seconds=time.monotonic()-burst_started
  c.atomic(root/'control.json',{'sequence':1,'command':'ready'})
  deadline=time.monotonic()+5
  while c.load(root/'heartbeat.json').get('lastSequence')!=1 and child.poll() is None and time.monotonic()<deadline:time.sleep(.01)
  start=time.monotonic();captured=c.load(root/'manifest.json');segments=[root/r['path'] for r in captured['segments']]
  parsed=c.analyze.read_rotated(segments);assert parsed==baseline
  normalized=c.analyze.normalize(parsed,[identity],{identity['activationNonce']:card},{})
  assert normalized['collectionComplete'];step['post-card']=time.monotonic()-start
  # Existing combined fixture exercises real parser replacement credit.
  ns['a']=c.analyze;ns['Q']=dict(copy.deepcopy(ns['REF']),acceptedProfile='Q');ns['Q']['values']['n']=2;combined,combined_card,auth=ns['recovery_fixture']()
  start=time.monotonic();recovered=c.analyze.normalize(combined,[identity],{identity['activationNonce']:combined_card},auth)
  assert recovered['collectionComplete'] and len(recovered['certificates'][0]['replacementCredit'])==4
  step['post-recovery']=time.monotonic()-start
  start=time.monotonic();c.atomic(root/'control.json',{'sequence':2,'command':'finish'});output=child.communicate(timeout=5)[0]
  assert child.returncode==0,output
  receipt=c.load(root/'collector-receipt.json');assert receipt['integrityComplete']
  captured=c.load(root/'manifest.json');assert captured['lastCheckpoint']=='finish' and captured['integrityComplete'] is False
  observations=[json.loads(line) for line in pathlib.Path(config['polls']).read_text().splitlines()]
  result=c.session_verdict(normalized,[identity],[receipt],[],{'verified':False},{'budgetErrors':0,'complete':True,'polls':observations})
  assert result['verdict']['comparison']=='inconclusive' and not result['verdict']['accepted']
  step['finish']=time.monotonic()-start
  measurement={'environment':'fake-host','ipcProvenance':'fake Noctalia IPC; real temp collector subprocess and parser','stepSeconds':step,'stepReserve':c.reserve(list(step.values())),'approvalSeconds':300-c.reserve(list(step.values())),'fakeIpcSeconds':host.elapsed,'pollSeconds':.02,'maxGapSeconds':1,'fullBurstBytes':len(payload.encode()),'fullBurstSeconds':burst_seconds,'offlineStepSumSeconds':sum(step.values()),'verdict':result['verdict']}
  print('MEASURED '+json.dumps(measurement,sort_keys=True))
  if len(sys.argv)>1:
   c.immutable(pathlib.Path(sys.argv[1])/'controller-smoke.json',measurement);shutil.copytree(root,pathlib.Path(sys.argv[1])/'temp-collector');c.immutable(pathlib.Path(sys.argv[1])/'combined-recovery-neutral.json',{'events':combined,'card':combined_card,'authorizations':auth,'normalized':recovered})
 finally:
  if child.poll() is None:child.terminate();child.communicate(timeout=5)
print('PASS real temp collector→strict parser→combined replacement→inconclusive verdict→finish/reap; immutable bytes match')
# Root authorization is checked before even a harmless injected command executes.
with tempfile.TemporaryDirectory() as td:
 root=pathlib.Path(td);spec={'argv':[sys.executable,'-c','print("{}")'],'json':True,'timeoutSeconds':2}
 session={'sessionId':'s','runId':'r','hostActions':{'finish-authorize':spec}}
 rh=c.RootHost(root,session);now=time.monotonic();permit={'id':'one','action':'finish-authorize','arguments':spec,'issuedAt':now,'expiresAt':now+30}
 auth={'approved':True,'author':'root-controller','sessionId':'s','runId':'r','bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'permits':[permit]}
 path=root/'auth.json';c.immutable(path,auth);assert rh.invoke('finish-authorize',path,spec)['authorized'] is True
 try:rh.invoke('finish-authorize',path,spec)
 except FileExistsError:pass
 else:raise AssertionError('replayed permit accepted')
 for field,value in [('approved',False),('author','worker'),('sessionId','other'),('bootId','other')]:
  bad=copy.deepcopy(auth);bad[field]=value;bad['permits'][0]['id']='new';c.atomic(path,bad);refuses(lambda:rh.invoke('finish-authorize',path,spec))
 bad=copy.deepcopy(auth);bad['permits'][0].update(id='late',issuedAt=now-100,expiresAt=now-1);c.atomic(path,bad);refuses(lambda:rh.invoke('finish-authorize',path,spec))
print('PASS fresh root/session/boot/exact-argv/one-use authorization; replay/stale/worker denied')
assert c.capture_limits(4*1024*1024,1024,1)['fileFillSeconds']==60
limits=c.capture_limits(100000,1000000,1);assert limits['pollSeconds']==.025 and limits['maxGapSeconds']==.05
refuses(lambda:c.capture_limits(100,0,1))
# Literal link restoration and conflict protection run solely inside a temp directory.
with tempfile.TemporaryDirectory() as td:
 root=pathlib.Path(td);pointer=root/'plugin';pointer.symlink_to('../literal-original')
 spec={'path':str(pointer),'from':'../literal-original','to':'./candidate'}
 rh=c.RootHost(root,{'sessionId':'s','runId':'r','hostActions':{'pointer-swap':spec}})
 now=time.monotonic();auth={'approved':True,'author':'root-controller','sessionId':'s','runId':'r','bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'permits':[{'id':'pointer-one','action':'pointer-swap','arguments':spec,'issuedAt':now,'expiresAt':now+30}]}
 path=root/'auth.json';c.immutable(path,auth);assert rh.invoke('pointer-swap',path,spec)['from']=='../literal-original'
 assert c.os.readlink(pointer)=='./candidate'
 auth['permits'][0]['id']='pointer-two';c.atomic(path,auth);refuses(lambda:rh.invoke('pointer-swap',path,spec));assert c.os.readlink(pointer)=='./candidate'
print('PASS measured rate caps and literal temp-pointer journal/conflict guard')
# The controller must retain the cold-only failure row when launch groups are short.
ns['a']=c.analyze
for candidate,want in [(14.,'revert'),(12.,'inconclusive')]:
 ev,identities,cards=ns['stage1_short_launch'](candidate);normal=c.analyze.normalize(ev,identities,cards,{})
 receipts=[{'integrityComplete':True,'exitReason':'finish','error':None,'clockOrigin':i['clockOrigin'],'runId':i['runId']} for i in identities]
 out=c.session_verdict(normal,identities,receipts,[],{'verified':False},{'budgetErrors':0,'complete':True,'polls':[]})
 assert out['verdict']['comparison']==want
prior={'events':ev,'identities':identities,'cards':cards,'authorizations':{},'receipts':receipts,'restoration':[],'clock':{'verified':False},'observations':{'budgetErrors':0,'complete':True,'polls':[]}}
ev2,ids2,cards2=ns['stage2_contract_capture']();normal2=c.analyze.normalize(ev2,ids2,cards2,{})
receipts2=[{'integrityComplete':True,'exitReason':'finish','error':None,'clockOrigin':i['clockOrigin'],'runId':i['runId']} for i in ids2]
evidence,launch=c.stage_evidence(normal2,ids2,receipts2,[],{'verified':False},{'budgetErrors':0,'complete':True,'polls':[]},prior)
assert evidence['launchIdentityComplete'] and not evidence['stage1Certified'] and not evidence['launchGroupsComplete'] and not evidence['restorationComplete'] and not evidence['clockOriginVerified'] and not launch
ids2bad=copy.deepcopy(ids2);ids2bad[0]['sourceCommit']='wrong'
evidence,_=c.stage_evidence(normal2,ids2bad,receipts2,[],{'verified':False},{'budgetErrors':0,'complete':True,'polls':[]},prior)
assert not evidence['launchIdentityComplete']
print('PASS controller cold-vs-full completeness and recomputed separate Stage1 source/group/restore/clock facts')
# No recovery path; expiry does not trigger cleanup, and an integrity receipt cannot
# certify missing settlement. Cleanup requires the recorded owner stop and reap.
with tempfile.TemporaryDirectory() as td:
 root=pathlib.Path(td);h=FakeHost(root);now=[0.];session={'schema':2,'sessionId':'s','runId':'r','environment':'fake-host','clockOrigin':'boot','identity':{'schema':2,'stage':'stage1','runId':'r','cardId':'c','activationNonce':'n','coldPairs':1,'launchPairs':0},'steps':{'pre':1,'post':1,'recovery':1,'finish':1}}
 obj=c.Controller(root,session,h,lambda:now[0]);obj.prepare({});obj.collector_started({'runId':'r','clockOrigin':'boot','collectorStarted':0,'exitReason':'running'});obj.activate({})
 obj.issue_initial({'initialModelEmpty':True,'initialStructureEmpty':True,'initialMemoEmpty':True,'initialDragEmpty':True,'initialQueueEmpty':True,'initialPairEmpty':True,'initialRenderPending':False,'initialEnqueued':0},saved,{},10)
 now[0]=2101;before=list(h.actions);obj.owner_complete('owner-reply-after-expiry');assert obj.window.invalid and h.actions==before
 obj.checked({'collectionComplete':True,'certificates':[{'physicalDrainComplete':True}]});refuses(lambda:obj.finish({}, {'collectionComplete':True}))
 obj.owner_stop({},'owner-stop-message');assert json.loads((root/'control.json').read_text())['command']=='stop'
 obj.stopped({'runId':'r','clockOrigin':'boot','wrapperEnded':2102,'processes':{}},lambda _:False);obj.restore({});assert obj.state['phase']=='restored' and not obj.state['protocolComplete']
print('PASS expiry during owner work retains invalid capture; no automatic pointer change; explicit stop/reap restores without acceptance')
extra=copy.deepcopy(events[2]);extra['operationId']='undeclared';extra['recordId']=5
refuses(lambda:c.materialize(manifest,saved,defs,events+[extra],True))
print('PASS undeclared extra release intent cannot enter immutable owner context')
