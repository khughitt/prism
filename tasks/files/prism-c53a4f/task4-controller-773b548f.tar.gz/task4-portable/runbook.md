# Capture-recovery controller runbook

This is a root-controller runbook, not a worker authorization. Every live setup,
IPC, timer, pointer, recovery publication and finish/stop operation needs fresh
root-owned session authorization. Prior desktop permission does not carry forward.
The Task4 checks use fake IPC and temporary stores; their measured reserve is not a
measurement of live IPC. Review the seconds-long smoke's verdict before any Task5
long rehearsal. No long rehearsal is launched by these scripts.

## Files and authority

Define CAPTURE_STATE from `${XDG_STATE_HOME:-$HOME/.local/state}/prism/panel-budget`,
CAPTURE_ROOT as its `capture-recovery-2026-10-13` child, CODE as `$CAPTURE_ROOT/code`,
and PRESERVED as its `task3-2026-10-13-preserved` sibling. Never write PRESERVED.
Each run has an exclusively created directory0700 and files0600. Invoke scripts
through Python/Node/Lua; do not change shared CLI launchers. The immutable reviewed
snapshot and SHA256 inventory in the Task4 report are authoritative.

Root resolves `command -v noctalia`, the running `/proc/PID/exe` identity and the
explicit `.worktrees/panel-budget/bin/prism` before setup. Preserve the literal
plugin symlink with `readlink`, not its resolved target. Record every pointer change
on the task immediately: what/from/to/how to restore. RootHost also writes the
literal pointer journal before replacement and refuses a changed link.

A session JSON has schema2, fresh sessionId/runId, environment, clockOrigin,
identity (the exact new builder identity), activationOrdinal1–4, pilot boolean, steps (`pre`, `post`,
`recovery`, `finish`, measured seconds), sourceProof, r2Root, buildRoot,
snapshotBundle, collectorConfig, artifactSha256 and rateMeasurement. Ordinals after1 require outgoingState (previous restored,
protocol-complete state) and referenceSnapshot (first fresh saved state); later
snapshots must match its documents/profiles/pair/runtime exactly. For live,
clockOrigin is `host-monotonic:<actual boot id>`. artifactSha256 includes all copied
plugin files, identity/transform manifests, collector/controller/state/guard code
and all frozen source artifacts. Verify every hash; any changed reference/source
invalidates the activation rather than updating one variant in place.

`hostActions` maps each action below to an exact `{argv,env,timeoutSeconds,json}`
command specification. argv is an array; no shell parsing. Set json true only for a
command that returns JSON. State/guard mutation env includes its reviewed approval
variable only behind RootHost's fresh permit. Pointer actions instead use
`{path,from,to}` with literal strings. `checkpoint-authorize`, `finish-authorize`,
`stop-authorize`, `recovery-authorize` have `{}` as their spec; the consumed permit
is their effect. Root prepares command specs; a worker never prepares live permits.

A permit file must be owned by the current user, mode0600, with approved=true,
author=`root-controller`, exact sessionId/runId/current bootId, and a `permits`
array. Each entry is `{id,action,arguments,issuedAt,expiresAt}`; arguments must equal
the immutable hostActions entry. id is unique alphanumeric/hyphen. issuedAt and
expiresAt use Python monotonic; expiry is at most60 seconds after issuance. Every
operation consumes its own id before acting, including failed attempts. A retry
needs a fresh permit; never extend/reuse an existing permit. Root writes these only
after actual authorization, using the actual root session identity. A grouped
permit file may name multiple imminent operations; refresh it when setup outlasts
its sixty-second validity, keeping consumed ids immutable.

## Independent Noctalia clock proof (required before asking for hands)

Run `python3 "$CODE/clock-gate.py" --source-proof ROOT_PROOF.json --r2-root
"$PRESERVED/r2-evidence-preserved" --output NEW_CLOCK_RESULT.json`. The output is
exclusive. Any missing/stale/mismatched item blocks. A synthetic producer cannot
pass this gate. Preliminary source inspection alone cannot pass it.

Root proof fields: schema2, environment=`live`, current root sessionId, sourceRoot,
packageRoot, observed, binding, excerpts. `observed` is exactly clock-gate.observe's
read-only result: current bootId; installed resolved path/SHA256/buildId/package;
running PID/startTicks/SHA256/buildId; sourceRevision/sourceFiles; Python monotonic
implementation; SHA256 of PKGINFO/BUILDINFO. Re-observe at every session; do not
copy a previous boot/PID assertion. Root independently endorses `binding` exactly:
rootSessionId, sourceRevision, binarySha256, package, noHostClockOverride=true,
linuxClock=`CLOCK_MONOTONIC`, originOffsetSeconds=0. This endorsement records the
source→package/build→actual installed/running binary mapping; do not infer it merely
because version labels agree. If that mapping cannot be established, stop here.

Each excerpts entry names a pinned source path and `{fileSha256,firstLine,text}`.
The tool checks the whole file hash and exact excerpt bytes against the official
v5.2.1 commit6ef43e2bf2f3d5b4205ec72a72e34a2ab76ce3b4. Inspect VERSION,
meson.build's vendored VM compilation, luau_host.cpp's luaL_openlibs/registrations/
sandbox and absence of an os.clock override, linit.cpp's luaopen_os, loslib.cpp's
os_clock→lua_clock and syslib clock entry, and lperf.cpp's Linux CLOCK_MONOTONIC,
1e-9 scale and absence of an origin offset. The current private unendorsed
inspection is evidence for root to review, not an authorization.

Historical C2 callback1911 is retained with its stored nonce origin; controller
C2-handsProfileQ-end is retained with its historical host-monotonic boot label.
The gate checks historical controller boot agreement within those phase records
and probe294942.885733029→controller294942.898069801 (12.337ms). A reversed or
seconds-offset pair fails. These are corroboration only, not an offset estimate
or proof that the historical boot equals today's boot.

## Setup and exact action commands

Use `controller.py create --run NEW_RUN --session SESSION.json`, then individual
`controller.py ACTION --run RUN [--authorization PERMIT.json] [--input INPUT.json]`
commands on root's active turns. No controller background polling loop exists.
`prepare` executes, in this order:

1. rotation-snapshot: `python3 "$CODE/rotation-guard.py" snapshot JOURNAL.json`.
2. rotation-pause: same helper `pause JOURNAL.json`, with
   PRISM_ROTATION_RETRY_APPROVED=yes. Preserve its journal/prior activation state.
   It stops only the timer, never disables units or kills the rotation service.
3. state-snapshot: `node "$CODE/snapshot.mjs" BUNDLE.json SAVED.json`, with
   PRISM_TASK3_REPO set to the explicit worktree. This fresh snapshot holds raw
   documents/runtime, exact scratch, P/Q canonical maps, unedited slider candidates,
   full definitions and resolver-source hashes under the reviewed lock.
4. state-clear: `node "$CODE/state.mjs" clear SAVED.json`, with
   PRISM_TASK3_APPROVED=yes and the explicit worktree environment.
5. `noctalia msg panel-close khughitt/prism:panel` (panel-close).
6. `noctalia msg plugins disable khughitt/prism` (plugins-disable).
7. pointer-swap uses the exact literal original and fresh instrumented target,
   with a journal before mutation. Root immediately records the task pointer note.
8. collector-launch: `python3 "$CODE/capture.py" launch RUN/run.json`.

The named collector creates its offset/archive before enable. run.json uses the
Task1 exact schema: live deadline2100; fresh socket `prism-budget-capture-<nonce>`;
log absolute; manifest/control/receipt/heartbeat/polls/identities paths directly
inside RUN. Its control path must be RUN/control.json, manifest RUN/manifest.json,
heartbeat RUN/heartbeat.json and receipt RUN/receipt.json. Never use the default
tmux server. Read heartbeat once on an active turn; `collector-started` refuses
until it contains collectorStarted and matching run/origin. Preserve all process
identities and the socket. No enable precedes this stamp.

`activate` performs:

```sh
noctalia msg plugins enable khughitt/prism
# export-ready: root's bounded, read-only readiness check for this plugin/export.
noctalia msg panel-open khughitt/prism:panel
```

The session's export-ready command must fail if readiness is absent; it may use a
bounded check before the card, never an owner-response polling loop. `checkpoint`
consumes a fresh permit and writes atomic ready control. Root reads heartbeat's
matching lastSequence before inspecting that durable checkpoint. `issue` takes
input `{current: PATH_TO_FRESH_STATE_CLEAR_OR_VERIFY_RESULT, remainingStepReserve}`;
it verifies source/build identity, fresh empty runtime activation and exact
P/canonical/test scratch before writing immutable action-manifest.json, saved.json
and owner-card.txt. Read the actual card; use the fresh snapshot's first unedited
slider, never an old exclusion list. Live artifacts are independently hash-checked
at preparation. Fresh nonce/runtime is mandatory even between C1 and C2.

## Owner turns, budgets and cards

Root posts owner-card.txt and ends its turn. Park the claim for the owner with
actual pointer path/from/to/restore, paused timer prior state/journal/resume command,
collector PID/startTicks/boot identity, fresh socket, collector deadline and exact
stop command. Never leave placeholders in an actual park. Collector exit does not
wake Codex. After the actual owner reply, resume the task and call `reply` with
`{replyId: ACTUAL_MESSAGE_ID}`. Do not synthesize a completion from an estimate.

Stage1 order is B1→C1→C2→B2: pilot1 cold each, then full5. B1/C1 have pilot1 or
full5 launch/control units; C2/B2 have none. The generated card says: wait for
controls, click Sample diagnostics (auto-expands), keep panel visible at least5 s
after the button disappears and controls settle, confirm once. No sliders/profiles.

Stage2 runs only after certified Stage1 cold gain/absolute/launch/control gates.
It captures its own new colds, launchPairs=0. Pilot has1 release/restore and1 Q/P
cycle; full has5 release/restore and3 Q/P cycles. Each two-second drag uses the named
unedited slider's own restore, with at least2-s dwell after each release and restore.
Named Q and P clicks must change Prism values and dwell at least5 s, including final
P before chat. Every action has its predeclared exact operation id/key/profile/order.

Initial card cap1200 s; separately approved recovery cap600 s; collector2100 s;
cumulative controller allowance300 s. Initial/recovery intervals are subtracted
exactly once. Record collectorStarted, initialCardIssued, initialCompleteReceived,
completenessChecked, recoveryRequested, approvalReceived, recoveryCardIssued,
recoveryCompleteReceived, finishSent and collectorExited. Window.invalid records
expiry and retains callbacks/bytes; it does not restore a pointer or shorten a card.

Measured step reserve is ceil(1.25*sum(stepSeconds)); require reserve+120≤300.
Live root setup must measure/check its actual remaining work before asking for
hands. Offline fake IPC times are separately labelled and cannot replace live IPC
measurements. Before initial issuance lifetime must fund1200+600+remaining reserve.
At recovery request:

```python
approval_deadline = min(collector_started+2100-600-final_step_reserve,
                        now+300-controller_seconds_used-final_step_reserve)
```

Recheck both lifetime and controller allowance on approval and on issuance. A
620-second lifetime with30-second final reserve refuses;630 allows the full600.
Approval wait cannot borrow recovery time. Late approval is refused; no590-s card.
The root reports the exact remaining approval deadline and deficits.

## Inspection, one recovery, finish and restore

After the reply, checkpoint on the active root turn and then `inspect`. Only the
named collector continuously reads logs. inspect_run reads stable archive/checkpoint
bytes, builds references from frozen snapshot plus independent intent, binds exact
raw intent-line hashes, and calls normalize(events,identities,cards,authorizations).
It checks callback/operation ids, exact Q/P references and ordinary deferred renders,
ready/cardSettled/final drain. An integrity receipt alone does not prove settlement.

A release intent is emitted after endDrag's callback endpoint and before accepted
describe: exact operation/key, corrected state.structure.byKey value, unchanged
Queue tostring text, generation/callback binding, observer endpoints. Definitions
and saved canonical source maps determine the expected scalar/map/scratch result;
acceptedReference is always the value checked. Missing, duplicate, stale, reordered,
wrong-key or serialization-disagreeing intents block certification. The original
manifest and raw records remain immutable. Profile/restore expectations remain
locked to saved source state. Luau's pinned lnumprint uses shortest round-trip
number formatting; mismatched canonicalValue/valueText refuses rather than guessing.

Keep the collector running through completeness and recovery decision. A closed
sample remains excluded. One combined approved packet may cover cold/launch,
release+restore and Q+P deficits, at most one extra unit of each type. Do not repair
missing records, source/identity/reference faults or budget errors by resampling.
`request-recovery` reserves a full600 s and enters awaiting-approval. Root obtains
fresh approval before `approve-recovery`, which consumes its exact permit and
publishes recovery.json atomically, then writes recovery-card.txt listing every
operation and replacementFor id. The visible **Recovery diagnostics** control is
inert without an approved manifest: visibility is not approval. Missing/unapproved
clicks do not sample, request operations, grant credit, or consume a valid packet.
There is no file watcher, export, reload, nonce change or second packet.

After the owner's second actual reply, repeat reply/checkpoint/inspect. For no
recovery, inspect goes directly to finish. `finish` rereads/verifies the protocol,
consumes a permit, sends atomic finish and returns. Root checks the final wrapper
receipt on its active turn; `exited` requires integrityComplete=true, clean finish,
matching identities/origin, final strict parser settlement and all recorded
process identities reaped. Only their conjunction publishes protocolComplete=true.
A failed/deadline receipt is retained as invalid. With explicit owner completion or
stop, `stop` sends stop under a fresh permit, `stopped` verifies reap, then restoration
is allowed without a protocol-complete claim. Never stop/clean up merely because a
predicted duration expired.

`restore` runs final-drain, panel-close, plugins-disable, pointer-restore,
plugins-enable, state-restore, rotation-resume, restore-verify. Root supplies a
read-only final-drain command that fails unless the tested slider is restored,
P is active, test scratch is empty, operation-qualified queue/describe/render/log
work drained and outgoing raw capture is frozen. Pointer restore uses the original
literal text. state-restore is the unchanged locked helper on SAVED.json; it refuses
raw-document/profile/test-scratch conflict, restores exact original scratch and
source documents, and preserves latest wallpaper while resolving canonical values.
Only after it succeeds resume the guard's prior timer activation with its journal.
restore-verify must confirm those results, the guard's `restored` journal and the
literal pointer. Any conflict stops subsequent writes and reports the exact error.
Root records restoration on the task and runs `host-load --section session`.

## Verdict and next gate

Use session_verdict with actual normalized records/identities, lifecycle receipts,
restoration receipts, clock result and complete raw error audit/poll rows. Unknown
errors are not zero. Native overlap rows are reported without subtracting samples.
Stage1 coldCollectionComplete is distinct from full collectionComplete. Stage2's
same-source Stage1 certificate is recomputed from its retained records/cards/
authorizations/receipts, primary B1/C1 launch/control groups and source identities;
its fresh launchPairs=0 records cannot supply that certificate. Source mismatch,
missing restoration, missing clock proof, incomplete groups or fake environment
cannot accept. Use the ordered analyzer verdict and separate estimator unchanged.

Root reviews exact Task4 spec conformance and quality, then performs the broad
Tasks1–4 protocol review. Deferred Task1 M1/M2 and Task2 valid=true reason=superseded
remain listed for that review, with no Minor corrective loop. No45-minute rehearsal
before scoped/broad acceptance and the seconds-long smoke verdict. When later
approved, watchdog2700/producer≥2400 are rehearsal-only; root needs Keith's message
after the45-minute watchdog for a real next controller turn and parks accordingly.
