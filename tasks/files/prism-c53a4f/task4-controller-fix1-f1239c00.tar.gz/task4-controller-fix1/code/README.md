# Panel-budget capture controller

Private scratch tooling; production Prism code is unchanged. The root controller
owns live permission, exact host command specifications and source/build clock proof.
Read `../runbook.md` before preparing a session. Calibration success is never live
acceptance, and these tools do not authorize a long rehearsal.

`controller.py` runs one explicit action on each root turn. Its inspection API is
`inspect_run(run_directory)`; each card uses its own immutable reply timestamp.
`session_verdict(normalized, identities, receipts, restoration, clock, observations,
stage1=None)` requires per-activation bound lifecycle and proof records. `clock`
contains an `activations` map; restoration entries come from the controller's
`restoration.json`. The runbook defines every field and recovery/cleanup command.

Focused checks (invoke using Python; Lua and tmux must be available):

- `controller-check.py`: budgets, source-clock refusal, intent oracle and permits.
- `corrective-check.py OLD_BUILD`: six reviewed defect regressions; OLD_BUILD is an
  immutable earlier build containing baseline/fix1-excluded-fake.log.
- `controller-integration.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI [recovery|cold|all]`:
  actual fresh Lua producer, controller inspection, temporary named collector,
  clean finish/reap, restoration and verdict. All host IPC/state is fake.
- `controller-abort-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: partial setup
  and crash reconciliation, no-collector cleanup, actual launched-collector abort,
  conflict refusal and cleanup resumption without repeating effects.
- `controller-proof-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: independent
  retained-stage binding and fake/synthetic prior-stage rejection. Its deliberately
  relabelled adversarial copies are test inputs only and never clock proof.
- `controller-recovery-negative-check.py SAVED_SUCCESSFUL_RECOVERY_RUN`: deliberate
  in-memory counterfeits of captured records, preserving all original files.

Use unique private output directories. Keep command/output/elapsed records and all
raw fixtures private. Portable review archives contain code, textual diffs, neutral
PASS summaries and hashes only. Earlier artifacts are never overwritten.
