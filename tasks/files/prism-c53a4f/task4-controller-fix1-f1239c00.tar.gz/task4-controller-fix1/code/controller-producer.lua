-- Fake host only: controllable monotonic clock and IPC models before serialization.
local scenario=arg[5];arg[5]='harness'
local root=assert(arg[0]:match('^(.*)/'));local H=dofile(root..'/frozen-task2/self-check.lua')
local base=arg[1];local variant=arg[6] or 'baseline';local prefix=arg[7];local key='glass.inactive.roughness'
local now=tonumber(os.getenv('FIXTURE_START')) or 1000
local delta=variant=='baseline' and .001 or (scenario:find('gainfail') and .00099 or .0005)
local nativeos=os;os=setmetatable({clock=function() now=now+delta;return now end},{__index=nativeos})
local h=H.host(base..'/'..variant..'/plugin',true,true);local initial;local identity=H.up(h.env.onFrameTick,'diagnosticIdentity')
local function wait(n) now=now+n end
local serial=0
local function deliver() serial=serial+1;local response=H.copy(H.success);response.stdout='response '..serial;h.launches[#h.launches].callback(response) end
local function drain()
 for _=1,1000 do
  if not h.frame then return end
  h.env.onFrameTick(16);local pair=H.up(h.env.onFrameTick,'diagnosticPair')
  if pair and pair.pending and pair.frameDone then h.launches[#h.launches].callback(H.success) end
 end
 error('unbounded fixture drain')
end
local function save(suffix)
 local f=assert(io.open(prefix..suffix..'.log','w'));f:write(table.concat(h.logs,'\n')..'\n');f:close()
end
local function slider() for _,n in ipairs(H.nodes(h.tree)) do if n.kind=='slider' and n.props.key==key..':slider' then return n end end;error('missing slider') end
local function param(value,held) for _,p in ipairs(h.model.params) do if p.key==key then p.value=value;p.held=held end end end
local function actions(recovery)
 local short=scenario:match('short%-(.+)')
 wait(short==(recovery and 'recovery-diagnostic' or 'initial-diagnostic') and .01 or 6)
 local s=slider();s.props.onChange(s.props.value+(recovery and .07 or .01));h.env.onFrameTick(16)
 wait(short==(recovery and 'recovery-drag' or 'initial-drag') and .01 or 2.1);s.props.onDragEnd()
 local value=tonumber(tostring(h.state.structure.byKey[key].value));param(value,{'scratch'})
 if not recovery and scenario:find('release') then
  h.env.onClose();deliver();deliver();h.env.onOpen({});deliver();h.tick();drain()
 else deliver();deliver();h.tick();drain() end
 wait(short==(recovery and 'recovery-release' or 'initial-release') and .01 or 2.1)
 local reset;for _,n in ipairs(H.nodes(h.tree)) do if n.props.tooltip=='Revert edit' and n.props.onClick and H.up(n.props.onClick,'key')==key then reset=n end end
 assert(reset).props.onClick();param(initial.params[1].value,{})
 for _,p in ipairs(initial.params) do if p.key==key then param(p.value,p.held) end end
 deliver();deliver();h.tick();drain();wait(short==(recovery and 'recovery-restore' or 'initial-restore') and .01 or 2.1)
 for i=1,2 do
  h.env.onKey(tostring(i),true);h.model.active.profile=h.model.profiles[i];deliver();deliver();h.tick();drain()
  wait(short==(recovery and (i==1 and 'recovery-Q' or 'recovery-P') or (i==1 and 'initial-Q' or 'initial-P')) and .01 or 5.1)
 end
end
for _,p in ipairs(h.model.params) do local held={};for _,layer in ipairs(p.held or {}) do if layer~='scratch' then held[#held+1]=layer end end;p.held=held end
h.model.profiles={'Q','P'};h.model.active.profile='P';h.env.update();deliver();h.tick();drain();initial=H.copy(h.model)
H.button(h,'Sample diagnostics').props.onClick()
local excluded
if scenario:find('excluded') or scenario:find('shortlaunch') then
 for _=1,1000 do
  h.env.onFrameTick(16);local pair=H.up(h.env.onFrameTick,'diagnosticPair')
  if pair and not pair.control then
   excluded=pair.id;local comparison=h.launches[#h.launches].callback
   h.env.update();h.env.update();local normal=h.launches[#h.launches].callback
   local unchanged=H.copy(H.success);unchanged.stdout='response '..serial
   h.env.onFrameTick(16);normal(unchanged);comparison(H.success);break
  end
  if pair and pair.pending and pair.frameDone then h.launches[#h.launches].callback(H.success) end
 end
 assert(excluded,'no launch to exclude')
end
drain()
local manual=identity.stage=='stage2';if manual then actions(false) else wait(6) end
local initialReply=now;save('-initial')
local recovery
if scenario:find('recovery') or scenario:find('release') or scenario=='excluded' then
 wait(1);local card=identity.cardId..'-recovery';local ops={};local replacement={}
 if manual then
  local start=identity.coldPairs+2*identity.launchPairs
  ops={{id=card..':release',kind='release',key=key},{id=card..':restore',kind='restore',key=key},{id=card..':Q',kind='profile',profile=h.model.profiles[1]},{id=card..':P',kind='profile',profile=h.model.profiles[2]}}
  for i=1,4 do replacement[#replacement+1]=identity.cardId..':action:'..(start+i) end
 else replacement={identity.cardId..':launch:1'} end
 recovery={schema=2,approved=true,runId=identity.runId,activationNonce=identity.activationNonce,cardId=card,replacementFor=replacement,coldPairs=0,launchPairs=manual and 0 or 1,operations=ops}
 h.env.noctalia.readFile=function() return 'fixture permit' end;local decode=h.env.noctalia.json.decode
 h.env.noctalia.json.decode=function(s) if s=='fixture permit' then return H.copy(recovery) end;return decode(s) end
 local button=assert(H.button(h,'Recovery diagnostics'))
 recovery.approved=false;local n=#h.logs;button.props.onClick();drain()
 for i=n+1,#h.logs do assert(not h.logs[i]:find('"class":"operationRequested"'),'unapproved target') end
 recovery.approved=true;button.props.onClick();h.tick();drain()
 if manual then actions(true) else wait(6) end
 -- A second click refuses; never takes another valid packet.
 assert(not H.button(h,'Recovery diagnostics'))
end
save('-final')
local metadata={schema=2,initialModel=initial,initialReply=initialReply,finalReply=now,recovery=recovery or false}
local f=assert(io.open(prefix..'-meta.json','w'));f:write(h.env.noctalia.json.encode(metadata));f:close()
print('PASS actual producer '..scenario..' '..variant..' independent intents and raw timing')
