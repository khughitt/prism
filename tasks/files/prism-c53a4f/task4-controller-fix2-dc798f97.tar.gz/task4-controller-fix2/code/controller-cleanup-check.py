"""Owned named-collector cleanup after assertion and harness stop; fake host only."""
import importlib.util,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('capture',ROOT/'capture.py');cap=importlib.util.module_from_spec(s);sys.path.insert(0,str(ROOT));s.loader.exec_module(cap)
OUT=pathlib.Path(sys.argv[1]);MODEL=sys.argv[2];CLI=sys.argv[3];os.umask(0o077);OUT.mkdir(mode=0o700)
for case in ('assertion','TERM','INT'):
 target=OUT/case
 injection="raise AssertionError('injected controller failure')" if case=='assertion' else "os.kill(os.getpid(),signal.SIG"+case+")"
 program=f"import importlib.util,sys,os,signal; sys.path.insert(0,{str(ROOT)!r}); sys.argv={['cleanup',str(target),MODEL,CLI]!r}; s=importlib.util.spec_from_file_location('integration',{str(ROOT/'controller-integration.py')!r}); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); exec({('def fail(*args): '+injection)!r}); m.c.verify_initial=fail; m.pipeline('release-recovery')"
 command=[sys.executable,'-c',program];p=subprocess.run(command,capture_output=True,text=True,timeout=20)
 run=next(x.parent for x in target.rglob('RUN.json'));cfg=json.loads((run/'RUN.json').read_text());ids=json.loads((run/'identities.json').read_text())
 deadline=time.monotonic()+3
 while any(cap.same_process(v) for v in ids.values()) and time.monotonic()<deadline:time.sleep(.01)
 alive={k:v for k,v in ids.items() if cap.same_process(v)}
 probe=subprocess.run(['tmux','-L',cfg['socket'],'has-session'],capture_output=True,text=True,timeout=3)
 evidence={'case':case,'argv':command,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'processes':ids,'remaining':alive,'namedServerPresent':probe.returncode==0}
 try:
  assert not alive and probe.returncode!=0,(case,'owned processes survived',alive)
  assert p.returncode==({'assertion':1,'TERM':143,'INT':130}[case]),(case,p.returncode,p.stderr)
  print('PASS owned collector cleanup',case)
 finally:
  # The regression supervisor owns cleanup even when the worker under test fails.
  cleanup=subprocess.run(['tmux','-L',cfg['socket'],'kill-server'],capture_output=True,text=True,timeout=3)
  evidence['supervisorCleanupExit']=cleanup.returncode
  deadline=time.monotonic()+3
  while any(cap.same_process(v) for v in ids.values()) and time.monotonic()<deadline:time.sleep(.01)
  evidence['afterSupervisorRemaining']={k:v for k,v in ids.items() if cap.same_process(v)}
  (run/'cleanup-proof.json').write_text(json.dumps(evidence,indent=2)+'\n')
  assert not evidence['afterSupervisorRemaining'],'supervisor cleanup failed'
