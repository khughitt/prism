"""Owned supervisor/child timeout and interruption cleanup; fake host only."""
import importlib.util,json,os,pathlib,re,signal,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));s=importlib.util.spec_from_file_location('capture',ROOT/'capture.py');cap=importlib.util.module_from_spec(s);s.loader.exec_module(cap)

def named(cfg,*args):
 env=os.environ.copy();env.pop('TMUX',None)
 return subprocess.run(['tmux','-L',cfg['socket'],'-f','/dev/null',*args],capture_output=True,text=True,timeout=3,env=env)

def reap_owned(target):
 proof=[]
 for file in sorted(target.rglob('RUN.json')):
  assert file.resolve().is_relative_to(target.resolve()),'owned config escaped private target'
  cfg=cap.config(file);assert cfg['environment']=='synthetic' and re.fullmatch('prism-budget-capture-task4fix2-[0-9a-f]{32}',cfg['socket']),'unowned socket'
  assert pathlib.Path(cfg['identities'])==file.parent/'identities.json','identity journal outside owned run'
  ids=json.loads((file.parent/'identities.json').read_text()) if (file.parent/'identities.json').exists() else {}
  current=named(cfg,'display-message','-p','#{pid}')
  if current.returncode==0:
   server=cap.process(int(current.stdout.strip()))
   assert 'server' not in ids or server==ids['server'],'named server identity conflict'
   ids['server']=server
   if 'wrapper' not in ids:
    wrapper=named(cfg,'display-message','-p','-t','capture:0','#{pane_pid}')
    if wrapper.returncode==0:ids['wrapper']=cap.process(int(wrapper.stdout.strip()))
   assert cap.same_process(server),'named server changed before cleanup'
   named(cfg,'kill-server')
  deadline=time.monotonic()+3
  while any(cap.same_process(v) for v in ids.values()) and time.monotonic()<deadline:time.sleep(.01)
  # A residual recorded process is signalled only while pid/start/boot still match.
  for v in ids.values():cap.terminate(v)
  deadline=time.monotonic()+3
  while any(cap.same_process(v) for v in ids.values()) and time.monotonic()<deadline:time.sleep(.01)
  for v in ids.values():
   if cap.same_process(v):os.kill(v['pid'],signal.SIGKILL)
  deadline=time.monotonic()+3
  while any(cap.same_process(v) for v in ids.values()) and time.monotonic()<deadline:time.sleep(.01)
  alive={k:v for k,v in ids.items() if cap.same_process(v)}
  present=named(cfg,'has-session').returncode==0
  proof.append({'config':str(file),'socket':cfg['socket'],'processes':ids,'remaining':alive,'namedServerPresent':present,'namedKillAttempted':current.returncode==0})
  assert not alive and not present,'owned processes survived supervisor cleanup'
 return proof

def supervise(command,target,timeout):
 target.mkdir(mode=0o700);child=None;child_id=None;interrupted=None;cleaning=False;cause='exit';stdout='';stderr='';forced=False
 def stopped(sig,frame):
  nonlocal interrupted
  interrupted=sig
  if child_id is not None and not cleaning:raise SystemExit(128+sig)
 prior={sig:signal.signal(sig,stopped) for sig in (signal.SIGTERM,signal.SIGINT)}
 began=time.monotonic()
 try:
  if interrupted is not None:raise SystemExit(128+interrupted)
  child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  try:child_id=cap.process(child.pid)
  except FileNotFoundError:pass
  if interrupted is not None:raise SystemExit(128+interrupted)
  stdout,stderr=child.communicate(timeout=timeout)
  return subprocess.CompletedProcess(command,child.returncode,stdout,stderr)
 except subprocess.TimeoutExpired:
  cause='timeout';raise
 except BaseException:
  cause='interrupted' if interrupted is not None else 'error';raise
 finally:
  cleaning=True
  # Own the launch from the outset; further stop signals cannot interrupt reaping.
  try:
   try:
    if child is not None:
     if child.poll() is None:child.terminate()
     try:stdout,stderr=child.communicate(timeout=15)
     except subprocess.TimeoutExpired:
      forced=True
      if child_id is not None and cap.same_process(child_id):child.kill()
      stdout,stderr=child.communicate(timeout=3)
   finally:
    owned=reap_owned(target)
    evidence={'argv':command,'timeoutSeconds':timeout,'cause':cause,'signal':interrupted,'child':child_id,'childExit':child.returncode if child is not None else None,'forcedChildKill':forced,'elapsedSeconds':time.monotonic()-began,'stdout':stdout,'stderr':stderr,'ownedRuns':owned}
    path=target/'supervisor-cleanup.json';assert not path.exists();path.write_text(json.dumps(evidence,indent=2)+'\n');path.chmod(0o600)
  finally:
   for sig,handler in prior.items():signal.signal(sig,handler)

def main():
 OUT=pathlib.Path(sys.argv[1]);MODEL=sys.argv[2];CLI=sys.argv[3];os.umask(0o077);OUT.mkdir(mode=0o700)
 for case in ('assertion','TERM','INT','timeout','supervisor-TERM','supervisor-INT','startup-TERM','residual-timeout','receipt-lag-timeout','success'):
  target=OUT/case
  action="raise AssertionError('injected controller failure')" if case=='assertion' else 'os.kill(os.getpid(),signal.SIG'+case+')' if case in ('TERM','INT') else 'time.sleep(5)' if case=='timeout' else 'os.kill(os.getppid(),signal.SIG'+case.split('-')[-1]+'); time.sleep(5)'
  program=f"import importlib.util,sys,os,signal,time; sys.path.insert(0,{str(ROOT)!r}); sys.argv={['cleanup',str(target),MODEL,CLI]!r}; s=importlib.util.spec_from_file_location('integration',{str(ROOT/'controller-integration.py')!r}); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); "
  if case=='startup-TERM':
   fixture="effect=m.Host.effect\ndef early(self,action,*args):\n if action=='collector-launch':\n  (m.OUT/'fixture-ready.json').write_text('startup before collector launch'); os.kill(os.getppid(),signal.SIGTERM); time.sleep(5)\n return effect(self,action,*args)\nm.Host.effect=early"
   program+=f"exec({fixture!r}); "
  elif case in ('residual-timeout','receipt-lag-timeout'):
   fixture="def fail(*args):\n (m.OUT/'fixture-ready.json').write_text('collector running without child cleanup')\n file=next(m.OUT.rglob('identities.json')); (m.OUT/'fixture-identities.json').write_bytes(file.read_bytes())\n "+("file.unlink()\n " if case=='receipt-lag-timeout' else "")+"signal.signal(signal.SIGTERM,lambda *args:os._exit(77)); time.sleep(5)\nm.c.verify_initial=fail"
   program+=f"exec({fixture!r}); "
  elif case!='success':
   fixture="def fail(*args):\n (m.OUT/'fixture-ready.json').write_text('collector running at verification boundary')\n "+action+"\nm.c.verify_initial=fail"
   program+=f"exec({fixture!r}); "
  program+="m.pipeline('release-recovery')"
  command=[sys.executable,'-c',program]
  try:
   p=supervise(command,target,2 if case.endswith('timeout') else 20)
   assert not case.endswith('timeout') and case not in ('supervisor-TERM','supervisor-INT','startup-TERM'),'supervisor stop did not occur'
   assert p.returncode==({'assertion':1,'TERM':143,'INT':130,'success':0}[case]),(case,p.returncode,p.stderr)
  except subprocess.TimeoutExpired:assert case.endswith('timeout')
  except SystemExit as e:assert case in ('supervisor-TERM','supervisor-INT','startup-TERM') and e.code==(130 if case=='supervisor-INT' else 143)
  evidence=json.loads((target/'supervisor-cleanup.json').read_text())
  assert not evidence['forcedChildKill'],'child did not clean up after graceful termination'
  if case!='success':assert (target/'fixture-ready.json').exists(),'fixture did not reach intended boundary'
  assert len(evidence['ownedRuns'])==1,'missing exact owned config'
  ids=evidence['ownedRuns'][0]['processes']
  if case=='startup-TERM':assert not ids,'startup fixture unexpectedly launched capture'
  elif case=='receipt-lag-timeout':
   recorded=json.loads((target/'fixture-identities.json').read_text());assert set(recorded)=={'server','wrapper','collector'} and not any(cap.same_process(v) for v in recorded.values()),'pre-receipt processes survived'
   assert all(v==recorded[k] for k,v in ids.items()),'discovered socket identity differs'
  else:assert set(ids)=={'server','wrapper','collector'},'fixture needs actual named capture processes'
  assert not any(cap.same_process(v) for v in ids.values()),'process resurrected after cleanup'
  if case in ('residual-timeout','receipt-lag-timeout'):assert evidence['childExit']==77
  if case=='residual-timeout':assert evidence['ownedRuns'][0]['namedKillAttempted'],'residual named-server path not exercised'
  if case in ('timeout','supervisor-TERM'):assert evidence['childExit']==143
  if case=='startup-TERM':assert evidence['childExit']==1 and 'collector-launch: 143' in evidence['stderr'],'startup invalidity must be preserved'
  if case=='supervisor-INT':assert evidence['childExit']==143,'supervisor uses graceful TERM for its child'
  print('PASS owned supervisor/collector cleanup',case)
if __name__=='__main__':main()
