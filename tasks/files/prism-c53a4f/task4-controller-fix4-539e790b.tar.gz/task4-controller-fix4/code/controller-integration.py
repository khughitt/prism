"""Bounded producer/controller/collector calibration. Never live host IPC."""
import copy, importlib.util, json, os, pathlib, subprocess, sys, time, uuid, signal
ROOT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('controller',os.environ.get('CONTROLLER_CODE',str(ROOT/'controller.py')));c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
cap=c.module('capture',ROOT/'capture.py')
OUT=pathlib.Path(sys.argv[1]);MODEL=pathlib.Path(sys.argv[2]);CLI=sys.argv[3];os.umask(0o077)
OUT.mkdir(mode=0o700,parents=True,exist_ok=True)
def waitfile(path,predicate=lambda x:True):
 end=time.monotonic()+8
 while time.monotonic()<end:
  if path.exists():
   value=c.load(path)
   if predicate(value):return value
  time.sleep(.01)
 raise AssertionError('bounded receipt wait: '+str(path))
def run(argv,**kwargs):
 r=subprocess.run(argv,capture_output=True,text=True,timeout=15,**kwargs)
 assert r.returncode==0,(argv,r.stdout,r.stderr)
 return r.stdout
builds={}
def build(stage,block,colds,launches):
 key=(stage,block,colds,launches)
 if key in builds:return builds[key]
 path=OUT/('build-'+str(len(builds)));nonce='task4fix2-'+uuid.uuid4().hex
 run([sys.executable,str(ROOT/'frozen-task2/build.py'),'--baseline','9bf4e8e920c005f8a4d1666b32b4e1a516856ac2','--candidate','e7384b0d7ab3e8e935cdf0776043839441132af5','--cli',CLI,'--output',str(path),'--nonce',nonce,'--stage',stage,'--block',block,'--cold-pairs',str(colds),'--launch-pairs',str(launches),'--recovery-manifest',str(OUT/'fake-manifest.json')])
 builds[key]=path;return path
class Host:
 def __init__(self,root,config):self.root=root;self.config=config;self.child=None;self.used=set();self.actions=[];self.actionSeconds={};self.pointer=root/'fake-pointer';self.pointer.symlink_to('original');self.state={'timer':True,'scratch':{'owner':1},'plugins':True}
 def invoke(self,action,auth,args):
  start=time.monotonic()
  try:return self.effect(action,auth,args)
  finally:self.actionSeconds[action]=self.actionSeconds.get(action,0)+time.monotonic()-start
 def effect(self,action,auth,args):
  token=(auth,action);assert auth.startswith('fake-permit-') and token not in self.used;self.used.add(token);self.actions.append(action)
  if action=='finish-authorize' and hasattr(self,'finishTail'):self.finishTail()
  if action=='rotation-snapshot':return {'active':self.state['timer']}
  if action=='rotation-pause':self.state['timer']=False
  if action=='state-snapshot':return {'scratch':copy.deepcopy(self.state['scratch'])}
  if action=='state-clear':self.state['scratch']={}
  if action=='plugins-disable':self.state['plugins']=False
  if action=='pointer-swap':assert os.readlink(self.pointer)=='original';self.pointer.unlink();self.pointer.symlink_to('candidate')
  if action=='collector-launch':
   self.child=subprocess.Popen(['bash',str(ROOT/'capture-wrapper.sh'),str(self.config)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
   return {'launcherPid':self.child.pid}
  if action=='plugins-enable':self.state['plugins']=True
  if action=='pointer-restore':assert os.readlink(self.pointer)=='candidate';self.pointer.unlink();self.pointer.symlink_to('original')
  if action=='plugins-restore':self.state['plugins']=True
  if action=='state-restore':assert self.state['scratch']=={};self.state['scratch']={'owner':1}
  if action=='rotation-resume':self.state['timer']=True
  if action=='restore-verify':return {'documentsEqual':self.state=={'timer':True,'scratch':{'owner':1},'plugins':True} and os.readlink(self.pointer)=='original','scratchExact':self.state['scratch']=={'owner':1}}
  return {}
def permit():return 'fake-permit-'+uuid.uuid4().hex
def bundle(model):
 values={p['key']:p['value'] for p in model['params']};P=model['profiles'][1];Q=model['profiles'][0]
 assert model['active']['profile']==P
 saved={'pair':{'P':P,'Q':Q},'profiles':{P:values,Q:copy.deepcopy(values)},'runtime':{'active':model['active'],'scratch':{'owner':1}},'uneditedNumeric':[{'key':'glass.inactive.roughness'}]}
 return {'saved':saved,'resolverSources':{},'definitions':{p['key']:{k:p[k] for k in ('type','range') if k in p} for p in model['params']}}
def pipeline(scenario,stage='stage2',variant='baseline',block='1',colds=1,launches=0):
 built=build(stage,block,colds,launches);identity=c.load(built/variant/'identity.json');root=OUT/(scenario+'-'+block+'-'+variant+'-'+uuid.uuid4().hex[:6]);root.mkdir(mode=0o700)
 log=root/'host.log';log.write_text('history outside offset\n');socket='prism-budget-capture-task4fix2-'+uuid.uuid4().hex
 cfg={'schema':2,'environment':'synthetic','runId':identity['runId'],'clockOrigin':identity['clockOrigin'],'socket':socket,'deadlineSeconds':2700,'pollSeconds':.1,'maxGapSeconds':2,'log':str(log)}
 for name in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[name]=str(root/(name+'.json'))
 c.immutable(root/'RUN.json',cfg)
 host=Host(root,root/'RUN.json');now=[time.monotonic()]
 session={'sessionId':'fake-session-'+uuid.uuid4().hex,'runId':identity['runId'],'environment':'fake-host','clockOrigin':identity['clockOrigin'],'identity':identity,'steps':{'pre':1,'post':1,'recovery':1,'finish':1},'snapshotBundle':str(root/'bundle.json')}
 obj=c.Controller(root,session,host,lambda:now[0]);steps={};start=time.monotonic()
 def stopped(signum,frame):raise SystemExit(128+signum)
 prior_signals={sig:signal.signal(sig,stopped) for sig in (signal.SIGTERM,signal.SIGINT)}
 try:
  obj.prepare(permit());hb=waitfile(root/'heartbeat.json',lambda r:r.get('collectorStarted') is not None);obj.collector_started(hb);obj.activate(permit())
  output=run(['lua',str(ROOT/'controller-producer.lua'),str(built),str(MODEL),str(ROOT/'frozen-task2/test_encode.lua'),CLI,scenario,variant,str(root/'producer')],env=os.environ|{'FIXTURE_START':str(hb['collectorStarted']+1)})
  meta=c.load(root/'producer-meta.json')
  if meta['recovery'] and meta['recovery']['operations']=={}:meta['recovery']['operations']=[]
  b=bundle(meta['initialModel']);c.immutable(root/'bundle.json',b)
  initial=c.analyze.read_rotated([root/'producer-initial.log']);now[0]=hb['collectorStarted']+.5
  current={'runtime':{'active':b['saved']['runtime']['active'],'scratch':{}},'canonical':b['saved']['profiles'][b['saved']['pair']['P']]}
  c.verify_initial(identity,initial[0],b,current,built/variant)
  obj.issue_initial(initial[0],b['saved'],c.action_manifest(identity,b['saved'],pilot=True),10)
  steps['pre']=time.monotonic()-start
  bursts=[]
  def append(raw):
   # Controlled fake writer: append in the fresh completed poll's sleep interval.
   # The unchanged collector correctly refuses a concurrent read/write race.
   prior=c.load(root/'heartbeat.json').get('lastPollEnd',0)
   waitfile(root/'heartbeat.json',lambda h:h.get('lastPollEnd',0)>prior and 0<=time.monotonic()-h['lastPollEnd']<.015)
   began=time.monotonic()
   with log.open('ab',buffering=0) as f:assert f.write(raw)==len(raw);os.fsync(f.fileno())
   bursts.append({'bytes':len(raw),'seconds':time.monotonic()-began})
   obj.invoke('checkpoint-authorize',permit());obj.control('ready');waitfile(root/'heartbeat.json',lambda r:r.get('lastSequence')==obj.state['sequence'])
  append((root/'producer-initial.log').read_bytes());steps['pre']=time.monotonic()-start
  now[0]=meta['initialReply'];start=time.monotonic();obj.owner_complete('fake-initial-owner-reply')
  normal,context=c.inspect_run(root);obj.checked(normal);steps['post']=time.monotonic()-start
  initial_normal=normal;initial_context=copy.deepcopy(context)
  if meta['recovery']:
   # Completed originals need no recovery; timing-negative fixtures still are incomplete.
   assert not normal['collectionComplete'],('recovery fixture original unexpectedly complete',scenario)
   start=time.monotonic();now[0]+=.1;obj.request_recovery(10);now[0]+=.1;obj.approve_recovery(permit(),meta['recovery'],10)
   old=(root/'producer-initial.log').read_bytes();full=(root/'producer-final.log').read_bytes();assert full.startswith(old)
   append(full[len(old):]);now[0]=meta['finalReply'];obj.owner_complete('fake-recovery-owner-reply')
   normal,context=c.inspect_run(root);obj.checked(normal);steps['recovery']=time.monotonic()-start
   assert context['bindings'][identity['activationNonce']]==initial_context['bindings'][identity['activationNonce']]
   assert context['recovery'] is not None
  c.immutable(root/'context.json',context);c.immutable(root/'normalized.json',normal)
  start=time.monotonic();now[0]+=.01
  before=(root/'producer-final.log').read_bytes();tail=(root/'producer-tail.log').read_bytes();assert tail.startswith(before)
  host.finishTail=lambda:append(tail[len(before):]);obj.finish(permit(),normal)
  out,err=host.child.communicate(timeout=8);assert host.child.returncode==0,(out,err)
  receipt=waitfile(root/'receipt.json',lambda r:'wrapperEnded' in r)
  deadline=time.monotonic()+2
  while any(cap.same_process(p) for p in receipt['processes'].values()) and time.monotonic()<deadline:time.sleep(.01)
  now[0]+=.01
  # Actual CLI/parser/receipt reread, with fixture clock injected only in this subprocess.
  cli_exit=run([sys.executable,'-c',f"import runpy,time,sys; sys.path.insert(0,{str(ROOT)!r}); time.monotonic=lambda:{now[0]!r}; sys.argv={['controller.py','exited','--run',str(root)]!r}; runpy.run_path({str(ROOT/'controller.py')!r},run_name='__main__')"])
  assert json.loads(cli_exit)['phase']=='complete';obj=c.Controller.resume(root,host,lambda:now[0])
  normal,context=c.inspect_run(root,receipt,obj.state['finishAudit']);obj.restore(permit())
  rows,audit=c.read_capture(root/'manifest.json',receipt);audit['polls']=[json.loads(l) for l in (root/'polls.json').read_text().splitlines()]
  restoration=c.load(root/'restoration.json');result={'root':root,'events':rows,'identities':[identity],'cards':context['cards'],'authorizations':context['authorizations'],'receipts':[receipt],'restoration':[restoration],'clock':{'activations':{}},'observations':audit,'normalized':normal,'state':obj.state,'initial':initial_normal}
  assert normal['collectionComplete']==obj.state['protocolComplete'] and normal['coldCollectionComplete']==obj.state['coldProtocolComplete']
  assert c.bound_proofs(normal,[identity],[receipt],[restoration],{'activations':{}})[0]
  assert all(not cap.same_process(p) for p in receipt['processes'].values()) and obj.state['phase']=='restored'
  steps['finish']=time.monotonic()-start
  measurement={'scenario':scenario,'steps':steps,'reserve':c.reserve(list(steps.values())),'controllerSeconds':obj.window.controller_seconds(now[0]),'fakeIpcActionSeconds':host.actionSeconds,'fakeIpcSeconds':sum(host.actionSeconds.values()),'bursts':bursts,'pollSeconds':cfg['pollSeconds'],'maxGapSeconds':cfg['maxGapSeconds'],'writerSynchronization':'fresh completed poll; synthetic writer only','ipcProvenance':'fake host temporary state; real named tmux collector and producer Lua; controlled synthetic producer clock, never Noctalia proof','actions':host.actions}
  c.immutable(root/'measurement.json',measurement);print('PASS lifecycle',scenario,variant,block,'protocol',normal['collectionComplete'],'cold',normal['coldCollectionComplete'],'reserve',measurement['reserve'])
  return result
 finally:
  try:
   if host.child is not None:
    # The short-lived launcher may have exited while its named server still owns capture.
    subprocess.run(['tmux','-L',socket,'kill-server'],capture_output=True,timeout=3);host.child.communicate(timeout=8)
    ids=c.load(root/'identities.json') if (root/'identities.json').exists() else {}
    deadline=time.monotonic()+3
    while any(cap.same_process(p) for p in ids.values()) and time.monotonic()<deadline:time.sleep(.01)
    remaining={k:p for k,p in ids.items() if cap.same_process(p)}
    c.immutable(root/'harness-cleanup.json',{'socket':socket,'processes':ids,'remaining':remaining})
    assert not remaining,'owned collector process survived cleanup'
  finally:
   for sig,handler in prior_signals.items():signal.signal(sig,handler)

def merged(parts):
 out={k:sum((p[k] for p in parts),[]) for k in ('events','identities','receipts','restoration')}
 for k in ('cards','authorizations'):out[k]={key:v for p in parts for key,v in p[k].items()}
 out['clock']={'activations':{}};out['observations']={'budgetErrors':sum(p['observations']['budgetErrors'] for p in parts),'complete':all(p['observations']['complete'] for p in parts),'polls':sum((p['observations']['polls'] for p in parts),[])}
 out['normalized']=c.analyze.normalize(out['events'],out['identities'],out['cards'],out['authorizations']);return out

def verdict(p,prior=None):return c.session_verdict(p['normalized'],p['identities'],p['receipts'],p['restoration'],p['clock'],p['observations'],prior)
if __name__=='__main__':
 mode=sys.argv[4] if len(sys.argv)>4 else 'all'
 if mode in ('all','recovery'):
  recovered=pipeline('release-recovery');assert recovered['normalized']['collectionComplete'];assert recovered['normalized']['certificates'][0]['replacementCredit']
  for name in ('initial-diagnostic','initial-drag','initial-release','initial-restore','initial-Q','initial-P','recovery-diagnostic','recovery-drag','recovery-release','recovery-restore','recovery-Q','recovery-P'):
   bad=pipeline('release-recovery-short-'+name);assert not bad['normalized']['collectionComplete'],name
   if name=='initial-P':assert not bad['normalized']['certificates'][0]['operationGatesComplete'],'recovery reply repaired original final P'
  excluded=pipeline('excluded','stage1',launches=1);assert excluded['normalized']['collectionComplete'] and excluded['normalized']['certificates'][0]['replacementCredit']
  assert not any(e['class']=='cardSettled' and e['cardId']==excluded['identities'][0]['cardId'] for e in excluded['events'])
 if mode in ('all','cold'):
  for outcome in ('gainfail','gainpass'):
   group=merged([pipeline('shortlaunch-'+outcome,'stage1',v,b,5,5) for b in ('1','2') for v in ('baseline','candidate')]);out=verdict(group)
   print('VERDICT',outcome,out['verdict']);assert out['verdict']['comparison']==('revert' if outcome=='gainfail' else 'inconclusive')
   for p in group['restoration']:assert p['coldProtocolComplete'] and not p['protocolComplete']
   for changed in ('error','incomplete','identity','receipt'):
    bad=copy.deepcopy(group)
    if changed=='error':bad['observations']['budgetErrors']=1
    if changed=='incomplete':bad['normalized']['coldCollectionComplete']=False
    if changed=='identity':bad['identities'][0]['clockOrigin']='wrong'
    if changed=='receipt':bad['receipts'][0]['integrityComplete']=False
    assert verdict(bad)['verdict']['comparison']!='revert',changed
 print('PASS requested producer/controller/collector integration group',mode)
