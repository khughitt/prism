# Panel-budget capture controller

Private scratch tooling; production Prism code is unchanged. The root controller
owns live permission, exact host command specifications and source/build clock proof.
Read `../runbook.md` before preparing a session. Calibration success is never live
acceptance, and these tools do not authorize a long rehearsal.

`controller.py` runs one explicit action on each root turn. Its inspection API is
`inspect_run(run_directory, receipt=None, prefix=None)`; each card uses its own immutable reply timestamp.
`session_verdict(normalized, identities, receipts, restoration, clock, observations,
stage1=None)` requires per-activation bound lifecycle and proof records. `clock`
contains an `activations` map; restoration entries come from the controller's
`restoration.json`. The runbook defines every field and recovery/cleanup command.

Focused checks (invoke using Python; Lua and tmux must be available):

- `controller-check.py`: budgets, source-clock refusal, intent oracle and permits.
- `corrective-check.py OLD_BUILD`: six reviewed defect regressions; OLD_BUILD is an
  immutable earlier build containing baseline/fix1-excluded-fake.log.
- `controller-integration.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI [recovery|cold|all]`:
  actual fresh Lua producer, controller inspection, temporary named collector,
  periodic callbacks during waits and after finish inspection, actual exit CLI/final
  raw reread, clean finish/reap, restoration and verdict. All host IPC/state is fake.
- `controller-cleanup-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: actual
  assertion/child TERM/INT, supervisor timeout/TERM/INT, startup and residual-server
  cases prove owned cleanup. Supervisors request graceful child termination first
  and always reap exact named socket/process identities in their outer finally.
- `controller-cleanup-boundary-check.py SUPERVISOR_SOURCE NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`:
  actual stop signals at cleanup entry and during child wait, owned reap, evidence
  and handler restoration, repeated bootstrap stops, and the forced-child-kill path.
  An outer test owner also cleans up when the reviewed old supervisor fails.
- `controller-abort-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: partial setup
  and crash reconciliation, no-collector cleanup, actual launched-collector abort,
  conflict refusal and cleanup resumption without repeating effects.
- `controller-proof-check.py NEW_OUT PRIVATE_MODEL EXPLICIT_PRISM_CLI`: independent
  retained-stage binding and fake/synthetic prior-stage rejection. Its deliberately
  relabelled adversarial copies are test inputs only and never clock proof.
- `controller-recovery-negative-check.py SAVED_SUCCESSFUL_RECOVERY_RUN`: deliberate
  in-memory counterfeits of captured records, preserving all original files.

Use unique private output directories. Keep command/output/elapsed records and all
raw fixtures private. Portable review archives contain code, textual diffs, neutral
PASS summaries and hashes only. Earlier artifacts are never overwritten.

`controller-periodic-check.py SAVED_SUCCESSFUL_RECOVERY_RUN NEW_PRIVATE_OUT`
checks material dwell changes and the actual exit CLI against separately copied
counterfeit captures. The original raw archives remain unchanged. The controller's
`exited(receipt, is_alive)` reads and validates final raw itself; callers cannot pass
a stale normalization. `inspectionAudit`, `finishAudit` and `finalAudit` bind raw
prefixes and final integrity; ordinary periodic observations may extend a stable
settlement, but material changes fail. See the runbook for the exact boundary.

Calibration uses a synchronized fake writer and synthetic clock injection into the
exit CLI process. It does not settle the preserved concurrent-append collector risk;
broad review, actual clock endorsement and live command specs remain root gates.
