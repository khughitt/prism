# Capture-recovery controller runbook

This is a root-controller runbook, not a worker authorization. Every live setup,
IPC, timer, pointer, recovery publication and finish/stop operation needs fresh
root-owned session authorization. Prior desktop permission does not carry forward.
The Task4 checks use fake IPC and temporary stores; their measured reserve is not a
measurement of live IPC. Review the seconds-long smoke's verdict before any Task5
long rehearsal. No long rehearsal is launched by these scripts.

## Files and authority

Define CAPTURE_STATE from `${XDG_STATE_HOME:-$HOME/.local/state}/prism/panel-budget`,
CAPTURE_ROOT as its `capture-recovery-2026-10-13` child, CODE as `$CAPTURE_ROOT/code`,
and PRESERVED as its `task3-2026-10-13-preserved` sibling. Never write PRESERVED.
Each run has an exclusively created directory0700 and files0600. Invoke scripts
through Python/Node/Lua; do not change shared CLI launchers. The immutable reviewed
snapshot and SHA256 inventory in the Task4 report are authoritative.

Root resolves `command -v noctalia`, the running `/proc/PID/exe` identity and the
explicit `.worktrees/panel-budget/bin/prism` before setup. Preserve the literal
plugin symlink with `readlink`, not its resolved target. Record every pointer change
on the task immediately: what/from/to/how to restore. RootHost also writes the
literal pointer journal before replacement and refuses a changed link.

A session JSON has schema2, fresh sessionId/runId, environment, clockOrigin,
identity (the exact new builder identity), activationOrdinal1–4, pilot boolean, steps (`pre`, `post`,
`recovery`, `finish`, measured seconds), sourceProof, r2Root, buildRoot,
snapshotBundle, collectorConfig, artifactSha256 and rateMeasurement. Ordinals after1 require outgoingState (previous restored,
clean protocol-complete state; Stage1 also permits independently coldProtocolComplete with short launch groups) and referenceSnapshot (first fresh saved state); later
snapshots must match its documents/profiles/pair/runtime exactly. For live,
clockOrigin is `host-monotonic:<actual boot id>`. artifactSha256 includes all copied
plugin files, identity/transform manifests, collector/controller/state/guard code
and all frozen source artifacts. Verify every hash; any changed reference/source
invalidates the activation rather than updating one variant in place.

`hostActions` maps each action below to an exact `{argv,env,timeoutSeconds,json}`
command specification. argv is an array; no shell parsing. Set json true only for a
command that returns JSON. State/guard mutation env includes its reviewed approval
variable only behind RootHost's fresh permit. Pointer actions instead use
`{path,from,to}` with literal strings. `checkpoint-authorize`, `finish-authorize`,
`stop-authorize`, `recovery-authorize` have `{}` as their spec; the consumed permit
is their effect. Root prepares command specs; a worker never prepares live permits.

A permit file must be owned by the current user, mode0600, with approved=true,
author=`root-controller`, exact sessionId/runId/current bootId, and a `permits`
array. Each entry is `{id,action,arguments,issuedAt,expiresAt}`; arguments must equal
the immutable hostActions entry. id is unique alphanumeric/hyphen. issuedAt and
expiresAt use Python monotonic; expiry is at most60 seconds after issuance. Every
operation consumes its own id before acting, including failed attempts. A retry
needs a fresh permit; never extend/reuse an existing permit. Root writes these only
after actual authorization, using the actual root session identity. A grouped
permit file may name multiple imminent operations; refresh it when setup outlasts
its sixty-second validity, keeping consumed ids immutable.

## Independent Noctalia clock proof (required before asking for hands)

Run `python3 "$CODE/clock-gate.py" --source-proof ROOT_PROOF.json --r2-root
"$PRESERVED/r2-evidence-preserved" --output NEW_CLOCK_RESULT.json`. The output is
exclusive. Any missing/stale/mismatched item blocks. A synthetic producer cannot
pass this gate. Preliminary source inspection alone cannot pass it.

Root proof fields: schema2, environment=`live`, current root sessionId, sourceRoot,
packageRoot, observed, binding, excerpts. `observed` is exactly clock-gate.observe's
read-only result: current bootId; installed resolved path/SHA256/buildId/package;
running PID/startTicks/SHA256/buildId; sourceRevision/sourceFiles; Python monotonic
implementation; SHA256 of PKGINFO/BUILDINFO. Re-observe at every session; do not
copy a previous boot/PID assertion. Root independently endorses `binding` exactly:
rootSessionId, sourceRevision, binarySha256, package, noHostClockOverride=true,
linuxClock=`CLOCK_MONOTONIC`, originOffsetSeconds=0. This endorsement records the
source→package/build→actual installed/running binary mapping; do not infer it merely
because version labels agree. If that mapping cannot be established, stop here.

Each excerpts entry names a pinned source path and `{fileSha256,firstLine,text}`.
The tool checks the whole file hash and exact excerpt bytes against the official
v5.2.1 commit6ef43e2bf2f3d5b4205ec72a72e34a2ab76ce3b4. Inspect VERSION,
meson.build's vendored VM compilation, luau_host.cpp's luaL_openlibs/registrations/
sandbox and absence of an os.clock override, linit.cpp's luaopen_os, loslib.cpp's
os_clock→lua_clock and syslib clock entry, and lperf.cpp's Linux CLOCK_MONOTONIC,
1e-9 scale and absence of an origin offset. The current private unendorsed
inspection is evidence for root to review, not an authorization.

Historical C2 callback1911 is retained with its stored nonce origin; controller
C2-handsProfileQ-end is retained with its historical host-monotonic boot label.
The gate checks historical controller boot agreement within those phase records
and probe294942.885733029→controller294942.898069801 (12.337ms). A reversed or
seconds-offset pair fails. These are corroboration only, not an offset estimate
or proof that the historical boot equals today's boot.

## Setup and exact action commands

Use `controller.py create --run NEW_RUN --session SESSION.json`, then individual
`controller.py ACTION --run RUN [--authorization PERMIT.json] [--input INPUT.json]`
commands on root's active turns. No controller background polling loop exists.
`prepare` executes, in this order:

1. rotation-snapshot: `python3 "$CODE/rotation-guard.py" snapshot JOURNAL.json`.
2. rotation-pause: same helper `pause JOURNAL.json`, with
   PRISM_ROTATION_RETRY_APPROVED=yes. Preserve its journal/prior activation state.
   It stops only the timer, never disables units or kills the rotation service.
3. state-snapshot: `node "$CODE/snapshot.mjs" BUNDLE.json SAVED.json`, with
   PRISM_TASK3_REPO set to the explicit worktree. This fresh snapshot holds raw
   documents/runtime, exact scratch, P/Q canonical maps, unedited slider candidates,
   full definitions and resolver-source hashes under the reviewed lock.
4. state-clear: `node "$CODE/state.mjs" clear SAVED.json`, with
   PRISM_TASK3_APPROVED=yes and the explicit worktree environment.
5. `noctalia msg panel-close khughitt/prism:panel` (panel-close).
6. `noctalia msg plugins disable khughitt/prism` (plugins-disable).
7. pointer-swap uses the exact literal original and fresh instrumented target,
   with a journal before mutation. Root immediately records the task pointer note.
8. collector-launch: `python3 "$CODE/capture.py" launch RUN/run.json`.

The named collector creates its offset/archive before enable. run.json uses the
Task1 exact schema: live deadline2100; fresh socket `prism-budget-capture-<nonce>`;
log absolute; manifest/control/receipt/heartbeat/polls/identities paths directly
inside RUN. Its control path must be RUN/control.json, manifest RUN/manifest.json,
heartbeat RUN/heartbeat.json and receipt RUN/receipt.json. Never use the default
tmux server. Read heartbeat once on an active turn; `collector-started` refuses
until it contains collectorStarted and matching run/origin. Preserve all process
identities and the socket. No enable precedes this stamp.

`activate` performs:

```sh
noctalia msg plugins enable khughitt/prism
# export-ready: root's bounded, read-only readiness check for this plugin/export.
noctalia msg panel-open khughitt/prism:panel
```

The session's export-ready command must fail if readiness is absent; it may use a
bounded check before the card, never an owner-response polling loop. `checkpoint`
consumes a fresh permit and writes atomic ready control. Root reads heartbeat's
matching lastSequence before inspecting that durable checkpoint. `issue` takes
input `{current: PATH_TO_FRESH_STATE_CLEAR_OR_VERIFY_RESULT, remainingStepReserve}`;
it verifies source/build identity, fresh empty runtime activation and exact
P/canonical/test scratch before writing immutable action-manifest.json, saved.json
and owner-card.txt. Read the actual card; use the fresh snapshot's first unedited
slider, never an old exclusion list. Live artifacts are independently hash-checked
at preparation. Fresh nonce/runtime is mandatory even between C1 and C2.

## Owner turns, budgets and cards

Root posts owner-card.txt and ends its turn. Park the claim for the owner with
actual pointer path/from/to/restore, paused timer prior state/journal/resume command,
collector PID/startTicks/boot identity, fresh socket, collector deadline and exact
stop command. Never leave placeholders in an actual park. Collector exit does not
wake Codex. After the actual owner reply, resume the task and call `reply` with
`{replyId: ACTUAL_MESSAGE_ID}`. Do not synthesize a completion from an estimate.

Stage1 order is B1→C1→C2→B2: pilot1 cold each, then full5. B1/C1 have pilot1 or
full5 launch/control units; C2/B2 have none. The generated card says: wait for
controls, click Sample diagnostics (auto-expands), keep panel visible at least5 s
after the button disappears and controls settle, confirm once. No sliders/profiles.

Stage2 runs only after certified Stage1 cold gain/absolute/launch/control gates.
It captures its own new colds, launchPairs=0. Pilot has1 release/restore and1 Q/P
cycle; full has5 release/restore and3 Q/P cycles. Each two-second drag uses the named
unedited slider's own restore, with at least2-s dwell after each release and restore.
Named Q and P clicks must change Prism values and dwell at least5 s, including final
P before chat. Every action has its predeclared exact operation id/key/profile/order.

Initial card cap1200 s; separately approved recovery cap600 s; collector2100 s;
cumulative controller allowance300 s. Initial/recovery intervals are subtracted
exactly once. Record collectorStarted, initialCardIssued, initialCompleteReceived,
completenessChecked, recoveryRequested, approvalReceived, recoveryCardIssued,
recoveryCompleteReceived, finishSent and collectorExited. Window.invalid records
expiry and retains callbacks/bytes; it does not restore a pointer or shorten a card.

Measured step reserve is ceil(1.25*sum(stepSeconds)); require reserve+120≤300.
Live root setup must measure/check its actual remaining work before asking for
hands. Offline fake IPC times are separately labelled and cannot replace live IPC
measurements. Before initial issuance lifetime must fund1200+600+remaining reserve.
At recovery request:

```python
approval_deadline = min(collector_started+2100-600-final_step_reserve,
                        now+300-controller_seconds_used-final_step_reserve)
```

Recheck both lifetime and controller allowance on approval and on issuance. A
620-second lifetime with30-second final reserve refuses;630 allows the full600.
Approval wait cannot borrow recovery time. Late approval is refused; no590-s card.
The root reports the exact remaining approval deadline and deficits.

## Inspection, one recovery, finish and restore

After the reply, checkpoint on the active root turn and then `inspect`. Only the
named collector continuously reads logs. inspect_run reads stable archive/checkpoint
bytes, builds references from frozen snapshot plus independent intent, binds exact
raw intent-line hashes, and calls normalize(events,identities,cards,authorizations).
It checks callback/operation ids, exact Q/P references and ordinary deferred renders,
initial diagnostic readiness, exact full approved recovery readiness, cardSettled and final drain.
The initial card's readiness IDs are diagnostics-only; recovery readiness IDs must
be the complete ordered approved plan (diagnostics then manual operations). Missing,
extra, reordered or stale IDs refuse. An excluded original need not emit cardSettled:
its eligible physical drain and owner dwell are checked independently, while an
approved replacement still needs its own successful settlement.

`inspect_run(RUN, receipt=None, prefix=None)` reads initialCompleteReceived.json and recoveryCompleteReceived.json
separately. Neither reply substitutes for the other. It enforces the five-second
physical-diagnostic-drain to first drag wait, each two-second drag and release/restore
dwell, and each five-second Q/P dwell including final P on both cards. A recovery's
acceptance must follow original completion and its recorded approval/card issuance.
Returned context includes `cardTiming` by card ID, `recovery` materialization, and
both original/recovery `bindings`, including each raw intent line's SHA256. Combined
operationGatesComplete is true only when both applicable timing gates pass. The
ownerApproved field records consumed approval, independently of those timing results.

A release intent is emitted after endDrag's callback endpoint and before accepted
describe: exact operation/key, corrected state.structure.byKey value, unchanged
Queue tostring text, generation/callback binding, observer endpoints. Definitions
and saved canonical source maps determine the expected scalar/map/scratch result;
acceptedReference is always the value checked. Missing, duplicate, stale, reordered,
wrong-key or serialization-disagreeing intents block certification. The original
manifest and raw records remain immutable. Profile/restore expectations remain
locked to saved source state. A recovery release may end at a different valid scalar.
Its own independent intent establishes its exact expected reference. Replacement
credit compares the same approved release key/kind and permits differences only at
that scalar and that key's normalized scratch membership. Every unaffected value,
profile, wallpaper and other held-scratch key remains exact. Both accepted references
must match their respective independent oracles; restore/profile matching is unchanged.
Luau's pinned lnumprint uses shortest round-trip
number formatting; mismatched canonicalValue/valueText refuses rather than guessing.

Keep the collector running through completeness and recovery decision. A closed
sample remains excluded. One combined approved packet may cover cold/launch,
release+restore and Q+P deficits, at most one extra unit of each type. Do not repair
missing records, source/identity/reference faults or budget errors by resampling.
`request-recovery` reserves a full600 s and enters awaiting-approval. Root obtains
fresh approval before `approve-recovery`, which consumes its exact permit and
publishes recovery.json atomically, then writes recovery-card.txt listing every
operation and replacementFor id. The visible **Recovery diagnostics** control is
inert without an approved manifest: visibility is not approval. Missing/unapproved
clicks do not sample, request operations, grant credit, or consume a valid packet.
There is no file watcher, export, reload, nonce change or second packet.

After the owner's second actual reply, repeat reply/checkpoint/inspect. For no
recovery, inspect goes directly to finish. `finish` rereads/verifies the raw protocol,
requires an explicit recorded owner conclusion and physical drain, consumes a permit,
and sends atomic finish. Full requested-unit success is a separate fact. `exited`
requires matching collector/run/origin/start, clean integrity-complete finish, preserved inspected history and all recorded process identities reaped. It publishes
`protocolComplete=collectionComplete` and independently
`coldProtocolComplete=coldCollectionComplete`. Clean byte integrity can therefore
coexist with protocolComplete=false. Cold-complete Stage1 gain failure can reach
revert after both blocks; cold gain pass with short launch groups stays inconclusive.
Incomplete cold, error, identity or lifecycle facts cannot produce that early revert.

Every host attempt is persisted before invocation as state.attempts plus immutable
attempt-ID.json; its result is retained in result-ID.json and state.receipts. Setup
enters `preparing` before the first effect. Failed/pending attempts are **uncertain**,
including a crash between effect and durable result. They block abort/restoration
until a fresh authorized `reconcile-ACTION` command independently observes the exact
state. `controller.py reconcile --input ATTEMPT.json` takes `{attemptId}`. Its immutable
session hostActions spec must run a bounded read-only root-prepared command returning
`{attemptId,action,outcome,receipt}`, where outcome is `completed` or `not-applied`.
The command binds the attempted effect/journal to observed state; unknown or conflicting
state must fail. Never infer not-applied from a missing result, overwrite an unknown
pointer/store/timer, or repeat the failed mutation merely to discover what happened.

`stop` requires an actual explicit completion/abort reply and a fresh permit. After
reconciliation it may run from partially prepared states. When collector-launch has
no completed effect it enters stopped without writing collector control or requiring
a nonexistent receipt. If launch did complete, it sends stop and `stopped` requires
actual wrapper exit/reap before cleanup. No estimate-driven stop/cleanup exists.

`restore` enters durable `restoring` and selects cleanup from completed setup effects:
final-drain if collector launched; panel-close/plugins-disable if the instrumented
plugin was enabled; pointer-restore if swapped; plugins-restore if disabled;
state-restore if scratch cleared; rotation-resume if paused; always restore-verify.
Each cleanup needs its own fresh permit and journal. A completed cleanup action is
not repeated after a crash; an uncertain one requires the same explicit reconciliation.
plugins-restore uses root's captured prior plugin activation state. For the normally
enabled original plugin its concrete command is the same `noctalia msg plugins enable
khughitt/prism`; it must not enable a plugin that root found disabled originally.

Root's final-drain command checks outgoing frozen capture and physical queue/describe/
render/log drain. Successful card settlement is not required for an explicitly aborted
or cleanly cold-complete short-launch capture. Pointer restore checks literal from/to.
The unchanged locked state helper refuses document/profile/test-scratch conflict and
restores exact original scratch and source documents while preserving latest wallpaper.
Resume only the guard's prior timer activation. `restore-verify` must return
`{documentsEqual:true,scratchExact:true}` after checking those facts, timer journal
and literal pointer; false/missing facts refuse a restored claim. Root supplies these
concrete read-only checks before live use; placeholder commands are not proof.

Root records restoration on the task and runs `host-load --section session`.

## Verdict and next gate

Use session_verdict with actual normalized records/identities, lifecycle receipts,
the controller's immutable `restoration.json` records, clock activations and complete
raw error audit/poll rows. `clock={activations:{nonce:clockVerifiedResult}}`; prepare
extends each independently verified clock result with activationNonce, runId and
identitySha256. Each restoration record carries sessionId, runId, clockOrigin,
activationNonce, identitySha256, collectorReceiptSha256, certificateSha256,
clockProofSha256, restored/documentsEqual/scratchExact and both protocol flags.
Hashes use controller.encoded (sorted, indented JSON plus newline). `bound_proofs`
checks each activation independently against actual collector receipt, normalized
certificate, identity and exact verified clock result. Retained Stage1 identities
must all be live; verified=true alone, current-stage proof, or relabelled calibration
cannot certify a prior stage. Unknown
errors are not zero. Native overlap rows are reported without subtracting samples.
Stage1 coldCollectionComplete is distinct from full collectionComplete. Stage2's
same-source Stage1 certificate is recomputed from its retained records/cards/
authorizations/receipts, primary B1/C1 launch/control groups and source identities;
its fresh launchPairs=0 records cannot supply that certificate. Source mismatch,
missing restoration, missing clock proof, incomplete groups or fake environment
cannot accept. Use the ordered analyzer verdict and separate estimator unchanged.

Root reviews exact Task4 spec conformance and quality, then performs the broad
Tasks1–4 protocol review. Deferred Task1 M1/M2 and Task2 valid=true reason=superseded
remain listed for that review, with no Minor corrective loop. No45-minute rehearsal
before scoped/broad acceptance and the seconds-long smoke verdict. When later
approved, watchdog2700/producer≥2400 are rehearsal-only; root needs Keith's message
after the45-minute watchdog for a real next controller turn and parks accordingly.

## Periodic observations and final raw capture

Each dwell starts at the first eligible physical drain after its relevant diagnostic
or operation completion. A subsequent read-only periodic tick/unchanged describe
and observer flush does not restart it when generations, card/operation identity,
accepted reference, profile, requested IDs and physical state remain unchanged.
Input, acceptance, reference/generation/state changes or other material activity
restart at the next physical drain; the full two/five seconds must then elapse.
The recovery card explicitly requires five seconds after diagnostics settle before
the first manual action, including a diagnostics-only card's confirmation.

`checked(normalized)` rereads the checkpoint and saves `inspectionAudit`; `finish`
checks its immutable byte prefix and revalidates any added observations before
saving `finishAudit` and consuming its permit. `exited(receipt, is_alive)` has no
caller-supplied normalized argument. It requires the actual collector receipt file,
rereads and strictly normalizes the final archived bytes at the finish checkpoint,
checks complete/error audit and the saved prefix SHA256/length, and independently
checks lifecycle identity and process exit. Context includes `captureAudit`; state
retains `inspectionAudit`, `finishAudit`, `finalAudit` and final `inspection`.

Additional records must preserve every inspected event and sample, all exclusions
and certificates, identity, timing endpoints, references and protocol facts. Only
proved read-only observations can extend the tail; native launches require their
complete enclosing second-tick callback. A drain's exact companion observer snapshot
may straddle the checkpoint; its callback ID and endpoints must match that drain.
Unknown owner requests, accepted state, new target samples, changed historical
bytes, missing raw/endpoints, source/reference changes and budget-error tails refuse.
Restoration hashes the final certified normalization.

The bounded integration injects a controllable synthetic clock solely into the
fake producer and the subprocess executing the actual exit CLI. It drives ordinary
second ticks and frame flushes during every wait, appends periodic rows after the
finish inspection, then reparses the collector's final raw archive. Its writer is
independent of collector heartbeat timing. The broad-protocol correction additionally
uses a real paced fake-host writer with prospective write intervals, 16-ms frame/input
schedule, one-second periodic callbacks, actual diagnostic batches and single-backup
one-MiB rotation. Historical unsynchronized refusals remain unchanged. These bounded
synthetic checks do not establish Noctalia throughput or long-run capacity.

The integration harness always reaps its own unique named tmux server in `finally`,
even when the launcher already exited; TERM/INT enter the same cleanup path. Its
`harness-cleanup.json` records process identities and verifies none remain. The
cleanup regression supervisor also reaps its test server after a failing assertion.

The cleanup supervisor also owns its child launch before calling Popen. Timeout or
supervisor TERM/INT requests graceful child termination and awaits its finally; an
outer finally still reaps any remaining exact owned socket and pid/start/boot
identities. `supervisor-cleanup.json` records cause, signal, child exit, whether a
forced kill was needed, and all owned run/socket/process results. A config from the
exclusive private target binds a socket even before the identity receipt arrives;
a current server must match the recorded identity when one exists. No default
tmux server or guessed process pattern is used. Further stop signals cannot
interrupt that cleanup: handlers only remember the first signal, and child output
waits check it at most every0.1s. Child TERM has a15s grace; forced child kill
requires its recorded pid/start/boot identity. Previous TERM/INT handlers are
restored together with these signals blocked, then the previous mask is restored.
An already-raised timeout/error keeps its original outcome; an ordinary stop
propagates128+the first signal only after cleanup. Boundary fixtures inject real
signals at the first finally instruction and repeatedly through cleanup/bootstrap;
their outer owner reaps even a failing old supervisor. The forced-kill fixture
retains its actual incomplete capture, like every other interrupted fixture.


## Broad-protocol corrective interface (review pending)

Ordinary `Capture.poll()` reads only through its observed source size. Same-inode
strict growth after that bound is provisional; it neither proves the captured
prefix unchanged nor publishes a complete capture. Full checkpoints still hash all
archives and compare the captured current-source range. A checkpoint whose hash
matched but whose source snapshot grew retries that full prefix at most eight times.
Mismatch, shrink, same-size metadata change, identity ambiguity and archive changes
remain immediate refusals. A uniquely relocated `.1` occurrence may change ctime
at rename only when identity, consumed size and mtime agree; its full source prefix,
archive, descriptor/path and later transition snapshots must still agree. This
preserves all outgoing late-tail, prefix mutation and second-rotation refusals.

Finish requires a stable source end exactly equal to its consumed cursor, then
rechecks descriptor and live pathname snapshots. A late uncaptured suffix refuses
finish, including an otherwise omitted budget-error line. `terminalCutoff` in the
manifest and terminal receipt binds generation, device, inode, `endOffset`,
`sourceSize`, mtime/ctime nanoseconds, total `capturedBytes` and ordered
`segmentSha256`. The parser requires equal receipt/manifest cutoffs and exact
cursor/last-segment/size/total/digest equality before its raw audit is complete.
The certified window ends at that validated source snapshot; subsequent writes are
outside it. Neither the receipt nor raw completeness certifies owner operations.

Closing the panel now flushes already completed diagnostic records in batches of
at most sixteen outside target timing, records an open `handoff` snapshot with the
current complete `handoffReference`, invokes the original close with unchanged
return packing, and flushes its completed callback without requiring another tick.
The finite tail is exactly `handoff`, its `observerSnapshot`, the completed `close`
callback, an `observerFlush`, and `handoffClosed`. The marker names
`handoffRecordId` and `closeCallbackId` and proves `closed=true, bufferEmpty=true`.
The current snapshot must prove physical quiescence and exact P/scratch/canonical
reference. A failed pre-close snapshot still logs the close but cannot certify it.

The controller ends visible dwell at the close callback's start endpoint, not at
the later chat reply. Original and recovery replies remain separate immutable
records; a later recovery cannot fill an original short dwell. A same-runtime
reopen after a completed card may precede its separately approved recovery, whose
fresh readiness/reference and operation checks still apply. Closing before target
acceptance does not create the missing operation or deferred/profile render.
The final parser accepts a valid closed handoff as a physical terminal boundary;
it does not generically ignore close/open or grant credit from a stale drain.

The short proof's representative-history measurement is a separate readiness gate.
A full-history checkpoint that exceeds the measured T/2 gap blocks extended capture,
even when exact bytes and protocol checks pass. Do not drop full checks, synchronize
the writer, reduce its rate, or authorize the long rehearsal on these short results.


### Broad wave1 cooperative validation and rate ruling

The single owner now calls `checkpoint(reason, service=None)`. Live collector service
performs real collection between complete sealed archive hashes, with stop/control,
deadline, start-to-start and work-interval checks. New sealed generations enter this
same checkpoint epoch; forced final collection precedes current archive/full prefix
validation without another yield. Rotation fully compares outgoing source/archive;
sealed history retains metadata continuity until full ready/settled/finish hashing.
No background verifier exists. Existing observation rows partition real checkpoint
work, preserving overlap accounting and byte totals.

A bounded observed outgoing tail may be consumed once before the seal anchor, only
when its extent was sampled before `_append` returned and uniquely matches `.1`.
Every later outgoing change, ambiguous occurrence or second rotation refuses. Eight
one-millisecond absent-path/enumeration retries require a uniquely held stable linked
occurrence. Ordinary metadata-only source changes during publication refuse except
verified rename. Finish requires an exact stable fully consumed cutoff as above.

Rate calibration separates native complete five-unit workload peaks from padding.
R is the maximum native peak across both variants, floored at 4MiB/min. Padding fills
only a trailing one-second source deficit after immediate native dispatch, never
paces native output from collector state. Actual combined source peaks remain
reported and govern conservative T=1MiB/rate, poll<=min(2,T/4), gap<=min(10,T/2)
and retained history ceil(rate*2400/MiB). The earlier additive-padding 3261.5MiB/.25s
refusals are preserved stress limits, not silently reclassified as passing. Current
qualification outcome belongs to the broad-wave report and accepted immutable freeze;
none of this authorizes a long or live run.

Adjacent minor dispositions: valid accepted-reference reason is false; the collector
calibration always closes launcher PIPEs and snapshots default tmux before launch.
Older archives and their prior triage remain immutable.
