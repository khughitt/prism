"""Actual collector loop, explicit synthetic retained-history initialization, independent writer."""
import json,os,sys,subprocess,time,threading,shutil,hashlib,signal,math
from pathlib import Path
import capture,logs
os.umask(0o077)
if sys.argv[1]=='child':
 root=Path(sys.argv[2]);seed=Path(sys.argv[3]);original=logs.start
 def seeded(log,manifest):
  original(log,manifest);state=json.loads((seed/'manifest.json').read_text());st=log.stat();held=state['current'];held.update(dev=st.st_dev,inode=st.st_ino,offset=st.st_size);state['log']=str(log)
  for r in state['segments'][:-1]:shutil.copyfile(seed/r['path'],root/r['path'])
  r=state['segments'][-1];raw=log.read_bytes();r.update(dev=st.st_dev,inode=st.st_ino,bytes=len(raw),startOffset=0,endOffset=len(raw),sha256=hashlib.sha256(raw).hexdigest());r['path']=f"segment-{r['generation']:06d}-{st.st_dev}-{st.st_ino}.raw";(root/r['path']).write_bytes(raw);logs.save(manifest,state)
 logs.start=seeded
 original_open=Path.open;original_archive=logs.Capture._archive;original_checkpoint=logs.Capture.checkpoint;meter=[0];reason=[None]
 class ReadMeter:
  def __init__(self,f):self.f=f
  def __getattr__(self,k):return getattr(self.f,k)
  def __enter__(self):return self
  def __exit__(self,*a):return self.f.__exit__(*a)
  def read(self,*a):
   data=self.f.read(*a);meter[0]+=len(data);return data
 def opened(path,*a,**kw):
  f=original_open(path,*a,**kw)
  return ReadMeter(f) if path.name.startswith('segment-') and a and a[0]=='rb' else f
 with original_open(root/'archive-validation.jsonl','x') as evidence:
  def archive(owner,record):
   at=time.monotonic();before=meter[0]
   original_archive(owner,record)
   evidence.write(json.dumps({'reason':reason[0],'generation':record['generation'],'bytesRead':meter[0]-before,'start':at,'end':time.monotonic()})+'\n');evidence.flush()
  def checkpoint(owner,why,service=None):
   reason[0]=why
   try:return original_checkpoint(owner,why,service)
   finally:reason[0]=None
  Path.open=opened;logs.Capture._archive=archive;logs.Capture.checkpoint=checkpoint
  result=capture.run_collector(root/'RUN.json')
 sys.exit(result)
root=Path(sys.argv[1]);seed=Path(sys.argv[2]);root.mkdir();log=root/'host.log';log.write_bytes(b'A'*(512*1024));guard=float(os.environ.get('GUARD_BPS','1425679'));guard_T=1024*1024/guard;cfg={'schema':2,'environment':'synthetic','runId':'capacity','clockOrigin':'monotonic','socket':'prism-budget-capture-capacity','deadlineSeconds':2700,'pollSeconds':min(.1,guard_T/4),'maxGapSeconds':min(10,guard_T/2),'log':str(log)}
for k in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[k]=str(root/(k+'.json'))
capture.atomic(root/'RUN.json',cfg);capture.atomic(root/'wrapper-ready.json',{});capture.atomic(root/'identities.json',{'testOwner':capture.process(os.getpid())});stop=threading.Event();spans=[];errors=[];child=None;thread=None
rate=float(os.environ.get('TARGET_BPS','1425679'));block=b'capacity '+b'.'*int(rate*.016)+b'\n';checkpoints=[]
def writer():
 try:
  while not stop.is_set():
   begin=time.monotonic()
   if log.stat().st_size+len(block)>1024*1024:log.replace(root/'host.log.1');log.write_bytes(b'')
   with log.open('ab',buffering=0) as f:f.write(block);os.fsync(f.fileno())
   spans.append({'start':begin,'end':time.monotonic(),'bytes':len(block)});stop.wait(max(0,.016-(time.monotonic()-begin)))
 except BaseException as e:errors.append(repr(e))
def wait(predicate,limit=30):
 at=time.monotonic()
 while time.monotonic()-at<limit:
  p=root/'heartbeat.json'
  if p.exists():
   d=json.loads(p.read_text())
   if d['exitReason']!='running':raise AssertionError(d)
   if predicate(d):return d
  if child.poll() is not None:raise AssertionError((root/'collector-receipt.json').read_text())
  time.sleep(.01)
 raise AssertionError('capacity receipt timeout')
try:
 with (root/'collector-output.log').open('x') as out:child=subprocess.Popen([sys.executable,__file__,'child',str(root),str(seed)],stdout=out,stderr=subprocess.STDOUT)
 capture.atomic(root/'child-identity.json',capture.process(child.pid));wait(lambda d:True)
 thread=threading.Thread(target=writer);thread.start()
 for seq in (1,2):
  at=time.monotonic();capture.atomic(root/'control.json',{'sequence':seq,'command':'ready'});wait(lambda d:d['lastSequence']==seq);checkpoints.append({'reason':'ready','start':at,'end':time.monotonic()})
 stop.set();thread.join();assert not errors,errors
 capture.atomic(root/'control.json',{'sequence':3,'command':'finish'});child.wait(timeout=30)
 receipt=json.loads((root/'collector-receipt.json').read_text());assert receipt['integrityComplete'],receipt
 polls=[json.loads(x) for x in (root/'polls.json').read_text().splitlines()];gap=max(b['start']-a['start'] for a,b in zip(polls,polls[1:]));work=max(x['end']-x['start'] for x in polls);assert max(gap,work)<=cfg['maxGapSeconds']
 manifest=json.loads((root/'manifest.json').read_text());assert len(manifest['segments'])>len(json.loads((seed/'manifest.json').read_text())['segments'])
 peak=max(sum(x['bytes'] for x in spans if s['start']<=x['start']<s['start']+1) for s in spans);actual_T=1024*1024/max(peak,4*1024*1024/60)
 assert cfg['pollSeconds']<=min(2,actual_T/4) and cfg['maxGapSeconds']<=min(10,actual_T/2)
 retained=sum(r['bytes'] for r in json.loads((seed/'manifest.json').read_text())['segments']);assert retained>=guard*2400
 capture.atomic(root/'proof.json',{'PASS':True,'actualSourcePeakBytesPerSecond':peak,'requiredHistoryMiB':math.ceil(guard*2400/1024/1024),'retainedBytes':sum(r['bytes'] for r in json.loads((seed/'manifest.json').read_text())['segments']),'targetBytesPerSecond':rate,'guardBytesPerSecond':guard,'configuredPollSeconds':cfg['pollSeconds'],'configuredGapSeconds':cfg['maxGapSeconds'],'writeSpans':spans,'checkpoints':checkpoints,'maxPollGapSeconds':gap,'maxWorkIntervalSeconds':work,'receipt':receipt,'initialization':'explicit synthetic history; no live resume interface'})
 print('PASS capacity',gap,work,len(manifest['segments']))
finally:
 stop.set()
 if thread:thread.join()
 if child and child.poll() is None:
  child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait()
 capture.atomic(root/'cleanup.json',{'childReaped':child is None or child.poll() is not None,'writerJoined':thread is None or not thread.is_alive()})
