"""Focused corrective regressions; all host state is temporary and synthetic."""
import copy, importlib.util, pathlib, tempfile, unittest, sys
ROOT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('controller',ROOT/'controller.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
class Host:
 def __init__(self,fail=None):self.fail=fail;self.actions=[]
 def invoke(self,action,authorization,arguments):
  assert authorization=='fresh';self.actions.append(action)
  if action==self.fail:raise RuntimeError('injected boundary')
  return {}
def session():return {'sessionId':'s','runId':'r','environment':'fake-host','clockOrigin':'o','identity':{'stage':'stage1'},'steps':{'finish':1}}
class Corrections(unittest.TestCase):
 def test_I1_initial_diagnostic_wait(self):
  # The review's concrete 0.01-second first-drag counterexample.
  rows=[dict(class_='')]
  rows=[{'class':'cardSettled','cardId':'c','timestamp':1}, {'class':'input','scope':'callback','timestamp':1.01,'startTimestamp':1.01}, {'class':'operationRequested','cardId':'c','operationKind':'release','operationId':'r','key':'a','valid':True,'timestamp':3.1}, {'class':'operationDone','operationId':'r','timestamp':4}]
  for i,r in enumerate(rows,1):r['recordId']=i
  with self.assertRaises(ValueError):c.operation_gates(rows,{'cardId':'c','operations':[{'id':'r','kind':'release','key':'a'}]},10)
 def test_I2_excluded_original_physical_drain(self):
  p=pathlib.Path(sys.argv[1])/'baseline/fix1-excluded-fake.log'
  rows=c.analyze.read_rotated([p]);card=rows[0]['cardId'];original=[r for r in rows if r['cardId']==card]
  self.assertFalse(any(r['class']=='cardSettled' for r in original))
  self.assertTrue(c.operation_gates(original,{'cardId':card,'operations':[]},original[-1]['timestamp']+6))
 def test_I3_partial_prepare_abort(self):
  for action in ('rotation-pause','state-clear','collector-launch'):
   with self.subTest(action=action),tempfile.TemporaryDirectory() as td:
    host=Host(action);obj=c.Controller(td,session(),host)
    with self.assertRaises(ValueError):obj.prepare('fresh')
    self.assertEqual(obj.state['phase'],'preparing')
    self.assertEqual(obj.state['attempts'][-1]['action'],action)
    self.assertEqual(obj.state['attempts'][-1]['status'],'uncertain')
 def test_I4_clean_incomplete_finish(self):
  with tempfile.TemporaryDirectory() as td:
   obj=c.Controller(td,session(),Host(),lambda:10);obj.window=c.Window(0,{'finish':1});obj.window.stamps['initialCompleteReceived']=5;obj.state['phase']='checked'
   normal={'collectionComplete':False,'coldCollectionComplete':True,'certificates':[{'physicalDrainComplete':True,'operationGatesComplete':True,'originVerified':True}]}
   with self.assertRaises((KeyError,FileNotFoundError)):obj.finish('fresh',normal)
   self.assertEqual(obj.state['phase'],'checked')
 def test_I5_prior_proof_binding(self):
  self.assertTrue(hasattr(c,'bound_proofs'),'missing independent per-activation lifecycle/clock/restoration binder')
 def test_I6_release_replacement_scalar(self):
  op={'kind':'release','key':'a','expectedReference':{'acceptedProfile':'P','acceptedWallpaper':False,'values':{'a':.2,'b':.5},'heldScratchKeys':[]}}
  new=copy.deepcopy(op);new['expectedReference']['values']['a']=.3;new['expectedReference']['heldScratchKeys']=['a']
  self.assertTrue(hasattr(c.analyze,'replacement_reference'),'scalar-specific replacement predicate missing')
  self.assertTrue(c.analyze.replacement_reference(op,new))
  new['expectedReference']['values']['b']=.6;self.assertFalse(c.analyze.replacement_reference(op,new))
if __name__=='__main__':unittest.main(argv=[sys.argv[0]],verbosity=2)
