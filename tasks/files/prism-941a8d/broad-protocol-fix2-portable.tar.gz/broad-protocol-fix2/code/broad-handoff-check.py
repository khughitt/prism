"""Counterfeit only in memory; saved actual generated handoffs remain immutable."""
import copy,json,sys
from pathlib import Path
import controller as c
root=Path(sys.argv[1]);cases=0
for path in root.glob('handoff-*-*'):
 if not (path/'normalized.json').exists():continue
 normal=c.load(path/'normalized.json');context=c.load(path/'context.json');identity=c.load(path/'session.json')['identity'];rows=normal['events']
 if 'short-' in path.name:continue
 def normalize(events):return c.analyze.normalize(events,[identity],context['cards'],context['authorizations'])
 assert normalize(rows)==normal
 handoff=next(e for e in reversed(sorted(rows,key=lambda e:e['recordId'])) if e['class']=='handoff')
 boundary=c.analyze.handoff_boundary(rows,handoff);assert boundary
 for name,field,value in [('not-closed','closed',False),('unflushed','bufferEmpty',False),('wrong-close','closeCallbackId',1234567),('wrong-link','handoffRecordId',1234567)]:
  altered=copy.deepcopy(rows);next(e for e in altered if e['recordId']==boundary['marker']['recordId'])[field]=value
  assert not normalize(altered)['certificates'][0]['physicalDrainComplete'],name;cases+=1
 altered=copy.deepcopy(rows);h=next(e for e in altered if e['recordId']==handoff['recordId']);key=next(iter(h['handoffReference']['values']));h['handoffReference']['values'][key]='wrong-current-reopened-value'
 assert not normalize(altered)['collectionComplete'];cases+=1
 altered=copy.deepcopy(rows);h=next(e for e in altered if e['recordId']==handoff['recordId']);h['queueIdle']=False
 assert not normalize(altered)['certificates'][0]['physicalDrainComplete'];cases+=1
 # Lost final marker has no ID gap but cannot certify the close callback suffix.
 altered=[e for e in rows if e['recordId']!=boundary['marker']['recordId']]
 assert not normalize(altered)['certificates'][0]['physicalDrainComplete'];cases+=1
 assert c.load(path/'initialCompleteReceived.json')['replyId']=='fake-initial-owner-reply'
 print('PASS durable handoff negatives',path.name)
assert cases
print('PASS',cases,'actual-record negative checks; old raw files untouched')
