import importlib.util,json,os,tempfile,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('rotation_guard',Path(__file__).with_name('rotation-guard.py'));g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
with tempfile.TemporaryDirectory(prefix='prism-rotation-check-') as temp:
    root=Path(temp);state=root/'fake.json';executable=root/'systemctl';journal=root/'guard.json'
    executable.write_text('''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
p=Path(os.environ['FAKE_WALI_STATE']);s=json.loads(p.read_text());a=sys.argv[2:];action=a[0];unit=a[-1];timer=unit=='wali-rotate.timer'
if action in ['stop','start']:
 s['calls'].append(action+' '+unit)
 if s.get('failAction')==action:p.write_text(json.dumps(s));sys.exit(7)
 assert timer
 s['active']=action=='start';s['generation']+=1
 p.write_text(json.dumps(s));sys.exit(0)
if action=='cat':print('[Timer]\\nOnActiveSec='+s.get('period','15min')+'\\nOnUnitActiveSec=15min\\nUnit=wali-rotate.service' if timer else '[Service]\\nType=oneshot\\nExecStart=/fixture/walictl next');sys.exit(0)
assert action=='show'
if timer and s.get('epochAfterTimerReads',0)>0:
 s['epochAfterTimerReads']-=1
 if s['epochAfterTimerReads']==0:s['generation']+=2
 p.write_text(json.dumps(s))
if not timer and s.get('busy',0)>0:s['busy']-=1;p.write_text(json.dumps(s));busy=True
else:busy=False
values={'LoadState':'loaded','ActiveState':('active' if s['active'] else 'inactive') if timer else ('activating' if busy else 'inactive'),'SubState':('waiting' if s['active'] else 'dead') if timer else ('start' if busy else 'dead'),'UnitFileState':s.get('enabled','enabled') if timer else 'linked','NeedDaemonReload':'no','FragmentPath':'/fixture/'+unit,'DropInPaths':'','Triggers':'wali-rotate.service' if timer else '', 'Unit':'wali-rotate.service' if timer else '', 'ActiveEnterTimestampMonotonic':str(s['generation']) if timer else '0','InactiveEnterTimestampMonotonic':str(s['generation']) if timer else '0','Result':'failed' if s.get('serviceFailure') and not timer else 'success'}
if not timer:values.pop('Unit')
for k,v in values.items():print(k+'='+v)
''');executable.chmod(0o700)
    os.environ['FAKE_WALI_STATE']=str(state);g.SYSTEMCTL=str(executable);g.WAIT_SECONDS=0.6;g.POLL_SECONDS=0.01
    def reset(active=True,**extra):
        state.write_text(json.dumps({'active':active,'generation':1,'calls':[],**extra}))
        try:before=g.snapshot()
        except KeyError as error:raise AssertionError('service snapshot must not require timer-only Unit property') from error
        journal.write_text(json.dumps({'before':before,'stage':'saved'}))
    def data():return json.loads(state.read_text())
    def edit(**changes):s=data();s.update(changes);state.write_text(json.dumps(s))
    def refuses(fn,text):
        try:fn()
        except (AssertionError,RuntimeError,TimeoutError) as e:assert text in str(e),(text,str(e))
        else:raise AssertionError('expected refusal: '+text)
    def inactive_epoch(which):
        reset(False,enabled='disabled')
        if which=='resume':g.pause(journal)
        before=json.loads(journal.read_text());edit(epochAfterTimerReads=2)
        refuses(lambda:(g.pause if which=='pause' else g.resume)(journal),'activation state changed')
        after=json.loads(journal.read_text())
        assert data()['generation']==3 and not data()['active'] and data()['calls']==[]
        if which=='pause':assert 'pausedState' not in after
        else:assert after['pausedState']==before['pausedState'] and 'resumedState' not in after
        print('PASS inactive '+which+' refuses concurrent start/stop epoch without commands or ownership adoption')
    if len(sys.argv)>1:
        assert sys.argv[1] in ('inactive-epoch-pause','inactive-epoch-resume')
        inactive_epoch(sys.argv[1].rsplit('-',1)[1]);sys.exit(0)
    inactive_epoch('pause');inactive_epoch('resume')
    reset();assert json.loads(journal.read_text())['before'].get('timer',{}).get('state',{}).get('active')=='active','snapshot must save actual timer activation state'
    g.pause(journal);assert not data()['active'];g.resume(journal);assert data()['active'] and data()['calls']==['stop wali-rotate.timer','start wali-rotate.timer']
    reset(False,enabled='disabled');g.pause(journal);g.resume(journal);assert not data()['active'] and data()['enabled']=='disabled' and data()['calls']==[]
    reset(busy=5);g.pause(journal);assert data()['busy']==0 and not data()['active'];g.resume(journal)
    reset(busy=999);refuses(lambda:g.pause(journal),'service wait timeout');assert not data()['active'] and json.loads(journal.read_text())['stage']=='paused-awaiting-service';edit(busy=0);g.resume(journal);assert data()['active']
    reset(serviceFailure=True);refuses(lambda:g.pause(journal),'service failed');assert not data()['active'];edit(serviceFailure=False);g.resume(journal)
    reset(failAction='stop');refuses(lambda:g.pause(journal),'systemctl failed');assert data()['active'] and json.loads(journal.read_text())['stage']=='pause-issued'
    reset();g.pause(journal);edit(failAction='start');refuses(lambda:g.resume(journal),'systemctl failed');assert not data()['active'] and json.loads(journal.read_text())['stage']=='resume-issued'
    reset();edit(period='20min');refuses(lambda:g.pause(journal),'configuration changed');assert data()['calls']==[]
    reset();g.pause(journal);edit(enabled='disabled');refuses(lambda:g.resume(journal),'configuration changed');assert not data()['active']
    reset();edit(generation=2);refuses(lambda:g.pause(journal),'activation state changed');assert data()['calls']==[]
    reset();g.pause(journal);edit(active=True,generation=3);refuses(lambda:g.resume(journal),'activation state changed');assert data()['calls']==['stop wali-rotate.timer']
    reset();g.pause(journal);edit(period='20min');refuses(lambda:g.resume(journal),'configuration changed');assert not data()['active']
print('PASS fixed rotation guard: active stop/start, prior inactive untouched, natural busy drain, timeout recovery, service/command failures, stale config/enablement/state conflicts refuse; zero real host mutations')
