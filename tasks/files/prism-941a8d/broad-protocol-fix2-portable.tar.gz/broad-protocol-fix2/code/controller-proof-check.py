"""Adversarial certification inputs. Relabelled copies below are tests, never proof."""
import importlib.util,pathlib,sys,copy
s=importlib.util.spec_from_file_location('integration',pathlib.Path(__file__).parent/'controller-integration.py');it=importlib.util.module_from_spec(s);s.loader.exec_module(it)
c=it.c
prior=it.merged([it.pipeline('full-gainpass','stage1',v,b,5,5) for b in ('1','2') for v in ('baseline','candidate')])
assert prior['normalized']['collectionComplete']
print('prior verdict',it.verdict(prior)['verdict'])
current=it.merged([it.pipeline('manual','stage2',v,b,1,0) for b in ('1','2') for v in ('baseline','candidate')])
assert current['normalized']['collectionComplete']
def adversarial_labels(p,environment):
 p=copy.deepcopy(p)
 for i in p['identities']:i['environment']=environment
 for e in p['events']:e['environment']=environment
 p['normalized']=c.analyze.normalize(p['events'],p['identities'],p['cards'],p['authorizations'])
 p['clock']={'activations':{}}
 for i,r,cert in zip(p['identities'],p['restoration'],p['normalized']['certificates']):
  r['identitySha256']=c.digest(c.encoded(i));r['certificateSha256']=c.digest(c.encoded(cert))
  proof={k:r[k] for k in ('sessionId','activationNonce','runId','clockOrigin','identitySha256')};proof.update(verified=True,sourceProofSha256='adversarial-test-only')
  r['clockProofSha256']=c.digest(c.encoded(proof));p['clock']['activations'][i['activationNonce']]=proof
 return p
live=adversarial_labels(current,'live');prior_live=adversarial_labels(prior,'live')
evidence,_=c.stage_evidence(live['normalized'],live['identities'],live['receipts'],live['restoration'],live['clock'],live['observations'],prior_live)
assert evidence['stage1Certified'] and evidence['clockOriginVerified'] and evidence['restorationComplete'],evidence
for environment in ('fake-host','synthetic'):
 bad=adversarial_labels(prior,environment)
 evidence,_=c.stage_evidence(live['normalized'],live['identities'],live['receipts'],live['restoration'],live['clock'],live['observations'],bad)
 assert not evidence['stage1Certified'];print('PASS prior',environment,'cannot certify live-labelled current even with matching proof booleans/hashes')
for which in ('clock-session','clock-origin','clock-source','clock-identity','restore-session','restore-run','restore-source','receipt-run','receipt-origin','restore-receipt','restore-certificate'):
 bad=copy.deepcopy(prior_live);nonce=bad['identities'][0]['activationNonce'];r=bad['restoration'][0];clock=bad['clock']['activations'][nonce]
 if which.startswith('clock-'):clock[{'session':'sessionId','origin':'clockOrigin','source':'sourceProofSha256','identity':'identitySha256'}[which[6:]]]='stale'
 elif which=='restore-session':r['sessionId']='other'
 elif which=='restore-run':r['runId']='other'
 elif which=='restore-source':r['identitySha256']='other'
 elif which=='receipt-run':bad['receipts'][0]['runId']='other'
 elif which=='receipt-origin':bad['receipts'][0]['clockOrigin']='other'
 elif which=='restore-receipt':r['collectorReceiptSha256']='other'
 elif which=='restore-certificate':r['certificateSha256']='other'
 evidence,_=c.stage_evidence(live['normalized'],live['identities'],live['receipts'],live['restoration'],live['clock'],live['observations'],bad)
 assert not evidence['stage1Certified'],which
 print('PASS independent prior binding refusal',which)
# Literal restored clean cold-only outgoing facts, never naked protocol booleans.
p=it.pipeline('shortlaunch-gainpass','stage1','baseline','1',5,5)
assert c.outgoing_complete(p['state'],'stage1') and not c.outgoing_complete(p['state'],'stage2')
for field in ('coldProtocolComplete','phase','invalid'):
 bad=copy.deepcopy(p['state']);bad[field]={'coldProtocolComplete':False,'phase':'complete','invalid':['failure']}[field];assert not c.outgoing_complete(bad,'stage1')
print('PASS only restored clean cold-complete outgoing Stage1 may continue matched blocks; Stage2 full requirement retained')
print('PASS cross-stage adversarial bindings; no source proof, live authorization or live acceptance created')
