"""Real collector with real files; injected monotonic fsync cost selects a bounded interleaving."""
import os,sys,json,tempfile,time,signal,importlib.util,copy
from pathlib import Path
from unittest.mock import patch
code=Path(os.environ.get('BROAD_CODE',Path(__file__).parent));sys.path.insert(0,str(code));s=importlib.util.spec_from_file_location('capture',code/'capture.py');cap=importlib.util.module_from_spec(s);s.loader.exec_module(cap)
mode=sys.argv[1] if len(sys.argv)>1 else 'slow';cost=.6 if mode in ('slow','terminal') else .1
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp);log=root/'host.log';log.write_bytes(b'');cfg={'schema':2,'runId':'persistence-test','environment':'synthetic','clockOrigin':'test','socket':'prism-budget-capture-persistence','deadlineSeconds':2700,'pollSeconds':.05,'maxGapSeconds':.5,'log':str(log)}
 for k in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[k]=str(root/(k+'.json'))
 cap.atomic(root/'RUN.json',cfg);cap.atomic(root/'wrapper-ready.json',{});cap.atomic(root/'identities.json',{'owner':cap.process(os.getpid())});cap.atomic(root/'control.json',{'sequence':1,'command':'finish'})
 real_fsync=os.fsync;now=[time.monotonic()];spans=[];polls=[];real_poll=cap.logs.Capture.poll
 def sync(fd):
  if os.readlink(f'/proc/self/fd/{fd}')==str(root/'polls.json'):
   start=now[0];target=3 if mode=='terminal' else 2;now[0]+=cost if mode=='coverage' or len(spans)+1==target else 0;spans.append((start,now[0]))
  real_fsync(fd)
 def poll(owner):polls.append(now[0]);result=real_poll(owner);now[0]+=.05;return result
 traps={s:signal.getsignal(s) for s in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
 try:
  with patch.object(cap.time,'monotonic',lambda:now[0]),patch.object(cap.os,'fsync',sync),patch.object(cap.logs.Capture,'poll',poll):exit_code=cap.run_collector(root/'RUN.json')
 finally:
  for s,h in traps.items():signal.signal(s,h)
 receipt=json.loads((root/'collector-receipt.json').read_text());rows=[json.loads(x) for x in (root/'polls.json').read_text().splitlines()]
 if mode in ('slow','terminal'):assert exit_code==1 and receipt['integrityComplete'] is False and 'gap' in receipt['error'],f'slow row fsync certified: {receipt}, actual collection starts {polls}'
 else:
  assert exit_code==0 and receipt['integrityComplete']
  observed=[row['previousIntervalPersistence'] for row in rows if row.get('previousIntervalPersistence')]+[receipt['lastIntervalPersistence']]
  assert [(row['start'],row['end']) for row in observed]==spans,(observed,spans)
  assert all(row['bytes']==0 and row['observation']=='persistence' for row in observed)
  spec=importlib.util.spec_from_file_location('analyze',code/'frozen-task2/analyze.py');analyze=importlib.util.module_from_spec(spec);spec.loader.exec_module(analyze)
  sample={'runId':cfg['runId'],'clockOrigin':cfg['clockOrigin'],'block':'1','variant':'baseline','class':'coldRender','scope':'callback','startTimestamp':spans[1][0]+.01,'endTimestamp':spans[1][1]-.01,'elapsedMs':80,'timestamp':spans[1][1]}
  normal={'exclusions':[],'events':[sample],'samples':[sample],'certificates':[{'originVerified':True}]};all_rows=rows+[receipt['lastIntervalPersistence']]
  overlap=analyze.overlap_report(normal,all_rows);assert overlap['overlapCount']==1 and overlap['observations'][overlap['samples'][0]['overlapObservationIndices'][0]]['kind']=='persistence'
  for mutation in ('missing-terminal','wrong-start','wrong-owner','duplicate'):
   bad=copy.deepcopy(all_rows)
   if mutation=='missing-terminal':bad.pop()
   elif mutation=='wrong-start':bad[-1]['start']+=.01
   elif mutation=='wrong-owner':bad[-1]['persistedObservationStart']-=1
   else:bad.append(copy.deepcopy(bad[-1]))
   try:analyze.overlap_report(normal,bad)
   except ValueError:pass
   else:raise AssertionError('invalid persistence evidence accepted: '+mutation)
  other=copy.deepcopy(all_rows)
  for row in other:
   row['clockOrigin']='other-clock'
   if row.get('previousIntervalPersistence'):row['previousIntervalPersistence']['clockOrigin']='other-clock'
  sample2=sample|{'clockOrigin':'other-clock','variant':'candidate'}
  assert analyze.overlap_report(normal|{'events':[sample,sample2],'samples':[sample,sample2]},rows+other[:-1]+[all_rows[-1],other[-1]])['overlapCount']==2
  zero=copy.deepcopy(all_rows);origin=zero[0]['start']
  def shift(row):
   row['start']-=origin;row['end']-=origin
   if 'persistedObservationStart' in row:row['persistedObservationStart']-=origin
   if row.get('previousIntervalPersistence'):shift(row['previousIntervalPersistence'])
  for row in zero:shift(row)
  zero[1]['previousIntervalPersistence']['persistedObservationStart']=False
  try:analyze.overlap_report(normal,zero)
  except ValueError:pass
  else:raise AssertionError('Boolean persistence anchor accepted as zero')
  bad=copy.deepcopy(all_rows);bad[1]['previousIntervalPersistence']['end']='not-a-number'
  try:analyze.overlap_report(normal,bad)
  except ValueError:pass
  else:raise AssertionError('nonnumeric persistence end accepted')
  print('PASS persistence overlap, separate clocks and six strict evidence negatives')
 print('PASS persistence',mode,'starts',polls,'spans',spans,'complete',receipt['integrityComplete'])
