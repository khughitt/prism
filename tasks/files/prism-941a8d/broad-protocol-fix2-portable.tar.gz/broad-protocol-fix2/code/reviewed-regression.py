"""RED replay of reviewed code against actual corrective producer/lifecycle inputs."""
import copy,importlib.util,pathlib,sys,tempfile,unittest
OLD=pathlib.Path(sys.argv[1]);FIX=pathlib.Path(sys.argv[2]);PROOF=pathlib.Path(sys.argv[3]);COLD=pathlib.Path(sys.argv[4])
s=importlib.util.spec_from_file_location('reviewed_controller',OLD/'controller.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
def fixture(root):
 ctx=old.load(root/'context.json');session=old.load(root/'session.json');n=old.load(root/'normalized.json')
 return {'events':n['events'],'identities':[session['identity']],'cards':ctx['cards'],'authorizations':ctx['authorizations'],'receipts':[old.load(root/'receipt.json')],'restoration':[old.load(root/'restoration.json')],'clock':{'verified':True},'observations':{'complete':True,'budgetErrors':0,'polls':[]},'normalized':n}
def merge(parts):
 p={k:sum((x[k] for x in parts),[]) for k in ('events','identities','receipts','restoration')}
 for k in ('cards','authorizations'):p[k]={key:v for x in parts for key,v in x[k].items()}
 p.update(clock={'verified':True},observations={'complete':True,'budgetErrors':0,'polls':[]});p['normalized']=old.analyze.normalize(p['events'],p['identities'],p['cards'],p['authorizations']);return p
class Host:
 def invoke(self,action,authorization,args):
  if action=='collector-launch':raise RuntimeError('failure after preceding pointer effect')
  return {}
class Regression(unittest.TestCase):
 def test_I1_actual_short_initial_diagnostic(self):
  root=next(FIX.glob('release-recovery-short-initial-diagnostic-*'));p=fixture(root)
  self.assertFalse(old.operation_gates(p['events'],old.load(root/'action-manifest.json'),old.load(root/'initialCompleteReceived.json')['receivedAt']))
 def test_I2_actual_excluded_original(self):
  root=next(FIX.glob('excluded-*'));p=fixture(root)
  self.assertTrue(old.operation_gates(p['events'],old.load(root/'action-manifest.json'),old.load(root/'initialCompleteReceived.json')['receivedAt']))
 def test_I3_abort_after_pointer(self):
  with tempfile.TemporaryDirectory() as td:
   obj=old.Controller(td,{'environment':'fake-host','steps':{'finish':1}},Host())
   with self.assertRaises(ValueError):obj.prepare('fake')
   obj.owner_stop('fresh-fake','explicit-abort');self.assertIn(obj.state['phase'],('stopping','stopped'))
 def test_I4_actual_cold_only_finish(self):
  root=next(COLD.glob('shortlaunch-gainfail-1-baseline-*'));p=fixture(root)
  with tempfile.TemporaryDirectory() as td:
   obj=old.Controller(td,{'environment':'fake-host','steps':{'finish':1}},Host(),lambda:10);obj.window=old.Window(0,{'finish':1});obj.window.stamps['initialCompleteReceived']=5;obj.state['phase']='checked'
   obj.finish('fresh-fake',p['normalized']);self.assertEqual(obj.state['phase'],'finishing')
 def test_I5_actual_prior_fake_certifies_live(self):
  prior=merge([fixture(p) for p in sorted(PROOF.glob('full-gainpass-*'))]);current=merge([fixture(p) for p in sorted(PROOF.glob('manual-*'))])
  for i in current['identities']:i['environment']='live'
  for e in current['events']:e['environment']='live'
  current['normalized']=old.analyze.normalize(current['events'],current['identities'],current['cards'],{})
  evidence,_=old.stage_evidence(current['normalized'],current['identities'],current['receipts'],current['restoration'],current['clock'],current['observations'],prior)
  self.assertFalse(evidence['stage1Certified'])
 def test_I6_actual_independent_release_replacement(self):
  root=next(FIX.glob('release-recovery-1-baseline-*'));p=fixture(root);ctx=old.load(root/'context.json');result=old.analyze.normalize(p['events'],p['identities'],p['cards'],p['authorizations'])
  self.assertTrue(result['collectionComplete'],'actual full recovery readiness/scalar references rejected by reviewed consumer')
if __name__=='__main__':unittest.main(argv=[sys.argv[0]],verbosity=2)
