import json,os,subprocess,sys,time
from pathlib import Path
SYSTEMCTL='/usr/bin/systemctl'
WAIT_SECONDS=30
POLL_SECONDS=0.25
TIMER='wali-rotate.timer'
SERVICE='wali-rotate.service'
PROPERTIES=('LoadState','ActiveState','SubState','UnitFileState','NeedDaemonReload','FragmentPath','DropInPaths','Triggers','Unit','ActiveEnterTimestampMonotonic','InactiveEnterTimestampMonotonic','Result')

def command(*args):
    result=subprocess.run([SYSTEMCTL,'--user',*args],capture_output=True,text=True,timeout=10)
    if result.returncode:raise RuntimeError('systemctl failed: '+args[0]+' '+args[-1]+' exit '+str(result.returncode))
    return result.stdout

def unit(name):
    values=dict(line.split('=',1) for line in command('show','--no-pager',*[f'--property={p}' for p in PROPERTIES],name).splitlines())
    assert values['LoadState']=='loaded','unit not loaded: '+name
    assert values['NeedDaemonReload']=='no','configuration changed: unit needs daemon reload'
    config_keys=('UnitFileState','FragmentPath','DropInPaths','Triggers')+(('Unit',) if name==TIMER else ())
    return {'config':{'unitText':command('cat',name),**{k:values[k] for k in config_keys}},
        'state':{'active':values['ActiveState'],'activeEnter':values['ActiveEnterTimestampMonotonic'],'inactiveEnter':values['InactiveEnterTimestampMonotonic']},
        'subState':values['SubState'],'result':values['Result']}

def snapshot():
    timer=unit(TIMER);service=unit(SERVICE)
    assert timer['config']['Unit']==SERVICE and timer['config']['Triggers']==SERVICE,'timer targets a different service'
    assert (timer['state']['active'],timer['subState']) in [('active','waiting'),('active','running'),('inactive','dead')],'unexpected timer state'
    return {'timer':timer,'service':service}

def save(file,record):
    file=Path(file);temp=file.with_suffix('.tmp');temp.write_text(json.dumps(record,indent=2)+'\n');temp.chmod(0o600);temp.replace(file)

def guard(record,current,expected):
    for name in ('timer','service'):
        assert current[name]['config']==record['before'][name]['config'],'configuration changed: '+name
    assert current['timer']['state']==expected,'timer activation state changed; refuse unrelated stop/start'

def wait_service(record,expected):
    deadline=time.monotonic()+WAIT_SECONDS
    while True:
        current=snapshot();guard(record,current,expected)
        if current['service']['state']['active']=='inactive':
            if current['service']['result']!='success':raise RuntimeError('rotation service failed; preserve journal and investigate')
            return current
        if current['service']['state']['active']=='failed':raise RuntimeError('rotation service failed; preserve journal and investigate')
        assert current['service']['state']['active'] in ('active','activating','deactivating'),'unexpected rotation service state'
        if time.monotonic()>=deadline:raise TimeoutError('rotation service wait timeout; no service killed, journal retains timer restoration state')
        time.sleep(POLL_SECONDS)

def pause(file):
    file=Path(file);record=json.loads(file.read_text());assert record['stage']=='saved','pause already attempted; inspect journal before repeating'
    current=snapshot();guard(record,current,record['before']['timer']['state'])
    record['stage']='pause-issued';save(file,record)
    if current['timer']['state']['active']=='active':command('stop',TIMER)
    current=snapshot()
    for name in ('timer','service'):assert current[name]['config']==record['before'][name]['config'],'configuration changed: '+name
    if record['before']['timer']['state']['active']=='inactive':guard(record,current,record['before']['timer']['state'])
    assert current['timer']['state']['active']=='inactive' and current['timer']['subState']=='dead','timer did not stop'
    record['pausedState']=current['timer']['state'];record['stage']='paused-awaiting-service';save(file,record)
    wait_service(record,record['pausedState']);record['stage']='paused';save(file,record)
    return {'timerPaused':True,'serviceInactive':True,'configurationPreserved':True,'previouslyActive':record['before']['timer']['state']['active']=='active'}

def resume(file):
    file=Path(file);record=json.loads(file.read_text());assert record['stage'] in ('paused','paused-awaiting-service','resumed-awaiting-service'),'no owned paused state to restore'
    if record['stage']!='resumed-awaiting-service':
        current=snapshot();guard(record,current,record['pausedState'])
        record['stage']='resume-issued';save(file,record)
        if record['before']['timer']['state']['active']=='active':command('start',TIMER)
        current=snapshot()
        for name in ('timer','service'):assert current[name]['config']==record['before'][name]['config'],'configuration changed: '+name
        if record['before']['timer']['state']['active']=='inactive':guard(record,current,record['pausedState'])
        assert current['timer']['state']['active']==record['before']['timer']['state']['active'],'timer prior activation was not restored'
        record['resumedState']=current['timer']['state'];record['stage']='resumed-awaiting-service';save(file,record)
    current=wait_service(record,record['resumedState']);record['stage']='restored';save(file,record)
    return {'timerRestored':True,'serviceInactive':True,'configurationPreserved':True,'active':current['timer']['state']['active']=='active'}

if __name__=='__main__':
    action,file=sys.argv[1:];file=Path(file)
    if action=='snapshot':
        assert not file.exists(),'refuse to overwrite prior timer state'
        before=snapshot();save(file,{'before':before,'stage':'saved'});print(json.dumps({'saved':str(file),'timerActive':before['timer']['state']['active'],'serviceActive':before['service']['state']['active']}))
    else:
        assert action in ('pause','resume'),'use snapshot|pause|resume FILE'
        assert os.environ.get('PRISM_ROTATION_RETRY_APPROVED')=='yes','root must obtain fresh pilot retry permission before timer mutation'
        print(json.dumps((pause if action=='pause' else resume)(file)))
