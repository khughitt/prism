#!/usr/bin/env bash
set -euo pipefail
# The launcher exits; the recorded wrapper/deadline owner lives inside named tmux.
exec python3 "$(dirname -- "$0")/capture.py" launch "$1"
