"""Failure injection at durable boundaries; temporary state and actual short collector."""
import importlib.util,sys,pathlib,copy,time,subprocess,os,uuid
s=importlib.util.spec_from_file_location('integration',pathlib.Path(__file__).parent/'controller-integration.py');it=importlib.util.module_from_spec(s);s.loader.exec_module(it)
c=it.c
class FaultHost(it.Host):
 def __init__(self,root,config,action,applied=True):super().__init__(root,config);self.action=action;self.applied=applied;self.armed=True;self.last=None
 def invoke(self,action,auth,args):
  if action.startswith('reconcile-'):
   assert auth not in self.used;self.used.add(auth);original=action.removeprefix('reconcile-');state=c.load(self.root/'state.json');a=next(a for a in reversed(state['attempts']) if a['action']==original and a['status'] in ('pending','uncertain'))
   return {'action':original,'attemptId':a['id'],'outcome':'completed' if self.applied else 'not-applied','receipt':self.last or {}}
  if action==self.action and self.armed:
   self.armed=False
   if self.applied:self.last=super().invoke(action,auth,args)
   raise RuntimeError('injected after effect' if self.applied else 'injected before effect')
  return super().invoke(action,auth,args)
def refuse(fn):
 try:fn()
 except ValueError:return
 raise AssertionError('unknown state permitted')
for action,applied,crash in [('rotation-pause',True,False),('state-clear',True,False),('pointer-swap',True,False),('collector-launch',False,False),('collector-launch',True,False),('pointer-swap',True,True),('state-restore',True,True)]:
 root=it.OUT/(action+str(applied)+str(crash));root.mkdir(mode=0o700);log=root/'host.log';log.write_text('old\n');socket='prism-budget-capture-abort-'+uuid.uuid4().hex
 cfg={'schema':2,'environment':'synthetic','runId':socket,'clockOrigin':'fake-clock','socket':socket,'deadlineSeconds':2700,'pollSeconds':.02,'maxGapSeconds':2,'log':str(log)}
 for name in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[name]=str(root/(name+'.json'))
 c.immutable(root/'RUN.json',cfg);host=FaultHost(root,root/'RUN.json',action,applied)
 session={'sessionId':socket,'runId':socket,'environment':'fake-host','clockOrigin':'fake-clock','identity':{'stage':'stage1'},'steps':{'finish':1}}
 obj=c.Controller(root,session,host)
 try:
  if action=='state-restore':
   obj.prepare(it.permit());it.waitfile(root/'heartbeat.json',lambda r:r.get('collectorStarted') is not None);obj.owner_stop(it.permit(),'fake-stop');host.child.communicate(timeout=8);receipt=it.waitfile(root/'receipt.json',lambda r:'wrapperEnded' in r)
   end=time.monotonic()+2
   while any(it.cap.same_process(p) for p in receipt['processes'].values()) and time.monotonic()<end:time.sleep(.01)
   obj.stopped(receipt,it.cap.same_process)
   refuse(lambda:obj.restore(it.permit()))
  else:refuse(lambda:obj.prepare(it.permit()))
  attempt=obj.state['attempts'][-1];assert attempt['action']==action and attempt['status']=='uncertain'
  if crash:
   # Emulate process death after the durable pending boundary; effects stay applied.
   state=c.load(root/'state.json');state['attempts'][-1].pop('error',None);state['attempts'][-1]['status']='pending';c.atomic(root/'state.json',state)
  obj=c.Controller.resume(root,host);before=dict(host.state);refuse(lambda:obj.owner_stop(it.permit(),'fake-stop'));assert host.state==before
  obj.reconcile(it.permit(),attempt['id'])
  if action!='state-restore':
   if host.child is not None:it.waitfile(root/'heartbeat.json',lambda r:r.get('collectorStarted') is not None)
   obj.owner_stop(it.permit(),'fake-owner-abort')
   if host.child is not None:
    host.child.communicate(timeout=8);receipt=it.waitfile(root/'receipt.json',lambda r:'wrapperEnded' in r)
    end=time.monotonic()+2
    while any(it.cap.same_process(p) for p in receipt['processes'].values()) and time.monotonic()<end:time.sleep(.01)
    obj.stopped(receipt,it.cap.same_process)
   else:assert obj.state['phase']=='stopped' and not (root/'control.json').exists()
  obj.restore(it.permit());assert obj.state['phase']=='restored' and host.state=={'timer':True,'scratch':{'owner':1},'plugins':True} and os.readlink(host.pointer)=='original'
  if action=='state-restore':assert host.actions.count('state-restore')==1,'crash cleanup effect repeated'
  print('PASS partial abort',action,'applied',applied,'crash',crash,'fresh reconciliation/cleanup; unknown refused; no collector receipt required when absent')
 finally:
  if host.child is not None and host.child.poll() is None:
   subprocess.run(['tmux','-L',socket,'kill-server'],capture_output=True,timeout=3);host.child.communicate(timeout=8)
# A conflicting pointer blocks restore without overwriting another actor.
root=it.OUT/'conflict';root.mkdir();host=it.Host(root,root/'unused');session={'sessionId':'s','runId':'r','environment':'fake-host','clockOrigin':'o','identity':{},'steps':{'finish':1}}
obj=c.Controller(root,session,host);host.invoke('pointer-swap',it.permit(),{});obj.state.update(phase='stopped',receipts={'pointer-swap':{}});host.pointer.unlink();host.pointer.symlink_to('other');obj.save()
try:obj.restore(it.permit())
except ValueError:pass
else:raise AssertionError('conflicting pointer overwritten')
assert os.readlink(host.pointer)=='other';print('PASS conflicting temporary pointer preserved; unresolved failed cleanup cannot repeat')
