"""Real-file race schedules; injections select an interleaving, never replace file data."""
import importlib.util,os,tempfile,sys,json,threading
from pathlib import Path
code=Path(os.environ.get('BROAD_CODE',Path(__file__).parent))
s=importlib.util.spec_from_file_location('logs',code/'logs.py');logs=importlib.util.module_from_spec(s);s.loader.exec_module(logs)
class AfterRead:
 def __init__(self,file,action):self.file=file;self.action=action
 def __getattr__(self,name):return getattr(self.file,name)
 def read(self,*args):
  data=self.file.read(*args)
  if self.action:action,self.action=self.action,None;action()
  return data

def case(name):
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);log=root/'host.log';log.write_bytes(b'');manifest=root/'manifest.json';logs.start(log,manifest);c=logs.Capture(manifest)
  def append(data):
   with log.open('ab',buffering=0) as f:f.write(data)
  try:
   append(b'abc\n');c.poll()
   if name.startswith('finish'):
    original=c._archives
    def late():
     original()
     if name=='finish-mutation':log.write_bytes(b'xyz\n')
     else:append(b'exceeded its CPU budget\n' if name=='finish-error' else b'D\n')
    c._archives=late
    try:r=c.checkpoint('finish')
    except AssertionError:pass
    else:
     assert not r['integrityComplete'] or c.state['current']['offset']==log.stat().st_size,'finish certified uncaptured suffix'
     assert name!='finish-mutation','finish certified mutated prefix'
   elif name=='observed-growth-rotation':
    append(b'D')
    def grow_rotate():append(b'observed tail\n');log.rename(root/'host.log.1');log.write_bytes(b'new\n')
    c.source=AfterRead(c.source,grow_rotate);c.poll()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDobserved tail\nnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='rotation-create-gap':
    append(b'D');timer=None
    def rotate():
     nonlocal timer
     log.rename(root/'host.log.1');timer=threading.Timer(.002,lambda:log.write_bytes(b'new\n'));timer.start()
    c.source=AfterRead(c.source,rotate)
    try:c.poll()
    finally:
     if timer:timer.join()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='rotation-after-append':
    append(b'D');original=c._append;fired=[False]
    def append_then_rotate(*args):
     result=original(*args)
     if not fired[0]:fired[0]=True;log.rename(root/'host.log.1');log.write_bytes(b'new\n')
     return result
    c._append=append_then_rotate;c.poll()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='rotation-during-read':
    append(b'D')
    def rotate():log.rename(root/'host.log.1');log.write_bytes(b'new\n')
    c.source=AfterRead(c.source,rotate);c.poll()
    assert b''.join(p.read_bytes() for p in c.paths())==b'abc\nDnew\n'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='read-growth':
    append(b'1234567');c.source=AfterRead(c.source,lambda:append(b'D'))
    c.poll();assert c.state['current']['offset']==11
    c.poll();assert b''.join(p.read_bytes() for p in c.paths())==b'abc\n1234567D'
    assert c.checkpoint('finish')['integrityComplete']
   elif name=='checkpoint-growth':
    c.source=AfterRead(c.source,lambda:append(b'D'))
    c.checkpoint('ready');c.poll();assert c.checkpoint('finish')['integrityComplete']
   elif name in ('growth-mutation','regrowth','archive-corrupt'):
    append(b'D')
    if name=='archive-corrupt':c.paths()[0].write_bytes(b'xxxx')
    elif name=='regrowth':log.write_bytes(b'xyz\nLONG')
    else:
     with log.open('r+b') as f:f.write(b'xyz')
    try:c.poll();c.checkpoint('finish')
    except AssertionError:pass
    else:raise AssertionError('corruption certified '+name)
  finally:c.close()
 print('PASS',name)
if __name__=='__main__':
 for name in sys.argv[1:] or ['observed-growth-rotation','rotation-create-gap','rotation-after-append','rotation-during-read','finish-append','finish-error','finish-mutation','read-growth','checkpoint-growth','growth-mutation','regrowth','archive-corrupt']:case(name)
