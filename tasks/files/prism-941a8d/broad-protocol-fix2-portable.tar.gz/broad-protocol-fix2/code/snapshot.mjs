// Freeze resolver inputs under the same store lock, without changing reviewed state.mjs.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {snapshot} from './state.mjs';
const repo=process.env.PRISM_TASK3_REPO;
const {withLock}=await import(`${repo}/src/lock.js`);
const {lockPath,defsDir}=await import(`${repo}/src/paths.js`);
const {loadDefs}=await import(`${repo}/src/defs.js`);
const {readRuntime,lookPath}=await import(`${repo}/src/contexts.js`);
const saved=await snapshot();
const hash=(bytes)=>crypto.createHash('sha256').update(bytes).digest('hex');
await withLock(lockPath(),async()=>{
 assert.deepEqual(readRuntime(),saved.runtime,'runtime changed during source freeze');
 for(const [name,bytes] of Object.entries(saved.documents)){
  const file=lookPath(name==='@base'?null:name);
  assert.equal(fs.existsSync(file)?fs.readFileSync(file).toString('base64'):null,bytes,'raw source changed during freeze');
 }
 const definitions=Object.fromEntries(loadDefs(defsDir()));
 const sources={};
 for(const name of ['values.js','resolve.js','layers.js','contexts.js','cli.js'])sources[name]=hash(fs.readFileSync(`${repo}/src/${name}`));
 const [output,stateOutput]=process.argv.slice(2);assert(output&&stateOutput,'bundle and state outputs required');
 fs.writeFileSync(output,JSON.stringify({saved,definitions,resolverSources:sources},null,2)+'\n',{mode:0o600,flag:'wx'});
 fs.writeFileSync(stateOutput,JSON.stringify(saved,null,2)+'\n',{mode:0o600,flag:'wx'});
 console.log(JSON.stringify({snapshot:output,sha256:hash(fs.readFileSync(output)),readOnly:true}));
});
