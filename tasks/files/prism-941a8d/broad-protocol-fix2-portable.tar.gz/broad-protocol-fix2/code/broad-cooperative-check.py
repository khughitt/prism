"""Cooperative checkpoint interleavings use real files and one collector owner."""
import tempfile,hashlib,os
from pathlib import Path
import logs

def case(kind):
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);log=root/'host.log';log.write_bytes(b'');manifest=root/'manifest.json';logs.start(log,manifest);c=logs.Capture(manifest)
  def append(raw):
   with log.open('ab',buffering=0) as f:f.write(raw)
  def rotate(raw):log.replace(root/'host.log.1');log.write_bytes(raw);c.poll()
  try:
   append(b'first\n');c.poll();rotate(b'second\n');rotate(b'current\n');called=[];first=c.paths()[0]
   def service(force):
    called.append(force)
    if len(called)==1:
     if kind=='corrupt-old':first.write_bytes(b'broken')
     elif kind=='rewrite-old':first.write_bytes(first.read_bytes())
     elif kind=='new-generation':rotate(b'new generation\n')
     elif kind=='corrupt-new':
      rotate(b'new generation\n');c.paths()[-2].write_bytes(b'broken')
     elif kind=='source-mutation':log.write_bytes(b'WRONG!!\n')
     elif kind=='growth':append(b'tail\n')
     elif kind=='stop':raise RuntimeError('stop')
    if force:
     c.poll()
     if kind=='late-finish-tail':append(b'late tail\n')
     elif kind=='late-finish-error':append(b'exceeded its CPU budget\n')
     elif kind=='late-finish-mutation':log.write_bytes(b'MUTATED\n')
   try:result=c.checkpoint('finish',service)
   except (AssertionError,RuntimeError):
    assert kind in ('corrupt-old','rewrite-old','corrupt-new','source-mutation','stop','late-finish-tail','late-finish-error','late-finish-mutation'),kind
    assert not c.integrity_complete
   else:
    assert kind in ('new-generation','growth'),kind
    assert result['integrityComplete'] and called[-1] is True
    assert c.state['current']['offset']==log.stat().st_size
    assert result['terminalCutoff']['segmentSha256']==[hashlib.sha256(p.read_bytes()).hexdigest() for p in c.paths()]
  finally:c.close()
 print('PASS cooperative',kind)
for kind in ('corrupt-old','rewrite-old','new-generation','corrupt-new','source-mutation','growth','stop','late-finish-tail','late-finish-error','late-finish-mutation'):case(kind)
