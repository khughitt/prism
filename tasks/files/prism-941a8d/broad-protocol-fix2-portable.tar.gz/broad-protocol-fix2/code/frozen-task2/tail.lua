local diagnosticPlainRender=render
render=function(...)
  if diagnosticPair and not diagnosticInternal then diagnosticInterfere('render-input-callback') end
  local started=os.clock()
  local returned=table.pack(diagnosticPlainRender(...))
  local finished=os.clock()
  diagnosticRendered=state.model~=nil and not state.help
  diagnosticEvent(diagnosticClass,(finished-started)*1000,{scope='render',rendered=diagnosticRendered,startTimestamp=started,endTimestamp=finished})
  return table.unpack(returned,1,returned.n)
end
local diagnosticPlainDescribed=described
described=function(result)
  if not diagnosticCold then diagnosticInterfere('describe-result',false) end
  return diagnosticCallback(diagnosticCold and 'coldSetup' or 'describeResult',function()
    local previousError=state.errorText
    diagnosticPlainDescribed(result)
    if not diagnosticCold and (diagnosticAccepted or diagnosticOutcome=='rejected' or state.errorText~=previousError) then
      diagnosticInterfere('describe-'..diagnosticOutcome)
    end
    if diagnosticAccepted and not diagnosticCold then diagnosticClass='changedDescribe' end
  end)
end
local diagnosticPlainProfile=pickProfile
pickProfile=function(...)
  local before=state.enqueued
  local returned=table.pack(diagnosticCallback('profileAction',diagnosticPlainProfile,...))
  if state.enqueued>before then diagnosticRequest('profile',nil,{profile=state.model.active.profile}) end
  return table.unpack(returned,1,returned.n)
end
local diagnosticPlainUnset=unsetParam
unsetParam=function(key,...)
  diagnosticRequest('restore',nil,{key=key})
  return diagnosticPlainUnset(key,...)
end
local diagnosticPlainReset=resetAction
resetAction=function(...)
  local action=diagnosticPlainReset(...)
  return function(...)
    local op=diagnosticRequest('restore')
    local before=state.enqueued
    local returned=table.pack(action(...))
    if before==state.enqueued then op.valid=false end
    return table.unpack(returned,1,returned.n)
  end
end
local diagnosticPlainFinishWrite=finishWrite
finishWrite=function(...) diagnosticInterfere('writeCompletion'); return diagnosticCallback('writeCompletion',diagnosticPlainFinishWrite,...) end
local diagnosticPlainTick,diagnosticPlainUpdate=onFrameTick,update
local diagnosticPlainOpen,diagnosticPlainClose,diagnosticPlainKey=onOpen,onClose,onKey
onOpen=function(...) diagnosticInterfere('open'); return diagnosticCallback('open',diagnosticPlainOpen,...) end
onClose=function(...)
  -- Closing disables host ticks. Flush completed evidence outside target timing.
  while #diagnosticBuffer>0 do diagnosticFlush(true) end
  diagnosticSnapshot('handoff');local handoff=diagnosticRecordId-1
  diagnosticInterfere('close')
  if diagnosticOperation then diagnosticOperation.valid=false end
  diagnosticDeferred=nil;diagnosticProfilePending=false
  local returned=table.pack(diagnosticCallback('close',diagnosticPlainClose,...))
  local closedCallback=diagnosticCallbackId
  while #diagnosticBuffer>0 do diagnosticFlush(true) end
  diagnosticDirect('handoffClosed',0,{scope='metadata',handoffRecordId=handoff,
    closeCallbackId=closedCallback,closed=not state.open,bufferEmpty=#diagnosticBuffer==0})
  return table.unpack(returned,1,returned.n)
end
onKey=function(...) diagnosticInterfere('key'); return diagnosticCallback('input',diagnosticPlainKey,...) end
update=function(...)
  return diagnosticCallback('secondTick',diagnosticPlainUpdate,...)
end
local function diagnosticReady()
  return state.open and state.model~=nil and state.shownStdout~=nil and not state.help and state.errorText==nil
    and state.drag==nil and state.queue.inFlight==nil and #state.queue.pending==0 and not describeRunning
    and not state.refreshPending and not state.refreshAfterDrag and not state.describeInvalidated
end
local function diagnosticPairFailure(reason)
  if diagnosticPair then
    diagnosticPair.interference=reason
    diagnosticEvent('pairInvalid',0,{scope='metadata',reason=reason})
  end
end
local function diagnosticFinishPair()
  if diagnosticPair and diagnosticPair.frameDone and not diagnosticPair.pending then
    local finished=os.clock()
    diagnosticEvent('pairInterval',(finished-diagnosticPair.started)*1000,{scope='interval',control=diagnosticPair.control,startTimestamp=diagnosticPair.started,endTimestamp=finished})
    if not diagnosticPair.interference and diagnosticOperation then diagnosticCompleted[diagnosticOperation.id]=true end
    diagnosticEvent('pairDone',0,{scope='metadata',valid=not diagnosticPair.interference,
      control=diagnosticPair.control,completionState=diagnosticPair.completionState or 'done'})
    diagnosticPair=nil
    if diagnosticSequence then diagnosticSequence.launchIndex=diagnosticSequence.launchIndex+1 end
    syncFrameTick()
  end
end
local function beginLaunchPair(id,control)
  if diagnosticPair or not diagnosticReady() then
    diagnosticPairFailure('overlap-or-unsettled')
    diagnosticEvent('pairRefused',0,{scope='metadata',reason='overlap-or-unsettled'})
    return false
  end
  diagnosticPair={id=id,control=control,pending=not control,frameDone=false,started=os.clock(),model=state.model,enqueued=state.enqueued,interference=false}
  diagnosticInternal=true
  if not control then
    local started=os.clock()
    local ok=run({'prism','describe','--json'},function(result)
      return diagnosticCallback('comparisonCompletion',function()
        local p=diagnosticPair
        if not p then diagnosticEvent('orphanCompletion',0,{scope='metadata'}); return end
        p.pending=false
        if type(result)~='table' or type(result.exitCode)~='number' or result.exitCode~=0
          or result.timedOut~=false or result.stdoutTruncated~=false or result.stderrTruncated~=false
          or type(result.stdout)~='string' or type(result.stderr)~='string' then diagnosticPairFailure('completion-failure') end
        local metadata={scope='metadata',control=false,resultType=type(result)}
        if type(result)=='table' then
          for _,key in ipairs({'exitCode','timedOut','stdoutTruncated','stderrTruncated'}) do metadata[key]=result[key] end
        end
        diagnosticEvent('comparisonCompletionResult',0,metadata)
        diagnosticFinishPair()
      end)
    end)
    local finished=os.clock()
    diagnosticEvent('launchHelper',(finished-started)*1000,{scope='launchHelper',control=false,startTimestamp=started,endTimestamp=finished})
    if not ok then diagnosticPairFailure('launch-failure'); diagnosticPair.pending=false; diagnosticPair.frameDone=true; diagnosticFinishPair(); diagnosticInternal=false; return false end
  end
  diagnosticClass='pairImmediate'
  render()
  diagnosticEvent('pairImmediateState',0,{scope='metadata',control=control})
  diagnosticInternal=false
  panel.setNeedsFrameTick(true)
  return true
end
diagnosticPlanOperations=function(colds,launches,operations)
  diagnosticRequested={};diagnosticCompleted={}
  for i=1,colds do diagnosticRequested[#diagnosticRequested+1]=diagnosticCardId..':cold:'..i end
  for i=1,launches do
    diagnosticRequested[#diagnosticRequested+1]=diagnosticCardId..':launch:'..i
    diagnosticRequested[#diagnosticRequested+1]=diagnosticCardId..':control:'..i
  end
  for _,op in ipairs(operations) do diagnosticRequested[#diagnosticRequested+1]=op.id end
end
local function diagnosticFields(value,allowed)
  if type(value)~='table' then return false end
  for key in pairs(value) do if not allowed[key] then return false end end
  return true
end
local function diagnosticArray(value)
  if type(value)~='table' then return false end
  for k in pairs(value) do if type(k)~='number' or k%1~=0 or k<1 or k>#value then return false end end
  return true
end
local function diagnosticManifest(m)
  if not diagnosticFields(m,{schema=true,approved=true,runId=true,activationNonce=true,cardId=true,replacementFor=true,coldPairs=true,launchPairs=true,operations=true})
    or m.schema~=2 or m.approved~=true or m.runId~=diagnosticIdentity.runId or m.activationNonce~=diagnosticIdentity.activationNonce
    or type(m.cardId)~='string' or m.cardId=='' or m.cardId==diagnosticCardId
    or (m.coldPairs~=0 and m.coldPairs~=1) or (m.launchPairs~=0 and m.launchPairs~=1)
    or not diagnosticArray(m.replacementFor) or #m.replacementFor==0 or not diagnosticArray(m.operations) or #m.operations>4
    or m.coldPairs+m.launchPairs+#m.operations==0 then return false end
  local known={};for _,id in ipairs(diagnosticRequested) do known[id]=true end
  local seen={};for _,id in ipairs(m.replacementFor) do if type(id)~='string' or not known[id] or seen[id] then return false end;seen[id]=true end
  for i=1,m.coldPairs do seen[m.cardId..':cold:'..i]=true end
  for i=1,m.launchPairs do seen[m.cardId..':launch:'..i]=true;seen[m.cardId..':control:'..i]=true end
  local release,restore,profiles=0,0,0;local releaseKey,restoreKey;local profileNames={}
  for _,op in ipairs(m.operations) do
    if not diagnosticFields(op,{id=true,kind=true,key=true,profile=true}) or type(op.id)~='string' or op.id=='' or seen[op.id] or known[op.id] then return false end
    seen[op.id]=true
    if op.kind=='release' or op.kind=='restore' then
      if type(op.key)~='string' or not state.structure.byKey[op.key] or op.profile~=nil then return false end
      if op.kind=='release' then release=release+1;releaseKey=op.key else restore=restore+1;restoreKey=op.key end
    elseif op.kind=='profile' then
      if type(op.profile)~='string' or op.key~=nil or profileNames[op.profile] then return false end
      local found=false;for _,name in ipairs(state.model.profiles) do if name==op.profile then found=true end end
      if not found then return false end
      profileNames[op.profile]=true;profiles=profiles+1
    else return false end
  end
  return release<=1 and restore<=1 and release==restore and (release==0 or releaseKey==restoreKey) and (profiles==0 or profiles==2)
end
diagnosticRecovery=function()
  if diagnosticRecoveryAccepted or not diagnosticCardStarted or not diagnosticQuiescent() then
    diagnosticEvent('recoveryRejected',0,{scope='metadata',reason='exhausted-or-unsettled'});return false
  end
  local ok,text=pcall(noctalia.readFile,diagnosticIdentity.recoveryManifest)
  local parsed,m=pcall(noctalia.json.decode,text)
  if not ok or type(text)~='string' or not parsed or not diagnosticManifest(m) then
    diagnosticRecoveryAvailable=true
    diagnosticEvent('recoveryRejected',0,{scope='metadata',reason='missing-malformed-or-unauthorized'});return false
  end
  for _,card in ipairs(state.structure.rack.cards) do state.expanded[card.device]=true end
  diagnosticRecoveryAccepted=true;diagnosticRecoveryAvailable=false;diagnosticCardReported=false
  diagnosticReplacementId=m.cardId;diagnosticReplacementFor=m.replacementFor;diagnosticCardId=m.cardId
  diagnosticPlanOperations(m.coldPairs,m.launchPairs,m.operations)
  diagnosticRecoveryOperations=m.operations;diagnosticRecoveryOperationIndex=1
  diagnosticReadyRequested=true
  diagnosticSequence={launchPairs=m.launchPairs,coldRemaining=m.coldPairs,phase='setup',launchIndex=1,stdout=state.shownStdout,model=state.model,enqueued=state.enqueued}
  diagnosticClass='recoveryAdministration';render();panel.setNeedsFrameTick(true)
  diagnosticEvent('recoveryAccepted',0,{scope='metadata',requestedOperationIds=diagnosticRequested})
  return true
end
local function diagnosticStart()
  if diagnosticHidden then return end
  return diagnosticCallback('diagnosticStart',function()
    assert(diagnosticReady(),'Diagnostics require a settled panel')
    for _,card in ipairs(state.structure.rack.cards) do state.expanded[card.device]=true end
    diagnosticCardStarted=true
    diagnosticPlanOperations(diagnosticIdentity.coldPairs,diagnosticIdentity.launchPairs,{})
    diagnosticHidden=true
    diagnosticReadyRequested=true
    diagnosticSequence={launchPairs=diagnosticIdentity.launchPairs,coldRemaining=diagnosticIdentity.coldPairs,phase='setup',launchIndex=1,stdout=state.shownStdout,model=state.model,enqueued=state.enqueued}
    panel.setNeedsFrameTick(true)
  end)
end
local function diagnosticReference()
  assert(diagnosticDepth==0,'reference outside target timing')
  local pending=diagnosticReferencePending;diagnosticReferencePending=pending and pending.next or nil
  if not pending then return end
  local started=os.clock()
  local valid=pending.op.valid and pending.generation==diagnosticAcceptGeneration and pending.model==state.model
    and pending.enqueued==state.enqueued and state.open and diagnosticExpanded()
  local values,held={},{}
  if valid then
    for _,param in ipairs(state.model.params) do
      values[param.key]=param.value
      if Presentation.holds(param,'scratch') then held[#held+1]=param.key end
    end
    table.sort(held)
  end
  local reason=false;if not valid then reason='superseded' end
  local finished=os.clock()
  diagnosticDirect('acceptedReference',(finished-started)*1000,{scope='observer',observer=true,
    operationId=pending.op.id,acceptGeneration=pending.generation,valid=valid,reason=reason,
    values=values,heldScratchKeys=held,acceptedProfile=valid and (state.model.active.profile or false) or false,
    acceptedWallpaper=valid and (state.model.active.wallpaper or false) or false,
    startTimestamp=started,endTimestamp=finished})
  if valid then diagnosticLatestReference=diagnosticRecordId end
  if valid and pending.op.callbackIdTarget and pending.op.renderIdTarget then
    diagnosticCompleted[pending.op.id]=true
    diagnosticDirect('operationDone',0,{scope='metadata',operationId=pending.op.id,operationKind=pending.op.kind,
      acceptGeneration=pending.generation,referenceId=diagnosticRecordId,callbackIdTarget=pending.op.callbackIdTarget,
      renderIdTarget=pending.op.renderIdTarget,targetClass=pending.op.class})
  end
end
onFrameTick=function(deltaMs)
  local ordinaryTickDue=state.drag~=nil or state.renderPending
  local sequenceDue=diagnosticSequence~=nil and diagnosticPair==nil
  local pairRenderDue=diagnosticPair~=nil and not diagnosticPair.frameDone
  local coldRenderDue=diagnosticSequence~=nil and diagnosticSequence.phase=='render' and diagnosticSequence.coldRemaining>0
  if diagnosticReferencePending and not ordinaryTickDue and not sequenceDue and not pairRenderDue then
    diagnosticReference();syncFrameTick();return
  end
  if diagnosticReadyRequested and ordinaryTickDue then
    local class=state.drag~=nil and state.drag.dirty and 'dragTick' or (state.renderPending and diagnosticDeferred or 'idle')
    diagnosticDeferred=nil
    return diagnosticCallback(class or 'idle',diagnosticPlainTick,deltaMs)
  end
  if diagnosticReadyRequested and not (ordinaryTickDue or pairRenderDue or coldRenderDue) then
    diagnosticReadyRequested=false
    if #diagnosticBuffer>0 then diagnosticFlush() end
    if state.model and diagnosticExpanded() then
      local saved=diagnosticReferencePending
      diagnosticReferencePending={op={id=diagnosticCardId..':reference',valid=true},generation=diagnosticAcceptGeneration,model=state.model,enqueued=state.enqueued}
      diagnosticReference();diagnosticReferencePending=saved
    end
    diagnosticSnapshot('ready')
    syncFrameTick()
    return
  end
  if #diagnosticBuffer>0 and not (ordinaryTickDue or sequenceDue or pairRenderDue) then diagnosticFlush(); syncFrameTick(); return end
  if diagnosticPair and not diagnosticPair.frameDone then
    return diagnosticCallback('pairFrame',function()
      diagnosticInternal=true
      diagnosticPair.completionState=diagnosticPair.pending and 'pending' or 'done'
      if diagnosticPair.model~=state.model or diagnosticPair.enqueued~=state.enqueued then diagnosticPairFailure('input-reference-change') end
      if diagnosticPair.interference or ordinaryTickDue then
        diagnosticPairFailure(diagnosticPair.interference or 'ordinary-frame-work')
      else render() end
      diagnosticEvent('pairFrameState',0,{scope='metadata',control=diagnosticPair.control,completionState=diagnosticPair.completionState})
      diagnosticPair.frameDone=true
      diagnosticInternal=false
      diagnosticFinishPair()
      diagnosticPlainTick(deltaMs)
    end)
  end
  if diagnosticPair and not ordinaryTickDue then syncFrameTick(); return end
  if diagnosticSequence and diagnosticPair==nil then
    local sequence=diagnosticSequence
    if sequence.failure or sequence.model~=state.model or sequence.enqueued~=state.enqueued or sequence.stdout~=state.shownStdout or state.errorText~=nil or not state.open or state.help then
      return diagnosticCallback('sequenceFailure',function() diagnosticEvent('sequenceFailureReason',0,{scope='metadata',reason=sequence.failure or 'input-change'}); diagnosticSequence=nil; if ordinaryTickDue then diagnosticPlainTick(deltaMs) end; syncFrameTick() end)
    end
    if not diagnosticReady() then
      return diagnosticCallback('sequenceWait',function()
        diagnosticEvent('sequenceWaitReason',0,{scope='metadata',describePending=describeRunning,
          queueBusy=state.queue.inFlight~=nil or #state.queue.pending>0})
        if ordinaryTickDue then diagnosticPlainTick(deltaMs) end
        syncFrameTick()
      end)
    end
    if sequence.coldRemaining>0 then
      if sequence.phase=='setup' then
        return diagnosticCallback('coldSetup',function()
          diagnosticInternal=true; diagnosticCold=true
          diagnosticRequest('cold',diagnosticCardId..':cold:'..tostring(sequence.coldIndex or 1))
          sequence.coldStarted=os.clock()
          local saved=state.shownStdout
          Retain.clear(memo); state.shownStdout=nil
          described({timedOut=false,exitCode=0,stdout=saved,stderr='',stdoutTruncated=false,stderrTruncated=false})
          sequence.model=state.model; sequence.phase='render'
          diagnosticCold=false; diagnosticInternal=false
        end)
      end
      return diagnosticCallback('coldRender',function()
        diagnosticInternal=true; diagnosticPlainTick(deltaMs); diagnosticInternal=false
        local finished=os.clock()
        diagnosticEvent('coldPairInterval',(finished-sequence.coldStarted)*1000,{scope='interval',startTimestamp=sequence.coldStarted,endTimestamp=finished})
        if diagnosticExpanded() and not sequence.failure and diagnosticOperation then diagnosticCompleted[diagnosticOperation.id]=true end
        diagnosticDeferred=nil
        sequence.coldRemaining=sequence.coldRemaining-1;sequence.coldIndex=(sequence.coldIndex or 1)+1; sequence.phase='setup'; syncFrameTick()
      end)
    end
    if sequence.launchPairs>0 and sequence.launchIndex<=sequence.launchPairs*2 then
      return diagnosticCallback('pairImmediate',function()
        local index=sequence.launchIndex
        local control=(index%2==0)==(diagnosticIdentity.variant=='baseline')
        diagnosticRequest(control and 'control' or 'launch',diagnosticCardId..(control and ':control:' or ':launch:')..math.ceil(index/2))
        beginLaunchPair('pair-'..math.ceil(index/2)..(control and '-control' or '-launch'),control)
      end)
    end
    return diagnosticCallback('sequenceDone',function() diagnosticSequence=nil; if ordinaryTickDue then diagnosticPlainTick(deltaMs) end; syncFrameTick() end)
  end
  local class=state.drag~=nil and state.drag.dirty and 'dragTick' or (state.renderPending and diagnosticDeferred or 'idle')
  diagnosticDeferred=nil
  return diagnosticCallback(class or 'idle',diagnosticPlainTick,deltaMs)
end

diagnosticEvent('activation',0,{scope='activation',initialModelEmpty=state.model==nil,initialStructureEmpty=state.structure==nil,initialMemoEmpty=next(memo.entries)==nil,initialEnqueued=state.enqueued,initialDragEmpty=state.drag==nil,initialRenderPending=state.renderPending,initialPairEmpty=diagnosticPair==nil,initialQueueEmpty=state.queue.inFlight==nil and #state.queue.pending==0})
