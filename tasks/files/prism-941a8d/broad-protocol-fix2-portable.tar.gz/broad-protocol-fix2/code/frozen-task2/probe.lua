local diagnosticIdentity = IDENTITY
local diagnosticBuffer, diagnosticCallbackId, diagnosticDepth = {}, 0, 0
local diagnosticRecordId=0
local diagnosticClockOrigin=diagnosticIdentity.clockOrigin
local diagnosticClass, diagnosticRendered, diagnosticAccepted = 'idle', false, false
local diagnosticOutcome, diagnosticAcceptGeneration, diagnosticProfileGeneration = 'none', 0, 0
local diagnosticProfilePending, diagnosticDeferred, diagnosticCold = false, false, false
local diagnosticHidden, diagnosticSequence, diagnosticPair = false, nil, nil
local diagnosticInternal = false
local diagnosticReadyRequested=false
local diagnosticRecoveryAvailable,diagnosticRecoveryAccepted=false,false
local diagnosticRecovery,diagnosticPlanOperations
local diagnosticRecoveryShown=false
local diagnosticRecoveryOperations,diagnosticRecoveryOperationIndex=nil,1
local diagnosticCardId=diagnosticIdentity.cardId
local diagnosticOperationCounter, diagnosticOperation, diagnosticReferencePending = 0, nil, nil
local diagnosticLatestReference=false
local diagnosticCompleted={}
local diagnosticRequested, diagnosticCardStarted, diagnosticCardReported = {}, false, false
local diagnosticReplacementId, diagnosticReplacementFor = false, {}
local function diagnosticExpanded()
  if not state.structure then return false end
  for _,card in ipairs(state.structure.rack.cards) do if state.expanded[card.device]~=true then return false end end
  return true
end
local function diagnosticEvent(class, elapsed, extra)
  diagnosticRecordId=diagnosticRecordId+1
  local event = {schema=2, recordId=diagnosticRecordId, callbackId=diagnosticDepth>0 and diagnosticCallbackId or 0,
    class=class, elapsedMs=elapsed, rendered=diagnosticRendered, accepted=diagnosticAccepted,
    pairId=diagnosticPair and diagnosticPair.id or false, control=diagnosticPair~=nil and diagnosticPair.control or false, pending=diagnosticPair and diagnosticPair.pending or false,
    interference=diagnosticPair and diagnosticPair.interference or false, timestamp=os.clock(),
    phase=class, complete=true, diagnosticsHidden=diagnosticHidden and not diagnosticRecoveryAvailable, acceptGeneration=diagnosticAcceptGeneration,
    profileGeneration=diagnosticProfileGeneration, outcome=diagnosticOutcome,
    stage=diagnosticIdentity.stage,cardId=diagnosticCardId,runId=diagnosticIdentity.runId,
    operationId=diagnosticOperation and diagnosticOperation.id or false,
    replacementId=diagnosticReplacementId,replacementFor=diagnosticReplacementFor,
    targetEligible=state.open and diagnosticExpanded() and diagnosticHidden and not diagnosticRecoveryAvailable and not state.help}
  if extra then for k,v in pairs(extra) do event[k]=v end end
  if event.scope=='render' and diagnosticOperation and (class=='deferredRender' or class=='profileRender') and event.targetEligible then diagnosticOperation.renderIdTarget=event.recordId end
  diagnosticBuffer[#diagnosticBuffer+1]=event
end
local function diagnosticInterfere(reason, inputChanged)
  if inputChanged~=false and reason~='describe-result' then diagnosticRecoveryAvailable=false;diagnosticRecoveryShown=false end
  if diagnosticPair then
    diagnosticPair.interference=reason
    diagnosticEvent('pairInterference',0,{scope='metadata',reason=reason})
  end
  if diagnosticSequence and not diagnosticInternal and inputChanged~=false then diagnosticSequence.failure=reason end
end
local function diagnosticCallback(class, fn, ...)
  if diagnosticDepth>0 then return fn(...) end
  diagnosticCallbackId=diagnosticCallbackId+1
  diagnosticDepth=1; diagnosticClass=class; diagnosticRendered=false; diagnosticAccepted=false; diagnosticOutcome='none'
  local started=os.clock()
  local returned=table.pack(fn(...))
  local finished=os.clock()
  diagnosticEvent(diagnosticClass,(finished-started)*1000,{scope='callback',startTimestamp=started,endTimestamp=finished})
  if diagnosticOperation and diagnosticRendered and (class=='deferredRender' or class=='profileRender') and state.open and diagnosticExpanded() then
    diagnosticOperation.callbackIdTarget=diagnosticCallbackId
    diagnosticOperation.class=class
  end
  diagnosticDepth=0
  if state.open then panel.setNeedsFrameTick(true) end
  return table.unpack(returned,1,returned.n)
end
local function diagnosticRequest(kind,explicitId,details)
  local approved=true
  if diagnosticRecoveryOperations and (kind=='release' or kind=='restore' or kind=='profile') then
    local expected=diagnosticRecoveryOperations[diagnosticRecoveryOperationIndex]
    approved=expected~=nil and expected.kind==kind and details~=nil
      and (kind=='profile' and expected.profile==details.profile or kind~='profile' and expected.key==details.key)
    if approved then explicitId=expected.id;diagnosticRecoveryOperationIndex=diagnosticRecoveryOperationIndex+1 end
  end
  diagnosticOperationCounter=diagnosticOperationCounter+1
  local op={id=explicitId or diagnosticCardId..':action:'..tostring(diagnosticOperationCounter),kind=kind,valid=approved}
  diagnosticOperation=op
  local known=false;for _,id in ipairs(diagnosticRequested) do if id==op.id then known=true end end
  if not known then diagnosticRequested[#diagnosticRequested+1]=op.id end
  diagnosticCardReported=false
  diagnosticEvent('operationRequested',0,{scope='metadata',operationKind=kind,valid=approved,key=details and details.key or false,profile=details and details.profile or false})
  return op
end
local function diagnosticInput(name, fn)
  if fn==nil then return nil end
  return function(...)
    diagnosticInterfere(name)
    local releasedKey=name=='onDragEnd' and state.drag and state.drag.key or nil
    if releasedKey then diagnosticRequest('release',nil,{key=releasedKey}) end
    local returned=table.pack(diagnosticCallback(name=='onDragEnd' and 'release' or 'input',fn,...))
    if releasedKey then
      assert(diagnosticDepth==0,'intent must follow release timing')
      local started=os.clock()
      local value=state.structure.byKey[releasedKey].value
      local valueText=tostring(value)
      local finished=os.clock()
      diagnosticEvent('operationIntent',(finished-started)*1000,{scope='observer',observer=true,
        key=releasedKey,canonicalValue=value,valueText=valueText,releaseCallbackId=diagnosticCallbackId,
        startTimestamp=started,endTimestamp=finished})
    end
    return table.unpack(returned,1,returned.n)
  end
end
local function diagnosticExpand(event)
  event.clockOrigin=diagnosticClockOrigin; event.variant=diagnosticIdentity.variant
  event.sourceCommit=diagnosticIdentity.sourceCommit; event.sourceHash=diagnosticIdentity.sourceHash
  event.activationNonce=diagnosticIdentity.activationNonce; event.block=diagnosticIdentity.block
  event.sourceSha256=diagnosticIdentity.sourceSha256;event.environment=diagnosticIdentity.environment
  return event
end
local function diagnosticDirect(class,elapsed,extra)
  diagnosticEvent(class,elapsed,extra)
  local event=diagnosticBuffer[#diagnosticBuffer];diagnosticBuffer[#diagnosticBuffer]=nil
  event.callbackId=diagnosticCallbackId
  event.rendered=false;event.accepted=false;event.pairId=false;event.control=false;event.pending=false;event.interference=false
  noctalia.log('prism-budget '..noctalia.json.encode(diagnosticExpand(event)))
end
local function diagnosticQuiescent()
  return state.open and state.model~=nil and state.structure~=nil and not state.help and state.errorText==nil
    and not state.selectionPending and state.drag==nil and state.queue.inFlight==nil and #state.queue.pending==0
    and not describeRunning and not state.renderPending and not state.refreshPending and not state.refreshAfterDrag
    and not state.describeInvalidated and diagnosticSequence==nil and diagnosticPair==nil
    and diagnosticReferencePending==nil and not diagnosticReadyRequested and #diagnosticBuffer==0
end
local function diagnosticSnapshot(class)
  assert(diagnosticDepth==0,'snapshot must be outside target timing')
  local started=os.clock()
  diagnosticCallbackId=diagnosticCallbackId+1
  local expandedIds,rackIds={},{}
  for id,expanded in pairs(state.expanded) do if expanded==true then expandedIds[#expandedIds+1]=id end end
  if state.structure~=nil then for _,card in ipairs(state.structure.rack.cards) do rackIds[#rackIds+1]=card.device end end
  table.sort(expandedIds);table.sort(rackIds)
  local allExpanded=state.structure~=nil and #expandedIds==#rackIds
  for _,id in ipairs(rackIds) do if state.expanded[id]~=true then allExpanded=false end end
  local queueIdle=state.queue.inFlight==nil and #state.queue.pending==0
  local modelReady=state.model~=nil and state.structure~=nil
  local settled=state.open and modelReady and queueIdle and not describeRunning and state.drag==nil
    and not state.renderPending and not state.refreshPending and not state.refreshAfterDrag and not state.describeInvalidated
    and state.errorText==nil and not state.selectionPending and not state.help
  local handoffReference=false
  if class=='handoff' and modelReady then
    local values,held={},{}
    for _,param in ipairs(state.model.params) do
      values[param.key]=param.value
      if Presentation.holds(param,'scratch') then held[#held+1]=param.key end
    end
    table.sort(held)
    handoffReference={acceptedProfile=state.model.active.profile or false,
      acceptedWallpaper=state.model.active.wallpaper or false,values=values,heldScratchKeys=held}
  end
  local bufferCount=#diagnosticBuffer
  local finished=os.clock()
  diagnosticDirect(class,(finished-started)*1000,{scope='metadata',observer=true,startTimestamp=started,endTimestamp=finished,
    queueIdle=queueIdle,queuePendingCount=#state.queue.pending,queueInFlight=state.queue.inFlight~=nil,
    describeRunning=describeRunning,dragEmpty=state.drag==nil,renderPending=state.renderPending,
    refreshPending=state.refreshPending,refreshAfterDrag=state.refreshAfterDrag,describeInvalidated=state.describeInvalidated,
    selectionPending=state.selectionPending,help=state.help,errorText=state.errorText or false,errorSticky=state.errorSticky,open=state.open,modelReady=modelReady,
    pairEmpty=diagnosticPair==nil,pairPending=diagnosticPair~=nil and diagnosticPair.pending or false,
    pairFrameDone=diagnosticPair~=nil and diagnosticPair.frameDone or false,
    comparisonCallbacksComplete=diagnosticPair==nil or not diagnosticPair.pending,
    sequenceComplete=diagnosticSequence==nil,sequencePhase=diagnosticSequence~=nil and diagnosticSequence.phase or false,
    bufferEmpty=bufferCount==0,bufferCount=bufferCount,expandedIds=expandedIds,rackIds=rackIds,allRackExpanded=allExpanded,
    currentProfile=modelReady and (state.model.active.profile or false) or false,
    handoffReference=handoffReference,referenceId=diagnosticLatestReference,requestedOperationIds=diagnosticRequested,readyEligible=class=='ready' and settled and allExpanded and diagnosticPair==nil and diagnosticSequence~=nil and diagnosticSequence.phase=='setup' and not diagnosticSequence.failure,
    physicalDrain=(class=='drain' or class=='handoff') and diagnosticQuiescent(),eligibleDrain=(class=='drain' or class=='handoff') and settled and allExpanded and diagnosticPair==nil and diagnosticSequence==nil and bufferCount==0})
  diagnosticDirect('observerSnapshot',(finished-started)*1000,{scope='observer',snapshotClass=class,startTimestamp=started,endTimestamp=finished})
end
local function diagnosticAllComplete()
  for _,id in ipairs(diagnosticRequested) do if not diagnosticCompleted[id] then return false end end
  return true
end
local function diagnosticFlush(recordsOnly)
  local records=diagnosticBuffer; diagnosticBuffer={}
  local count=math.min(#records,16)
  local started=os.clock()
  for i=1,count do noctalia.log('prism-budget '..noctalia.json.encode(diagnosticExpand(records[i]))) end
  local finished=os.clock()
  local elapsed=(finished-started)*1000
  diagnosticCallbackId=diagnosticCallbackId+1; diagnosticDepth=1
  diagnosticEvent('observerFlush',elapsed,{scope='observer',startTimestamp=started,endTimestamp=finished,recordCount=count,remainingRecords=#records-count,bufferEmpty=#records==count})
  local observer=diagnosticBuffer[1]; diagnosticBuffer={}; diagnosticDepth=0
  noctalia.log('prism-budget '..noctalia.json.encode(diagnosticExpand(observer)))
  for i=count+1,#records do diagnosticBuffer[#diagnosticBuffer+1]=records[i] end
  if #diagnosticBuffer==0 and not recordsOnly then
    local quiescent=diagnosticQuiescent()
    diagnosticSnapshot('drain')
    local drain=diagnosticRecordId-1
    if diagnosticCardStarted and quiescent then
      if not diagnosticCardReported and #diagnosticRequested>0 and diagnosticExpanded() and diagnosticAllComplete() then
        diagnosticCardReported=true
        diagnosticDirect('cardSettled',0,{scope='metadata',requestedOperationIds=diagnosticRequested,eligibleDrain=true,drainRecordId=drain,bufferEmpty=true})
        diagnosticSnapshot('drain')
      end
      if diagnosticIdentity.recoveryManifest~=nil and not diagnosticRecoveryAccepted then
        diagnosticRecoveryAvailable=true
        if not diagnosticRecoveryShown then
          diagnosticRecoveryShown=true;diagnosticClass='recoveryAdministration';render()
        end
      end
    end
  end
end
