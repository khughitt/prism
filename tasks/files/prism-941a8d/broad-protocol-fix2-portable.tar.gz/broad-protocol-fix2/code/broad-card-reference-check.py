"""Original/recovery handoff mutations remain in memory; old raw stays immutable."""
import copy,os,sys,importlib.util
from pathlib import Path
from unittest.mock import patch
code=Path(os.environ.get('BROAD_CODE',Path(__file__).parent));sys.path.insert(0,str(code));s=importlib.util.spec_from_file_location('controller',code/'controller.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
root=Path(sys.argv[1]);passed=0
for path in sorted(root.glob('handoff-release-recovery-*')):
 if 'short-' in path.name:continue
 normal,context=c.inspect_run(path);assert normal['collectionComplete'],path
 identity=c.load(path/'session.json')['identity'];rows=normal['events'];handoffs=[r for r in rows if r['class']=='handoff' and r['eligibleDrain']];assert len(handoffs)==2
 original_read=c.read_capture
 for which,handoff in enumerate(handoffs):
  for field in ('values','acceptedProfile','acceptedWallpaper','heldScratchKeys'):
   bad=copy.deepcopy(rows);ref=next(e for e in bad if e['recordId']==handoff['recordId'])['handoffReference']
   if field=='values':key=next(k for k,v in ref[field].items() if type(v) in (int,float));ref[field][key]+=.03
   elif field=='heldScratchKeys':ref[field]=sorted(set(ref[field])^{next(iter(ref['values']))})
   else:ref[field]='unexpected-current-reference'
   def altered(*args,**kwargs):
    _,audit=original_read(*args,**kwargs);return bad,audit
   with patch.object(c,'read_capture',altered):actual,_=c.inspect_run(path)
   assert not actual['collectionComplete'],f'{identity["variant"]} card{which} {field}: changed handoff certified by controller'
   actual=c.analyze.normalize(bad,[identity],context['cards'],context['authorizations'])
   assert not actual['collectionComplete'],f'{identity["variant"]} card{which} {field}: changed handoff certified by parser'
   passed+=1
 print('PASS per-card references',identity['variant'])
for path in sorted(root.glob('*short-initial-P*')):
 normal,_=c.inspect_run(path);assert not normal['collectionComplete'];passed+=1
print('PASS',passed,'per-card mismatch/short-original checks')
