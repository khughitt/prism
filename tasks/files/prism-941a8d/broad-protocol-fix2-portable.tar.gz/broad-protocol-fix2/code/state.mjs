import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const repo=process.env.PRISM_TASK3_REPO;
assert(repo, 'set PRISM_TASK3_REPO to the explicit panel-budget worktree');
const {readRuntime,writeRuntime,listContexts,lookPath}=await import(`${repo}/src/contexts.js`);
const {writeScratch}=await import(`${repo}/src/scratch.js`);
const {withLock}=await import(`${repo}/src/lock.js`);
const {lockPath,activePath,defsDir}=await import(`${repo}/src/paths.js`);
const {loadDefs}=await import(`${repo}/src/defs.js`);
const {loadStore,loadLayers,withScratch}=await import(`${repo}/src/layers.js`);
const {resolveLayered}=await import(`${repo}/src/resolve.js`);
const defs=loadDefs(defsDir());
const raw=(file)=>fs.existsSync(file)?fs.readFileSync(file).toString('base64'):null;
const documents=()=>Object.fromEntries([null,...listContexts().profile].map(name=>[name??'@base',raw(lookPath(name))]));
const canonical=(base,active,scratch)=>resolveLayered(defs,base,withScratch(loadLayers(active),scratch)).params;
function guardDocuments(saved){assert.deepEqual(documents(),saved.documents,'profile/base document changed; stop without overwriting owner edits');}
export async function snapshot(){
  return withLock(lockPath(),async()=>{
    const runtime=readRuntime(),P=runtime.active.profile,names=listContexts().profile;
    assert(names.includes(P),'current P must be an existing profile');
    const store=loadStore(defs);
    const resolved=Object.fromEntries(names.map(profile=>[profile,canonical(store.base,{...runtime.active,profile},{})]));
    let Q,different=[];
    // Listed names are sorted, so keeping the first equal count breaks ties by name.
    for (const name of names) {
      if (name===P) continue;
      const changed=Object.keys(resolved[P]).filter(key=>!Object.is(resolved[P][key],resolved[name][key]));
      if (changed.length>different.length) {Q=name;different=changed;}
    }
    assert(different.length>Object.keys(store.params).length/2,'current pair must change most canonical values');
    const profiles=Object.fromEntries([P,Q].map(name=>[name,resolved[name]]));
    return {schema:1,scope:'preflight-only-until-fresh-approved-snapshot',runtime,runtimeRaw:raw(activePath()),documents:documents(),canonical:store.params,
      pair:{P,Q,total:Object.keys(store.params).length,PtoQ:different,QtoP:[...different],eligible:different.length>Object.keys(store.params).length/2},
      profiles,uneditedNumeric:[...defs].filter(([key,def])=>def.ui?.control==='slider'&&!Object.hasOwn(runtime.scratch,key)).map(([key,def])=>({key,value:store.params[key],range:def.range,step:def.ui?.step}))};
  });
}
export async function clear(saved){
  return withLock(lockPath(),async()=>{
    guardDocuments(saved);
    assert.equal(saved.runtime.active.profile,saved.pair.P,'fresh saved profile must equal chosen P');
    assert.equal(saved.pair.eligible,true,'fresh pair no longer changes most canonical values');
    assert.deepEqual(readRuntime(),saved.runtime,'runtime changed since approved snapshot');
    assert.equal(raw(activePath()),saved.runtimeRaw,'raw runtime changed since approved snapshot');
    writeScratch({});
    assert.deepEqual(readRuntime(),{active:saved.runtime.active,scratch:{}});
    return {cleared:true,runtime:readRuntime(),canonical:loadStore(defs).params};
  });
}
export async function restore(saved){
  return withLock(lockPath(),async()=>{
    guardDocuments(saved);
    const current=readRuntime();
    assert.equal(current.active.profile,saved.pair.P,'profile changed; return to P and drain, or stop on unrelated conflict');
    assert.deepEqual(current.scratch,{},'test scratch is not empty; drain and restore test slider first');
    const active={...saved.runtime.active};
    if(current.active.wallpaper===undefined)delete active.wallpaper;
    else active.wallpaper=current.active.wallpaper;
    const expected=canonical(loadStore(defs).base,active,saved.runtime.scratch);
    writeRuntime({active,scratch:saved.runtime.scratch});
    assert.deepEqual(readRuntime(),{active,scratch:saved.runtime.scratch},'runtime/scratch restoration failed');
    guardDocuments(saved);
    const values=loadStore(defs).params;
    assert.deepEqual(values,expected,'canonical restoration failed');
    return {restored:true,runtime:readRuntime(),canonical:values,documentsEqual:true,scratchExact:true,
      wallpaperPreserved:JSON.stringify(active.wallpaper)!==JSON.stringify(saved.runtime.active.wallpaper),
      canonicalMatchesOriginal:JSON.stringify(values)===JSON.stringify(saved.canonical)};
  });
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  const [action,file]=process.argv.slice(2);
  assert(file&&['snapshot','clear','restore'].includes(action),'use snapshot|clear|restore SNAPSHOT.json');
  if(action==='snapshot'){
    assert(!fs.existsSync(file),'refuse to overwrite a saved snapshot');
    fs.writeFileSync(file,JSON.stringify(await snapshot(),null,2)+'\n',{mode:0o600});
    console.log(JSON.stringify({snapshot:file,readOnly:true}));
  }else{
    assert.equal(process.env.PRISM_TASK3_APPROVED,'yes','controller must obtain fresh desktop/setup permission before any write');
    console.log(JSON.stringify(await (action==='clear'?clear:restore)(JSON.parse(fs.readFileSync(file))),null,2));
  }
}
