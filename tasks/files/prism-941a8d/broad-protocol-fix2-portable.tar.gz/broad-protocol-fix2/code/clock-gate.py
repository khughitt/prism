"""Independent Noctalia source/build/boot proof. Synthetic producers are not proof."""
import argparse,hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
REVISION='6ef43e2bf2f3d5b4205ec72a72e34a2ab76ce3b4'
SOURCE_HASHES={
 'VERSION':'4e001f5f34a8940927b497e5657a1bba9a35094b2c1f992de2fbee40af237d5b',
 'meson.build':'b5d9b119a4deef02b6f0a1eba8c7a1c9832c079f68a5e629233b86264f1dc7ec',
 'src/scripting/luau_host.cpp':'a1a8d6332bf758fa7c1ce90d0191dd00b850a5ec974a33b620bf1ea297b2737e',
 'third_party/luau/VM/src/linit.cpp':'7ef7f58f38fae175616a79b94f3f133645b81f813a460c270b0e16b32e1ac37a',
 'third_party/luau/VM/src/loslib.cpp':'5e4336688da9c6b9fc5c97a2b35464e2554c15aa83a3cc5d9defb168be1caaee',
 'third_party/luau/VM/src/lperf.cpp':'896d6c266d01832893ef8ee8c641bc6dfee709689b293cacc28fc84bc3cb8217'}

def require(ok,why):
 if not ok:raise ValueError(why)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run(*argv):return subprocess.check_output(argv,text=True).strip()
def build_id(path):
 matches=re.findall(r'Build ID: ([0-9a-f]+)',run('readelf','-n',str(path)));require(len(matches)==1,'missing executable build identity');return matches[0]
def observe(proof):
 root=Path(proof['sourceRoot']);pid=proof['observed']['running']['pid'];exe=Path(shutil.which('noctalia')).resolve();running=Path(f'/proc/{pid}/exe')
 require(root.is_dir(),'missing primary source')
 require(run('git','-C',str(root),'rev-parse','HEAD')==REVISION,'source revision mismatch')
 require(run('git','-C',str(root),'rev-parse','v5.2.1')==REVISION,'source tag mismatch')
 require(not run('git','-C',str(root),'status','--porcelain','--untracked-files=no'),'source tree modified')
 files={name:sha(root/name) for name in SOURCE_HASHES};require(files==SOURCE_HASHES,'source clock identity changed')
 require(set(proof['excerpts'])==set(SOURCE_HASHES),'incomplete implementation source chain')
 for name,excerpt in proof['excerpts'].items():
  lines=(root/name).read_text().splitlines();start=excerpt['firstLine']-1;count=len(excerpt['text'].splitlines())
  require(start>=0 and count and '\n'.join(lines[start:start+count])==excerpt['text'],'source excerpt not exact: '+name)
 package=run('pacman','-Q','noctalia');pkgroot=Path(proof['packageRoot'])
 require('pkgver = '+package.split()[1] in (pkgroot/'PKGINFO').read_text(),'package source version mismatch')
 require('pkgver = '+package.split()[1] in (pkgroot/'BUILDINFO').read_text(),'package build version mismatch')
 stat=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();require(stat[0]!='Z','running host exited')
 require(running.resolve()==exe,'running host executable path differs')
 return {'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
 'installed':{'path':str(exe),'sha256':sha(exe),'buildId':build_id(exe),'package':package},
 'running':{'pid':pid,'startTicks':int(stat[19]),'sha256':sha(running),'buildId':build_id(running)},
 'sourceRevision':REVISION,'sourceFiles':files,'pythonMonotonic':time.get_clock_info('monotonic').implementation,
 'packageFiles':{name:sha(pkgroot/name) for name in ('PKGINFO','BUILDINFO')}}

def historical(root):
 root=Path(root);phases=(root/'phases-private.jsonl').read_bytes();rows=[json.loads(x) for x in phases.splitlines()]
 targets=[e for e in rows if e['phase']=='C2-handsProfileQ-end'];require(len(targets)==1,'missing historical Q completion')
 candidates=[]
 for path in (root/'C2').glob('segment-*.raw'):
  for line in path.read_bytes().splitlines():
   if b'prism-budget ' not in line:continue
   event=json.loads(line.split(b'prism-budget ',1)[1])
   if event.get('scope')=='callback' and event.get('class')=='open' and event.get('callbackId')==1911:
    candidates.append((event,hashlib.sha256(line).hexdigest()))
 require(len(candidates)==1,'missing/duplicate exact historical probe event')
 event,rawsha=candidates[0]
 return {'controllerOrigin':targets[0]['clockOrigin'],'origins':sorted({e['clockOrigin'] for e in rows}),
 'probeOrigin':event['clockOrigin'],'probeTimestamp':event['timestamp'],'controllerTimestamp':targets[0]['seconds'],
 'rawSha256':rawsha,'phasesSha256':hashlib.sha256(phases).hexdigest()}

def verify(proof,actual,r2):
 require(proof.get('schema')==2 and proof.get('environment')=='live','missing live source proof')
 require(proof.get('observed')==actual,'installed/running/source/package/boot proof stale')
 require(actual['sourceRevision']==REVISION and actual['sourceFiles']==SOURCE_HASHES,'source clock identity mismatch')
 require(actual['installed']['sha256']==actual['running']['sha256'] and actual['installed']['buildId']==actual['running']['buildId'],'installed/running mismatch')
 require(actual['pythonMonotonic']=='clock_gettime(CLOCK_MONOTONIC)','Python monotonic implementation mismatch')
 require(isinstance(proof.get('binding'),dict),'root source/build endorsement missing')
 b=proof['binding'];require(b.get('noHostClockOverride') is True and type(b.get('originOffsetSeconds')) is int,'invalid root clock binding types')
 require(b=={'rootSessionId':proof['sessionId'],'sourceRevision':REVISION,'binarySha256':actual['installed']['sha256'],'package':actual['installed']['package'],'noHostClockOverride':True,'linuxClock':'CLOCK_MONOTONIC','originOffsetSeconds':0},'root source/build/host clock binding absent or inconsistent')
 require(isinstance(proof['sessionId'],str) and proof['sessionId'],'missing root session identity')
 require(set(proof['excerpts'])==set(SOURCE_HASHES),'incomplete implementation source chain')
 require(all(e['fileSha256']==SOURCE_HASHES[k] and type(e['firstLine']) is int and e['firstLine']>0 and e['text'] for k,e in proof['excerpts'].items()),'invalid implementation excerpts')
 require(r2['origins']==[r2['controllerOrigin']] and r2['controllerOrigin'].startswith('host-monotonic:') and r2['probeOrigin'],'historical internal origin mismatch')
 delta=r2['controllerTimestamp']-r2['probeTimestamp'];require(0<=delta<=.05,'historical reversed/seconds-offset clocks')
 return {'schema':2,'verified':True,'sessionId':proof['sessionId'],'clockOrigin':'host-monotonic:'+actual['bootId'],'observed':actual,'r2':r2,'r2DeltaSeconds':delta,'corroborationOnly':True,'sourceProofSha256':hashlib.sha256(json.dumps(proof,sort_keys=True).encode()).hexdigest()}

def main():
 p=argparse.ArgumentParser();p.add_argument('--source-proof',required=True);p.add_argument('--r2-root',required=True);p.add_argument('--output',required=True);a=p.parse_args();os.umask(0o077)
 try:
  proof=json.loads(Path(a.source_proof).read_bytes());result=verify(proof,observe(proof),historical(a.r2_root))
 except (OSError,KeyError,ValueError,TypeError,subprocess.CalledProcessError) as error:
  result={'schema':2,'verified':False,'error':str(error)}
 with Path(a.output).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print('PASS Noctalia source/build/boot clock gate' if result['verified'] else 'BLOCKED clock gate: '+result['error'])
 return 0 if result['verified'] else 1
if __name__=='__main__':raise SystemExit(main())
