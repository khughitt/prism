"""Counterfeit final captures derived from an actual completed fake-host lifecycle.
Each case is a new private copy; original producer/capture archives are untouched.
"""
import copy,importlib.util,json,pathlib,shutil,subprocess,sys,os
ROOT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('controller',ROOT/'controller.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
source=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);os.umask(0o077);out.mkdir(mode=0o700)
base=c.load(source/'state.json');before=c.load(source/'normalized.json');receipt=c.load(source/'receipt.json')
assert base['phase']=='restored' and before['collectionComplete']
assert len(base['inspection']['events'])>len(before['events'])
assert c.verify_final_observations(before,base['inspection'])
assert 'Wait at least5 seconds after diagnostics physically settle before the first manual action' in (source/'recovery-card.txt').read_text()
print('PASS original periodic initial/recovery dwell, immutable final prefix and actual CLI lifecycle; recovery card names five-second wait')
rows=c.analyze.read_rotated([source/'producer-final.log']);manifest=c.load(source/'recovery.json');reply=c.load(source/'recoveryCompleteReceived.json')['receivedAt']
bundle=c.load(source/'bundle.json');expected=c.materialize(manifest,bundle['saved'],bundle['definitions'],rows,True)['reference']
assert c.operation_gates(rows,manifest,reply,expected)
for name in ('input','accepted','generation','reference','profile','queue-state'):
 bad=copy.deepcopy(rows);tail=[e for e in bad if e['cardId']==manifest['cardId'] and reply-1.5<e['timestamp']<=reply]
 tick=next(e for e in tail if e['class']=='secondTick');drain=next(e for e in reversed(tail) if e['class']=='drain')
 if name=='input':tick['class']='input'
 elif name=='accepted':tick['accepted']=True
 elif name=='generation':tick['acceptGeneration']+=1
 elif name=='reference':drain['referenceId']+=1
 elif name=='profile':drain['currentProfile']='different'
 else:drain['queueIdle']=False
 try:c.operation_gates(bad,manifest,reply,expected)
 except ValueError:print('PASS material dwell restart/refusal',name)
 else:raise AssertionError('material dwell change ignored: '+name)

for name in ('periodic','split-observer','history-value','history-timing','unknown-request','accepted-state','source','reference','tail-target','callback-end','missing-callback','missing-raw','error-tail','generation','profile'):
 root=out/name;shutil.copytree(source,root,symlinks=True)
 state=copy.deepcopy(base);state['phase']='finishing';state['inspection']=before
 state['stamps']={k:v for k,v in state['stamps'].items() if k not in ('collectorExited','restoreDone')}
 c.atomic(root/'state.json',state)
 m=c.load(root/'manifest.json');raw=b''.join((root/r['path']).read_bytes() for r in m['segments'])
 prefix=state['finishAudit']['bytes'];lines=raw.splitlines(keepends=True);parsed=[];offset=0
 for index,line in enumerate(lines):
  if b'prism-budget ' in line:parsed.append((index,offset,json.loads(line.split(b'prism-budget ',1)[1])))
  offset+=len(line)
 if name=='split-observer':
  assert parsed[-1][2]['class']=='observerSnapshot'
  prefix=parsed[-1][1];state['finishAudit'].update(bytes=prefix,rawSha256=c.digest(raw[:prefix]))
  shortened=copy.deepcopy(base['inspection']);last=parsed[-1][2]['recordId']
  for key in ('events','samples'):shortened[key]=[e for e in shortened[key] if e['recordId']!=last]
  state['inspection']=shortened;c.atomic(root/'state.json',state)
 history=[x for x in parsed if x[1]<prefix];tail=[x for x in parsed if x[1]>=prefix]
 def choose(items,cls):return next(x for x in items if x[2]['class']==cls)
 changed=None
 if name=='history-value':
  changed=choose(history,'acceptedReference');key=next(iter(changed[2]['values']));changed[2]['values'][key]='counterfeit'
 elif name=='history-timing':changed=choose(history,'coldRender');changed[2]['elapsedMs']+=.01
 elif name=='unknown-request':
  changed=choose(tail,'secondTick');changed[2]['class']='operationRequested';changed[2]['scope']='metadata';changed[2].update(operationId='unapproved',operationKind='release',valid=True,key='wrong')
 elif name=='accepted-state':changed=choose(tail,'secondTick');changed[2]['accepted']=True
 elif name=='source':changed=choose(tail,'secondTick');changed[2]['sourceHash']='wrong'
 elif name=='reference':changed=choose(tail,'drain');changed[2]['referenceId']+=1
 elif name=='tail-target':changed=choose(tail,'secondTick');changed[2]['class']='coldRender';changed[2]['rendered']=True
 elif name=='callback-end':changed=choose(tail,'secondTick');changed[2]['complete']=False
 elif name=='missing-callback':lines[choose(tail,'secondTick')[0]]=b''
 elif name=='error-tail':lines.append(b'Noctalia exceeded its CPU budget\n')
 elif name=='generation':changed=choose(tail,'secondTick');changed[2]['acceptGeneration']+=1
 elif name=='profile':changed=choose(tail,'drain');changed[2]['currentProfile']='wrong'
 if changed is not None:lines[changed[0]]=b'prism-budget '+json.dumps(changed[2],separators=(',',':')).encode()+b'\n'
 raw=b''.join(lines);first=m['segments'][0];(root/first['path']).write_bytes(raw);first.update(bytes=len(raw),sha256=c.digest(raw));m['segments']=[first];c.atomic(root/'manifest.json',m)
 if name=='missing-raw':(root/first['path']).unlink()
 now=max(base['stamps'].values())+1
 command=[sys.executable,'-c',f"import runpy,time,sys; sys.path.insert(0,{str(ROOT)!r}); time.monotonic=lambda:{now!r}; sys.argv={['controller.py','exited','--run',str(root)]!r}; runpy.run_path({str(ROOT/'controller.py')!r},run_name='__main__')"]
 p=subprocess.run(command,capture_output=True,text=True,timeout=10)
 c.immutable(root/'negative-command.json',{'argv':command,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'counterfeitCopy':True})
 assert (p.returncode==0)==(name in ('periodic','split-observer')),(name,p.stdout,p.stderr)
 print('PASS actual CLI final raw',name,'allowed' if p.returncode==0 else 'refused')
