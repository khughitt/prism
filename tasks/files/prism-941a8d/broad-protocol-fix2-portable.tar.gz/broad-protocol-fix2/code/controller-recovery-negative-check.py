"""Counterfeit copies of actual producer rows; original archives stay unchanged."""
import copy,importlib.util,json,pathlib,sys
s=importlib.util.spec_from_file_location('controller',pathlib.Path(__file__).parent/'controller.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
root=pathlib.Path(sys.argv[1]);session=c.load(root/'session.json');identity=session['identity'];nonce=identity['activationNonce'];bundle=c.load(root/'bundle.json');manifest=c.load(root/'action-manifest.json');recovery=c.load(root/'recovery.json');rows=c.analyze.read_rotated([root/'producer-final.log']);initial_reply=c.load(root/'initialCompleteReceived.json')['receivedAt'];reply=c.load(root/'recoveryCompleteReceived.json')['receivedAt']
def evaluate(rows,m=None,approved=True):
 m=m or recovery;c.validate_recovery(m,identity,manifest)
 rc=c.materialize(m,bundle['saved'],bundle['definitions'],rows,True);rg=c.operation_gates(rows,m,reply,rc['reference'])
 auth={nonce:{'manifest':m,'operations':rc['operations'],'originVerified':True,'ownerApproved':approved}}
 n,context=c.inspect_capture(rows,[identity],{nonce:manifest},{nonce:bundle['saved']},{nonce:bundle['definitions']},{nonce:initial_reply},True,auth,{nonce:rg})
 return n,context,rc
n,ctx,rc=evaluate(rows);assert n['collectionComplete']
original=next(op for op in ctx['cards'][nonce]['operations'] if op['kind']=='release');replacement=next(op for op in rc['operations'] if op['kind']=='release');key=original['key'];assert original['expectedReference']['values'][key]!=replacement['expectedReference']['values'][key]
assert n['certificates'][0]['replacementCredit'][original['id']]==replacement['id']
print('PASS independently materialized different-scalar replacement credits exact approved release key')
for mutation in ('other-param','profile','wallpaper','other-scratch','key-scratch','wrong-release-value','missing-intent','duplicate-intent','stale-intent','wrong-intent-key','wrong-intent-value','intent-after-accept','unapproved','second-packet','ready-missing','ready-extra','ready-order','ready-stale'):
 bad=copy.deepcopy(rows);m=copy.deepcopy(recovery);approved=True
 ref=next(e for e in bad if e['class']=='acceptedReference' and e['operationId']==replacement['id']);intent=next(e for e in bad if e['class']=='operationIntent' and e['operationId']==replacement['id']);ready=next(e for e in bad if e['class']=='ready' and e['cardId']==m['cardId'])
 other=next(k for k,v in ref['values'].items() if k!=key and type(v) in (int,float))
 if mutation=='other-param':ref['values'][other]+=1
 if mutation=='profile':ref['acceptedProfile']='wrong'
 if mutation=='wallpaper':ref['acceptedWallpaper']=False
 if mutation=='other-scratch':ref['heldScratchKeys']=sorted(ref['heldScratchKeys']+[other])
 if mutation=='key-scratch':ref['heldScratchKeys']=[]
 if mutation=='wrong-release-value':ref['values'][key]+=.01
 if mutation=='missing-intent':bad.remove(intent)
 if mutation=='duplicate-intent':bad.append(copy.deepcopy(intent))
 if mutation=='stale-intent':intent['acceptGeneration']-=1
 if mutation=='wrong-intent-key':intent['key']=other
 if mutation=='wrong-intent-value':intent['canonicalValue']+=.01
 if mutation=='intent-after-accept':intent['recordId']=ref['recordId']+1
 if mutation=='unapproved':approved=False
 if mutation=='second-packet':bad.append(copy.deepcopy(next(e for e in bad if e['class']=='recoveryAccepted')))
 if mutation=='ready-missing':ready['requestedOperationIds'].pop()
 if mutation=='ready-extra':ready['requestedOperationIds'].append('unknown')
 if mutation=='ready-order':ready['requestedOperationIds'].reverse()
 if mutation=='ready-stale':ready['requestedOperationIds'][0]=original['id']
 try:result,_,_=evaluate(bad,m,approved);assert not result['collectionComplete'],mutation
 except (ValueError,KeyError):pass
 print('PASS actual producer counterexample refused',mutation)
# Narrow comparison itself preserves unaffected values/profile/wallpaper/other held keys.
for kind in ('restore','profile'):
 old=copy.deepcopy(original);new=copy.deepcopy(replacement);old['kind']=new['kind']=kind
 assert not c.analyze.replacement_reference(old,new),kind
for field in ('values','acceptedProfile','acceptedWallpaper','heldScratchKeys'):
 new=copy.deepcopy(replacement)
 if field=='values':new['expectedReference'][field][other]+=1
 elif field=='heldScratchKeys':new['expectedReference'][field]=sorted(new['expectedReference'][field]+[other])
 else:new['expectedReference'][field]='wrong'
 assert not c.analyze.replacement_reference(original,new),field
print('PASS exact restore/profile and unaffected-map/profile/wallpaper/scratch replacement matching retained')
