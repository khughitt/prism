"""Measure mandated full validation against real retained archives; no long sleep."""
import hashlib,json,math,os,sys,time,threading
from pathlib import Path
from unittest.mock import patch
import logs
os.umask(0o077);root=Path(sys.argv[1]);root.mkdir(mode=0o700);mib=int(sys.argv[2]);assert mib>=160
log=root/'host.log';log.write_bytes(b'A'*(512*1024));st=log.stat();g=mib+1
segments=[];block=b'S'*(1024*1024);sha=hashlib.sha256(block).hexdigest()
for n in range(1,g):
 name=f'segment-{n:06d}-1-{n}.raw';(root/name).write_bytes(block)
 segments.append({'path':name,'generation':n,'dev':1,'inode':n,'startOffset':0,'endOffset':len(block),'bytes':len(block),'sha256':sha})
data=log.read_bytes();name=f'segment-{g:06d}-{st.st_dev}-{st.st_ino}.raw';(root/name).write_bytes(data)
segments.append({'path':name,'generation':g,'dev':st.st_dev,'inode':st.st_ino,'startOffset':0,'endOffset':len(data),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest=root/'manifest.json';logs.save(manifest,{'schema':2,'log':str(log),'current':{'dev':st.st_dev,'inode':st.st_ino,'offset':len(data),'generation':g},'nextGeneration':g+1,'segments':segments,'integrityComplete':False})
metrics=[];writes=[];stop=threading.Event();realopen=Path.open;meter={'archive':0,'source':0}
class Handle:
 def __init__(self,f,kind):self.f=f;self.kind=kind
 def __getattr__(self,k):return getattr(self.f,k)
 def __enter__(self):return self
 def __exit__(self,*args):return self.f.__exit__(*args)
 def read(self,*args):
  raw=self.f.read(*args);meter[self.kind]+=len(raw);return raw

def opened(path,*args,**kwargs):
 f=realopen(path,*args,**kwargs)
 return Handle(f,'source' if path==log else 'archive') if path==log or path.name.startswith('segment-') else f

def writer():
 while not stop.is_set():
  start=time.monotonic()
  with realopen(log,'ab',buffering=0) as f:f.write(b'growth\n');os.fsync(f.fileno())
  writes.append({'start':start,'end':time.monotonic(),'bytes':7});stop.wait(.016)
owner=None;thread=None
try:
 with patch.object(Path,'open',opened):
  at=time.monotonic();owner=logs.Capture(manifest);metrics.append({'reason':'startup','start':at,'end':time.monotonic(),'readBytes':dict(meter)})
  thread=threading.Thread(target=writer);thread.start()
  for reason in ('ready','settled'):
   meter.update(archive=0,source=0);at=time.monotonic();owner.checkpoint(reason);metrics.append({'reason':reason,'start':at,'end':time.monotonic(),'readBytes':dict(meter)})
  stop.set();thread.join();owner.poll()
  meter.update(archive=0,source=0);at=time.monotonic();result=owner.checkpoint('finish');metrics.append({'reason':'finish','start':at,'end':time.monotonic(),'readBytes':dict(meter)})
 assert result['integrityComplete']
 (root/'measurement.json').write_text(json.dumps({'retainedMiB':mib+.5,'checkpoints':metrics,'writeSpans':writes,'threadJoined':not thread.is_alive()},indent=2))
 print('PASS history',mib,'MiB',json.dumps([dict(reason=x['reason'],seconds=x['end']-x['start'],readBytes=x['readBytes']) for x in metrics]))
finally:
 stop.set()
 if thread:thread.join()
 if owner:owner.close()
