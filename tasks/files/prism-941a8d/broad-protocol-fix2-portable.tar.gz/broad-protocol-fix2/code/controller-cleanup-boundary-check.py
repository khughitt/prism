"""Exact signal-boundary regressions against the real supervisor and owned collector."""
import ast,importlib.util,json,os,pathlib,signal,subprocess,sys,time

def main():
 os.umask(0o077)
 source,out,model,cli=map(pathlib.Path,sys.argv[1:5]);out.mkdir(mode=0o700)
 spec=importlib.util.spec_from_file_location('cleanup',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 tree=ast.parse(source.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='supervise')
 owner=next(n for n in fn.body if isinstance(n,ast.Try));entry=owner.finalbody[0].lineno
 cases=sys.argv[5:] or ['timeout-entry-TERM','TERM-entry-TERM','TERM-entry-INT','repeated-cleanup','bootstrap-repeated','forced-child-kill']
 failed=[]
 for case in cases:
  target=out/case;events=[];before={s:signal.getsignal(s) for s in (signal.SIGTERM,signal.SIGINT)};child_id=None;child=None
  injection="def hold(*args):\n (m.OUT/'fixture-ready.json').write_text('owned collector running')\n "
  if case=='forced-child-kill':injection+="signal.signal(signal.SIGTERM,signal.SIG_IGN)\n "
  if case.startswith('TERM-') or case=='repeated-cleanup':injection+="os.kill(os.getppid(),signal.SIGTERM)\n "
  injection+="time.sleep(30)\nm.c.verify_initial=hold"
  program=f"import importlib.util,sys,os,signal,time;sys.path.insert(0,{str(m.ROOT)!r});sys.argv={['boundary',str(target),str(model),str(cli)]!r};s=importlib.util.spec_from_file_location('integration',{str(m.ROOT/'controller-integration.py')!r});m=importlib.util.module_from_spec(s);s.loader.exec_module(m);exec({injection!r});m.pipeline('release-recovery')"
  original_popen=m.subprocess.Popen
  # Outer ownership begins before calling supervise, including failures in old code.
  def launch(*a,**kw):
   nonlocal child,child_id
   p=original_popen(*a,**kw)
   if a and a[0]==command:
    child=p;child_id=m.cap.process(p.pid)
   return p
  command=[sys.executable,'-c',program];m.subprocess.Popen=launch
  def deliver(label,sigs):
   events.append(label)
   for sig in sigs:signal.raise_signal(sig)
  def trace(frame,event,arg):
   if event=='line' and frame.f_code is m.supervise.__code__:
    if frame.f_lineno==entry and 'entry' not in events and case not in ('bootstrap-repeated','forced-child-kill'):
     deliver('entry',[signal.SIGINT if case=='TERM-entry-INT' else signal.SIGTERM])
    if case=='repeated-cleanup' and 'entry' in events and 'cleanup-wait' not in events and frame.f_lineno>entry and 'communicate(timeout=15)' in source_lines[frame.f_lineno-1]:
     deliver('cleanup-wait',[signal.SIGTERM,signal.SIGINT,signal.SIGTERM])
    if case=='repeated-cleanup' and 'entry' in events:
     for label,needle in [('evidence',"path=target/'supervisor-cleanup.json'"),('restore','blocked=signal.pthread_sigmask')]:
      if label not in events and needle in source_lines[frame.f_lineno-1]:deliver(label,[signal.SIGTERM,signal.SIGINT])
    if case=='bootstrap-repeated' and child_id is not None and 'bootstrap' not in events:
     deliver('bootstrap',[signal.SIGTERM,signal.SIGINT,signal.SIGTERM])
   if event=='call' and frame.f_code is m.reap_owned.__code__ and case=='repeated-cleanup' and 'reap' not in events:
    deliver('reap',[signal.SIGINT,signal.SIGTERM])
   return trace
  source_lines=source.read_text().splitlines();observed={};began=time.monotonic()
  try:
   sys.settrace(trace)
   try:m.supervise(command,target,2 if case.startswith('timeout') or case=='forced-child-kill' else 8);observed['returned']=True
   except (SystemExit,subprocess.TimeoutExpired) as error:observed['exception']={'type':type(error).__name__,'code':getattr(error,'code',None)}
   finally:sys.settrace(None)
   observed['elapsedSeconds']=time.monotonic()-began
   observed['events']=events;observed['child']=child_id;observed['childAlive']=child_id is not None and m.cap.same_process(child_id)
   observed['handlersRestored']=all(signal.getsignal(s)==h for s,h in before.items())
   proof=target/'supervisor-cleanup.json';observed['cleanupEvidence']=json.loads(proof.read_text()) if proof.exists() else None
   observed['remainingBeforeOuterCleanup']={}
   for file in target.rglob('identities.json'):
    ids=json.loads(file.read_text());observed['remainingBeforeOuterCleanup'].update({k:v for k,v in ids.items() if m.cap.same_process(v)})
  finally:
   sys.settrace(None);m.subprocess.Popen=original_popen
   # Test failures never surrender ownership to the code being tested.
   for sig in before:signal.signal(sig,lambda *args:None)
   try:
    if child is not None and child.poll() is None:
     if child_id is not None and m.cap.same_process(child_id):child.terminate()
     try:child.communicate(timeout=2)
     except subprocess.TimeoutExpired:
      if child_id is not None and m.cap.same_process(child_id):child.kill()
      child.communicate(timeout=3)
    observed['outerCleanup']=m.reap_owned(target)
   finally:
    for sig,handler in before.items():signal.signal(sig,handler)
   (out/(case+'-proof.json')).write_text(json.dumps(observed,indent=2)+'\n')
  try:
   assert not observed['childAlive'],'supervisor returned with its child alive'
   assert not observed['remainingBeforeOuterCleanup'],'supervisor left owned named collector running'
   assert observed['handlersRestored'],'supervisor did not restore prior handlers'
   evidence=observed['cleanupEvidence'];assert evidence is not None,'supervisor skipped cleanup evidence'
   assert all(not r['remaining'] and not r['namedServerPresent'] for r in evidence['ownedRuns'])
   if case!='bootstrap-repeated':assert (target/'fixture-ready.json').exists(),'fixture missed running collector'
   for receipt in target.rglob('receipt.json'):
    assert json.loads(receipt.read_text())['integrityComplete'] is False,'interrupted capture became complete'
   for state in target.rglob('state.json'):
    assert json.loads(state.read_text()).get('protocolComplete') is not True,'interrupted protocol became complete'
   if case=='repeated-cleanup':assert events==['entry','cleanup-wait','reap','evidence','restore'],events
   if case=='bootstrap-repeated':assert events==['bootstrap'],events
   if case=='forced-child-kill':assert evidence['forcedChildKill'] and evidence['childExit']==-signal.SIGKILL
   else:assert not evidence['forcedChildKill']
   if case.startswith('TERM-') or case in ('repeated-cleanup','bootstrap-repeated'):
    assert observed['exception']=={'type':'SystemExit','code':143},observed['exception']
    assert observed['elapsedSeconds']<5,'pending stop did not promptly leave bounded wait'
   if case.startswith('timeout'):assert events==['entry']
   print('PASS signal boundary',case,flush=True)
  except AssertionError as error:failed.append(case);print('FAIL signal boundary',case,str(error),flush=True)
 assert not failed,failed
if __name__=='__main__':main()
