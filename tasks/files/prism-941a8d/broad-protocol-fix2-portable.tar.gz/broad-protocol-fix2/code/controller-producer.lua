-- Fake host only: controllable monotonic clock and IPC models before serialization.
local scenario=arg[5];arg[5]='harness'
local root=assert(arg[0]:match('^(.*)/'));local H=dofile(root..'/frozen-task2/self-check.lua')
local base=arg[1];local variant=arg[6] or 'baseline';local prefix=arg[7];local key='glass.inactive.roughness'
local now=tonumber(os.getenv('FIXTURE_START')) or 1000
local paced=os.getenv('PACED')=='1'
local delta=variant=='baseline' and .001 or (scenario:find('gainfail') and .00099 or .0005)
if paced then delta=.0000001 end
local nativeos=os;os=setmetatable({clock=function() now=now+delta;return now end},{__index=nativeos})
local h=H.host(base..'/'..variant..'/plugin',true,true);local initial;local identity=H.up(h.env.onFrameTick,'diagnosticIdentity')
if paced then
 for _,line in ipairs(h.logs) do io.write(line..'\n') end;io.flush()
 local log=h.env.noctalia.log
 h.env.noctalia.log=function(line) log(line);io.write(line..'\n');io.flush() end
end
local function step()
 if paced then local tick=assert(tonumber(io.read('*l')),'scheduler ended');now=math.max(now,tick) end
end
if paced then h.tick=function() step();h.env.onFrameTick(16) end end
local wait
local serial=0
local function deliver() serial=serial+1;local response=H.copy(H.success);response.stdout='response '..serial;h.launches[#h.launches].callback(response) end
local function drain()
 for _=1,1000 do
  if not h.frame then return end
  step();h.env.onFrameTick(16);local pair=H.up(h.env.onFrameTick,'diagnosticPair')
  if pair and pair.pending and pair.frameDone then h.launches[#h.launches].callback(H.success) end
 end
 error('unbounded fixture drain')
end
wait=function(n)
 if paced then
  local stop=now+n;local nextSecond=now+1;local index=0
  while now<stop do
   step();index=index+1
   if h.state.drag then
    for _,node in ipairs(H.nodes(h.tree)) do
     if node.kind=='slider' and node.props.key==key..':slider' then
      node.props.onChange(node.props.value+(index%2==0 and .001 or -.001));break
     end
    end
   end
   if now>=nextSecond then
    nextSecond=nextSecond+1;local count=#h.launches;h.env.update()
    if #h.launches>count then local unchanged=H.copy(H.success);unchanged.stdout='response '..serial;h.launches[#h.launches].callback(unchanged) end
   end
   if h.frame then h.env.onFrameTick(16) end
  end
  if not h.state.drag then drain() end;return
 end
 -- Exercise preserved periodic callbacks and their real frame/observer flushes.
 local stop=now+n
 for _=1,math.floor(n) do
  now=now+1;local count=#h.launches;h.env.update()
  local unchanged=H.copy(H.success);unchanged.stdout='response '..serial
  if #h.launches>count then h.launches[#h.launches].callback(unchanged) end
  if h.state.drag then h.env.onFrameTick(16) else drain() end
 end
 now=math.max(now,stop)
end
local function save(suffix)
 local f=assert(io.open(prefix..suffix..'.log','w'));f:write(table.concat(h.logs,'\n')..'\n');f:close()
end
local function slider() for _,n in ipairs(H.nodes(h.tree)) do if n.kind=='slider' and n.props.key==key..':slider' then return n end end;error('missing slider') end
local function param(value,held) for _,p in ipairs(h.model.params) do if p.key==key then p.value=value;p.held=held end end end
local function actions(recovery)
 local short=scenario:match('short%-(.+)')
 wait(short==(recovery and 'recovery-diagnostic' or 'initial-diagnostic') and .01 or 6)
 for dragIndex=1,(scenario:find('full') and 5 or 1) do
 local s=slider();s.props.onChange(s.props.value+(recovery and .07 or .01));h.env.onFrameTick(16)
 wait(short==(recovery and 'recovery-drag' or 'initial-drag') and .01 or 2.1);s.props.onDragEnd()
 local value=tonumber(tostring(h.state.structure.byKey[key].value));param(value,{'scratch'})
 if not recovery and scenario:find('release') then
  h.env.onClose();deliver();deliver();h.env.onOpen({});deliver();h.tick();drain()
 else deliver();deliver();h.tick();drain() end
 wait(short==(recovery and 'recovery-release' or 'initial-release') and .01 or 2.1)
 local reset;for _,n in ipairs(H.nodes(h.tree)) do if n.props.tooltip=='Revert edit' and n.props.onClick and H.up(n.props.onClick,'key')==key then reset=n end end
 assert(reset).props.onClick();param(initial.params[1].value,{})
 for _,p in ipairs(initial.params) do if p.key==key then param(p.value,p.held) end end
 deliver();deliver();h.tick();drain();wait(short==(recovery and 'recovery-restore' or 'initial-restore') and .01 or 2.1)
 end
 for cycle=1,(scenario:find('full') and 6 or 2) do
  local i=(cycle-1)%2+1
  h.env.onKey(tostring(i),true);h.model.active.profile=h.model.profiles[i];deliver();deliver();h.tick();drain()
  wait(short==(recovery and (i==1 and 'recovery-Q' or 'recovery-P') or (i==1 and 'initial-Q' or 'initial-P')) and .01 or 5.1)
 end
end
for _,p in ipairs(h.model.params) do local held={};for _,layer in ipairs(p.held or {}) do if layer~='scratch' then held[#held+1]=layer end end;p.held=held end
h.model.profiles={'Q','P'};h.model.active.profile='P';h.env.update();deliver();h.tick();drain();initial=H.copy(h.model)
H.button(h,'Sample diagnostics').props.onClick()
local excluded
if scenario:find('excluded') or scenario:find('shortlaunch') then
 for _=1,1000 do
  step();h.env.onFrameTick(16);local pair=H.up(h.env.onFrameTick,'diagnosticPair')
  if pair and not pair.control then
   excluded=pair.id;local comparison=h.launches[#h.launches].callback
   h.env.update();h.env.update();local normal=h.launches[#h.launches].callback
   local unchanged=H.copy(H.success);unchanged.stdout='response '..serial
   h.env.onFrameTick(16);normal(unchanged);comparison(H.success);break
  end
  if pair and pair.pending and pair.frameDone then h.launches[#h.launches].callback(H.success) end
 end
 assert(excluded,'no launch to exclude')
end
drain()
local manual=identity.stage=='stage2';if manual then actions(false) else wait(scenario:find('short%-initial%-diagnostic') and .01 or 6) end
local closed={}
local function handoff(label)
 if not scenario:find('handoff') then return end
 local at=now;h.env.onClose();local count=#h.logs
 assert(not h.frame,'close must disable frame ticks')
 if paced then local stop=now+3;while now<stop do step() end else now=now+3 end -- No host callbacks while hidden.
 assert(#h.logs==count,'closed host unexpectedly ticked')
 local seen=false;for _,line in ipairs(h.logs) do if line:find('\"class\":\"close\"') then seen=true end end
 assert(seen,'close callback must be durable before any later frame')
 closed[#closed+1]={card=label,visibleUntil=at,replyAt=now,logsAtClose=count}
end
handoff('initial')
local initialReply=now;save('-initial')
local recovery
if scenario:find('recovery') or scenario:find('release') or scenario=='excluded' then
 if scenario:find('handoff') then
  h.env.onOpen({});local unchanged=H.copy(H.success);unchanged.stdout='response '..serial
  if scenario:find('reopen%-changed') then
   for _,p in ipairs(h.model.params) do if p.key==key then p.value=p.value+.03 end end
   serial=serial+1;unchanged.stdout='response '..serial
  end
  h.launches[#h.launches].callback(unchanged);drain()
 end
 wait(1);local card=identity.cardId..'-recovery';local ops={};local replacement={}
 if manual then
  local start=identity.coldPairs+2*identity.launchPairs
  ops={{id=card..':release',kind='release',key=key},{id=card..':restore',kind='restore',key=key},{id=card..':Q',kind='profile',profile=h.model.profiles[1]},{id=card..':P',kind='profile',profile=h.model.profiles[2]}}
  for i=1,4 do replacement[#replacement+1]=identity.cardId..':action:'..(start+i) end
 else replacement={identity.cardId..':launch:1'} end
 recovery={schema=2,approved=true,runId=identity.runId,activationNonce=identity.activationNonce,cardId=card,replacementFor=replacement,coldPairs=0,launchPairs=manual and 0 or 1,operations=ops}
 h.env.noctalia.readFile=function() return 'fixture permit' end;local decode=h.env.noctalia.json.decode
 h.env.noctalia.json.decode=function(s) if s=='fixture permit' then return H.copy(recovery) end;return decode(s) end
 local button=assert(H.button(h,'Recovery diagnostics'))
 recovery.approved=false;local n=#h.logs;button.props.onClick();drain()
 for i=n+1,#h.logs do assert(not h.logs[i]:find('"class":"operationRequested"'),'unapproved target') end
 recovery.approved=true;button.props.onClick();h.tick();drain()
 if manual then actions(true) else wait(6) end
 -- A second click refuses; never takes another valid packet.
 assert(not H.button(h,'Recovery diagnostics'))
end
if recovery then handoff('recovery') end
save('-final')
local finalReply=now;if not scenario:find('handoff') then wait(3) end;save('-tail')
local metadata={schema=2,initialModel=initial,initialReply=initialReply,finalReply=finalReply,recovery=recovery or false,handoffs=closed}
local f=assert(io.open(prefix..'-meta.json','w'));f:write(h.env.noctalia.json.encode(metadata));f:close()
print('PASS actual producer '..scenario..' '..variant..' independent intents and raw timing')
