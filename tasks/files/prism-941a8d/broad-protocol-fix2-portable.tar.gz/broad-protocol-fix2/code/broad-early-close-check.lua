-- Real generated host closes with an asynchronous acceptance still pending.
arg[5]='harness'
local root=assert(arg[0]:match('^(.*)/'));local H=dofile(root..'/frozen-task2/self-check.lua')
for _,variant in ipairs({'baseline','candidate'}) do
 local h=H.host(arg[1]..'/'..variant..'/plugin',true,true)
 H.button(h,'Sample diagnostics').props.onClick();h.env.onFrameTick(16)
 h.env.onClose();h.env.onOpen({});h.env.onClose()
 assert(not h.frame)
 local handoff
 for _,record in ipairs(h.emitted) do if record.class=='handoff' then handoff=record end end
 assert(handoff and handoff.describeRunning==true,'pending acceptance unexpectedly quiescent')
 local f=assert(io.open(arg[6]..'-'..variant..'.log','w'));f:write(table.concat(h.logs,'\n')..'\n');f:close()
 print('PASS actual pending-acceptance close '..variant)
end
