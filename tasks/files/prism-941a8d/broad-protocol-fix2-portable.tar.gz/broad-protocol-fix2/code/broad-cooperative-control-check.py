"""Real collector control/deadline/gap refusal while cooperative hashes are active."""
import tempfile,json,time,os,signal
from pathlib import Path
from unittest.mock import patch
import capture,logs
for kind in ('stop','deadline','gap'):
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);log=root/'host.log';log.write_bytes(b'');cfg={'schema':2,'environment':'synthetic','runId':'cooperative-control','clockOrigin':'test','socket':'prism-budget-capture-cooperative-control','deadlineSeconds':2700,'pollSeconds':.05,'maxGapSeconds':.25,'log':str(log)}
  for k in ('manifest','control','receipt','heartbeat','polls','identities'):cfg[k]=str(root/(k+'.json'))
  capture.atomic(root/'RUN.json',cfg);capture.atomic(root/'wrapper-ready.json',{});capture.atomic(root/'identities.json',{'owner':capture.process(os.getpid())});capture.atomic(root/'control.json',{'sequence':1,'command':'ready'})
  original_start=logs.start;original_archive=logs.Capture._archive;original_checkpoint=logs.Capture.checkpoint;active=[False];fired=[False];now=[time.monotonic()]
  def seeded(log,manifest):
   original_start(log,manifest);c=logs.Capture(manifest)
   try:
    log.write_bytes(b'first');c.poll();log.replace(root/'host.log.1');log.write_bytes(b'second');c.poll()
   finally:c.close()
  def checkpoint(c,reason,service=None):
   active[0]=True
   try:return original_checkpoint(c,reason,service)
   finally:active[0]=False
  def archive(c,r):
   original_archive(c,r)
   if active[0] and not fired[0]:
    fired[0]=True
    if kind=='stop':capture.atomic(root/'control.json',{'sequence':2,'command':'stop'})
    else:now[0]+=2701 if kind=='deadline' else .26
  traps={s:signal.getsignal(s) for s in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
  try:
   with patch.object(logs,'start',seeded),patch.object(logs.Capture,'checkpoint',checkpoint),patch.object(logs.Capture,'_archive',archive),patch.object(capture.time,'monotonic',lambda:now[0]):code=capture.run_collector(root/'RUN.json')
  finally:
   for s,h in traps.items():signal.signal(s,h)
  result=json.loads((root/'collector-receipt.json').read_text());assert fired[0] and code==1 and result['integrityComplete'] is False
  assert result['exitReason']=={'stop':'stop','deadline':'deadline','gap':'failure'}[kind],result
  if kind=='gap':assert 'gap' in result['error']
  if kind=='stop':assert result['lastSequence']==2
  print('PASS cooperative control',kind)
