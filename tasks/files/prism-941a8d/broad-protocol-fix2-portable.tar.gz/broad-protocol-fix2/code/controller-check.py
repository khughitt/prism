import importlib.util, math, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
assert (ROOT/'controller.py').exists(), 'controller budget/reservation implementation missing'
s=importlib.util.spec_from_file_location('controller',ROOT/'controller.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
def refuses(fn):
 try: fn()
 except (ValueError,AssertionError,PermissionError): return
 raise AssertionError('unsafe operation permitted')
assert c.reserve([100])==125
assert c.reserve([144])==180
refuses(lambda:c.reserve([144.000001]))
w=c.Window(100,{'pre':10,'post':10,'recovery':10,'finish':10})
w.stamp('initialCardIssued',110);w.stamp('initialCompleteReceived',1310);w.stamp('completenessChecked',1320)
assert w.controller_seconds(1320)==20
assert w.request_recovery(1320,30)==1570
refuses(lambda:w.approve(1571,30))
w.approve(1570,30);w.issue_recovery(1570,30)
w.stamp('recoveryCompleteReceived',2170);w.stamp('finishSent',2180);w.stamp('collectorExited',2190)
assert w.controller_seconds(2190)==290
for now,ok in [(1480,False),(1470,True)]:
 x=c.Window(0,{'finish':24});x.stamp('initialCardIssued',1);x.stamp('initialCompleteReceived',1201);x.stamp('completenessChecked',1202)
 if ok: assert x.can_issue(now,30)
 else: assert not x.can_issue(now,30)
x=c.Window(0,{'finish':1});x.stamp('initialCardIssued',1);x.stamp('initialCompleteReceived',1202)
assert x.invalid and x.stamps['initialCompleteReceived']==1202
assert not x.can_issue(2100,1)
assert c.Window(0,{'finish':1}).can_initial(298,2)
assert not c.Window(0,{'finish':1}).can_initial(299,2)
print('PASS reservation boundaries; initial20min; approval wait and full600; expiry retains observations')
import copy,json,tempfile,shutil
assert hasattr(c,'materialize'),'independent operation context missing'
saved={'pair':{'P':'P','Q':'Q'},'runtime':{'active':{'profile':'P'},'scratch':{}},'profiles':{'P':{'a':.2,'b':.5},'Q':{'a':.7,'b':.8}},'uneditedNumeric':[{'key':'a'}]}
defs={'a':{'type':'float','range':[0,1]},'b':{'type':'float','range':[0,1]}}
manifest={'cardId':'c','activationNonce':'n','operations':[{'id':'c:action:1','kind':'release','key':'a'},{'id':'c:action:2','kind':'restore','key':'a'},{'id':'c:action:3','kind':'profile','profile':'Q'},{'id':'c:action:4','kind':'profile','profile':'P'}]}
events=[{'class':'operationRequested','operationKind':'release','valid':True,'operationId':'c:action:1','key':'a','recordId':1,'callbackId':0,'acceptGeneration':4},
 {'class':'release','scope':'callback','operationId':'c:action:1','recordId':2,'callbackId':2,'endTimestamp':10,'acceptGeneration':4},
 {'class':'operationIntent','scope':'observer','observer':True,'callbackId':0,'operationId':'c:action:1','key':'a','recordId':3,'releaseCallbackId':2,'startTimestamp':10.01,'endTimestamp':10.02,'timestamp':10.03,'acceptGeneration':4,'canonicalValue':.21,'valueText':'0.21'},
 {'class':'acceptedReference','valid':True,'operationId':'c:action:1','recordId':4,'timestamp':11,'acceptGeneration':5}]
ctx=c.materialize(manifest,saved,defs,events,True)
assert ctx['operations'][0]['expectedReference']=={'acceptedProfile':'P','acceptedWallpaper':False,'values':{'a':.21,'b':.5},'heldScratchKeys':['a']}
assert ctx['operations'][1]['expectedReference']['heldScratchKeys']==[]
assert ctx['operations'][2]['expectedReference']['values']=={'a':.7,'b':.8}
for field,value in [('key','b'),('canonicalValue',.3),('valueText','0.22'),('acceptGeneration',3),('releaseCallbackId',9),('startTimestamp',9)]:
 bad=copy.deepcopy(events);bad[2][field]=value;refuses(lambda:c.materialize(manifest,saved,defs,bad,True))
refuses(lambda:c.materialize(manifest,saved,defs,events+[events[2]],True))
refuses(lambda:c.materialize(manifest,saved,defs,events[:2]+events[3:],True))
for altered in [{'a':.22,'b':.5},{'a':.21,'b':.6},{'a':.2,'b':.21}]:
 assert not c.analyze.exact_reference(ctx['operations'][0]['expectedReference'],dict(ctx['operations'][0]['expectedReference'],values=altered))
rounded=copy.deepcopy(events);rounded[2].update(canonicalValue=.30000000000000004,valueText='0.30000000000000004')
assert c.materialize(manifest,saved,defs,rounded,True)['operations'][0]['expectedReference']['values']['a']==.30000000000000004
rounded[2]['valueText']='0.3';refuses(lambda:c.materialize(manifest,saved,defs,rounded,True))
print('PASS independent intent oracle; wrong key/value/other param, duplicate/stale/timing, exact Queue serialization refused')
assert (ROOT/'clock-gate.py').exists(),'independent Noctalia clock gate missing'
cg=c.module('clock_gate',ROOT/'clock-gate.py')
actual={'bootId':'new-boot','installed':{'path':'/fixture/noctalia','sha256':'bin','buildId':'build','package':'noctalia 5.2.1-1'},'running':{'pid':123,'startTicks':456,'sha256':'bin','buildId':'build'},'sourceRevision':cg.REVISION,'sourceFiles':cg.SOURCE_HASHES,'pythonMonotonic':'clock_gettime(CLOCK_MONOTONIC)','packageFiles':{'PKGINFO':'pkg','BUILDINFO':'buildinfo'}}
proof={'schema':2,'environment':'live','sessionId':'root-session','observed':actual,'binding':{'rootSessionId':'root-session','sourceRevision':cg.REVISION,'binarySha256':'bin','package':'noctalia 5.2.1-1','noHostClockOverride':True,'linuxClock':'CLOCK_MONOTONIC','originOffsetSeconds':0},'excerpts':{k:{'fileSha256':v,'firstLine':1,'text':'fixture'} for k,v in cg.SOURCE_HASHES.items()}}
historical={'controllerOrigin':'host-monotonic:old-boot','origins':['host-monotonic:old-boot'],'probeOrigin':'historical-nonce','probeTimestamp':294942.885733029,'controllerTimestamp':294942.898069801,'rawSha256':'raw','phasesSha256':'phases'}
assert cg.verify(proof,actual,historical)['clockOrigin']=='host-monotonic:new-boot'
for path,value in [(('observed','bootId'),'bad'),(('observed','running','buildId'),'bad'),(('observed','installed','package'),'bad'),(('binding','linuxClock'),'CLOCK_PROCESS_CPUTIME_ID'),(('binding','noHostClockOverride'),False), (('binding','originOffsetSeconds'),1)]:
 bad=copy.deepcopy(proof);obj=bad
 for key in path[:-1]:obj=obj[key]
 obj[path[-1]]=value;refuses(lambda:cg.verify(bad,actual,historical))
refuses(lambda:cg.verify({},actual,historical))
for timestamp in [294942.884,294945.898]:refuses(lambda:cg.verify(proof,actual,dict(historical,controllerTimestamp=timestamp)))
refuses(lambda:cg.verify(proof,actual,dict(historical,origins=['host-monotonic:other-boot'])))
print('PASS clock source/build/boot/override/missing-proof and historical reverse/offset negatives; old boot remains historical')
import subprocess,time
# Root authorization is checked before even a harmless injected command executes.
with tempfile.TemporaryDirectory() as td:
 root=pathlib.Path(td);spec={'argv':[sys.executable,'-c','print("{}")'],'json':True,'timeoutSeconds':2}
 session={'sessionId':'s','runId':'r','hostActions':{'finish-authorize':spec}}
 rh=c.RootHost(root,session);now=time.monotonic();permit={'id':'one','action':'finish-authorize','arguments':spec,'issuedAt':now,'expiresAt':now+30}
 auth={'approved':True,'author':'root-controller','sessionId':'s','runId':'r','bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'permits':[permit]}
 path=root/'auth.json';c.immutable(path,auth);assert rh.invoke('finish-authorize',path,spec)['authorized'] is True
 try:rh.invoke('finish-authorize',path,spec)
 except FileExistsError:pass
 else:raise AssertionError('replayed permit accepted')
 for field,value in [('approved',False),('author','worker'),('sessionId','other'),('bootId','other')]:
  bad=copy.deepcopy(auth);bad[field]=value;bad['permits'][0]['id']='new';c.atomic(path,bad);refuses(lambda:rh.invoke('finish-authorize',path,spec))
 bad=copy.deepcopy(auth);bad['permits'][0].update(id='late',issuedAt=now-100,expiresAt=now-1);c.atomic(path,bad);refuses(lambda:rh.invoke('finish-authorize',path,spec))
print('PASS fresh root/session/boot/exact-argv/one-use authorization; replay/stale/worker denied')
assert c.capture_limits(4*1024*1024,1024,1)['fileFillSeconds']==60
limits=c.capture_limits(100000,1000000,1);assert limits['pollSeconds']==.025 and limits['maxGapSeconds']==.05
refuses(lambda:c.capture_limits(100,0,1))
# Literal link restoration and conflict protection run solely inside a temp directory.
with tempfile.TemporaryDirectory() as td:
 root=pathlib.Path(td);pointer=root/'plugin';pointer.symlink_to('../literal-original')
 spec={'path':str(pointer),'from':'../literal-original','to':'./candidate'}
 rh=c.RootHost(root,{'sessionId':'s','runId':'r','hostActions':{'pointer-swap':spec}})
 now=time.monotonic();auth={'approved':True,'author':'root-controller','sessionId':'s','runId':'r','bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'permits':[{'id':'pointer-one','action':'pointer-swap','arguments':spec,'issuedAt':now,'expiresAt':now+30}]}
 path=root/'auth.json';c.immutable(path,auth);assert rh.invoke('pointer-swap',path,spec)['from']=='../literal-original'
 assert c.os.readlink(pointer)=='./candidate'
 auth['permits'][0]['id']='pointer-two';c.atomic(path,auth);refuses(lambda:rh.invoke('pointer-swap',path,spec));assert c.os.readlink(pointer)=='./candidate'
print('PASS measured rate caps and literal temp-pointer journal/conflict guard')
extra=copy.deepcopy(events[2]);extra['operationId']='undeclared';extra['recordId']=5
refuses(lambda:c.materialize(manifest,saved,defs,events+[extra],True))
print('PASS undeclared extra release intent cannot enter immutable owner context')
