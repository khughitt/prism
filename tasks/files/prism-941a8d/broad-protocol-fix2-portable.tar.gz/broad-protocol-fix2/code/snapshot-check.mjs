import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'prism-controller-snapshot-'));
process.env.PRISM_CONFIG_DIR=path.join(temp,'config');process.env.PRISM_STATE_DIR=path.join(temp,'state');
const repo=process.env.PRISM_TASK3_REPO;
const {loadDefs}=await import(`${repo}/src/defs.js`);const {defsDir}=await import(`${repo}/src/paths.js`);
const {writeRuntime}=await import(`${repo}/src/contexts.js`);
const defs=loadDefs(defsDir());
try {
 const dir=path.join(temp,'config/contexts/profile');fs.mkdirSync(dir,{recursive:true});
 fs.writeFileSync(path.join(dir,'P.yaml'),'glass.inactive.roughness: 0.4\n');
 fs.writeFileSync(path.join(dir,'Q.yaml'),[...defs].filter(([,d])=>['float','int'].includes(d.type)).map(([key,d])=>`${key}: ${d.default===d.range[0]?d.range[1]:d.range[0]}`).join('\n')+'\n');
 writeRuntime({active:{profile:'P'},scratch:{}});
 const script=new URL('./snapshot.mjs',import.meta.url).pathname;
 const bundle=path.join(temp,'bundle.json'),saved=path.join(temp,'saved.json');
 execFileSync(process.execPath,[script,bundle,saved],{env:process.env});
 const b=JSON.parse(fs.readFileSync(bundle));assert.deepEqual(b.saved,JSON.parse(fs.readFileSync(saved)));assert.equal(Object.keys(b.definitions).length,83);assert.equal(b.saved.pair.P,'P');assert.equal(b.saved.pair.Q,'Q');assert.equal(Object.keys(b.resolverSources).length,5);
 assert.equal(fs.statSync(bundle).mode&0o777,0o600);
 console.log('PASS locked temporary snapshot bundle/definitions/raw documents/resolver hashes and unchanged state helper format');
} finally {fs.rmSync(temp,{recursive:true,force:true});}
