#!/usr/bin/env python3
import argparse,json,math
from collections import defaultdict
from pathlib import Path
from statistics import median
CLASSES=('coldRender','dragTick','release','changedDescribe','deferredRender','profileRender')

def spread_limit(values):
    center=median(values)
    return max(1.0,median(abs(x-center) for x in values))

def number(value,label):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0: raise ValueError('invalid '+label)
    return value

def stage_name(stage):
    if stage not in ('stage1','stage2'): raise ValueError('invalid stage')

def boolean(obj,key):
    if type(obj.get(key)) is not bool: raise ValueError('invalid boolean '+key)
    return obj[key]

def decide(stage,blocks,evidence,launch_complete):
    stage_name(stage)
    if not isinstance(evidence,dict) or type(launch_complete) is not bool or not isinstance(blocks,list): raise ValueError('invalid decision input')
    flags=('integrityComplete','referenceComplete','identityComplete','correctnessComplete','errorComplete','correct')
    for key in flags: boolean(evidence,key)
    if stage=='stage2':
        for key in ('stage1Certified','launchIdentityComplete','launchGroupsComplete','restorationComplete','clockOriginVerified'):boolean(evidence,key)
        if evidence.get('environment') not in ('live','fake-host','synthetic'):raise ValueError('invalid environment')
    errors=evidence.get('budgetErrors')
    if 'budgetErrors' not in evidence or errors is not None and (type(errors) is not int or errors<0): raise ValueError('invalid budgetErrors')
    needed=('coldRender',) if stage=='stage1' else CLASSES
    complete=len(blocks)==2
    for block in blocks:
        if not isinstance(block,dict): raise ValueError('invalid block')
        for variant in ('baseline','candidate'):
            values=block.get(variant,{})
            if not isinstance(values,dict): raise ValueError('invalid variant')
            for key,items in values.items():
                if key not in CLASSES or not isinstance(items,list): raise ValueError('invalid sample class')
                for value in items:number(value,'sample')
            complete=complete and all(len(values.get(key,[]))>=5 for key in needed)
    result=dict(comparison='inconclusive',accepted=False,return_to_design=True,stage2Eligible=False)
    if stage=='stage1':result['ownerHeavyClasses']='not_run'
    if not complete or not all(evidence[key] for key in flags if key!='correct') or errors is None or stage=='stage1' and (not evidence['correct'] or errors!=0):
        return result|{'reason':'incomplete_or_invalid_evidence'}
    if stage=='stage2' and (not evidence['correct'] or errors!=0):return result|dict(comparison='revert',reason='correctness_or_budget_failed')
    gain=all(median(b['baseline']['coldRender'])-median(b['candidate']['coldRender'])>spread_limit(b['baseline']['coldRender']) for b in blocks)
    if not gain:return result|dict(comparison='revert',reason='cold_gain_failed',coldGainPassed=False)
    cold_target=all(median(b['candidate']['coldRender'])<15 for b in blocks)
    result|=dict(coldGainPassed=True,coldTargetPassed=cold_target)
    if stage=='stage1':
        if not cold_target:return result|{'reason':'cold_target_failed'}
        if not launch_complete:return result|{'reason':'launch_incomplete'}
        return result|dict(comparison='pending_stage2',return_to_design=False,stage2Eligible=True,reason='stage1_passed')
    regression=any(median(b['candidate'][k])-median(b['baseline'][k])>spread_limit(b['baseline'][k]) for b in blocks for k in CLASSES if k!='coldRender')
    if regression:return result|dict(comparison='revert',reason='target_regression')
    absolute=all(median(b['candidate'][k])<15 if k in ('coldRender','profileRender') else median(b['candidate'][k])<=12 for b in blocks for k in CLASSES)
    certified=launch_complete and all(evidence[k] for k in ('stage1Certified','launchIdentityComplete','launchGroupsComplete','restorationComplete','clockOriginVerified')) and evidence['environment']=='live'
    return result|dict(comparison='keep',accepted=absolute and certified,return_to_design=not (absolute and certified),reason='accepted' if absolute and certified else 'absolute_target_failed' if not absolute else 'acceptance_evidence_incomplete',calibration=evidence['environment']!='live')

def estimate(stage,pilot):
    stage_name(stage)
    if not isinstance(pilot,dict):raise ValueError('invalid pilot')
    for gate in ('collectionComplete','operationGatesComplete'):
        if boolean(pilot,gate) is not True:raise ValueError('incomplete pilot '+gate)
    try:
        seconds=number(pilot['occupancySeconds'],'occupancySeconds')+number(pilot['analysisSeconds'],'analysisSeconds')
        activations=pilot['activations']
        if not isinstance(activations,list) or len(activations)!=4:raise ValueError('four measured activations required')
        for activation in activations:
            seconds+=4*number(activation['coldUnitSeconds'],'coldUnitSeconds')
            if stage=='stage2':
                seconds+=4*number(activation['releaseRestoreUnitSeconds'],'releaseRestoreUnitSeconds')
                seconds+=2*number(activation['profileCycleUnitSeconds'],'profileCycleUnitSeconds')
        if stage=='stage1':
            for key in ('launchUnitSeconds','controlUnitSeconds'):
                if not isinstance(pilot[key],list) or len(pilot[key])!=2:raise ValueError('two measured '+key+' required')
                seconds+=4*sum(number(x,key) for x in pilot[key])
    except (KeyError,TypeError) as exc:raise ValueError('missing/invalid pilot field') from exc
    return math.ceil(seconds*1.25/60)

def read_rotated(segments,offset=0):
    data=b''.join(Path(p).read_bytes() for p in segments)
    if offset<0 or offset>len(Path(segments[0]).read_bytes()): raise ValueError('invalid saved log offset')
    events=[]
    for line in data[offset:].decode().splitlines():
        marker='prism-budget '
        if marker in line:
            payload=line.split(marker,1)[1]
            def unique(pairs):
                out={}
                for k,v in pairs:
                    if k in out: raise ValueError('duplicate JSON field '+k)
                    out[k]=v
                return out
            events.append(json.loads(payload,object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON number"))))
    return events

REF_FIELDS=('acceptedProfile','acceptedWallpaper','values','heldScratchKeys')
SCOPES=('callback','render','nativeLaunch','launchHelper','observer','metadata','activation','interval')

def string(value,label):
    if not isinstance(value,str) or not value:raise ValueError('invalid '+label)
    return value

def integer(value,label,minimum=0):
    if type(value) is not int or value<minimum:raise ValueError('invalid '+label)
    return value

def array(value,label):
    # Lua's encoder represents an explicitly empty table as {}, never as missing.
    if value=={} and type(value) is dict:return []
    if not isinstance(value,list):raise ValueError('invalid '+label)
    return value

def ids(value,label):
    result=array(value,label)
    for item in result:string(item,label)
    if len(set(result))!=len(result):raise ValueError('duplicate '+label)
    return result

def exact(left,right):
    if type(left) in (int,float) and type(right) in (int,float):return left==right
    if type(left) is not type(right):return False
    if isinstance(left,dict):return left.keys()==right.keys() and all(exact(left[k],right[k]) for k in left)
    if isinstance(left,list):return len(left)==len(right) and all(exact(x,y) for x,y in zip(left,right))
    return left==right

def reference_value(item):
    if type(item) in (int,float):
        if not math.isfinite(item):raise ValueError('invalid reference number')
    elif type(item) in (str,bool):pass
    elif isinstance(item,list):
        for value in item:reference_value(value)
    elif isinstance(item,dict):
        for key,value in item.items():string(key,'reference value key');reference_value(value)
    else:raise ValueError('invalid reference value')

def reference(value):
    if not isinstance(value,dict) or any(key not in value for key in REF_FIELDS):raise ValueError('missing expected reference')
    if value['acceptedProfile'] is not False and not isinstance(value['acceptedProfile'],str):raise ValueError('invalid acceptedProfile')
    wall=value['acceptedWallpaper']
    if isinstance(wall,dict):
        if set(wall)!={'id','path'} or any(not isinstance(wall[k],str) for k in wall):raise ValueError('invalid acceptedWallpaper')
    elif wall is not False and not isinstance(wall,str):raise ValueError('invalid acceptedWallpaper')
    values=value['values']
    if not isinstance(values,dict) or not values:raise ValueError('invalid reference values')
    for key,item in values.items():
        string(key,'reference key')
        reference_value(item)
    held=ids(value['heldScratchKeys'],'heldScratchKeys')
    if held!=sorted(held) or any(k not in values for k in held):raise ValueError('invalid scratch keys')
    return {k:held if k=='heldScratchKeys' else value[k] for k in REF_FIELDS}

def exact_reference(left,right):return exact(reference(left),reference(right))

def declared_operations(value):
    result=array(value,'operations');seen=set()
    for op in result:
        if not isinstance(op,dict):raise ValueError('invalid operation')
        kind=op.get('kind')
        if kind not in ('release','restore','profile'):raise ValueError('invalid operation kind')
        field='profile' if kind=='profile' else 'key'
        if set(op)!={'id','kind',field,'expectedReference'}:raise ValueError('invalid declared operation fields')
        name=string(op['id'],'operation id');string(op[field],field);reference(op['expectedReference'])
        if name in seen:raise ValueError('duplicate declared operation')
        seen.add(name)
    return result

def diagnostic_operations(card,colds,launches):
    return ([dict(id=f'{card}:cold:{n}',kind='cold') for n in range(1,colds+1)]+
        [dict(id=f'{card}:{kind}:{n}',kind=kind) for n in range(1,launches+1) for kind in ('launch','control')])

def endpoints(event):
    start=number(event.get('startTimestamp'),'startTimestamp');end=number(event.get('endTimestamp'),'endTimestamp')
    if end<start or end>event['timestamp']:raise ValueError('reversed/future endpoints')
    if not math.isclose(event['elapsedMs'],(end-start)*1000,rel_tol=1e-9,abs_tol=1e-6):raise ValueError('elapsedMs differs from endpoints')
    return start,end

def snapshot(event,drain=False):
    true=('queueIdle','dragEmpty','open','modelReady','pairEmpty','comparisonCallbacksComplete','allRackExpanded')
    false=('queueInFlight','describeRunning','renderPending','refreshPending','refreshAfterDrag','describeInvalidated','selectionPending','help','pairPending','errorSticky')
    for key in true+false+('bufferEmpty','sequenceComplete','readyEligible','physicalDrain','eligibleDrain','pairFrameDone'):boolean(event,key)
    integer(event.get('queuePendingCount'),'queuePendingCount');integer(event.get('bufferCount'),'bufferCount')
    expanded=ids(event.get('expandedIds'),'expandedIds');rack=ids(event.get('rackIds'),'rackIds')
    if expanded!=sorted(expanded) or rack!=sorted(rack):raise ValueError('unsorted rack ids')
    ids(event.get('requestedOperationIds'),'requestedOperationIds')
    if event.get('referenceId') is not False:integer(event.get('referenceId'),'referenceId',1)
    if 'errorText' not in event or not (event['errorText'] is False or isinstance(event['errorText'],str)):raise ValueError('invalid errorText')
    if 'currentProfile' not in event or 'sequencePhase' not in event:raise ValueError('missing snapshot facts')
    endpoints(event)
    return (event['referenceId'] is not False and all(event[k] for k in true) and not any(event[k] for k in false) and event['queuePendingCount']==0 and event['errorText'] is False and expanded==rack and bool(rack) and
        (event['sequenceComplete'] and event['physicalDrain'] and event['eligibleDrain'] and event['bufferEmpty'] and event['bufferCount']==0 if drain else event['readyEligible'] and event['sequencePhase']=='setup'))

def normalize(events,identities,cards,authorizations):
    if not isinstance(events,list) or not isinstance(identities,list) or not isinstance(cards,dict) or not isinstance(authorizations,dict):raise ValueError('invalid normalization context')
    expected={};positions=set()
    for identity in identities:
        if not isinstance(identity,dict) or identity.get('schema')!=2 or type(identity.get('schema')) is not int:raise ValueError('schema2 identity required')
        nonce=string(identity.get('activationNonce'),'activationNonce');stage_name(identity.get('stage'))
        if nonce in expected or (identity.get('stage'),identity.get('block'),identity.get('variant')) in positions:raise ValueError('duplicate/pooling identity')
        if identity.get('variant') not in ('baseline','candidate') or identity.get('block') not in ('1','2') or identity.get('environment') not in ('live','fake-host','synthetic'):raise ValueError('invalid identity enum')
        for key in ('sourceCommit','sourceHash','runId','cardId','clockOrigin'):string(identity.get(key),key)
        if not isinstance(identity.get('sourceSha256'),dict) or not identity['sourceSha256']:raise ValueError('missing sourceSha256')
        for key,item in identity['sourceSha256'].items():string(key,'source path');string(item,'source digest')
        for key,allowed in (('coldPairs',(1,5)),('launchPairs',(0,1,5))):
            if type(identity.get(key)) is not int or identity[key] not in allowed:raise ValueError('invalid '+key)
        expected[nonce]=identity;positions.add((identity['stage'],identity['block'],identity['variant']))
    if set(cards)!=set(expected) or not set(authorizations)<=set(expected):raise ValueError('missing/stale card context')
    per=defaultdict(list);samples=[];exclusions=[];certificates=[]
    common_bool=('rendered','accepted','pending','complete','control','diagnosticsHidden','targetEligible')
    timed=('callback','render','interval','observer','nativeLaunch','launchHelper')
    for event in events:
        if not isinstance(event,dict):raise ValueError('event must be object')
        nonce=event.get('activationNonce');identity=expected.get(nonce)
        if identity is None:raise ValueError('unknown/stale activation nonce')
        if type(event.get('schema')) is not int or event['schema']!=2:raise ValueError('schema2 records required')
        for key in ('variant','sourceCommit','sourceHash','sourceSha256','block','stage','runId','environment','clockOrigin'):
            if not exact(event.get(key),identity[key]):raise ValueError('identity mismatch: '+key)
        string(event.get('class'),'class');string(event.get('cardId'),'cardId')
        if event.get('scope') not in SCOPES:raise ValueError('invalid scope')
        for key in common_bool:boolean(event,key)
        string(event.get('phase'),'phase');string(event.get('outcome'),'outcome')
        for key in ('recordId','callbackId','acceptGeneration','profileGeneration'):integer(event.get(key),key,1 if key=='recordId' else 0)
        for key in ('pairId','interference','operationId','replacementId'):
            if event.get(key) is not False:string(event.get(key),key)
        ids(event.get('replacementFor'),'replacementFor')
        number(event.get('timestamp'),'timestamp');number(event.get('elapsedMs'),'elapsedMs')
        if event['scope'] in timed:endpoints(event)
        if event['class'] in ('ready','drain'):
            if event['scope']!='metadata' or boolean(event,'observer') is not True:raise ValueError('invalid snapshot scope')
            snapshot(event,event['class']=='drain')
        if event['class']=='acceptedReference':
            if event['scope']!='observer' or boolean(event,'observer') is not True:raise ValueError('reference must be observer')
            boolean(event,'valid')
            if 'reason' not in event or not (event['reason'] is False or isinstance(event['reason'],str)):raise ValueError('missing reference reason')
            if event['valid']:reference(event)
            elif event.get('values')!={} or array(event.get('heldScratchKeys'),'heldScratchKeys'):raise ValueError('invalid superseded reference maps')
        if event['class']=='operationRequested':
            if event['scope']!='metadata':raise ValueError('invalid request scope')
            boolean(event,'valid')
            if event.get('operationKind') not in ('cold','launch','control','release','restore','profile'):raise ValueError('invalid requested kind')
        if event['class']=='operationDone':
            if event['scope']!='metadata':raise ValueError('invalid completion scope')
            for key in ('referenceId','callbackIdTarget','renderIdTarget'):integer(event.get(key),key,1)
            if event.get('operationKind') not in ('release','restore','profile') or event.get('targetClass') not in ('deferredRender','profileRender'):raise ValueError('invalid done enum')
        if event['class']=='cardSettled':
            if event['scope']!='metadata':raise ValueError('invalid settlement scope')
            ids(event.get('requestedOperationIds'),'requestedOperationIds');integer(event.get('drainRecordId'),'drainRecordId',1)
            for key in ('eligibleDrain','bufferEmpty'):boolean(event,key)
        per[nonce].append(event)
    if set(per)!=set(expected):raise ValueError('missing activation records')
    for nonce,records in per.items():
        identity=expected[nonce];records.sort(key=lambda e:e['recordId']);byid={e['recordId']:e for e in records}
        if len(byid)!=len(records) or [e['recordId'] for e in records]!=list(range(1,len(records)+1)):raise ValueError('duplicate/gapped record ids')
        if any(b['timestamp']<a['timestamp'] for a,b in zip(records,records[1:])):raise ValueError('nonmonotonic record construction')
        first=records[0]
        if first['class']!='activation' or first['scope']!='activation' or sum(e['class']=='activation' for e in records)!=1 or not first['complete']:raise ValueError('missing fresh activation')
        for key in ('initialModelEmpty','initialStructureEmpty','initialMemoEmpty','initialDragEmpty','initialQueueEmpty','initialPairEmpty'):
            if boolean(first,key) is not True:raise ValueError('runtime not reset '+key)
        if boolean(first,'initialRenderPending') or integer(first.get('initialEnqueued'),'initialEnqueued')!=0:raise ValueError('runtime not reset')
        card=cards[nonce]
        if not isinstance(card,dict) or set(card)!={'cardId','operations','reference','operationGatesComplete','originVerified'} or card['cardId']!=identity['cardId']:raise ValueError('invalid action card')
        ops=declared_operations(card['operations']);reference(card['reference'])
        gate=boolean(card,'operationGatesComplete');origin=boolean(card,'originVerified')
        original=diagnostic_operations(card['cardId'],identity['coldPairs'],identity['launchPairs'])+ops
        plans={card['cardId']:original};card_refs={card['cardId']:card['reference']};recovery=None
        accepted=[e for e in records if e['class']=='recoveryAccepted']
        if len(accepted)>1:raise ValueError('second recovery cannot count')
        if accepted:
            context=authorizations.get(nonce)
            if not isinstance(context,dict) or set(context)!={'manifest','ownerApproved','originVerified','operations'}:raise ValueError('missing exact recovery authorization context')
            owner_approved=boolean(context,'ownerApproved');authorization_origin=boolean(context,'originVerified')
            authorized=owner_approved and authorization_origin
            m=context['manifest']
            fields={'schema','approved','runId','activationNonce','cardId','replacementFor','coldPairs','launchPairs','operations'}
            if not isinstance(m,dict) or set(m)!=fields or type(m['schema']) is not int or m['schema']!=2 or m['approved'] is not True or m['runId']!=identity['runId'] or m['activationNonce']!=nonce:raise ValueError('malformed/stale/unapproved manifest')
            rid=string(m['cardId'],'recovery cardId')
            if rid==card['cardId']:raise ValueError('recovery card not fresh')
            for key in ('coldPairs','launchPairs'):
                if type(m[key]) is not int or m[key] not in (0,1):raise ValueError('excess recovery unit')
            replacements=ids(m['replacementFor'],'replacementFor')
            if not replacements or not set(replacements)<=set(op['id'] for op in original):raise ValueError('invalid replacement originals')
            manual=declared_operations(context['operations'])
            if not exact(m['operations'],[{k:v for k,v in op.items() if k!='expectedReference'} for op in manual]):raise ValueError('authorization operation mismatch')
            kinds=[op['kind'] for op in manual];release=[op for op in manual if op['kind']=='release'];restore=[op for op in manual if op['kind']=='restore'];profiles=[op for op in manual if op['kind']=='profile']
            if len(release)>1 or len(release)!=len(restore) or release and release[0]['key']!=restore[0]['key'] or len(profiles) not in (0,2) or len({op['profile'] for op in profiles})!=len(profiles):raise ValueError('invalid combined recovery')
            planned=diagnostic_operations(rid,m['coldPairs'],m['launchPairs'])+manual
            names=[op['id'] for op in planned]
            if not planned or len(set(names))!=len(names) or set(names)&set(op['id'] for op in original):raise ValueError('empty/colliding recovery')
            e=accepted[0]
            if e['cardId']!=rid or e['replacementId']!=rid or ids(e['replacementFor'],'replacementFor')!=replacements or ids(e.get('requestedOperationIds'),'requestedOperationIds')!=names:raise ValueError('recovery acceptance mismatch')
            prior_drains=[d for d in records if d['class']=='drain' and d['recordId']<e['recordId']]
            authorized=authorized and bool(prior_drains and snapshot(prior_drains[-1],True))
            plans[rid]=planned;card_refs[rid]=card['reference'];recovery=(e,m,authorized)
        for e in records:
            if e['cardId'] not in plans:raise ValueError('unknown card')
            replacement=e['cardId']!=card['cardId']
            if replacement:
                if not recovery or e['replacementId']!=e['cardId'] or ids(e['replacementFor'],'replacementFor')!=recovery[1]['replacementFor']:raise ValueError('stale replacement labels')
                if e['recordId']<recovery[0]['recordId'] and not (e['class']=='recoveryAdministration' and e['scope']=='render' and e['callbackId']==recovery[0]['callbackId']):raise ValueError('target before recovery acceptance')
            elif e['replacementId'] is not False or array(e['replacementFor'],'replacementFor'):raise ValueError('unexpected original replacement label')
        callbacks={}
        eligible=[]
        for e in records:
            if e['scope']=='callback':
                if e['callbackId'] in callbacks:raise ValueError('duplicate callback span')
                callbacks[e['callbackId']]=e
            reason=None
            if e['scope'] in ('callback','render','nativeLaunch','launchHelper') and e['callbackId']==0:reason='callback-id-zero'
            elif not e['complete']:reason='incomplete-span'
            elif e['interference']:reason='interference:'+e['interference']
            elif e['class'] in CLASSES:
                if not e['diagnosticsHidden']:reason='diagnostic-control-visible'
                elif not e['targetEligible']:reason='target-ineligible'
                elif e['class']=='changedDescribe' and not e['accepted']:reason='describe-not-accepted'
                elif e['class']!='changedDescribe' and not e['rendered']:reason='no-real-render'
            if reason:exclusions.append(dict(event=e,reason=reason))
            else:eligible.append(e)
        eligible_ids={e['recordId'] for e in eligible}
        for e in eligible:
            if e['scope'] in ('render','nativeLaunch','launchHelper'):
                end=callbacks.get(e['callbackId'])
                if end is None or end['recordId'] not in eligible_ids or end['recordId']<=e['recordId'] or not(end['startTimestamp']<=e['startTimestamp']<=e['endTimestamp']<=end['endTimestamp']):
                    eligible_ids.discard(e['recordId']);exclusions.append(dict(event=e,reason='missing-or-incomplete-callback-end'))
        for e in eligible:
            if e['scope']=='callback' and e['class'] in CLASSES and e['class']!='changedDescribe':
                renders=[r for r in eligible if r['scope']=='render' and r['recordId'] in eligible_ids and r['callbackId']==e['callbackId'] and r['class']==e['class'] and r['operationId']==e['operationId'] and r['acceptGeneration']==e['acceptGeneration']]
                if not renders:
                    eligible_ids.discard(e['recordId']);exclusions.append(dict(event=e,reason='missing-real-render'))
        launch=pairs(dict(events=records,samples=[e for e in eligible if e['recordId'] in eligible_ids]))
        completed={};ready_ok={};settled={};fatal=False
        for cardid,planned in plans.items():
            names=[op['id'] for op in planned];manual_ids={op['id'] for op in planned if op['kind'] in ('release','restore','profile')}
            ready=[e for e in records if e['class']=='ready' and e['cardId']==cardid]
            valid_ready=[]
            for e in ready:
                ref=byid.get(e['referenceId'])
                if snapshot(e) and ref and ref['class']=='acceptedReference' and ref['valid'] and ref['cardId']==cardid and ref['operationId']==cardid+':reference' and ref['acceptGeneration']==e['acceptGeneration'] and ref['recordId']<e['recordId'] and exact_reference(ref,card_refs[cardid]) and ids(e['requestedOperationIds'],'requestedOperationIds')==[op['id'] for op in planned if op['id'] not in manual_ids]:valid_ready.append(e)
            ready_ok[cardid]=len(valid_ready)==1
            requests=[e for e in records if e['class']=='operationRequested' and e['cardId']==cardid]
            requested=[e['operationId'] for e in requests]
            if len(set(requested))!=len(requested) or not set(requested)<=set(names):fatal=True
            order=[e['operationId'] for e in requests if e['operationId'] in manual_ids]
            expected_order=[op['id'] for op in planned if op['id'] in manual_ids]
            if order!=[name for name in expected_order if name in order]:fatal=True
            for op in planned:
                name=op['id'];req=[e for e in requests if e['operationId']==name]
                if len(req)!=1 or not req[0]['valid'] or req[0]['operationKind']!=op['kind'] or not valid_ready or req[0]['recordId']<=valid_ready[0]['recordId']:continue
                selected=[e for e in eligible if e['recordId'] in eligible_ids and e['cardId']==cardid and e['operationId']==name]
                if op['kind']=='cold':
                    ends=[e for e in selected if e['class']=='coldRender' and e['scope']=='callback']
                    renders=[e for e in selected if e['class']=='coldRender' and e['scope']=='render']
                    spans=[e for e in selected if e['class']=='coldPairInterval' and e['scope']=='interval']
                    setups=[e for e in selected if e['class']=='coldSetup' and e['scope']=='callback' and e['accepted']]
                    if len(ends)==len(renders)==len(spans)==len(setups)==1:
                        end,render,span,setup=ends[0],renders[0],spans[0],setups[0]
                        if end['callbackId']==render['callbackId']!=setup['callbackId'] and setup['acceptGeneration']==render['acceptGeneration']==end['acceptGeneration']==span['acceptGeneration']>req[0]['acceptGeneration'] and req[0]['recordId']<setup['recordId']<render['recordId']<span['recordId']<end['recordId'] and setup['startTimestamp']<=span['startTimestamp']<=setup['endTimestamp']<=render['startTimestamp']<=render['endTimestamp']<=span['endTimestamp']<=end['endTimestamp']:completed[name]=op
                elif op['kind'] in ('launch','control'):
                    done=[e for e in selected if e['class']=='pairDone']
                    if len(done)==1 and any(p['identity'][3]==done[0]['pairId'] and p['identity'][4]==cardid and p['control']==(op['kind']=='control') for p in launch['pairs']):completed[name]=op
                else:
                    field='profile' if op['kind']=='profile' else 'key'
                    if req[0].get(field)!=op[field]:fatal=True;continue
                    done=[e for e in selected if e['class']=='operationDone'];target='profileRender' if op['kind']=='profile' else 'deferredRender'
                    if len(done)!=1:continue
                    d=done[0];ref=byid.get(d['referenceId']);render=byid.get(d['renderIdTarget']);end=callbacks.get(d['callbackIdTarget'])
                    desc=[e for e in selected if e['class']=='changedDescribe' and e['scope']=='callback' and e['accepted'] and e['acceptGeneration']==d['acceptGeneration']]
                    links=(ref and render and end and d['operationKind']==op['kind'] and d['targetClass']==target and ref['class']=='acceptedReference' and ref['valid'] and all(x['operationId']==name and x['cardId']==cardid and x['acceptGeneration']==d['acceptGeneration'] for x in (ref,render,end)) and d['acceptGeneration']>req[0]['acceptGeneration'] and render['scope']=='render' and render['class']==end['class']==target and render['callbackId']==end['callbackId'] and render['recordId'] in eligible_ids and end['recordId'] in eligible_ids and req[0]['recordId']<render['recordId']<end['recordId']<ref['recordId']<d['recordId'] and len(desc)==1 and req[0]['recordId']<desc[0]['recordId']<render['recordId'] and desc[0]['endTimestamp']<=render['startTimestamp'] and exact_reference(ref,op['expectedReference']))
                    release_ends=[x for x in selected if x['class']=='release' and x['scope']=='callback' and req[0]['recordId']<x['recordId']<min((x['recordId'] for x in desc),default=0)]
                    if op['kind']=='release' and len(release_ends)!=1:links=False
                    if not links:fatal=True
                    else:completed[name]=op|dict(callbackIdTarget=d['callbackIdTarget'],renderIdTarget=d['renderIdTarget'],generation=d['acceptGeneration'],describeIds=[x['recordId'] for x in desc],requestCallbackId=release_ends[0]['callbackId'] if release_ends else None)
            settlements=[e for e in records if e['class']=='cardSettled' and e['cardId']==cardid and ids(e['requestedOperationIds'],'requestedOperationIds')==names]
            settled[cardid]=False
            for e in settlements:
                drain=byid.get(e['drainRecordId'])
                if drain and drain['class']=='drain' and drain['cardId']==cardid and drain['recordId']<e['recordId'] and snapshot(drain,True) and ids(drain['requestedOperationIds'],'requestedOperationIds')==names and e['eligibleDrain'] and e['bufferEmpty'] and all(op['id'] in completed for op in planned):settled[cardid]=True
        missing=[op for op in original if op['id'] not in completed];credit={}
        if recovery:
            rid=recovery[1]['cardId'];allowed=set(recovery[1]['replacementFor']);available=[op for op in plans[rid] if op['id'] in completed]
            if recovery[2] and ready_ok[rid] and settled[rid] and not fatal:
                for op in missing:
                    for new in available:
                        if op['id'] in allowed and op['kind']==new['kind'] and all(op.get(k)==new.get(k) for k in ('key','profile')) and (op['kind'] in ('cold','launch','control') or exact_reference(op['expectedReference'],new['expectedReference'])):
                            credit[op['id']]=new['id'];available.remove(new);break
        still_missing=[op['id'] for op in missing if op['id'] not in credit]
        drains=[e for e in records if e['class']=='drain'];final=drains[-1] if drains else None
        final_reference=byid.get(final['referenceId']) if final else None
        final_reference_ok=bool(final_reference and final_reference['class']=='acceptedReference' and final_reference['valid'] and final_reference['recordId']<final['recordId'] and exact_reference(final_reference,card['reference']) and final['currentProfile']==card['reference']['acceptedProfile'])
        physical=bool(final and snapshot(final,True) and final_reference_ok and not any(e['scope']=='callback' and e['recordId']>final['recordId'] for e in records))
        startup=any(e['class']=='open' and e['scope']=='callback' and e['complete'] and e['recordId']<min((r['recordId'] for r in records if r['class']=='ready'),default=0) for e in records)
        runtime_complete=all(e['complete'] for e in records)
        recovery_complete=not recovery or recovery[2] and ready_ok[recovery[1]['cardId']] and settled[recovery[1]['cardId']]
        complete=gate and origin and recovery_complete and runtime_complete and startup and ready_ok[card['cardId']] and physical and not fatal and not still_missing and (settled[card['cardId']] if not missing else bool(credit))
        usable={name for name in completed if name in {op['id'] for op in original}}|set(credit.values())
        for e in eligible:
            if e['recordId'] not in eligible_ids:continue
            if e['class'] in CLASSES:
                op=completed.get(e['operationId'])
                admitted=e['operationId'] in usable
                if e['class'] in ('deferredRender','profileRender'):admitted=admitted and op['kind'] in ('release','restore','profile') and e['callbackId']==op.get('callbackIdTarget') and e['acceptGeneration']==op.get('generation')
                elif e['class']=='changedDescribe':admitted=admitted and op['kind'] in ('release','restore','profile') and e['recordId'] in op.get('describeIds',[])
                elif e['class']=='release':admitted=admitted and op['kind']=='release' and e['callbackId']==op.get('requestCallbackId')
                if not admitted:
                    exclusions.append(dict(event=e,reason='operation-not-certified'));continue
            samples.append(e)
        certificates.append(dict(activationNonce=nonce,collectionComplete=complete,physicalDrainComplete=physical,readyComplete=ready_ok[card['cardId']],operationGatesComplete=gate,originVerified=origin,missingOperationIds=still_missing,replacementCredit=credit,calibration=identity['environment']!='live',liveCollectionCertified=complete and identity['environment']=='live'))
    return dict(events=events,samples=samples,exclusions=exclusions,certificates=certificates,collectionComplete=all(c['collectionComplete'] for c in certificates),calibration=any(c['calibration'] for c in certificates),liveCollectionCertified=all(c['liveCollectionCertified'] for c in certificates))

def target_blocks(normalized):
    # Each block/variant has exactly one activation; never pool across blocks or runtimes.
    groups=defaultdict(lambda:defaultdict(dict)); held={}
    for event in normalized['samples']:
        if event['scope']!='callback' or event['class'] not in CLASSES: continue
        block,variant,nonce=event['block'],event['variant'],event['activationNonce']
        key=(block,variant)
        if key in held and held[key]!=nonce: raise ValueError('multiple activations would pool a block')
        held[key]=nonce
        groups[block][variant].setdefault(event['class'],[]).append(event['elapsedMs'])
    return dict(groups)

def pairs(normalized):
    grouped=defaultdict(list)
    callback_ends={(e['activationNonce'],e['callbackId']):e for e in normalized['events'] if e['scope']=='callback'}
    for event in normalized['events']:
        if event['pairId']: grouped[(event['activationNonce'],event['block'],event['variant'],event['pairId'],event['cardId'])].append(event)
    valid=[]; excluded=[]
    def before(left,right):
        return left['clockOrigin']==right['clockOrigin'] and left['recordId']<right['recordId'] and left['timestamp']<=right['timestamp']
    for identity,records in grouped.items():
        immediate=[e for e in records if e['class']=='pairImmediate' and e['scope']=='render']
        frame=[e for e in records if e['class']=='pairFrame' and e['scope']=='render']
        states=[e for e in records if e['class']=='pairFrameState']
        done=[e for e in records if e['class']=='pairDone']
        completion=[e for e in records if e['class']=='comparisonCompletionResult']
        native=[e for e in records if e['scope']=='nativeLaunch']
        helper=[e for e in records if e['scope']=='launchHelper']
        reason=None
        if any(e['interference'] or not e['complete'] or e['callbackId']==0 or not e['diagnosticsHidden'] or not e['targetEligible'] for e in records): reason='interference-or-incomplete'
        elif len(immediate)!=1 or len(frame)!=1 or len(states)!=1 or len(done)!=1: reason='missing-or-duplicate-pair-span'
        elif done[0].get('valid') is not True: reason='failed-or-malformed-pair'
        elif immediate[0]['callbackId']==frame[0]['callbackId']: reason='frame-shares-callback'
        elif states[0].get('completionState') not in ('pending','done') or states[0]['pending']!=(states[0].get('completionState')=='pending'): reason='invalid-completion-state'
        elif states[0]['completionState']!=done[0].get('completionState'): reason='inconsistent-completion-state'
        elif not immediate[0]['rendered'] or not frame[0]['rendered']: reason='pair-not-rendered'
        elif any(e['control']!=done[0]['control'] for e in records): reason='inconsistent-control'
        elif done[0]['control'] and (native or helper or completion or states[0]['pending']): reason='control-has-command'
        elif not done[0]['control'] and (len(native)!=1 or len(helper)!=1 or len(completion)!=1): reason='missing-launch-or-completion'
        elif not done[0]['control'] and (type(completion[0].get('exitCode')) is not int or completion[0]['exitCode']!=0 or any(completion[0].get(k) is not False for k in ('timedOut','stdoutTruncated','stderrTruncated'))): reason='failed-or-malformed-completion'
        if reason is None:
            for evidence in immediate+frame+native+helper+completion+states+done:
                endpoint=callback_ends.get((evidence['activationNonce'],evidence['callbackId']))
                if endpoint is None or not endpoint['complete'] or endpoint['interference'] or not endpoint['diagnosticsHidden'] or endpoint['clockOrigin']!=evidence['clockOrigin'] or endpoint['recordId']<=evidence['recordId'] or endpoint['timestamp']<evidence['timestamp']:
                    reason='missing-or-incomplete-callback-end'
                    break
                if evidence['scope'] in ('render','nativeLaunch','launchHelper') and not (endpoint['startTimestamp']<=evidence['startTimestamp']<=evidence['endTimestamp']<=endpoint['endTimestamp']):
                    reason='callback-endpoint-mismatch'
                    break
                if evidence['cardId']!=endpoint['cardId'] or evidence['operationId']!=endpoint['operationId']:
                    reason='callback-operation-mismatch'
                    break
        if reason is None:
            if states[0]['callbackId']!=frame[0]['callbackId'] or not before(immediate[0],frame[0]) or not before(frame[0],states[0]):
                reason='invalid-immediate-frame-order'
            elif frame[0]['pending']!=states[0]['pending']:
                reason='inconsistent-frame-pending-state'
            elif completion:
                early=before(completion[0],frame[0])
                late=before(states[0],completion[0])
                if (states[0]['completionState']=='done' and not early) or (states[0]['completionState']=='pending' and not late):
                    reason='completion-state-contradicts-order'
        if reason: excluded.append({'identity':identity,'reason':reason,'records':records}); continue
        first,second=immediate[0],frame[0]
        valid.append({'identity':identity,'control':done[0]['control'],'completionState':states[0]['completionState'],
            'immediateSampleId':first['recordId'],'frameSampleId':second['recordId'],
            'immediateMs':first['elapsedMs'],'frameMs':second['elapsedMs'],'differenceMs':first['elapsedMs']-second['elapsedMs']})
    aggregates=[]
    for activation in sorted({p['identity'][:3] for p in valid}):
        for control in (False,True):
            for state in ('pending','done'):
                selected=[p for p in valid if p['identity'][:3]==activation and p['control']==control and p['completionState']==state]
                if selected: aggregates.append({'identity':activation,'control':control,'completionState':state,'count':len(selected),
                    'primary':len(selected)>=5 and (control or sum(p['identity'][:3]==activation and p['control'] for p in valid)>=5),'medianDifferenceMs':median(p['differenceMs'] for p in selected),'maximumDifferenceMs':max(p['differenceMs'] for p in selected)})
    return {'pairs':valid,'exclusions':excluded,'groups':aggregates,'inconclusive':not any(g['primary'] and not g['control'] for g in aggregates)}

def intervals(normalized):
    out=[]
    for event in normalized['samples']:
        if event['scope']!='interval':continue
        start=number(event.get('startTimestamp'),'startTimestamp'); end=number(event.get('endTimestamp'),'endTimestamp')
        if end<start: raise ValueError('negative interval')
        out.append({'activationNonce':event['activationNonce'],'clockOrigin':event['clockOrigin'],'class':event['class'],'pairId':event['pairId'],'seconds':end-start,'startTimestamp':start,'endTimestamp':end})
    return out

def distribution(values):
    return dict(count=len(values),minimum=min(values),median=median(values),maximum=max(values),mad=median(abs(v-median(values)) for v in values)) if values else dict(count=0,minimum=None,median=None,maximum=None,mad=None)

def overlap_report(normalized,observations):
    if not isinstance(observations,list):raise ValueError('invalid observations')
    origins={e['clockOrigin'] for e in normalized['events']}
    if not all(c['originVerified'] for c in normalized['certificates']):raise ValueError('unverified clock origin')
    checked=[]
    for obs in observations:
        if not isinstance(obs,dict) or obs.get('kind') not in ('poll','checkpoint'):raise ValueError('invalid observation')
        if obs.get('clockOrigin') not in origins:raise ValueError('observation clock mismatch')
        start=number(obs.get('start'),'observation start');end=number(obs.get('end'),'observation end')
        if end<start:raise ValueError('reversed observation')
        integer(obs.get('bytes'),'observation bytes')
        checked.append(obs|{'durationSeconds':end-start})
    selected=[e for e in normalized['samples'] if e['scope']=='callback' and e['class'] in CLASSES]
    full=[];groups=defaultdict(list)
    for event in selected:
        start,end=endpoints(event)
        overlap=[i for i,o in enumerate(checked) if o['clockOrigin']==event['clockOrigin'] and max(start,o['start'])<min(end,o['end'])]
        row=event|{'overlapObservationIndices':overlap,'overlapCount':len(overlap)};full.append(row)
        groups[(event['block'],event['variant'],event['class'])].append(row)
    return dict(overlapCount=sum(e['overlapCount'] for e in full),samples=full,observations=checked,
        groups=[dict(block=k[0],variant=k[1],targetClass=k[2],samples=v,timingMs=distribution([e['elapsedMs'] for e in v]),overlapCount=sum(e['overlapCount'] for e in v)) for k,v in sorted(groups.items())],
        pollDurationsSeconds=distribution([o['durationSeconds'] for o in checked if o['kind']=='poll']),pollBytes=distribution([o['bytes'] for o in checked if o['kind']=='poll']),checkpointDurationsSeconds=distribution([o['durationSeconds'] for o in checked if o['kind']=='checkpoint']),exclusions=normalized['exclusions'])

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--stage',choices=('stage1','stage2'),required=True);p.add_argument('--pilot')
    p.add_argument('--log',action='append');p.add_argument('--offset',type=int,default=0);p.add_argument('--identity',action='append')
    p.add_argument('--cards');p.add_argument('--authorizations');p.add_argument('--evidence');p.add_argument('--observations');p.add_argument('--output')
    args=p.parse_args()
    def load(path):return json.loads(Path(path).read_text())
    if args.pilot:result={'estimateMinutes':estimate(args.stage,load(args.pilot))}
    else:
        if not args.log or not args.identity or not args.cards or not args.authorizations or not args.evidence:p.error('--log, --identity, --cards, --authorizations and --evidence required')
        normalized=normalize(read_rotated(args.log,args.offset),[load(path) for path in args.identity],load(args.cards),load(args.authorizations))
        evidence=load(args.evidence);launch_complete=boolean(evidence,'launchComplete')
        for key in ('integrityComplete','referenceComplete','identityComplete'):
            evidence[key]=boolean(evidence,key) and normalized['collectionComplete']
        if args.stage=='stage2':
            evidence['clockOriginVerified']=boolean(evidence,'clockOriginVerified') and normalized['liveCollectionCertified']
            environments={e['environment'] for e in normalized['events']}
            if environments!={evidence.get('environment')}:raise ValueError('evidence environment mismatch')
        blocks=target_blocks(normalized)
        verdict=decide(args.stage,[blocks.get(block,{}) for block in ('1','2')],evidence,launch_complete)
        result=normalized|dict(blocks=blocks,verdict=verdict,launch=pairs(normalized),intervals=intervals(normalized))
        if args.observations:result['overlap']=overlap_report(normalized,load(args.observations))
    text=json.dumps(result,indent=2)+'\n'
    if args.output:Path(args.output).write_text(text)
    else:print(text,end='')
if __name__=='__main__':main()
