import importlib.util,copy
from pathlib import Path
s=importlib.util.spec_from_file_location('analysis',Path(__file__).with_name('analyze.py'));a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
E=dict(integrityComplete=True,referenceComplete=True,identityComplete=True,correctnessComplete=True,errorComplete=True,correct=True,budgetErrors=0)
def blocks(b=14,c=10):return [{v:{k:[b if v=='baseline' and k=='coldRender' else c]*5 for k in a.CLASSES} for v in ('baseline','candidate')} for _ in range(2)]
def decision(stage,bs,e=E,launch=True):return a.decide(stage,bs,e,launch)
b=blocks();b[0]['candidate']['coldRender']=[14]*5
short=copy.deepcopy(b);short[1]['candidate']['coldRender'].pop()
assert decision('stage1',short)['comparison']=='inconclusive'
assert decision('stage1',b,dict(E,errorComplete=False,budgetErrors=None))['comparison']=='inconclusive'
assert decision('stage1',b)['comparison']=='revert'
for extra in ({'errorComplete':False,'budgetErrors':None},{'integrityComplete':False},{'budgetErrors':1},{'correct':False}):assert decision('stage1',b,E|extra)['comparison']=='inconclusive'
assert decision('stage1',blocks(14,13))['comparison']=='revert'
assert decision('stage1',blocks(14,12.999999))['comparison']=='pending_stage2'
for c in (15,16):
 r=decision('stage1',blocks(20,c));assert r['comparison']=='inconclusive' and r['coldGainPassed'] and not r['coldTargetPassed'] and not r['accepted'] and r['return_to_design']
r=decision('stage1',blocks(),launch=False);assert r['comparison']=='inconclusive' and not r['stage2Eligible']
r=decision('stage1',blocks());assert r['comparison']=='pending_stage2' and not r['accepted'] and r['stage2Eligible'] and not r['return_to_design']
b=blocks();b[0]['candidate']={'coldRender':[10]*5};b[0]['baseline']={'coldRender':[14]*5};b[1]=copy.deepcopy(b[0]);assert decision('stage1',b)['comparison']=='pending_stage2'
S=E|dict(stage1Certified=True,launchIdentityComplete=True,launchGroupsComplete=True,restorationComplete=True,clockOriginVerified=True,environment='live')
assert decision('stage2',blocks(),S)['accepted']
for n in (0,1):
 b=blocks();b[n]['candidate']['release']=[11.000001]*5;assert decision('stage2',b,S)['comparison']=='revert'
b=blocks(20,14);r=decision('stage2',b,S);assert r['comparison']=='keep' and not r['accepted'] and r['return_to_design']
for flag in ('stage1Certified','launchIdentityComplete','launchGroupsComplete','restorationComplete','clockOriginVerified'):
 assert not decision('stage2',blocks(),S|{flag:False})['accepted']
assert not decision('stage2',blocks(),S|{'environment':'fake-host'})['accepted']
for field in E:
 bad=dict(E);del bad[field]
 try:decision('stage1',blocks(),bad)
 except ValueError:pass
 else:raise AssertionError('missing evidence accepted '+field)
pilot=dict(occupancySeconds=120,analysisSeconds=30,collectionComplete=True,operationGatesComplete=True,activations=[dict(coldUnitSeconds=2,releaseRestoreUnitSeconds=6,profileCycleUnitSeconds=8) for _ in range(4)],launchUnitSeconds=[2,2],controlUnitSeconds=[1,1])
assert a.estimate('stage1',pilot)==5 and a.estimate('stage2',pilot)==8
for mutation in ('analysis','activations','negative','nan','null','gates'):
 p=copy.deepcopy(pilot)
 if mutation=='analysis':del p['analysisSeconds']
 if mutation=='activations':p['activations'].pop()
 if mutation=='negative':p['occupancySeconds']=-1
 if mutation=='nan':p['analysisSeconds']=float('nan')
 if mutation=='null':p['analysisSeconds']=None
 if mutation=='gates':p['operationGatesComplete']=False
 try:a.estimate('stage1',p)
 except ValueError:pass
 else:raise AssertionError('invalid estimate accepted '+mutation)
print('PASS ordered stage1 boundaries; stage2 isolated blocks/full classes/live gates; estimates 5/8 and missing/invalid gates')
for extra in ({'budgetErrors':1},{'correct':False}):assert decision('stage2',blocks(),S|extra)['comparison']=='revert','complete stage2 retains original failed correctness/error revert'
